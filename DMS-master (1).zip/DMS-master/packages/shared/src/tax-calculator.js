/**
 * Pure, side-effect-free tax calculation, header discount pro-rating,
 * and rounding engine for Indian GST secondary invoicing.
 */

export const INVOICE_ERROR_CODES = {
  HEADER_DISCOUNT_EXCEEDED: 'HEADER_DISCOUNT_EXCEEDED',
  HEADER_DISCOUNT_REASON_REQUIRED: 'HEADER_DISCOUNT_REASON_REQUIRED',
  NO_LINES: 'NO_LINES',
  INVALID_LINE: 'INVALID_LINE',
  SAME_DAY_CANCEL_ONLY: 'SAME_DAY_CANCEL_ONLY',
  RULE_NOT_FOUND: 'RULE_NOT_FOUND',
  PRICE_MISMATCH: 'PRICE_MISMATCH',
  EXCEEDS_RESERVED_QTY: 'EXCEEDS_RESERVED_QTY'
};

export const HEADER_DISCOUNT_REASON_THRESHOLD_PCT = 3.0;

/**
 * Calculates line-by-line taxable values, CGST/SGST/IGST splits,
 * pro-rated header discounts, and net invoice totals with rounding.
 *
 * @param {Object} params
 * @param {Array} params.lines - Array of { skuId, qty, unitPrice, gstRate, hsnCode, orderLineId, orderId }
 * @param {string} params.dealerStateCode - 2-digit GST state code of dealer
 * @param {string} params.retailerStateCode - 2-digit GST state code of retailer
 * @param {number} [params.headerDiscountPct=0] - Header discount percentage (0-100)
 * @param {number} [params.headerDiscountAmount=0] - Header discount flat amount
 * @param {number} [params.maxHeaderDiscountPct=0] - Maximum allowed header discount %
 * @param {string} [params.headerDiscountReason=''] - Reason for header discount
 *
 * @returns {Object} Invoice tax breakdown with lines, tax totals, and rounding
 */
export function calculateInvoiceTaxes({
  lines = [],
  dealerStateCode = '27',
  retailerStateCode = '27',
  headerDiscountPct = 0,
  headerDiscountAmount = 0,
  maxHeaderDiscountPct = 10,
  headerDiscountReason = ''
}) {
  if (!lines || lines.length === 0) {
    const err = new Error('Invoice must contain at least one line item.');
    err.code = INVOICE_ERROR_CODES.NO_LINES;
    throw err;
  }

  // 1. Calculate Gross Amounts
  let grossAmount = 0;
  const processedLines = lines.map((line, idx) => {
    const qty = parseInt(line.qty, 10);
    const unitPrice = Number(line.unitPrice);
    const gstRate = Number(line.gstRate || 0);

    if (isNaN(qty) || qty <= 0) {
      const err = new Error(`Line ${idx + 1}: Quantity must be a positive integer.`);
      err.code = INVOICE_ERROR_CODES.INVALID_LINE;
      throw err;
    }

    if (isNaN(unitPrice) || unitPrice < 0) {
      const err = new Error(`Line ${idx + 1}: Unit price must be a non-negative number.`);
      err.code = INVOICE_ERROR_CODES.INVALID_LINE;
      throw err;
    }

    const lineGross = Math.round(qty * unitPrice * 100) / 100;
    grossAmount += lineGross;

    return {
      ...line,
      qty,
      unitPrice,
      gstRate,
      grossAmount: lineGross
    };
  });

  grossAmount = Math.round(grossAmount * 100) / 100;

  // 2. Validate & Compute Header Discount
  let effectiveDiscountAmount = 0;
  let effectiveDiscountPct = 0;

  const numPct = Number(headerDiscountPct || 0);
  const numAmt = Number(headerDiscountAmount || 0);

  if (numPct > 0 && numAmt > 0) {
    const err = new Error('Specify header discount as either percentage or fixed amount, not both.');
    err.code = INVOICE_ERROR_CODES.HEADER_DISCOUNT_EXCEEDED;
    throw err;
  }

  if (numPct > 0) {
    if (numPct > Number(maxHeaderDiscountPct)) {
      const err = new Error(
        `Header discount of ${numPct}% exceeds dealer maximum allowed limit of ${maxHeaderDiscountPct}%.`
      );
      err.code = INVOICE_ERROR_CODES.HEADER_DISCOUNT_EXCEEDED;
      throw err;
    }

    if (numPct > HEADER_DISCOUNT_REASON_THRESHOLD_PCT && !String(headerDiscountReason || '').trim()) {
      const err = new Error(
        `A justification reason is mandatory for header discounts exceeding ${HEADER_DISCOUNT_REASON_THRESHOLD_PCT}%.`
      );
      err.code = INVOICE_ERROR_CODES.HEADER_DISCOUNT_REASON_REQUIRED;
      throw err;
    }

    effectiveDiscountPct = numPct;
    effectiveDiscountAmount = Math.round(((grossAmount * numPct) / 100) * 100) / 100;
  } else if (numAmt > 0) {
    const maxAllowedAmt = Math.round(((grossAmount * Number(maxHeaderDiscountPct)) / 100) * 100) / 100;
    if (numAmt > maxAllowedAmt + 0.01) {
      const equivPct = grossAmount > 0 ? ((numAmt / grossAmount) * 100).toFixed(1) : '0';
      const err = new Error(
        `Header discount amount of ₹${numAmt} (${equivPct}%) exceeds dealer maximum allowed limit of ${maxHeaderDiscountPct}%.`
      );
      err.code = INVOICE_ERROR_CODES.HEADER_DISCOUNT_EXCEEDED;
      throw err;
    }

    const calculatedPct = grossAmount > 0 ? (numAmt / grossAmount) * 100 : 0;
    if (calculatedPct > HEADER_DISCOUNT_REASON_THRESHOLD_PCT && !String(headerDiscountReason || '').trim()) {
      const err = new Error(
        `A justification reason is mandatory for header discounts exceeding ${HEADER_DISCOUNT_REASON_THRESHOLD_PCT}%.`
      );
      err.code = INVOICE_ERROR_CODES.HEADER_DISCOUNT_REASON_REQUIRED;
      throw err;
    }

    effectiveDiscountAmount = Math.min(grossAmount, numAmt);
    effectiveDiscountPct = Math.round(calculatedPct * 100) / 100;
  }

  // 3. Pro-rate Header Discount Across Lines BEFORE calculating tax
  let sumDiscountShare = 0;
  let maxGrossIdx = 0;
  let maxGrossVal = -1;

  processedLines.forEach((line, idx) => {
    if (line.grossAmount > maxGrossVal) {
      maxGrossVal = line.grossAmount;
      maxGrossIdx = idx;
    }
    const share = grossAmount > 0
      ? Math.round(((line.grossAmount / grossAmount) * effectiveDiscountAmount) * 100) / 100
      : 0;
    line.discountShare = share;
    sumDiscountShare += share;
  });

  // Reconcile rounding cent discrepancy onto the largest line
  const diffDiscount = Math.round((effectiveDiscountAmount - sumDiscountShare) * 100) / 100;
  if (diffDiscount !== 0 && processedLines[maxGrossIdx]) {
    processedLines[maxGrossIdx].discountShare = Math.round(
      (processedLines[maxGrossIdx].discountShare + diffDiscount) * 100
    ) / 100;
  }

  // 4. Calculate Taxable Value & Tax (Intra vs Inter State)
  const normDealerState = String(dealerStateCode || '').trim().padStart(2, '0');
  const normRetailerState = String(retailerStateCode || '').trim().padStart(2, '0');
  const isIntraState = normDealerState === normRetailerState;

  let taxableTotal = 0;
  let cgstTotal = 0;
  let sgstTotal = 0;
  let igstTotal = 0;

  const finalizedLines = processedLines.map((line) => {
    const taxableValue = Math.max(0, Math.round((line.grossAmount - line.discountShare) * 100) / 100);
    taxableTotal += taxableValue;

    let cgstAmount = 0;
    let sgstAmount = 0;
    let igstAmount = 0;

    if (isIntraState) {
      // Intra-state: CGST (half) + SGST (half)
      const halfRate = line.gstRate / 2;
      cgstAmount = Math.round(((taxableValue * halfRate) / 100) * 100) / 100;
      sgstAmount = Math.round(((taxableValue * halfRate) / 100) * 100) / 100;
      igstAmount = 0;
    } else {
      // Inter-state: IGST (full)
      cgstAmount = 0;
      sgstAmount = 0;
      igstAmount = Math.round(((taxableValue * line.gstRate) / 100) * 100) / 100;
    }

    cgstTotal += cgstAmount;
    sgstTotal += sgstAmount;
    igstTotal += igstAmount;

    const lineTax = Math.round((cgstAmount + sgstAmount + igstAmount) * 100) / 100;
    const lineTotal = Math.round((taxableValue + lineTax) * 100) / 100;

    return {
      ...line,
      taxableValue,
      cgstAmount,
      sgstAmount,
      igstAmount,
      lineTax,
      lineTotal
    };
  });

  taxableTotal = Math.round(taxableTotal * 100) / 100;
  cgstTotal = Math.round(cgstTotal * 100) / 100;
  sgstTotal = Math.round(sgstTotal * 100) / 100;
  igstTotal = Math.round(igstTotal * 100) / 100;
  const taxTotal = Math.round((cgstTotal + sgstTotal + igstTotal) * 100) / 100;

  // 5. Rounding to nearest integer rupee
  const unroundedTotal = Math.round((taxableTotal + taxTotal) * 100) / 100;
  const netTotal = Math.round(unroundedTotal); // Round to nearest rupee
  const rounding = Math.round((netTotal - unroundedTotal) * 100) / 100;

  return {
    lines: finalizedLines,
    isIntraState,
    dealerStateCode: normDealerState,
    retailerStateCode: normRetailerState,
    grossAmount,
    headerDiscountAmount: effectiveDiscountAmount,
    headerDiscountPct: effectiveDiscountPct,
    headerDiscountReason: headerDiscountReason || null,
    taxableTotal,
    cgstTotal,
    sgstTotal,
    igstTotal,
    taxTotal,
    unroundedTotal,
    rounding,
    netTotal
  };
}

