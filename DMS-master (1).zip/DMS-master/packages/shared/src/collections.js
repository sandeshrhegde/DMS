/**
 * Constants and pure business logic for Collections, Allocations, and Ageing Buckets.
 */

export const PAYMENT_MODES = {
  CASH: 'CASH',
  CHEQUE: 'CHEQUE',
  UPI: 'UPI',
  NEFT: 'NEFT'
};

export const COLLECTION_STATUSES = {
  RECORDED: 'RECORDED',
  BOUNCED: 'BOUNCED',
  CANCELLED: 'CANCELLED'
};

export const INVOICE_PAYMENT_STATUSES = {
  UNPAID: 'UNPAID',
  PARTIALLY_PAID: 'PARTIALLY_PAID',
  PAID: 'PAID'
};

export const AGEING_BUCKET_KEYS = {
  DAYS_0_30: '0_30',
  DAYS_31_60: '31_60',
  DAYS_61_90: '61_90',
  DAYS_90_PLUS: '90_plus'
};

export const DEFAULT_BOUNCE_CHARGE = 500.0;

/**
 * Pure function: Allocates payment amount across open invoices in FIFO order.
 *
 * @param {number} paymentAmount - Total payment amount received
 * @param {Array} openInvoices - List of open invoices sorted in FIFO order
 * @returns {{ allocations: Array, allocatedAmount: number, advanceAmount: number }}
 */
export function allocatePaymentFifo(paymentAmount, openInvoices = []) {
  const numericPayment = Number(paymentAmount) || 0;
  if (numericPayment < 0) {
    throw new Error('Payment amount must be greater than or equal to zero.');
  }

  // Sort FIFO: invoiceDate ASC, createdAt ASC
  const sorted = [...openInvoices].sort((a, b) => {
    const timeA = new Date(a.invoiceDate || a.createdAt).getTime();
    const timeB = new Date(b.invoiceDate || b.createdAt).getTime();
    return timeA - timeB;
  });

  let remaining = Math.round(numericPayment * 100) / 100;
  const allocations = [];

  for (const inv of sorted) {
    if (remaining <= 0) break;

    const net = Number(inv.netTotal) || 0;
    const paid = Number(inv.paidAmount) || 0;
    const openBalance = Math.max(0, Math.round((net - paid) * 100) / 100);

    if (openBalance <= 0) continue;

    const alloc = Math.min(remaining, openBalance);
    const roundedAlloc = Math.round(alloc * 100) / 100;

    allocations.push({
      invoiceId: inv.id,
      invoiceNo: inv.invoiceNo,
      amount: roundedAlloc,
      openBalanceBefore: openBalance,
      openBalanceAfter: Math.round((openBalance - roundedAlloc) * 100) / 100
    });

    remaining = Math.round((remaining - roundedAlloc) * 100) / 100;
  }

  const allocatedAmount = Math.round((numericPayment - remaining) * 100) / 100;
  const advanceAmount = Math.max(0, Math.round(remaining * 100) / 100);

  return {
    allocations,
    allocatedAmount,
    advanceAmount
  };
}

/**
 * Pure function: Validates manual allocations against open invoice balances and total payment amount.
 *
 * @param {number} paymentAmount - Total payment amount received
 * @param {Array} manualAllocations - [{ invoiceId, amount }]
 * @param {Array} openInvoices - Available open invoices
 * @returns {{ allocations: Array, allocatedAmount: number, advanceAmount: number }}
 */
export function validateManualAllocations(paymentAmount, manualAllocations = [], openInvoices = []) {
  const numericPayment = Number(paymentAmount) || 0;
  if (numericPayment <= 0) {
    throw new Error('Payment amount must be greater than zero.');
  }

  const invoiceMap = new Map(openInvoices.map((inv) => [inv.id, inv]));
  let totalAllocated = 0;
  const processedAllocations = [];

  for (const alloc of manualAllocations) {
    const inv = invoiceMap.get(alloc.invoiceId);
    if (!inv) {
      throw new Error(`Invoice ${alloc.invoiceId} is not an open eligible invoice for this retailer.`);
    }

    const allocAmt = Math.round(Number(alloc.amount) * 100) / 100;
    if (allocAmt <= 0) {
      continue; // Skip zero or negative allocations
    }

    const net = Number(inv.netTotal) || 0;
    const paid = Number(inv.paidAmount) || 0;
    const openBalance = Math.max(0, Math.round((net - paid) * 100) / 100);

    if (allocAmt > openBalance + 0.001) {
      throw new Error(
        `Over-allocation error: Allocation of ₹${allocAmt.toFixed(2)} exceeds invoice ${inv.invoiceNo} open balance of ₹${openBalance.toFixed(2)}.`
      );
    }

    totalAllocated = Math.round((totalAllocated + allocAmt) * 100) / 100;
    processedAllocations.push({
      invoiceId: inv.id,
      invoiceNo: inv.invoiceNo,
      amount: allocAmt,
      openBalanceBefore: openBalance,
      openBalanceAfter: Math.round((openBalance - allocAmt) * 100) / 100
    });
  }

  if (totalAllocated > numericPayment + 0.001) {
    throw new Error(
      `Over-allocation error: Total allocated ₹${totalAllocated.toFixed(2)} exceeds payment amount of ₹${numericPayment.toFixed(2)}.`
    );
  }

  const advanceAmount = Math.max(0, Math.round((numericPayment - totalAllocated) * 100) / 100);

  return {
    allocations: processedAllocations,
    allocatedAmount: totalAllocated,
    advanceAmount
  };
}

/**
 * Pure function: Calculates ageing buckets for a list of open invoices.
 *
 * @param {Array} openInvoices - List of invoices with invoiceDate and open balance
 * @param {number} creditDays - Configured credit days for the retailer (e.g. 30)
 * @param {Date|string} asOfDate - Date as of which ageing is computed (defaults to now)
 * @returns {Object} Ageing breakdown
 */
export function calculateAgeingBuckets(openInvoices = [], creditDays = 30, asOfDate = new Date()) {
  const asOf = new Date(asOfDate);
  const effectiveCreditDays = Number(creditDays) || 30;

  const buckets = {
    '0_30': 0.0,
    '31_60': 0.0,
    '61_90': 0.0,
    '90_plus': 0.0
  };

  let totalOutstanding = 0.0;
  let totalOverdue = 0.0;
  let oldestInvoiceDays = 0;
  const overdueInvoices = [];

  for (const inv of openInvoices) {
    const net = Number(inv.netTotal) || 0;
    const paid = Number(inv.paidAmount) || 0;
    const openBalance = Math.max(0, Math.round((net - paid) * 100) / 100);

    if (openBalance <= 0) continue;

    const invDate = new Date(inv.invoiceDate || inv.createdAt);
    const diffTime = asOf.getTime() - invDate.getTime();
    const ageDays = Math.max(0, Math.floor(diffTime / (1000 * 60 * 60 * 24)));

    if (ageDays > oldestInvoiceDays) {
      oldestInvoiceDays = ageDays;
    }

    if (ageDays <= 30) {
      buckets['0_30'] += openBalance;
    } else if (ageDays <= 60) {
      buckets['31_60'] += openBalance;
    } else if (ageDays <= 90) {
      buckets['61_90'] += openBalance;
    } else {
      buckets['90_plus'] += openBalance;
    }

    totalOutstanding += openBalance;

    if (ageDays > effectiveCreditDays) {
      totalOverdue += openBalance;
      overdueInvoices.push({
        id: inv.id,
        invoiceNo: inv.invoiceNo,
        invoiceDate: inv.invoiceDate,
        netTotal: net,
        paidAmount: paid,
        openBalance,
        ageDays,
        overdueDays: ageDays - effectiveCreditDays
      });
    }
  }

  return {
    buckets: {
      '0_30': Math.round(buckets['0_30'] * 100) / 100,
      '31_60': Math.round(buckets['31_60'] * 100) / 100,
      '61_90': Math.round(buckets['61_90'] * 100) / 100,
      '90_plus': Math.round(buckets['90_plus'] * 100) / 100
    },
    totalOutstanding: Math.round(totalOutstanding * 100) / 100,
    totalOverdue: Math.round(totalOverdue * 100) / 100,
    oldestInvoiceDays,
    effectiveCreditDays,
    hasOverdue: overdueInvoices.length > 0,
    overdueInvoices
  };
}

