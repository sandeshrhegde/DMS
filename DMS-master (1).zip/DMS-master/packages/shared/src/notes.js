/**
 * Pure, side-effect-free calculations, validations, and constants
 * for Retailer Returns (Sales Returns), Quarantine Inspection,
 * Financial Credit/Debit Notes, and Approval Workflows.
 */

export const NOTE_TYPES = {
  CREDIT_SALES_RETURN: 'CREDIT_SALES_RETURN',
  CREDIT_FINANCIAL: 'CREDIT_FINANCIAL',
  DEBIT: 'DEBIT'
};

export const NOTE_REASON_CODES = {
  RETURN_DAMAGED: 'RETURN_DAMAGED',
  RETURN_WRONG_ITEM: 'RETURN_WRONG_ITEM',
  RATE_DIFFERENCE: 'RATE_DIFFERENCE',
  SCHEME_BENEFIT: 'SCHEME_BENEFIT',
  CHEQUE_BOUNCE_CHARGE: 'CHEQUE_BOUNCE_CHARGE',
  OTHER: 'OTHER'
};

export const NOTE_STATUSES = {
  DRAFT: 'DRAFT',
  PENDING_APPROVAL: 'PENDING_APPROVAL',
  APPROVED: 'APPROVED',
  CANCELLED: 'CANCELLED'
};

export const NOTE_ERROR_CODES = {
  INVALID_NOTE_TYPE: 'INVALID_NOTE_TYPE',
  INVALID_REASON_CODE: 'INVALID_REASON_CODE',
  REF_INVOICE_REQUIRED: 'REF_INVOICE_REQUIRED',
  NO_RETURN_LINES: 'NO_RETURN_LINES',
  OVER_RETURN_EXCEEDED: 'OVER_RETURN_EXCEEDED',
  INVALID_RETURN_QTY: 'INVALID_RETURN_QTY',
  INVOICE_NOT_FOUND: 'INVOICE_NOT_FOUND',
  APPROVAL_REQUIRED: 'APPROVAL_REQUIRED',
  NOT_IN_DRAFT_OR_PENDING: 'NOT_IN_DRAFT_OR_PENDING',
  CANNOT_CANCEL_APPROVED: 'CANNOT_CANCEL_APPROVED',
  ALREADY_INSPECTED: 'ALREADY_INSPECTED',
  INSPECTION_QTY_MISMATCH: 'INSPECTION_QTY_MISMATCH',
  OVER_ALLOCATION: 'OVER_ALLOCATION'
};

export const DEFAULT_NOTE_APPROVAL_THRESHOLD = 50000.0;

/**
 * Calculates current financial year string in standard format (e.g., '26-27').
 */
export function getFinancialYear(date = new Date()) {
  const d = new Date(date);
  const month = d.getMonth(); // 0-indexed, 3 = April
  const fullYear = d.getFullYear();
  const startYear = month >= 3 ? fullYear : fullYear - 1;
  const startYearShort = String(startYear).slice(-2);
  const endYearShort = String(startYear + 1).slice(-2);
  return `${startYearShort}-${endYearShort}`;
}

/**
 * Pure calculation for Sales Return line reversals:
 * Ensures exact reversal of unit price, discount share pro-rata,
 * and CGST/SGST vs IGST tax split based on original invoice lines.
 *
 * @param {Object} params
 * @param {Array} params.requestedLines - Array of { invoiceLineId, skuId, qty, batch }
 * @param {Object} params.originalInvoice - The original invoice with its lines
 * @param {string} [params.dealerStateCode]
 * @param {string} [params.retailerStateCode]
 * @returns {Object} Calculated note summary with processed lines
 */
export function calculateSalesReturnReversal({
  requestedLines = [],
  originalInvoice,
  dealerStateCode,
  retailerStateCode
}) {
  if (!requestedLines || requestedLines.length === 0) {
    const err = new Error('Sales return must have at least one return line.');
    err.code = NOTE_ERROR_CODES.NO_RETURN_LINES;
    err.status = 400;
    throw err;
  }

  if (!originalInvoice || !originalInvoice.lines) {
    const err = new Error('Original invoice details with lines are required.');
    err.code = NOTE_ERROR_CODES.INVOICE_NOT_FOUND;
    err.status = 404;
    throw err;
  }

  const invoiceLinesById = new Map();
  originalInvoice.lines.forEach((line) => {
    invoiceLinesById.set(line.id, line);
  });

  const isIntraState = String(dealerStateCode || '').trim() === String(retailerStateCode || '').trim();

  let totalGross = 0;
  let totalDiscount = 0;
  let totalTaxable = 0;
  let totalCgst = 0;
  let totalSgst = 0;
  let totalIgst = 0;

  const processedLines = requestedLines.map((req, idx) => {
    const returnQty = parseInt(req.qty, 10);
    if (isNaN(returnQty) || returnQty <= 0) {
      const err = new Error(`Line ${idx + 1}: Return quantity must be a positive integer.`);
      err.code = NOTE_ERROR_CODES.INVALID_RETURN_QTY;
      err.status = 400;
      throw err;
    }

    const invLine = invoiceLinesById.get(req.invoiceLineId);
    if (!invLine) {
      const err = new Error(`Line ${idx + 1}: Invoice line with ID ${req.invoiceLineId} not found on referenced invoice.`);
      err.code = NOTE_ERROR_CODES.INVOICE_NOT_FOUND;
      err.status = 404;
      throw err;
    }

    // Cumulative check: returnQty must be <= already billed qty - previously returned
    const maxReturnable = req.maxReturnableQty !== undefined
      ? req.maxReturnableQty
      : invLine.qty;

    if (returnQty > maxReturnable) {
      const err = new Error(
        `Line ${idx + 1} (${invLine.sku?.name || invLine.skuId}): Return quantity ${returnQty} exceeds maximum returnable quantity of ${maxReturnable}.`
      );
      err.code = NOTE_ERROR_CODES.OVER_RETURN_EXCEEDED;
      err.status = 400;
      throw err;
    }

    const originalQty = invLine.qty || 1;
    const ratio = returnQty / originalQty;

    // Use SAME unit price
    const unitPrice = invLine.unitPrice;
    const lineGross = Math.round(returnQty * unitPrice * 100) / 100;
    
    // Pro-rata discount share
    const lineDiscount = Math.round((invLine.discountShare * ratio) * 100) / 100;
    const lineTaxable = Math.round((lineGross - lineDiscount) * 100) / 100;

    let lineCgst = 0;
    let lineSgst = 0;
    let lineIgst = 0;

    if (isIntraState) {
      lineCgst = Math.round((invLine.cgstAmount * ratio) * 100) / 100;
      lineSgst = Math.round((invLine.sgstAmount * ratio) * 100) / 100;
      lineIgst = 0;
    } else {
      lineCgst = 0;
      lineSgst = 0;
      lineIgst = Math.round((invLine.igstAmount * ratio) * 100) / 100;
    }

    const lineTax = Math.round((lineCgst + lineSgst + lineIgst) * 100) / 100;
    const lineTotal = Math.round((lineTaxable + lineTax) * 100) / 100;

    totalGross += lineGross;
    totalDiscount += lineDiscount;
    totalTaxable += lineTaxable;
    totalCgst += lineCgst;
    totalSgst += lineSgst;
    totalIgst += lineIgst;

    return {
      invoiceLineId: invLine.id,
      skuId: invLine.skuId,
      batch: req.batch || invLine.batch || 'DEFAULT',
      qty: returnQty,
      unitPrice,
      hsnCode: invLine.hsnCode,
      gstRate: invLine.gstRate,
      grossAmount: lineGross,
      discountShare: lineDiscount,
      taxableValue: lineTaxable,
      cgstAmount: lineCgst,
      sgstAmount: lineSgst,
      igstAmount: lineIgst,
      lineTax,
      lineTotal,
      quarantinedQty: returnQty,
      inspectedGoodQty: 0,
      inspectedDamagedQty: 0,
      isInspected: false
    };
  });

  const rawGross = Math.round(totalGross * 100) / 100;
  const rawDiscount = Math.round(totalDiscount * 100) / 100;
  const rawTaxable = Math.round(totalTaxable * 100) / 100;
  const rawCgst = Math.round(totalCgst * 100) / 100;
  const rawSgst = Math.round(totalSgst * 100) / 100;
  const rawIgst = Math.round(totalIgst * 100) / 100;
  const rawTaxTotal = Math.round((rawCgst + rawSgst + rawIgst) * 100) / 100;

  const rawNet = rawTaxable + rawTaxTotal;
  const totalAmount = Math.round(rawNet);
  const rounding = Math.round((totalAmount - rawNet) * 100) / 100;

  return {
    grossAmount: rawGross,
    discountAmount: rawDiscount,
    taxableAmount: rawTaxable,
    cgstAmount: rawCgst,
    sgstAmount: rawSgst,
    igstAmount: rawIgst,
    taxAmount: rawTaxTotal,
    rounding,
    totalAmount,
    lines: processedLines
  };
}

/**
 * Pure calculation for Financial Credit and Debit Notes.
 * Supports taxable or non-taxable financial adjustments.
 *
 * @param {Object} params
 * @param {string} params.type - CREDIT_FINANCIAL or DEBIT
 * @param {number} params.amount - Base or adjustment amount
 * @param {boolean} [params.isTaxable=false] - Whether GST applies
 * @param {number} [params.gstRate=18] - Applicable GST % if taxable
 * @param {string} [params.dealerStateCode]
 * @param {string} [params.retailerStateCode]
 * @returns {Object} Calculated note breakdown
 */
export function calculateFinancialNote({
  type,
  amount,
  isTaxable = false,
  gstRate = 18.0,
  dealerStateCode = '27',
  retailerStateCode = '27'
}) {
  const numAmount = Math.round(Number(amount || 0) * 100) / 100;
  if (isNaN(numAmount) || numAmount <= 0) {
    throw new Error('Financial note amount must be greater than zero.');
  }

  const isIntraState = String(dealerStateCode || '').trim() === String(retailerStateCode || '').trim();

  if (!isTaxable) {
    return {
      isTaxable: false,
      grossAmount: numAmount,
      discountAmount: 0.0,
      taxableAmount: 0.0,
      gstRate: 0.0,
      cgstAmount: 0.0,
      sgstAmount: 0.0,
      igstAmount: 0.0,
      taxAmount: 0.0,
      rounding: 0.0,
      totalAmount: numAmount
    };
  }

  const rate = Number(gstRate) || 0;
  const taxableAmount = numAmount;
  let cgst = 0;
  let sgst = 0;
  let igst = 0;

  if (isIntraState) {
    const halfRate = rate / 2;
    cgst = Math.round((taxableAmount * halfRate / 100) * 100) / 100;
    sgst = Math.round((taxableAmount * halfRate / 100) * 100) / 100;
  } else {
    igst = Math.round((taxableAmount * rate / 100) * 100) / 100;
  }

  const taxAmount = Math.round((cgst + sgst + igst) * 100) / 100;
  const rawNet = taxableAmount + taxAmount;
  const totalAmount = Math.round(rawNet);
  const rounding = Math.round((totalAmount - rawNet) * 100) / 100;

  return {
    isTaxable: true,
    grossAmount: taxableAmount,
    discountAmount: 0.0,
    taxableAmount,
    gstRate: rate,
    cgstAmount: cgst,
    sgstAmount: sgst,
    igstAmount: igst,
    taxAmount,
    rounding,
    totalAmount
  };
}

/**
 * Checks if a note requires DEALER_OWNER approval based on configurable threshold.
 *
 * @param {Object} params
 * @param {number} params.totalAmount
 * @param {number} [params.threshold=50000]
 * @returns {{ requiresApproval: boolean, initialStatus: string }}
 */
export function checkNoteApprovalRequirement({ totalAmount, threshold = DEFAULT_NOTE_APPROVAL_THRESHOLD }) {
  const numAmount = Number(totalAmount || 0);
  const numThreshold = Number(threshold || DEFAULT_NOTE_APPROVAL_THRESHOLD);

  if (numAmount > numThreshold) {
    return {
      requiresApproval: true,
      initialStatus: NOTE_STATUSES.PENDING_APPROVAL
    };
  }

  return {
    requiresApproval: false,
    initialStatus: NOTE_STATUSES.APPROVED
  };
}

/**
 * Pure validation for Quarantine Inspection split.
 *
 * @param {Object} params
 * @param {number} params.pendingQuarantineQty - Currently uninspected quarantined qty
 * @param {number} params.goodQty - Quantity confirmed as good (moves to AVAILABLE)
 * @param {number} params.damagedQty - Quantity confirmed as damaged (moves to DAMAGED)
 */
export function validateQuarantineInspection({ pendingQuarantineQty, goodQty, damagedQty }) {
  const good = parseInt(goodQty, 10);
  const damaged = parseInt(damagedQty, 10);
  const pending = parseInt(pendingQuarantineQty, 10);

  if (isNaN(good) || good < 0) {
    throw new Error('Good quantity must be a non-negative integer.');
  }

  if (isNaN(damaged) || damaged < 0) {
    throw new Error('Damaged quantity must be a non-negative integer.');
  }

  if (good + damaged !== pending) {
    const err = new Error(
      `Total inspected quantity (${good + damaged}) must exactly match pending quarantine quantity (${pending}).`
    );
    err.code = NOTE_ERROR_CODES.INSPECTION_QTY_MISMATCH;
    err.status = 400;
    throw err;
  }

  return { good, damaged };
}
