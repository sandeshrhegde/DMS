/**
 * Shared order constants, status workflows, and error codes for DMS secondary ordering.
 */

export const ORDER_CHANNEL = {
  PORTAL: 'PORTAL',
  MOBILE: 'MOBILE'
};

export const ORDER_STATUS = {
  DRAFT: 'DRAFT',
  SUBMITTED: 'SUBMITTED',
  PENDING_APPROVAL: 'PENDING_APPROVAL',
  APPROVED: 'APPROVED',
  PARTIALLY_BILLED: 'PARTIALLY_BILLED',
  FULLY_BILLED: 'FULLY_BILLED',
  CLOSED: 'CLOSED',
  CANCELLED: 'CANCELLED'
};

export const ORDER_STATUS_LABELS = {
  DRAFT: 'Draft',
  SUBMITTED: 'Submitted',
  PENDING_APPROVAL: 'Pending Approval (Credit Breach)',
  APPROVED: 'Approved (Stock Reserved)',
  PARTIALLY_BILLED: 'Partially Billed',
  FULLY_BILLED: 'Fully Billed',
  CLOSED: 'Closed',
  CANCELLED: 'Cancelled'
};

export const ORDER_STATUS_COLORS = {
  DRAFT: 'secondary',
  SUBMITTED: 'info',
  PENDING_APPROVAL: 'warning',
  APPROVED: 'success',
  PARTIALLY_BILLED: 'primary',
  FULLY_BILLED: 'success',
  CLOSED: 'secondary',
  CANCELLED: 'destructive'
};

export const ORDER_ERROR_CODES = {
  RETAILER_NOT_APPROVED: 'RETAILER_NOT_APPROVED',
  NON_BILLABLE_SKU: 'NON_BILLABLE_SKU',
  NO_PRICE: 'NO_PRICE',
  CREDIT_LIMIT_EXCEEDED: 'CREDIT_LIMIT_EXCEEDED',
  INSUFFICIENT_STOCK: 'INSUFFICIENT_STOCK',
  INVALID_STATUS_TRANSITION: 'INVALID_STATUS_TRANSITION',
  UNAUTHORIZED: 'UNAUTHORIZED'
};

export const ORDER_EXPIRY_DEFAULT_DAYS = 7;

