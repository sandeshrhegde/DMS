/**
 * Shared dashboard contracts, types and constants.
 * Used by both backend API and frontend React application.
 */

export const DASHBOARD_ROLES = Object.freeze({
  BRAND_ADMIN: 'BRAND_ADMIN',
  DEALER_OWNER: 'DEALER_OWNER',
  DEALER_OPERATOR: 'DEALER_OPERATOR',
  SALESMAN: 'SALESMAN'
});

export const DEALER_ROLES = Object.freeze([
  DASHBOARD_ROLES.DEALER_OWNER,
  DASHBOARD_ROLES.DEALER_OPERATOR,
  DASHBOARD_ROLES.SALESMAN
]);

export const BRAND_ROLES = Object.freeze([
  DASHBOARD_ROLES.BRAND_ADMIN
]);

export const BRAND_DASHBOARD_PATH = '/dashboard/brand';
export const DEALER_DASHBOARD_PATH = '/dashboard/dealer';

export function isBrandRole(role) {
  return role === DASHBOARD_ROLES.BRAND_ADMIN;
}

export function isDealerRole(role) {
  return DEALER_ROLES.includes(role);
}

/**
 * @typedef {Object} SalesTrendPoint
 * @property {string} date - ISO Date string YYYY-MM-DD
 * @property {number} value - Sales revenue amount in INR
 */

/**
 * @typedef {Object} KpiCard
 * @property {string} label - Display label for KPI
 * @property {number} value - Numeric value
 * @property {number} [change] - Optional percentage change
 * @property {'increase' | 'decrease' | 'neutral'} [changeType] - Trend direction
 * @property {'currency' | 'number' | 'percent'} [format] - Formatter hint
 * @property {string} [helperText] - Subtitle or context
 */

/**
 * @typedef {Object} DealerSalesPoint
 * @property {string} dealerId - Unique dealer identifier
 * @property {string} name - Dealer business name
 * @property {number} value - Total sales value in INR
 */

/**
 * @typedef {Object} LowStockDealerPoint
 * @property {string} dealerId - Unique dealer identifier
 * @property {string} dealer - Dealer business name
 * @property {number} skus - Number of SKUs currently under minimum threshold
 * @property {'Critical' | 'Low' | 'Warning'} status - Severity status
 * @property {number} [minimumThreshold] - Configured threshold
 */

/**
 * @typedef {Object} StockAlertPoint
 * @property {string} sku - Product SKU code
 * @property {string} name - Product display name
 * @property {number} available - Current units in stock
 * @property {number} minimum - Configured minimum stock requirement
 * @property {string} [category] - Part or vehicle category
 */

/**
 * @typedef {Object} BrandDashboardResponse
 * @property {{
 *   today: number,
 *   monthToDate: number,
 *   vsLastMonthPercent: number
 * }} totalSecondarySales - Total secondary sales metrics
 * @property {number} activeDealersCount - Number of active dealers in system
 * @property {DealerSalesPoint[]} salesByDealer - Top 10 dealers ranked by sales
 * @property {LowStockDealerPoint[]} dealersWithLowStock - Dealers requiring inventory replenishment
 * @property {number} pendingRetailerApprovalsCount - Pending approvals queue count
 * @property {SalesTrendPoint[]} salesTrend - Last 30 days daily sales trend
 * @property {KpiCard[]} kpis - High-level executive KPI cards
 */

/**
 * @typedef {Object} DealerDashboardResponse
 * @property {number} todaysSales - Today's sales value in INR
 * @property {number} monthToDateSales - Month to date sales value in INR
 * @property {number} collectionsToday - Collections completed today
 * @property {number} pendingOrdersCount - Number of orders currently pending
 * @property {number} outstandingTotal - Total outstanding accounts receivable
 * @property {StockAlertPoint[]} stockAlerts - Top 10 SKUs falling below minimum stock level
 * @property {SalesTrendPoint[]} salesTrend - Last 30 days daily sales trend
 * @property {KpiCard[]} kpis - Operational KPI cards
 */
