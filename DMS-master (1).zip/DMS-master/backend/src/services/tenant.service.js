import { prisma } from '../config/database.js';
export async function withTenant(user, work) {
  if (!prisma) throw new Error('PostgreSQL is required for tenant-scoped database operations.');
  return prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT set_config('app.is_brand', ${user.role === 'BRAND_ADMIN' ? 'true' : 'false'}, true)`;
    await tx.$executeRaw`SELECT set_config('app.dealer_id', ${user.dealerId ?? ''}, true)`;
    return work(tx);
  });
}
