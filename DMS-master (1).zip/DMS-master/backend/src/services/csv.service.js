import fs from 'fs';
import path from 'path';

/**
 * Robust RFC 4180 compliant CSV parser.
 * Supports quoted fields, embedded commas, escaped quotes (""), and varied line endings.
 */
export function parseCsv(text) {
  if (!text || typeof text !== 'string') {
    return { headers: [], records: [] };
  }

  const lines = [];
  let row = [];
  let inQuotes = false;
  let cell = '';

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (inQuotes) {
      if (char === '"') {
        if (nextChar === '"') {
          cell += '"';
          i++; // skip escaped quote
        } else {
          inQuotes = false;
        }
      } else {
        cell += char;
      }
    } else {
      if (char === '"') {
        inQuotes = true;
      } else if (char === ',') {
        row.push(cell.trim());
        cell = '';
      } else if (char === '\r') {
        // Skip carriage return
      } else if (char === '\n') {
        row.push(cell.trim());
        if (row.some((val) => val !== '')) {
          lines.push(row);
        }
        row = [];
        cell = '';
      } else {
        cell += char;
      }
    }
  }

  if (cell !== '' || row.length > 0) {
    row.push(cell.trim());
    if (row.some((val) => val !== '')) {
      lines.push(row);
    }
  }

  if (lines.length === 0) {
    return { headers: [], records: [] };
  }

  const headers = lines[0].map((h) => h.replace(/^["']|["']$/g, '').trim());
  const records = [];

  for (let r = 1; r < lines.length; r++) {
    const currentLine = lines[r];
    const obj = {};
    for (let c = 0; c < headers.length; c++) {
      const val = currentLine[c] !== undefined ? currentLine[c] : '';
      obj[headers[c]] = val.replace(/^["']|["']$/g, '').trim();
    }
    records.push({
      rowNumber: r + 1,
      data: obj
    });
  }

  return { headers, records };
}

/**
 * Loads a sample CSV file from the backend/samples directory.
 */
export function getSampleCsv(fileName) {
  const filePath = path.resolve('samples', fileName);
  if (fs.existsSync(filePath)) {
    return fs.readFileSync(filePath, 'utf8');
  }
  return '';
}

