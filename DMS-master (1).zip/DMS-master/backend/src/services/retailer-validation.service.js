import { prisma } from '../config/database.js';

const CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

/**
 * Calculates the expected 15th checksum character for a 14-character GSTIN prefix.
 */
export function calculateGstinChecksumChar(prefix14) {
  if (!prefix14 || prefix14.length < 14) return null;
  const upper = prefix14.toUpperCase().slice(0, 14);

  let sum = 0;
  for (let i = 0; i < 14; i++) {
    const val = CHARS.indexOf(upper[i]);
    if (val === -1) return null;
    const multiplier = i % 2 === 0 ? 1 : 2;
    let product = val * multiplier;
    product = Math.floor(product / 36) + (product % 36);
    sum += product;
  }

  const remainder = sum % 36;
  const checkCode = (36 - remainder) % 36;
  return CHARS[checkCode];
}

/**
 * Validates GSTIN structure regex and Luhn mod-36 checksum.
 */
export function validateGstin(gstin) {
  if (!gstin || typeof gstin !== 'string') {
    return { valid: false, error: 'GSTIN is required.' };
  }

  const cleaned = gstin.trim().toUpperCase();
  const formatRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

  if (!formatRegex.test(cleaned)) {
    return {
      valid: false,
      error: 'Invalid GSTIN format. Expected 15 characters: 2-digit state code + 10-char PAN + entity code + Z + check digit (e.g. 27AABCT3518Q1ZW).'
    };
  }

  const expectedChar = calculateGstinChecksumChar(cleaned.slice(0, 14));
  if (cleaned[14] !== expectedChar) {
    return {
      valid: false,
      error: `GSTIN checksum mismatch. The 15th character is '${cleaned[14]}', but expected '${expectedChar}' per Luhn mod-36 validation.`
    };
  }

  return { valid: true, gstin: cleaned };
}

/**
 * Validates PAN format (5 letters, 4 digits, 1 letter).
 */
export function validatePan(pan) {
  if (!pan || typeof pan !== 'string') {
    return { valid: false, error: 'PAN is required.' };
  }
  const cleaned = pan.trim().toUpperCase();
  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
  if (!panRegex.test(cleaned)) {
    return {
      valid: false,
      error: 'Invalid PAN format. Must be 5 uppercase letters, 4 digits, and 1 uppercase letter (e.g. AABCT3518Q).'
    };
  }
  return { valid: true, pan: cleaned };
}

/**
 * Validates Indian 10-digit mobile number format.
 */
export function validateMobile(mobile) {
  if (!mobile || typeof mobile !== 'string') {
    return { valid: false, error: 'Mobile number is required.' };
  }
  const cleaned = mobile.trim().replace(/[\s-]/g, '');
  const mobileRegex = /^(?:\+91|91|0)?[6-9]\d{9}$/;

  if (!mobileRegex.test(cleaned)) {
    return {
      valid: false,
      error: 'Invalid mobile number. Must be a valid 10-digit Indian mobile number starting with 6, 7, 8, or 9.'
    };
  }

  // Extract last 10 digits
  const normalized = cleaned.slice(-10);
  return { valid: true, mobile: normalized };
}

/**
 * Checks for duplicates on GSTIN, PAN, and mobile across ALL dealers.
 * Returns matching retailers as warnings for the approver/creator.
 */
export async function checkRetailerDuplicates({ gstin, pan, mobile, excludeRetailerId = null }) {
  const warnings = [];
  const normalizedMobile = mobile ? mobile.trim().slice(-10) : null;
  const normalizedGstin = gstin ? gstin.trim().toUpperCase() : null;
  const normalizedPan = pan ? pan.trim().toUpperCase() : null;

  const conditions = [];

  if (normalizedGstin) {
    conditions.push({ gstin: normalizedGstin });
  }

  if (normalizedPan) {
    conditions.push({ pan: normalizedPan });
  }

  if (normalizedMobile) {
    conditions.push({ mobile: normalizedMobile });
  }

  if (conditions.length === 0) return warnings;

  const where = {
    OR: conditions
  };

  if (excludeRetailerId) {
    where.id = { not: excludeRetailerId };
  }

  const matches = await prisma.retailer.findMany({
    where,
    include: {
      dealer: { select: { id: true, code: true, name: true } },
      geoNode: { select: { id: true, name: true, type: true } }
    }
  });

  for (const match of matches) {
    if (normalizedGstin && match.gstin?.toUpperCase() === normalizedGstin) {
      warnings.push({
        field: 'gstin',
        value: normalizedGstin,
        matchedRetailerId: match.id,
        matchedRetailerName: match.legalName,
        matchedTradeName: match.tradeName,
        dealerId: match.dealer.id,
        dealerCode: match.dealer.code,
        dealerName: match.dealer.name,
        status: match.status,
        message: `GSTIN ${normalizedGstin} is already registered under retailer '${match.legalName}' (Dealer: ${match.dealer.name}) with status ${match.status}.`
      });
    }

    if (normalizedPan && match.pan?.toUpperCase() === normalizedPan) {
      warnings.push({
        field: 'pan',
        value: normalizedPan,
        matchedRetailerId: match.id,
        matchedRetailerName: match.legalName,
        matchedTradeName: match.tradeName,
        dealerId: match.dealer.id,
        dealerCode: match.dealer.code,
        dealerName: match.dealer.name,
        status: match.status,
        message: `PAN ${normalizedPan} is already registered under retailer '${match.legalName}' (Dealer: ${match.dealer.name}) with status ${match.status}.`
      });
    }

    if (normalizedMobile && match.mobile?.slice(-10) === normalizedMobile) {
      warnings.push({
        field: 'mobile',
        value: normalizedMobile,
        matchedRetailerId: match.id,
        matchedRetailerName: match.legalName,
        matchedTradeName: match.tradeName,
        dealerId: match.dealer.id,
        dealerCode: match.dealer.code,
        dealerName: match.dealer.name,
        status: match.status,
        message: `Mobile ${normalizedMobile} is already associated with retailer '${match.legalName}' (Dealer: ${match.dealer.name}) with status ${match.status}.`
      });
    }
  }

  return warnings;
}

