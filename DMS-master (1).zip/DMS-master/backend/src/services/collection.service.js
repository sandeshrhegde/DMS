import { prisma } from '../config/database.js';
import {
  allocatePaymentFifo,
  validateManualAllocations,
  calculateAgeingBuckets,
  PAYMENT_MODES,
  COLLECTION_STATUSES,
  INVOICE_PAYMENT_STATUSES,
  DEFAULT_BOUNCE_CHARGE,
  NOTE_TYPES,
  NOTE_REASON_CODES,
  NOTE_STATUSES
} from '@dms/shared';
import { getInvoiceFinancialYear } from './invoice.service.js';
import { getNextDebitNoteSequence } from './note.service.js';

/**
 * Number to words converter for Indian Rupee receipts.
 */
export function numberToWordsRupees(amount) {
  const num = Math.round(Number(amount) || 0);
  if (num === 0) return 'Zero Rupees Only';

  const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
    'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'FifFifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertTwoDigits(n) {
    if (n < 20) return units[n];
    return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
  }

  function convertThreeDigits(n) {
    const h = Math.floor(n / 100);
    const rest = n % 100;
    if (h === 0) return convertTwoDigits(rest);
    return units[h] + ' Hundred' + (rest !== 0 ? ' and ' + convertTwoDigits(rest) : '');
  }

  let crore = Math.floor(num / 10000000);
  let remainder = num % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder = remainder % 100000;
  let thousand = Math.floor(remainder / 1000);
  let hundred = remainder % 1000;

  let words = '';
  if (crore > 0) words += convertTwoDigits(crore) + ' Crore ';
  if (lakh > 0) words += convertTwoDigits(lakh) + ' Lakh ';
  if (thousand > 0) words += convertTwoDigits(thousand) + ' Thousand ';
  if (hundred > 0) words += convertThreeDigits(hundred) + ' ';

  return words.trim() + ' Rupees Only';
}

/**
 * Obtains the next gapless sequence number for collections in a given financial year.
 */
export async function getNextCollectionSequence(dealerId, financialYear, tx = prisma) {
  const sequenceRecord = await tx.$queryRaw`
    INSERT INTO dealer_collection_sequences (id, dealer_id, financial_year, current_value, updated_at)
    VALUES (gen_random_uuid(), ${dealerId}::uuid, ${financialYear}, 1, NOW())
    ON CONFLICT (dealer_id, financial_year)
    DO UPDATE SET current_value = dealer_collection_sequences.current_value + 1, updated_at = NOW()
    RETURNING current_value;
  `;

  if (sequenceRecord && sequenceRecord.length > 0) {
    return sequenceRecord[0].current_value;
  }

  const count = await tx.collection.count({
    where: { dealerId }
  });
  return count + 1;
}

/**
 * Fetches open (unpaid or partially paid) invoices for a retailer.
 */
export async function getRetailerOpenInvoices(dealerId, retailerId, tx = prisma) {
  const invoices = await tx.invoice.findMany({
    where: {
      dealerId,
      retailerId,
      status: 'ISSUED'
    },
    orderBy: [
      { invoiceDate: 'asc' },
      { createdAt: 'asc' }
    ]
  });

  return invoices
    .map((inv) => {
      const net = inv.netTotal || 0;
      const paid = inv.paidAmount || 0;
      const openBalance = Math.max(0, Math.round((net - paid) * 100) / 100);
      return {
        ...inv,
        openBalance
      };
    })
    .filter((inv) => inv.openBalance > 0.009);
}

/**
 * Records a new payment collection and executes FIFO or manual allocation in an atomic transaction.
 */
export async function createCollectionTransaction({
  dealerId,
  retailerId,
  date = new Date(),
  mode,
  amount,
  reference,
  chequeDate,
  bankName,
  collectedBy,
  notes,
  allocations = [],
  autoAllocateFifo = true,
  user
}) {
  const numAmount = Math.round(Number(amount) * 100) / 100;
  if (!numAmount || numAmount <= 0) {
    const err = new Error('Collection amount must be greater than zero.');
    err.status = 400;
    throw err;
  }

  if (!Object.values(PAYMENT_MODES).includes(mode)) {
    const err = new Error(`Invalid payment mode '${mode}'. Allowed modes: ${Object.values(PAYMENT_MODES).join(', ')}.`);
    err.status = 400;
    throw err;
  }

  return await prisma.$transaction(async (tx) => {
    // 1. Verify dealer and retailer
    const [dealer, retailer] = await Promise.all([
      tx.dealer.findUnique({ where: { id: dealerId } }),
      tx.retailer.findUnique({ where: { id: retailerId } })
    ]);

    if (!dealer) {
      const err = new Error('Dealer not found.');
      err.status = 404;
      throw err;
    }
    if (!retailer) {
      const err = new Error('Retailer not found.');
      err.status = 404;
      throw err;
    }

    // 2. Fetch current open invoices for the retailer
    const openInvoices = await getRetailerOpenInvoices(dealerId, retailerId, tx);

    // 3. Compute allocations
    let allocationResult;
    if (autoAllocateFifo || !allocations || allocations.length === 0) {
      allocationResult = allocatePaymentFifo(numAmount, openInvoices);
    } else {
      allocationResult = validateManualAllocations(numAmount, allocations, openInvoices);
    }

    const { allocations: resolvedAllocations, allocatedAmount, advanceAmount } = allocationResult;

    // 4. Generate collection number
    const collectionDate = date ? new Date(date) : new Date();
    const fy = getInvoiceFinancialYear(collectionDate);
    const seq = await getNextCollectionSequence(dealerId, fy, tx);
    const collectionNo = `RCP/${dealer.code}/${fy}/${String(seq).padStart(6, '0')}`;

    // 5. Create Collection record
    const collection = await tx.collection.create({
      data: {
        dealerId,
        retailerId,
        collectionNo,
        date: collectionDate,
        mode,
        amount: numAmount,
        allocatedAmount,
        advanceAmount,
        reference: reference || null,
        chequeDate: chequeDate ? new Date(chequeDate) : null,
        bankName: bankName || null,
        collectedBy: collectedBy || user?.name || user?.email || 'Dealership Cashier',
        status: COLLECTION_STATUSES.RECORDED,
        notes: notes || null,
        createdByEmail: user?.email || null,
        allocations: {
          create: resolvedAllocations.map((a) => ({
            invoiceId: a.invoiceId,
            amount: a.amount
          }))
        }
      },
      include: {
        allocations: {
          include: { invoice: true }
        },
        retailer: true,
        dealer: true
      }
    });

    // 6. Update paid amounts and payment status on allocated invoices
    for (const alloc of resolvedAllocations) {
      const currentInvoice = await tx.invoice.findUnique({
        where: { id: alloc.invoiceId }
      });

      if (currentInvoice) {
        const newPaidAmount = Math.round((currentInvoice.paidAmount + alloc.amount) * 100) / 100;
        const newStatus =
          newPaidAmount >= (currentInvoice.netTotal - 0.01)
            ? INVOICE_PAYMENT_STATUSES.PAID
            : INVOICE_PAYMENT_STATUSES.PARTIALLY_PAID;

        await tx.invoice.update({
          where: { id: currentInvoice.id },
          data: {
            paidAmount: newPaidAmount,
            paymentStatus: newStatus
          }
        });
      }
    }

    // 7. Post Credit LedgerEntry on Retailer Ledger
    const invoiceSummary = resolvedAllocations.length > 0
      ? `Allocated against ${resolvedAllocations.map((a) => a.invoiceNo || a.invoiceId).join(', ')}`
      : 'On-Account Advance Payment';

    await tx.ledgerEntry.create({
      data: {
        dealerId,
        retailerId,
        type: 'COLLECTION',
        debit: 0.0,
        credit: numAmount,
        refType: 'COLLECTION',
        refId: collection.id,
        date: collectionDate,
        notes: `Payment receipt ${collectionNo} via ${mode}${reference ? ` (${reference})` : ''} - ${invoiceSummary}${advanceAmount > 0 ? ` (Advance: ₹${advanceAmount.toFixed(2)})` : ''}`,
        createdByEmail: user?.email || null
      }
    });

    return collection;
  });
}

/**
 * Handles Cheque Bounce:
 * 1. Reverses invoice allocations (reopening invoices).
 * 2. Creates a debit LedgerEntry to reverse the collection credit.
 * 3. Applies a configurable bounce penalty charge as a separate debit LedgerEntry.
 * 4. Marks Collection status as BOUNCED.
 */
export async function bounceChequeTransaction({
  collectionId,
  dealerId,
  reason = 'Cheque returned unpaid / insufficient funds',
  bounceCharge,
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const collection = await tx.collection.findUnique({
      where: { id: collectionId },
      include: {
        allocations: { include: { invoice: true } },
        dealer: true,
        retailer: true
      }
    });

    if (!collection) {
      const err = new Error('Collection receipt not found.');
      err.status = 404;
      throw err;
    }

    if (dealerId && collection.dealerId !== dealerId) {
      const err = new Error('Access denied: Collection belongs to another dealership.');
      err.status = 403;
      throw err;
    }

    if (collection.mode !== PAYMENT_MODES.CHEQUE) {
      const err = new Error(`Bounce action is only applicable to CHEQUE payments (current mode: ${collection.mode}).`);
      err.status = 400;
      throw err;
    }

    if (collection.status === COLLECTION_STATUSES.BOUNCED) {
      const err = new Error('This cheque collection is already marked as BOUNCED.');
      err.status = 400;
      throw err;
    }

    if (collection.status === COLLECTION_STATUSES.CANCELLED) {
      const err = new Error('Cannot bounce a CANCELLED collection receipt.');
      err.status = 400;
      throw err;
    }

    // Determine configurable bounce charge (from dealer setting or argument or default)
    const effectiveBounceCharge = bounceCharge !== undefined
      ? Math.max(0, Number(bounceCharge) || 0)
      : (collection.dealer?.bounceCharge ?? DEFAULT_BOUNCE_CHARGE);

    const now = new Date();

    // 1. Reopen allocated invoices and mark allocations reversed
    for (const alloc of collection.allocations) {
      if (alloc.isReversed) continue;

      const invoice = alloc.invoice;
      if (invoice) {
        const revertedPaidAmount = Math.max(0, Math.round((invoice.paidAmount - alloc.amount) * 100) / 100);
        const revertedStatus =
          revertedPaidAmount <= 0.01
            ? INVOICE_PAYMENT_STATUSES.UNPAID
            : INVOICE_PAYMENT_STATUSES.PARTIALLY_PAID;

        await tx.invoice.update({
          where: { id: invoice.id },
          data: {
            paidAmount: revertedPaidAmount,
            paymentStatus: revertedStatus
          }
        });
      }

      await tx.collectionAllocation.update({
        where: { id: alloc.id },
        data: { isReversed: true }
      });
    }

    // 2. Mark collection as BOUNCED
    const updatedCollection = await tx.collection.update({
      where: { id: collection.id },
      data: {
        status: COLLECTION_STATUSES.BOUNCED,
        bounceReason: reason,
        bounceCharge: effectiveBounceCharge,
        bouncedAt: now,
        bouncedByEmail: user?.email || null
      },
      include: {
        allocations: { include: { invoice: true } },
        dealer: true,
        retailer: true
      }
    });

    // 3. Post debit LedgerEntry reversing the original collection amount
    await tx.ledgerEntry.create({
      data: {
        dealerId: collection.dealerId,
        retailerId: collection.retailerId,
        type: 'DEBIT_NOTE',
        debit: collection.amount,
        credit: 0.0,
        refType: 'CHEQUE_BOUNCE',
        refId: collection.id,
        date: now,
        notes: `Cheque bounce reversal for receipt ${collection.collectionNo} (Ref: ${collection.reference || 'N/A'}) - Reason: ${reason}`,
        createdByEmail: user?.email || null
      }
    });

    // 4. Generate formal gapless DEBIT Note for bounce penalty charge if > 0
    if (effectiveBounceCharge > 0) {
      const financialYear = getInvoiceFinancialYear(now);
      const debitSeq = await getNextDebitNoteSequence(collection.dealerId, financialYear, tx);
      const debitNoteNo = `DN-${financialYear}-${String(debitSeq).padStart(4, '0')}`;

      const debitNote = await tx.note.create({
        data: {
          dealerId: collection.dealerId,
          retailerId: collection.retailerId,
          noteNo: debitNoteNo,
          financialYear,
          type: NOTE_TYPES.DEBIT,
          reasonCode: NOTE_REASON_CODES.CHEQUE_BOUNCE_CHARGE,
          status: NOTE_STATUSES.APPROVED,
          grossAmount: effectiveBounceCharge,
          taxableAmount: 0.0,
          isTaxable: false,
          totalAmount: effectiveBounceCharge,
          balanceAmount: 0.0,
          allocatedAmount: 0.0,
          requiresApproval: false,
          approvedByEmail: user?.email || 'SYSTEM',
          approvedAt: now,
          createdByEmail: user?.email || null,
          notes: `Cheque bounce penalty charge on receipt ${collection.collectionNo} (${reason})`
        }
      });

      await tx.ledgerEntry.create({
        data: {
          dealerId: collection.dealerId,
          retailerId: collection.retailerId,
          type: 'DEBIT_NOTE',
          debit: effectiveBounceCharge,
          credit: 0.0,
          refType: 'DEBIT_NOTE',
          refId: debitNote.id,
          date: now,
          notes: `Debit Note ${debitNote.noteNo} for Cheque bounce penalty charge on receipt ${collection.collectionNo} - Reason: ${reason}`,
          createdByEmail: user?.email || null
        }
      });
    }

    return updatedCollection;
  });
}

/**
 * Fetches structured retailer ledger statement, including running balance,
 * invoice-wise open items, ageing buckets, and credit limit utilisation.
 */
export async function getRetailerLedgerData({
  dealerId,
  retailerId,
  asOfDate = new Date(),
  tx = prisma
}) {
  const [dealer, retailer] = await Promise.all([
    tx.dealer.findUnique({ where: { id: dealerId } }),
    tx.retailer.findUnique({ where: { id: retailerId }, include: { geoNode: true } })
  ]);

  if (!retailer) {
    const err = new Error('Retailer not found.');
    err.status = 404;
    throw err;
  }

  // 1. Fetch all ledger entries
  const entries = await tx.ledgerEntry.findMany({
    where: {
      dealerId,
      retailerId
    },
    orderBy: [
      { date: 'asc' },
      { createdAt: 'asc' }
    ]
  });

  // Calculate running balance
  let runningBalance = 0;
  let totalDebit = 0;
  let totalCredit = 0;

  const entriesWithRunningBalance = entries.map((e) => {
    totalDebit = Math.round((totalDebit + (e.debit || 0)) * 100) / 100;
    totalCredit = Math.round((totalCredit + (e.credit || 0)) * 100) / 100;
    runningBalance = Math.round((runningBalance + (e.debit || 0) - (e.credit || 0)) * 100) / 100;
    return {
      ...e,
      runningBalance
    };
  });

  const currentOutstanding = runningBalance;
  const onAccountAdvance = currentOutstanding < 0 ? Math.abs(currentOutstanding) : 0;
  const netDue = currentOutstanding > 0 ? currentOutstanding : 0;

  // 2. Fetch open items (invoices)
  const openInvoices = await getRetailerOpenInvoices(dealerId, retailerId, tx);

  // 3. Compute Ageing Buckets
  const effectiveCreditDays = retailer.creditDays || dealer?.creditDays || 30;
  const ageing = calculateAgeingBuckets(openInvoices, effectiveCreditDays, asOfDate);

  // 4. Credit limit utilisation
  const creditLimit = retailer.creditLimit || 0;
  const creditUtilisationPct = creditLimit > 0
    ? Math.min(999, Math.round((netDue / creditLimit) * 10000) / 100)
    : 0;
  const availableCredit = Math.max(0, Math.round((creditLimit - netDue) * 100) / 100);

  return {
    retailer: {
      id: retailer.id,
      legalName: retailer.legalName,
      tradeName: retailer.tradeName,
      gstin: retailer.gstin,
      pan: retailer.pan,
      mobile: retailer.mobile,
      billingAddress: retailer.billingAddress,
      creditLimit: retailer.creditLimit,
      creditDays: effectiveCreditDays,
      status: retailer.status
    },
    dealer: {
      id: dealer?.id,
      code: dealer?.code,
      name: dealer?.name,
      gstin: dealer?.gstin,
      address: dealer?.address,
      stateCode: dealer?.stateCode
    },
    summary: {
      totalDebit,
      totalCredit,
      currentOutstanding,
      netDue,
      onAccountAdvance,
      creditLimit,
      availableCredit,
      creditUtilisationPct,
      creditDays: effectiveCreditDays,
      openInvoicesCount: openInvoices.length,
      hasOverdue: ageing.hasOverdue,
      totalOverdue: ageing.totalOverdue
    },
    ageing,
    openInvoices,
    entries: entriesWithRunningBalance
  };
}

/**
 * Returns outstanding list and credit utilisation across all retailers for a dealer.
 */
export async function getDealerOutstandingOverview({
  dealerId,
  search,
  filter,
  tx = prisma
}) {
  const dealer = await tx.dealer.findUnique({ where: { id: dealerId } });
  if (!dealer) {
    const err = new Error('Dealer not found.');
    err.status = 404;
    throw err;
  }

  // Fetch all active/approved retailers
  const retailers = await tx.retailer.findMany({
    where: { dealerId },
    orderBy: { legalName: 'asc' }
  });

  // For each retailer, compute ledger balance and open invoices ageing
  const results = [];
  let dealerTotalOutstanding = 0;
  let dealerTotalOverdue = 0;
  let dealerTotalCreditLimit = 0;
  let overdueCount = 0;

  for (const ret of retailers) {
    const ledgerSum = await tx.ledgerEntry.aggregate({
      where: { dealerId, retailerId: ret.id },
      _sum: { debit: true, credit: true }
    });

    const debit = ledgerSum._sum.debit || 0;
    const credit = ledgerSum._sum.credit || 0;
    const balance = Math.round((debit - credit) * 100) / 100;

    const openInvoices = await getRetailerOpenInvoices(dealerId, ret.id, tx);
    const effectiveCreditDays = ret.creditDays || dealer.creditDays || 30;
    const ageing = calculateAgeingBuckets(openInvoices, effectiveCreditDays);

    const netDue = balance > 0 ? balance : 0;
    const advance = balance < 0 ? Math.abs(balance) : 0;
    const limit = ret.creditLimit || 0;
    const utilisationPct = limit > 0
      ? Math.min(999, Math.round((netDue / limit) * 10000) / 100)
      : 0;

    if (ageing.hasOverdue) overdueCount++;
    dealerTotalOutstanding += netDue;
    dealerTotalOverdue += ageing.totalOverdue;
    dealerTotalCreditLimit += limit;

    results.push({
      id: ret.id,
      legalName: ret.legalName,
      tradeName: ret.tradeName,
      gstin: ret.gstin,
      mobile: ret.mobile,
      retailerClass: ret.retailerClass,
      channelType: ret.channelType,
      creditLimit: limit,
      creditDays: effectiveCreditDays,
      status: ret.status,
      currentOutstanding: balance,
      netDue,
      onAccountAdvance: advance,
      overdueAmount: ageing.totalOverdue,
      hasOverdue: ageing.hasOverdue,
      oldestInvoiceDays: ageing.oldestInvoiceDays,
      creditUtilisationPct: utilisationPct,
      openInvoicesCount: openInvoices.length,
      buckets: ageing.buckets
    });
  }

  // Filter and search
  let filtered = results;
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter((r) =>
      r.legalName.toLowerCase().includes(q) ||
      (r.tradeName && r.tradeName.toLowerCase().includes(q)) ||
      (r.gstin && r.gstin.toLowerCase().includes(q)) ||
      r.mobile.includes(q)
    );
  }

  if (filter === 'overdue') {
    filtered = filtered.filter((r) => r.hasOverdue);
  } else if (filter === 'exceeded') {
    filtered = filtered.filter((r) => r.creditUtilisationPct > 100);
  } else if (filter === 'has_balance') {
    filtered = filtered.filter((r) => r.netDue > 0);
  }

  // Sort descending by outstanding balance by default
  filtered.sort((a, b) => b.netDue - a.netDue);

  return {
    summary: {
      totalRetailers: retailers.length,
      overdueRetailers: overdueCount,
      totalOutstanding: Math.round(dealerTotalOutstanding * 100) / 100,
      totalOverdue: Math.round(dealerTotalOverdue * 100) / 100,
      totalCreditLimit: Math.round(dealerTotalCreditLimit * 100) / 100,
      dealerOverallUtilisationPct: dealerTotalCreditLimit > 0
        ? Math.round((dealerTotalOutstanding / dealerTotalCreditLimit) * 10000) / 100
        : 0
    },
    retailers: filtered
  };
}

/**
 * Returns complete receipt data formatted for A4 printing or PDF generation.
 */
export async function getCollectionReceiptData(collectionId, dealerId, tx = prisma) {
  const collection = await tx.collection.findUnique({
    where: { id: collectionId },
    include: {
      dealer: true,
      retailer: true,
      allocations: {
        include: {
          invoice: true
        }
      }
    }
  });

  if (!collection) {
    const err = new Error('Collection receipt not found.');
    err.status = 404;
    throw err;
  }

  if (dealerId && collection.dealerId !== dealerId) {
    const err = new Error('Access denied: Collection belongs to another dealership.');
    err.status = 403;
    throw err;
  }

  const amountInWords = numberToWordsRupees(collection.amount);

  return {
    receiptNo: collection.collectionNo,
    date: collection.date,
    mode: collection.mode,
    amount: collection.amount,
    allocatedAmount: collection.allocatedAmount,
    advanceAmount: collection.advanceAmount,
    reference: collection.reference,
    chequeDate: collection.chequeDate,
    bankName: collection.bankName,
    collectedBy: collection.collectedBy,
    status: collection.status,
    bounceReason: collection.bounceReason,
    bounceCharge: collection.bounceCharge,
    bouncedAt: collection.bouncedAt,
    notes: collection.notes,
    amountInWords,
    dealer: {
      name: collection.dealer.name,
      code: collection.dealer.code,
      gstin: collection.dealer.gstin,
      address: collection.dealer.address,
      contactPhone: collection.dealer.contactPhone,
      contactEmail: collection.dealer.contactEmail
    },
    retailer: {
      legalName: collection.retailer.legalName,
      tradeName: collection.retailer.tradeName,
      gstin: collection.retailer.gstin,
      mobile: collection.retailer.mobile,
      billingAddress: collection.retailer.billingAddress
    },
    allocations: collection.allocations.map((a) => ({
      id: a.id,
      amount: a.amount,
      isReversed: a.isReversed,
      invoiceNo: a.invoice?.invoiceNo,
      invoiceDate: a.invoice?.invoiceDate,
      invoiceTotal: a.invoice?.netTotal
    }))
  };
}

