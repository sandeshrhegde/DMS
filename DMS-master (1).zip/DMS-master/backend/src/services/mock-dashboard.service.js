const mockTenants = [
  { id: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1', name: 'Demo Motors', slug: 'demo-motors' },
  { id: 'd7f38fd6-87e8-4c08-8efe-04409f6975d8', name: 'City Auto Group', slug: 'city-auto-group' }
];

export function getMockDashboard(tenantId) {
  const tenant = mockTenants.find((item) => item.id === tenantId) ?? mockTenants[0];

  return {
    mode: 'mock',
    tenant,
    metrics: { vehiclesInStock: 24, openLeads: 11, salesThisMonth: 8, serviceAppointmentsToday: 6 },
    recentVehicles: [
      { id: 'vehicle-001', stockNumber: 'DM-1001', make: 'Toyota', model: 'Camry', year: 2023, status: 'available' },
      { id: 'vehicle-002', stockNumber: 'DM-1002', make: 'Honda', model: 'City', year: 2024, status: 'reserved' }
    ]
  };
}

export function getMockTenants() {
  return mockTenants;
}
