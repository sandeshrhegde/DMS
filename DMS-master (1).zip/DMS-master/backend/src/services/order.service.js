import { prisma } from '../config/database.js';
import { resolvePrice } from './pricing-resolver.service.js';
import { computeIsBillable } from '../masters/sku.routes.js';
import {
  ORDER_STATUS,
  ORDER_CHANNEL,
  ORDER_ERROR_CODES,
  ORDER_EXPIRY_DEFAULT_DAYS
} from '@dms/shared';

/**
 * Calculates financial year code (e.g. 2627 for Apr 2026 - Mar 2027)
 */
export function getFinancialYear(date = new Date()) {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1 to 12
  if (month >= 4) {
    const start = String(year).slice(-2);
    const end = String(year + 1).slice(-2);
    return `${start}${end}`;
  } else {
    const start = String(year - 1).slice(-2);
    const end = String(year).slice(-2);
    return `${start}${end}`;
  }
}

/**
 * Generates sequential order number per dealer per financial year.
 * Format: ORD-{FY}-{0001}
 */
export async function generateOrderNumber(dealerId, date = new Date(), tx = prisma) {
  const fy = getFinancialYear(date);
  const prefix = `ORD-${fy}-`;

  const lastOrder = await tx.order.findFirst({
    where: {
      dealerId,
      financialYear: fy,
      orderNo: { startsWith: prefix }
    },
    orderBy: { orderNo: 'desc' },
    select: { orderNo: true }
  });

  let nextSeq = 1;
  if (lastOrder && lastOrder.orderNo) {
    const parts = lastOrder.orderNo.split('-');
    if (parts.length >= 3) {
      const parsed = parseInt(parts[2], 10);
      if (!isNaN(parsed)) {
        nextSeq = parsed + 1;
      }
    }
  }

  return {
    orderNo: `${prefix}${String(nextSeq).padStart(4, '0')}`,
    financialYear: fy
  };
}

/**
 * Returns current outstanding balance for a retailer from the real append-only ledger.
 */
export async function getRetailerOutstanding(retailerId, tx = prisma) {
  const sum = await tx.ledgerEntry.aggregate({
    where: { retailerId },
    _sum: { debit: true, credit: true }
  });
  const totalDebit = sum._sum.debit || 0.0;
  const totalCredit = sum._sum.credit || 0.0;
  return Math.round((totalDebit - totalCredit) * 100) / 100;
}

/**
 * Checks if the retailer has any unpaid or partially paid invoice that is overdue
 * beyond their configured creditDays.
 */
export async function checkRetailerOverdueInvoices(retailerId, tx = prisma) {
  const retailer = await tx.retailer.findUnique({
    where: { id: retailerId },
    include: { dealer: true }
  });
  if (!retailer) {
    return { hasOverdue: false, effectiveCreditDays: 30, overdueInvoices: [], totalOverdueAmount: 0 };
  }

  const effectiveCreditDays = retailer.creditDays || retailer.dealer?.creditDays || 30;
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - effectiveCreditDays);

  const openInvoices = await tx.invoice.findMany({
    where: {
      retailerId,
      status: 'ISSUED',
      invoiceDate: { lt: cutoffDate }
    },
    orderBy: { invoiceDate: 'asc' }
  });

  const overdueInvoices = openInvoices
    .filter((inv) => (inv.netTotal - (inv.paidAmount || 0)) > 0.009)
    .map((inv) => ({
      id: inv.id,
      invoiceNo: inv.invoiceNo,
      invoiceDate: inv.invoiceDate,
      netTotal: inv.netTotal,
      paidAmount: inv.paidAmount || 0,
      openBalance: Math.round((inv.netTotal - (inv.paidAmount || 0)) * 100) / 100
    }));

  const totalOverdueAmount = overdueInvoices.reduce((acc, inv) => acc + inv.openBalance, 0);

  return {
    hasOverdue: overdueInvoices.length > 0,
    effectiveCreditDays,
    overdueInvoices,
    totalOverdueAmount: Math.round(totalOverdueAmount * 100) / 100
  };
}

/**
 * Gets configured order expiry in days from system settings or default (7 days).
 */
export async function getOrderExpiryDays(tx = prisma) {
  try {
    const setting = await tx.systemSetting.findUnique({
      where: { key: 'orderExpiryDays' }
    });
    if (setting && setting.value) {
      const parsed = parseInt(setting.value, 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  } catch {
    // fallback if table is not yet seeded
  }
  return ORDER_EXPIRY_DEFAULT_DAYS;
}

/**
 * Fetches available stock on hand aggregated by SKU for a warehouse/dealer.
 */
export async function getAvailableStockBySku({ dealerId, warehouseId, skuIds = [] }, tx = prisma) {
  const where = {
    dealerId,
    stockState: 'AVAILABLE'
  };
  if (warehouseId) where.warehouseId = warehouseId;
  if (skuIds.length > 0) where.skuId = { in: skuIds };

  const stockRecords = await tx.stockOnHand.findMany({
    where,
    select: {
      skuId: true,
      batch: true,
      qty: true,
      warehouseId: true
    }
  });

  const totals = {};
  for (const rec of stockRecords) {
    totals[rec.skuId] = (totals[rec.skuId] || 0) + (rec.qty || 0);
  }

  return { totals, records: stockRecords };
}

/**
 * Validates and prices lines for an order using resolvePrice and billable check.
 *
 * Rules:
 * 1. Retailer must exist, belong to dealer, and be APPROVED.
 * 2. Every SKU must exist and be isBillable (has MRP and HSN code >= 6 digits, isActive).
 * 3. Every SKU must have a matching valid APPROVED price rule via resolvePrice.
 */
export async function calculateOrderPricing({
  dealerId,
  retailerId,
  warehouseId,
  items = [],
  date = new Date(),
  tx = prisma
}) {
  if (!dealerId) {
    const err = new Error('dealerId is required.');
    err.status = 400;
    throw err;
  }
  if (!retailerId) {
    const err = new Error('retailerId is required.');
    err.status = 400;
    throw err;
  }

  // 1. Fetch and validate retailer
  const retailer = await tx.retailer.findUnique({
    where: { id: retailerId },
    include: { geoNode: true }
  });

  if (!retailer) {
    const err = new Error('Retailer not found.');
    err.status = 404;
    throw err;
  }

  if (retailer.dealerId !== dealerId) {
    const err = new Error('Retailer does not belong to this dealership.');
    err.status = 403;
    throw err;
  }

  if (retailer.status !== 'APPROVED') {
    const err = new Error(
      `Retailer "${retailer.legalName}" is in ${retailer.status} status. Only APPROVED retailers can place secondary orders.`
    );
    err.status = 400;
    err.code = ORDER_ERROR_CODES.RETAILER_NOT_APPROVED;
    throw err;
  }

  if (!items || items.length === 0) {
    return {
      retailer,
      lines: [],
      totalAmount: 0,
      creditLimit: retailer.creditLimit,
      currentOutstanding: 0,
      creditLimitExceeded: false
    };
  }

  // 2. Load approved price rules for pricing resolver
  const approvedRules = await tx.priceRule.findMany({
    where: {
      priceList: {
        status: 'APPROVED'
      }
    },
    include: {
      priceList: true
    }
  });

  // 3. Fetch SKUs
  const skuIds = items.map((i) => i.skuId).filter(Boolean);
  const skus = await tx.sku.findMany({
    where: { id: { in: skuIds } }
  });
  const skuMap = new Map();
  skus.forEach((s) => skuMap.set(s.id, s));

  // 4. Fetch available stock for reference
  const { totals: availableStockBySku } = await getAvailableStockBySku(
    { dealerId, warehouseId, skuIds },
    tx
  );

  const processedLines = [];
  let totalAmount = 0;

  for (let idx = 0; idx < items.length; idx++) {
    const item = items[idx];
    const sku = skuMap.get(item.skuId);

    if (!sku) {
      const err = new Error(`Item ${idx + 1}: SKU ${item.skuId} not found.`);
      err.status = 400;
      throw err;
    }

    const orderedQty = parseInt(item.orderedQty ?? item.qty, 10);
    if (isNaN(orderedQty) || orderedQty <= 0) {
      const err = new Error(`Item ${idx + 1} (${sku.code}): orderedQty must be a positive integer.`);
      err.status = 400;
      throw err;
    }

    // Billable check: must have valid HSN and MRP
    const isBillable = computeIsBillable(sku);
    if (!isBillable) {
      const err = new Error(
        `SKU "${sku.code} - ${sku.name}" is not billable. Every orderable SKU must have an active status, valid MRP, and HSN master code.`
      );
      err.status = 400;
      err.code = ORDER_ERROR_CODES.NON_BILLABLE_SKU;
      err.skuId = sku.id;
      throw err;
    }

    // Price resolution using resolvePrice engine
    const priceResolution = resolvePrice(
      {
        retailer,
        sku,
        date,
        landingPrice: sku.landingPrice,
        rules: approvedRules
      },
      approvedRules
    );

    if (priceResolution.error || priceResolution.price == null) {
      const err = new Error(
        `No approved price rule found for SKU "${sku.code} - ${sku.name}" and retailer "${retailer.legalName}". Secondary orders require an approved price rule.`
      );
      err.status = 400;
      err.code = ORDER_ERROR_CODES.NO_PRICE;
      err.skuId = sku.id;
      throw err;
    }

    const unitPrice = Number(priceResolution.price);
    const lineValue = Math.round(unitPrice * orderedQty * 100) / 100;
    totalAmount += lineValue;

    processedLines.push({
      skuId: sku.id,
      skuCode: sku.code,
      skuName: sku.name,
      mrp: sku.mrp,
      orderedQty,
      unitPrice,
      ruleId: priceResolution.ruleId || null,
      pricingLevel: priceResolution.level || null,
      lineValue,
      availableStock: availableStockBySku[sku.id] || 0
    });
  }

  totalAmount = Math.round(totalAmount * 100) / 100;
  const currentOutstanding = await getRetailerOutstanding(retailer.id, tx);
  const overdueCheck = await checkRetailerOverdueInvoices(retailer.id, tx);
  const totalExposure = currentOutstanding + totalAmount;
  const creditLimitExceeded = totalExposure > retailer.creditLimit;

  return {
    retailer,
    lines: processedLines,
    totalAmount,
    creditLimit: retailer.creditLimit,
    currentOutstanding,
    creditLimitExceeded,
    hasOverdueInvoices: overdueCheck.hasOverdue,
    overdueAmount: overdueCheck.totalOverdueAmount,
    overdueInvoices: overdueCheck.overdueInvoices
  };
}

/**
 * Resolves or validates the warehouse for the order.
 */
export async function resolveOrderWarehouse(dealerId, requestedWarehouseId, tx = prisma) {
  if (requestedWarehouseId) {
    const wh = await tx.warehouse.findUnique({
      where: { id: requestedWarehouseId }
    });
    if (wh && wh.dealerId === dealerId && wh.isActive) {
      return wh;
    }
  }

  // Fall back to default warehouse
  let wh = await tx.warehouse.findFirst({
    where: { dealerId, isDefault: true, isActive: true }
  });

  if (!wh) {
    wh = await tx.warehouse.findFirst({
      where: { dealerId, isActive: true }
    });
  }

  return wh;
}

/**
 * Executes atomic stock reservation for an approved order.
 *
 * Rules:
 * - Writes RESERVED ledger rows moving qty from AVAILABLE to RESERVED.
 * - If available stock is short, reserves whatever is available and marks remainder as shortfallQty.
 * - Updates StockLedger (append-only) and updates StockOnHand summary.
 */
export async function executeStockReservation({ orderId, user, tx }) {
  const order = await tx.order.findUnique({
    where: { id: orderId },
    include: {
      lines: { include: { sku: true } },
      dealer: true
    }
  });

  if (!order) {
    const err = new Error('Order not found for reservation.');
    err.status = 404;
    throw err;
  }

  const warehouse = await resolveOrderWarehouse(order.dealerId, order.warehouseId, tx);
  if (!warehouse) {
    const err = new Error('No active warehouse found to reserve stock for dealership.');
    err.status = 400;
    throw err;
  }

  // Ensure order has warehouseId set
  if (order.warehouseId !== warehouse.id) {
    await tx.order.update({
      where: { id: order.id },
      data: { warehouseId: warehouse.id }
    });
  }

  for (const line of order.lines) {
    // Get all available stock on hand batches for this SKU and warehouse
    const availableBatches = await tx.stockOnHand.findMany({
      where: {
        dealerId: order.dealerId,
        warehouseId: warehouse.id,
        skuId: line.skuId,
        stockState: 'AVAILABLE',
        qty: { gt: 0 }
      },
      orderBy: { batch: 'asc' }
    });

    const totalAvailable = availableBatches.reduce((acc, b) => acc + b.qty, 0);
    const qtyToReserve = Math.min(line.orderedQty, totalAvailable);
    const shortfallQty = Math.max(0, line.orderedQty - qtyToReserve);

    let remainingToReserve = qtyToReserve;

    for (const batchRecord of availableBatches) {
      if (remainingToReserve <= 0) break;
      const allocateQty = Math.min(remainingToReserve, batchRecord.qty);

      if (allocateQty > 0) {
        // 1. Append StockLedger row for deducting AVAILABLE
        await tx.stockLedger.create({
          data: {
            dealerId: order.dealerId,
            warehouseId: warehouse.id,
            skuId: line.skuId,
            batch: batchRecord.batch,
            stockState: 'AVAILABLE',
            qtyChange: -allocateQty,
            sourceType: 'ORDER_RESERVE',
            sourceId: order.orderNo,
            createdByEmail: user?.email || null
          }
        });

        // 2. Append StockLedger row for adding RESERVED
        await tx.stockLedger.create({
          data: {
            dealerId: order.dealerId,
            warehouseId: warehouse.id,
            skuId: line.skuId,
            batch: batchRecord.batch,
            stockState: 'RESERVED',
            qtyChange: allocateQty,
            sourceType: 'ORDER_RESERVE',
            sourceId: order.orderNo,
            createdByEmail: user?.email || null
          }
        });

        // 3. Decrement AVAILABLE in StockOnHand
        await tx.stockOnHand.update({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId: order.dealerId,
              warehouseId: warehouse.id,
              skuId: line.skuId,
              batch: batchRecord.batch,
              stockState: 'AVAILABLE'
            }
          },
          data: {
            qty: { decrement: allocateQty }
          }
        });

        // 4. Increment RESERVED in StockOnHand
        await tx.stockOnHand.upsert({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId: order.dealerId,
              warehouseId: warehouse.id,
              skuId: line.skuId,
              batch: batchRecord.batch,
              stockState: 'RESERVED'
            }
          },
          update: {
            qty: { increment: allocateQty }
          },
          create: {
            dealerId: order.dealerId,
            warehouseId: warehouse.id,
            skuId: line.skuId,
            batch: batchRecord.batch,
            stockState: 'RESERVED',
            qty: allocateQty
          }
        });

        remainingToReserve -= allocateQty;
      }
    }

    // Update order line with reserved and shortfall quantities
    await tx.orderLine.update({
      where: { id: line.id },
      data: {
        reservedQty: qtyToReserve,
        shortfallQty
      }
    });
  }

  return { warehouseId: warehouse.id };
}

/**
 * Releases reserved stock when an order is cancelled or expired.
 *
 * Rules:
 * - Reverses RESERVED ledger rows back to AVAILABLE.
 * - Writes ORDER_CANCEL_RELEASE entries to StockLedger.
 * - Updates StockOnHand summary.
 */
export async function executeStockRelease({ orderId, user, tx }) {
  const order = await tx.order.findUnique({
    where: { id: orderId },
    include: { lines: true }
  });

  if (!order) {
    const err = new Error('Order not found for release.');
    err.status = 404;
    throw err;
  }

  const warehouseId = order.warehouseId;
  if (!warehouseId) return;

  // Find all reservation ledger rows for this order
  const reserveLedgers = await tx.stockLedger.findMany({
    where: {
      dealerId: order.dealerId,
      warehouseId,
      sourceType: 'ORDER_RESERVE',
      sourceId: order.orderNo,
      stockState: 'RESERVED',
      qtyChange: { gt: 0 }
    }
  });

  for (const entry of reserveLedgers) {
    const releaseQty = entry.qtyChange;
    if (releaseQty <= 0) continue;

    // 1. Append StockLedger row for deducting RESERVED
    await tx.stockLedger.create({
      data: {
        dealerId: order.dealerId,
        warehouseId,
        skuId: entry.skuId,
        batch: entry.batch,
        stockState: 'RESERVED',
        qtyChange: -releaseQty,
        sourceType: 'ORDER_CANCEL_RELEASE',
        sourceId: order.orderNo,
        createdByEmail: user?.email || null
      }
    });

    // 2. Append StockLedger row for adding back to AVAILABLE
    await tx.stockLedger.create({
      data: {
        dealerId: order.dealerId,
        warehouseId,
        skuId: entry.skuId,
        batch: entry.batch,
        stockState: 'AVAILABLE',
        qtyChange: releaseQty,
        sourceType: 'ORDER_CANCEL_RELEASE',
        sourceId: order.orderNo,
        createdByEmail: user?.email || null
      }
    });

    // 3. Decrement RESERVED in StockOnHand
    await tx.stockOnHand.update({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: order.dealerId,
          warehouseId,
          skuId: entry.skuId,
          batch: entry.batch,
          stockState: 'RESERVED'
        }
      },
      data: {
        qty: { decrement: releaseQty }
      }
    });

    // 4. Increment AVAILABLE in StockOnHand
    await tx.stockOnHand.upsert({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: order.dealerId,
          warehouseId,
          skuId: entry.skuId,
          batch: entry.batch,
          stockState: 'AVAILABLE'
        }
      },
      update: {
        qty: { increment: releaseQty }
      },
      create: {
        dealerId: order.dealerId,
        warehouseId,
        skuId: entry.skuId,
        batch: entry.batch,
        stockState: 'AVAILABLE',
        qty: releaseQty
      }
    });
  }

  // Reset reservedQty on order lines
  await tx.orderLine.updateMany({
    where: { orderId: order.id },
    data: { reservedQty: 0 }
  });
}

/**
 * Creates a new DRAFT order.
 */
export async function createDraftOrder({
  dealerId,
  retailerId,
  warehouseId,
  channel = ORDER_CHANNEL.PORTAL,
  notes,
  items = [],
  user
}) {
  return await prisma.$transaction(async (tx) => {
    // 1. Resolve warehouse
    const warehouse = await resolveOrderWarehouse(dealerId, warehouseId, tx);

    // 2. Pricing and validation
    const pricing = await calculateOrderPricing({
      dealerId,
      retailerId,
      warehouseId: warehouse?.id,
      items,
      date: new Date(),
      tx
    });

    // Check overdue invoices - block new orders if overdue
    if (pricing.hasOverdueInvoices) {
      const err = new Error(
        `New orders are blocked: Retailer has ₹${pricing.overdueAmount.toFixed(2)} in overdue invoice(s) exceeding credit period. Outstanding payment must be settled before placing new orders.`
      );
      err.status = 400;
      err.code = 'RETAILER_OVERDUE_BLOCKED';
      err.details = {
        overdueAmount: pricing.overdueAmount,
        overdueInvoices: pricing.overdueInvoices
      };
      throw err;
    }

    // 3. Generate Order Number
    const { orderNo, financialYear } = await generateOrderNumber(dealerId, new Date(), tx);

    // 4. Create Order
    const order = await tx.order.create({
      data: {
        dealerId,
        orderNo,
        financialYear,
        retailerId,
        warehouseId: warehouse?.id,
        channel,
        status: ORDER_STATUS.DRAFT,
        totalAmount: pricing.totalAmount,
        creditLimit: pricing.creditLimit,
        currentOutstanding: pricing.currentOutstanding,
        creditLimitExceeded: pricing.creditLimitExceeded,
        notes: notes || null,
        lines: {
          create: pricing.lines.map((l) => ({
            skuId: l.skuId,
            orderedQty: l.orderedQty,
            unitPrice: l.unitPrice,
            ruleId: l.ruleId,
            pricingLevel: l.pricingLevel,
            lineValue: l.lineValue,
            reservedQty: 0,
            shortfallQty: 0,
            billedQty: 0
          }))
        }
      },
      include: {
        lines: {
          include: { sku: true }
        },
        retailer: true,
        warehouse: true
      }
    });

    return order;
  });
}

/**
 * Updates an existing DRAFT order.
 */
export async function updateDraftOrder({
  orderId,
  dealerId,
  retailerId,
  warehouseId,
  notes,
  items,
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const existing = await tx.order.findUnique({
      where: { id: orderId }
    });

    if (!existing) {
      const err = new Error('Order not found.');
      err.status = 404;
      throw err;
    }

    if (existing.dealerId !== dealerId) {
      const err = new Error('Order does not belong to this dealership.');
      err.status = 403;
      throw err;
    }

    if (existing.status !== ORDER_STATUS.DRAFT) {
      const err = new Error(`Cannot modify order in ${existing.status} status. Only DRAFT orders can be edited.`);
      err.status = 400;
      err.code = ORDER_ERROR_CODES.INVALID_STATUS_TRANSITION;
      throw err;
    }

    const targetRetailerId = retailerId || existing.retailerId;
    const warehouse = await resolveOrderWarehouse(dealerId, warehouseId || existing.warehouseId, tx);

    const pricing = await calculateOrderPricing({
      dealerId,
      retailerId: targetRetailerId,
      warehouseId: warehouse?.id,
      items: items || [],
      date: new Date(),
      tx
    });

    if (pricing.hasOverdueInvoices) {
      const err = new Error(
        `Order update blocked: Retailer has ₹${pricing.overdueAmount.toFixed(2)} in overdue invoice(s) exceeding credit period. Outstanding payment must be settled before updating orders.`
      );
      err.status = 400;
      err.code = 'RETAILER_OVERDUE_BLOCKED';
      err.details = {
        overdueAmount: pricing.overdueAmount,
        overdueInvoices: pricing.overdueInvoices
      };
      throw err;
    }

    // Delete existing lines
    await tx.orderLine.deleteMany({
      where: { orderId: existing.id }
    });

    // Update order with new lines
    const updated = await tx.order.update({
      where: { id: existing.id },
      data: {
        retailerId: targetRetailerId,
        warehouseId: warehouse?.id,
        notes: notes !== undefined ? notes : existing.notes,
        totalAmount: pricing.totalAmount,
        creditLimit: pricing.creditLimit,
        currentOutstanding: pricing.currentOutstanding,
        creditLimitExceeded: pricing.creditLimitExceeded,
        lines: {
          create: pricing.lines.map((l) => ({
            skuId: l.skuId,
            orderedQty: l.orderedQty,
            unitPrice: l.unitPrice,
            ruleId: l.ruleId,
            pricingLevel: l.pricingLevel,
            lineValue: l.lineValue,
            reservedQty: 0,
            shortfallQty: 0,
            billedQty: 0
          }))
        }
      },
      include: {
        lines: { include: { sku: true } },
        retailer: true,
        warehouse: true
      }
    });

    return updated;
  });
}

/**
 * Submits an order.
 *
 * Workflow:
 * 1. Checks retailer credit limit vs total exposure (outstanding + orderTotal).
 * 2. If creditLimit is exceeded -> PENDING_APPROVAL (awaits dealer owner approval).
 * 3. If creditLimit is satisfied -> auto-transitions to APPROVED and executes stock reservation.
 */
export async function submitOrder({ orderId, dealerId, user }) {
  return await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: {
        lines: { include: { sku: true } },
        retailer: true
      }
    });

    if (!order) {
      const err = new Error('Order not found.');
      err.status = 404;
      throw err;
    }

    if (order.dealerId !== dealerId) {
      const err = new Error('Order does not belong to this dealership.');
      err.status = 403;
      throw err;
    }

    if (order.status !== ORDER_STATUS.DRAFT) {
      const err = new Error(`Order cannot be submitted from status ${order.status}. Only DRAFT orders can be submitted.`);
      err.status = 400;
      err.code = ORDER_ERROR_CODES.INVALID_STATUS_TRANSITION;
      throw err;
    }

    if (!order.lines || order.lines.length === 0) {
      const err = new Error('Cannot submit an order with no line items.');
      err.status = 400;
      throw err;
    }

    // Refresh pricing and billable validation at submission time
    const pricing = await calculateOrderPricing({
      dealerId,
      retailerId: order.retailerId,
      warehouseId: order.warehouseId,
      items: order.lines.map((l) => ({ skuId: l.skuId, orderedQty: l.orderedQty })),
      date: new Date(),
      tx
    });

    // Check overdue invoices - block submission if overdue
    if (pricing.hasOverdueInvoices) {
      const err = new Error(
        `Order submission blocked: Retailer has ₹${pricing.overdueAmount.toFixed(2)} in overdue invoice(s) exceeding credit period. Outstanding payment must be settled before placing new orders.`
      );
      err.status = 400;
      err.code = 'RETAILER_OVERDUE_BLOCKED';
      err.details = {
        overdueAmount: pricing.overdueAmount,
        overdueInvoices: pricing.overdueInvoices
      };
      throw err;
    }

    const expiryDays = await getOrderExpiryDays(tx);
    const expiresAt = new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000);

    // Credit Check using real outstanding balance from append-only ledger
    const outstanding = await getRetailerOutstanding(order.retailerId, tx);
    const creditLimit = order.retailer.creditLimit || 0;
    const totalExposure = outstanding + pricing.totalAmount;
    const isExceeded = totalExposure > creditLimit;

    if (isExceeded) {
      // Exceeded -> PENDING_APPROVAL for Dealer Owner
      const updatedOrder = await tx.order.update({
        where: { id: order.id },
        data: {
          status: ORDER_STATUS.PENDING_APPROVAL,
          totalAmount: pricing.totalAmount,
          creditLimit,
          currentOutstanding: outstanding,
          creditLimitExceeded: true,
          submittedAt: new Date(),
          expiresAt
        },
        include: {
          lines: { include: { sku: true } },
          retailer: true,
          warehouse: true
        }
      });

      return {
        order: updatedOrder,
        autoApproved: false,
        message: `Order submitted and placed in PENDING_APPROVAL. Retailer credit limit of ₹${creditLimit.toLocaleString()} is exceeded by total exposure of ₹${totalExposure.toLocaleString()}.`
      };
    } else {
      // Within credit limit -> Auto-APPROVED & reserve stock
      await tx.order.update({
        where: { id: order.id },
        data: {
          status: ORDER_STATUS.APPROVED,
          totalAmount: pricing.totalAmount,
          creditLimit,
          currentOutstanding: outstanding,
          creditLimitExceeded: false,
          submittedAt: new Date(),
          approvedByEmail: user?.email || 'SYSTEM_AUTO_APPROVAL',
          approvedAt: new Date(),
          expiresAt
        }
      });

      // Execute atomic stock reservation
      await executeStockReservation({ orderId: order.id, user, tx });

      const finalOrder = await tx.order.findUnique({
        where: { id: order.id },
        include: {
          lines: { include: { sku: true } },
          retailer: true,
          warehouse: true
        }
      });

      return {
        order: finalOrder,
        autoApproved: true,
        message: 'Order credit check passed. Auto-approved and inventory reserved.'
      };
    }
  });
}

/**
 * Manually approves a credit-blocked order (DEALER_OWNER or BRAND_ADMIN).
 * Transitions status to APPROVED and reserves stock.
 */
export async function approveOrder({ orderId, user }) {
  return await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: {
        lines: { include: { sku: true } },
        retailer: true
      }
    });

    if (!order) {
      const err = new Error('Order not found.');
      err.status = 404;
      throw err;
    }

    if (order.status !== ORDER_STATUS.PENDING_APPROVAL) {
      const err = new Error(`Order in status ${order.status} cannot be approved. Only PENDING_APPROVAL orders can be approved.`);
      err.status = 400;
      err.code = ORDER_ERROR_CODES.INVALID_STATUS_TRANSITION;
      throw err;
    }

    // Role check: BRAND_ADMIN or DEALER_OWNER of this dealership
    if (user.role !== 'BRAND_ADMIN' && user.role !== 'DEALER_OWNER') {
      const err = new Error('Only DEALER_OWNER or BRAND_ADMIN can approve credit-blocked orders.');
      err.status = 403;
      err.code = ORDER_ERROR_CODES.UNAUTHORIZED;
      throw err;
    }

    if (user.role === 'DEALER_OWNER' && user.dealerId !== order.dealerId) {
      const err = new Error('Dealer Owner cannot approve orders for a different dealership.');
      err.status = 403;
      throw err;
    }

    const expiryDays = await getOrderExpiryDays(tx);
    const expiresAt = new Date(Date.now() + expiryDays * 24 * 60 * 60 * 1000);

    await tx.order.update({
      where: { id: order.id },
      data: {
        status: ORDER_STATUS.APPROVED,
        approvedByEmail: user.email,
        approvedAt: new Date(),
        expiresAt
      }
    });

    // Execute atomic stock reservation
    await executeStockReservation({ orderId: order.id, user, tx });

    const updated = await tx.order.findUnique({
      where: { id: order.id },
      include: {
        lines: { include: { sku: true } },
        retailer: true,
        warehouse: true
      }
    });

    return {
      order: updated,
      message: `Order ${order.orderNo} approved by ${user.email}. Stock has been reserved.`
    };
  });
}

/**
 * Cancels an order.
 * If order was APPROVED (stock was reserved), releases the reserved stock back to AVAILABLE.
 */
export async function cancelOrder({ orderId, reason, user }) {
  return await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: { lines: true }
    });

    if (!order) {
      const err = new Error('Order not found.');
      err.status = 404;
      throw err;
    }

    if (user.role !== 'BRAND_ADMIN' && user.dealerId !== order.dealerId) {
      const err = new Error('Cannot cancel orders belonging to another dealership.');
      err.status = 403;
      throw err;
    }

    if (order.status === ORDER_STATUS.CANCELLED) {
      return { order, message: 'Order is already cancelled.' };
    }

    if (order.status === ORDER_STATUS.CLOSED || order.status === ORDER_STATUS.FULLY_BILLED) {
      const err = new Error(`Cannot cancel order in ${order.status} status.`);
      err.status = 400;
      err.code = ORDER_ERROR_CODES.INVALID_STATUS_TRANSITION;
      throw err;
    }

    const wasApproved = order.status === ORDER_STATUS.APPROVED;

    // Release stock reservation if previously approved
    if (wasApproved) {
      await executeStockRelease({ orderId: order.id, user, tx });
    }

    const updated = await tx.order.update({
      where: { id: order.id },
      data: {
        status: ORDER_STATUS.CANCELLED,
        cancelledByEmail: user?.email || null,
        cancelledAt: new Date(),
        cancelledReason: reason || 'Cancelled by user'
      },
      include: {
        lines: { include: { sku: true } },
        retailer: true,
        warehouse: true
      }
    });

    return {
      order: updated,
      releasedStock: wasApproved,
      message: `Order ${order.orderNo} cancelled.${wasApproved ? ' Reserved inventory has been restored to AVAILABLE.' : ''}`
    };
  });
}

