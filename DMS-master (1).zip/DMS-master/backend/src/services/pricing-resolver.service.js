import {
  PRICE_PRECEDENCE_ORDER,
  PRICE_ERROR_CODES,
  PRICE_METHOD,
  PRICE_TARGET_TYPE
} from '@dms/shared';

export const PRECEDENCE_LEVELS = PRICE_PRECEDENCE_ORDER;

/**
 * Checks whether a candidate rule targets the given retailer based on targetType and targetId.
 */
export function matchesTarget(rule, retailer) {
  if (!rule || !retailer) return false;
  const targetType = rule.targetType?.toUpperCase();
  const targetId = rule.targetId;

  switch (targetType) {
    case 'RETAILER':
      return Boolean(
        targetId &&
        retailer.id &&
        String(targetId).toLowerCase() === String(retailer.id).toLowerCase()
      );

    case 'RETAILER_CLASS': {
      if (!targetId) return false;
      const tid = String(targetId).toUpperCase();
      const rClass = retailer.retailerClass ? String(retailer.retailerClass).toUpperCase() : null;
      const rChannel = retailer.channelType ? String(retailer.channelType).toUpperCase() : null;
      return tid === rClass || tid === rChannel;
    }

    case 'CLUSTER': {
      if (!targetId) return false;
      const tid = String(targetId).toLowerCase();
      return Boolean(
        (retailer.clusterId && String(retailer.clusterId).toLowerCase() === tid) ||
        (retailer.geoNodeId && String(retailer.geoNodeId).toLowerCase() === tid) ||
        (retailer.clusterName && String(retailer.clusterName).toLowerCase() === tid) ||
        (retailer.geoNode?.id && String(retailer.geoNode.id).toLowerCase() === tid) ||
        (retailer.geoNode?.name && String(retailer.geoNode.name).toLowerCase() === tid) ||
        (retailer.geoAncestors?.clusterId && String(retailer.geoAncestors.clusterId).toLowerCase() === tid)
      );
    }

    case 'CITY': {
      if (!targetId) return false;
      const tid = String(targetId).toLowerCase();
      return Boolean(
        (retailer.cityId && String(retailer.cityId).toLowerCase() === tid) ||
        (retailer.cityName && String(retailer.cityName).toLowerCase() === tid) ||
        (retailer.geoAncestors?.cityId && String(retailer.geoAncestors.cityId).toLowerCase() === tid) ||
        (retailer.geoAncestors?.cityName && String(retailer.geoAncestors.cityName).toLowerCase() === tid) ||
        (retailer.geoNode?.path && retailer.geoNode.path.toLowerCase().includes(`/${tid}`))
      );
    }

    case 'REGION': {
      if (!targetId) return false;
      const tid = String(targetId).toLowerCase();
      return Boolean(
        (retailer.regionId && String(retailer.regionId).toLowerCase() === tid) ||
        (retailer.regionName && String(retailer.regionName).toLowerCase() === tid) ||
        (retailer.geoAncestors?.regionId && String(retailer.geoAncestors.regionId).toLowerCase() === tid) ||
        (retailer.geoAncestors?.regionName && String(retailer.geoAncestors.regionName).toLowerCase() === tid) ||
        (retailer.geoNode?.path && retailer.geoNode.path.toLowerCase().includes(`/${tid}`))
      );
    }

    case 'STATE': {
      if (!targetId) return false;
      const tid = String(targetId).toLowerCase();
      return Boolean(
        (retailer.stateId && String(retailer.stateId).toLowerCase() === tid) ||
        (retailer.stateName && String(retailer.stateName).toLowerCase() === tid) ||
        (retailer.stateCode && String(retailer.stateCode).toLowerCase() === tid) ||
        (retailer.geoAncestors?.stateId && String(retailer.geoAncestors.stateId).toLowerCase() === tid) ||
        (retailer.geoAncestors?.stateName && String(retailer.geoAncestors.stateName).toLowerCase() === tid) ||
        (retailer.geoNode?.path && retailer.geoNode.path.toLowerCase().includes(`/${tid}`))
      );
    }

    case 'ZONE': {
      if (!targetId) return false;
      const tid = String(targetId).toLowerCase();
      return Boolean(
        (retailer.zoneId && String(retailer.zoneId).toLowerCase() === tid) ||
        (retailer.zoneName && String(retailer.zoneName).toLowerCase() === tid) ||
        (retailer.geoAncestors?.zoneId && String(retailer.geoAncestors.zoneId).toLowerCase() === tid) ||
        (retailer.geoAncestors?.zoneName && String(retailer.geoAncestors.zoneName).toLowerCase() === tid) ||
        (retailer.geoNode?.path && retailer.geoNode.path.toLowerCase().includes(`/${tid}`))
      );
    }

    case 'NATIONAL':
      return true;

    default:
      return false;
  }
}

/**
 * Checks whether a rule is valid on the given date (considering both PriceList and Rule valid windows).
 */
export function isRuleDateValid(rule, targetDate) {
  const d = new Date(targetDate);
  if (isNaN(d.getTime())) return false;

  // Check PriceList validity if attached
  if (rule.priceList) {
    if (rule.priceList.status && rule.priceList.status !== 'APPROVED') return false;
    if (rule.priceList.validFrom && new Date(rule.priceList.validFrom) > d) return false;
    if (rule.priceList.validTo && new Date(rule.priceList.validTo) < d) return false;
  }

  // Check rule-specific validity
  if (rule.validFrom && new Date(rule.validFrom) > d) return false;
  if (rule.validTo && new Date(rule.validTo) < d) return false;

  return true;
}

/**
 * Checks whether a rule corresponds to the requested SKU.
 */
export function isRuleSkuMatch(rule, sku) {
  if (!rule || !sku) return false;
  if (rule.skuId && sku.id && String(rule.skuId).toLowerCase() === String(sku.id).toLowerCase()) {
    return true;
  }
  if (rule.skuCode && sku.code && String(rule.skuCode).toLowerCase() === String(sku.code).toLowerCase()) {
    return true;
  }
  if (rule.sku?.id && sku.id && String(rule.sku.id).toLowerCase() === String(sku.id).toLowerCase()) {
    return true;
  }
  if (rule.sku?.code && sku.code && String(rule.sku.code).toLowerCase() === String(sku.code).toLowerCase()) {
    return true;
  }
  return false;
}

/**
 * Calculates selling price from a pricing rule method and value.
 */
export function calculatePriceFromRule({ rule, sku, landingPrice }) {
  const method = rule.method?.toUpperCase();
  const value = Number(rule.value);
  const mrp = Number(sku?.mrp ?? 0);
  const effectiveLanding = Number(landingPrice ?? sku?.landingPrice ?? 0);

  let rawPrice = 0;
  switch (method) {
    case 'FIXED':
      rawPrice = value;
      break;
    case 'PERCENT_OFF_MRP':
      rawPrice = mrp * (1 - value / 100);
      break;
    case 'MARKUP_ON_LANDING':
      rawPrice = effectiveLanding * (1 + value / 100);
      break;
    default:
      rawPrice = value;
  }

  return Math.round(rawPrice * 100) / 100;
}

/**
 * Validates price guardrails:
 * 1. price <= MRP
 * 2. price >= landing price + minMarginPct %
 */
export function validateGuardrails({ method, value, sku, landingPrice, minMarginPct = 10 }) {
  const calculatedPrice = calculatePriceFromRule({
    rule: { method, value },
    sku,
    landingPrice
  });

  const mrp = sku?.mrp != null ? Number(sku.mrp) : null;
  const effectiveLanding = landingPrice != null
    ? Number(landingPrice)
    : (sku?.landingPrice != null ? Number(sku.landingPrice) : null);

  // 1. Guardrail: price must be <= MRP
  if (mrp != null && calculatedPrice > mrp) {
    return {
      valid: false,
      code: PRICE_ERROR_CODES.GUARDRAIL_EXCEEDS_MRP,
      calculatedPrice,
      maxAllowedPrice: mrp,
      error: `Guardrail breach: Calculated price (₹${calculatedPrice}) exceeds SKU MRP (₹${mrp}). Secondary price must be <= MRP.`
    };
  }

  // 2. Guardrail: price must be >= landing price + minMarginPct %
  if (effectiveLanding != null && effectiveLanding > 0) {
    const minAllowedPrice = Math.round((effectiveLanding * (1 + Number(minMarginPct) / 100)) * 100) / 100;
    if (calculatedPrice < minAllowedPrice) {
      return {
        valid: false,
        code: PRICE_ERROR_CODES.GUARDRAIL_BELOW_MIN_MARGIN,
        calculatedPrice,
        minAllowedPrice,
        error: `Guardrail breach: Calculated price (₹${calculatedPrice}) falls below minimum allowed price of ₹${minAllowedPrice} (landing price ₹${effectiveLanding} + ${minMarginPct}% minimum margin).`
      };
    }
  }

  return {
    valid: true,
    calculatedPrice,
    mrp,
    effectiveLanding
  };
}

/**
 * Pure, side-effect-free function: resolvePrice({ retailer, sku, date, landingPrice, rules })
 *
 * Picks the most specific valid APPROVED rule in precedence order:
 * Retailer → Retailer class/channel → Cluster → City → Region → State → Zone → National
 *
 * Returns: { price, ruleId, level }
 * If no rule matches, returns { error: 'NO_PRICE' }
 */
export function resolvePrice(params = {}, rulesArg) {
  const {
    retailer,
    sku,
    date = new Date(),
    landingPrice,
    rules: inlineRules
  } = params;

  const rules = rulesArg || inlineRules || [];

  if (!retailer || !sku) {
    return {
      error: PRICE_ERROR_CODES.NO_PRICE,
      price: null,
      ruleId: null,
      level: null,
      message: 'Retailer and SKU are required to resolve secondary price.'
    };
  }

  const targetDate = new Date(date);

  // Filter rules that match SKU and are active/approved/date-valid
  const candidateRules = rules.filter((rule) => {
    if (!isRuleSkuMatch(rule, sku)) return false;
    if (!isRuleDateValid(rule, targetDate)) return false;
    return true;
  });

  // Precedence order: Retailer → Retailer class/channel → Cluster → City → Region → State → Zone → National
  for (const level of PRECEDENCE_LEVELS) {
    const matchesForLevel = candidateRules.filter(
      (rule) => rule.targetType?.toUpperCase() === level && matchesTarget(rule, retailer)
    );

    if (matchesForLevel.length > 0) {
      // Tie-breaker for multiple rules at the same level:
      // Higher priceList version wins, then latest update date
      matchesForLevel.sort((a, b) => {
        const verA = a.priceList?.version ?? a.version ?? 1;
        const verB = b.priceList?.version ?? b.version ?? 1;
        if (verB !== verA) return verB - verA;
        const timeA = new Date(a.updatedAt || a.createdAt || 0).getTime();
        const timeB = new Date(b.updatedAt || b.createdAt || 0).getTime();
        return timeB - timeA;
      });

      const winningRule = matchesForLevel[0];
      const price = calculatePriceFromRule({
        rule: winningRule,
        sku,
        landingPrice
      });

      return {
        price,
        ruleId: winningRule.id,
        level: winningRule.targetType,
        method: winningRule.method,
        value: winningRule.value,
        rule: winningRule,
        priceListId: winningRule.priceListId
      };
    }
  }

  return {
    error: PRICE_ERROR_CODES.NO_PRICE,
    price: null,
    ruleId: null,
    level: null,
    message: 'No valid approved price rule found for this SKU and retailer on the specified date.'
  };
}

