import { prisma } from '../config/database.js';

/**
 * Atomic and Idempotent GRN Confirmation.
 *
 * Rules:
 * - Single database transaction.
 * - Idempotent: double-clicks or repeat calls return current state without double posting.
 * - Posts accepted good quantity (up to invoiced qty) to AVAILABLE in StockLedger & StockOnHand.
 * - Posts damaged quantity to DAMAGED in StockLedger & StockOnHand.
 * - Does NOT post short or excess quantities to inventory.
 * - Creates TransitClaim (OPEN) for any variance (SHORT, EXCESS, DAMAGED).
 * - ASN status becomes RECEIVED or RECEIVED_WITH_VARIANCE.
 */
export async function confirmGrnTransaction({
  asnId,
  warehouseId,
  receivedLines = [],
  user
}) {
  return await prisma.$transaction(async (tx) => {
    // 1. Fetch ASN with lines
    const asn = await tx.asn.findUnique({
      where: { id: asnId },
      include: {
        lines: { include: { sku: true } },
        receivedWarehouse: true
      }
    });

    if (!asn) {
      const err = new Error('ASN not found.');
      err.status = 404;
      throw err;
    }

    // 2. Idempotency Check: if already processed, return immediately
    if (asn.status === 'RECEIVED' || asn.status === 'RECEIVED_WITH_VARIANCE') {
      const claims = await tx.transitClaim.findMany({ where: { asnId: asn.id } });
      return {
        idempotent: true,
        message: 'GRN has already been confirmed for this ASN.',
        asn: { ...asn, claims }
      };
    }

    if (asn.status === 'CANCELLED') {
      const err = new Error('Cannot receive a CANCELLED ASN.');
      err.status = 400;
      throw err;
    }

    // 3. Verify destination warehouse belongs to dealer
    const warehouse = await tx.warehouse.findUnique({
      where: { id: warehouseId }
    });

    if (!warehouse) {
      const err = new Error('Destination warehouse not found.');
      err.status = 404;
      throw err;
    }

    if (warehouse.dealerId !== asn.dealerId) {
      const err = new Error('Destination warehouse does not belong to this dealership.');
      err.status = 403;
      throw err;
    }

    // 4. Generate unique GRN number
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randPart = Math.floor(1000 + Math.random() * 9000);
    const grnNumber = `GRN-${dateStr}-${randPart}`;
    const grnDate = new Date();

    const lineMap = new Map();
    receivedLines.forEach((l) => lineMap.set(l.asnLineId || l.id, l));

    let hasVariance = false;
    const createdClaims = [];

    // 5. Process each ASN line
    for (const line of asn.lines) {
      const sub = lineMap.get(line.id) || {};

      const goodQty = sub.receivedGoodQty !== undefined
        ? Math.max(0, parseInt(sub.receivedGoodQty, 10))
        : line.invoicedQty;

      const shortQty = Math.max(0, parseInt(sub.shortQty || 0, 10));
      const excessQty = Math.max(0, parseInt(sub.excessQty || 0, 10));
      const damagedQty = Math.max(0, parseInt(sub.damagedQty || 0, 10));
      const reason = sub.varianceReason ? String(sub.varianceReason).trim() : null;
      const photoUrl = sub.photoUrl ? String(sub.photoUrl).trim() : null;

      // Check if this line has variance
      const isLineVariance = shortQty > 0 || excessQty > 0 || damagedQty > 0 || goodQty !== line.invoicedQty;
      if (isLineVariance) {
        hasVariance = true;
      }

      // a) Post accepted good quantity (capped at invoiced qty) to AVAILABLE
      const acceptedGoodQty = Math.min(goodQty, line.invoicedQty);
      if (acceptedGoodQty > 0) {
        // Append to StockLedger
        await tx.stockLedger.create({
          data: {
            dealerId: asn.dealerId,
            warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'AVAILABLE',
            qtyChange: acceptedGoodQty,
            sourceType: 'GRN_RECEIPT',
            sourceId: grnNumber,
            inwardDate: grnDate,
            createdByEmail: user?.email || null
          }
        });

        // Maintain StockOnHand summary
        await tx.stockOnHand.upsert({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId: asn.dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'AVAILABLE'
            }
          },
          update: {
            qty: { increment: acceptedGoodQty },
            inwardDate: grnDate
          },
          create: {
            dealerId: asn.dealerId,
            warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'AVAILABLE',
            qty: acceptedGoodQty,
            inwardDate: grnDate
          }
        });
      }

      // b) Post damaged quantity to DAMAGED
      if (damagedQty > 0) {
        await tx.stockLedger.create({
          data: {
            dealerId: asn.dealerId,
            warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'DAMAGED',
            qtyChange: damagedQty,
            sourceType: 'GRN_DAMAGE',
            sourceId: grnNumber,
            inwardDate: grnDate,
            createdByEmail: user?.email || null
          }
        });

        await tx.stockOnHand.upsert({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId: asn.dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'DAMAGED'
            }
          },
          update: {
            qty: { increment: damagedQty },
            inwardDate: grnDate
          },
          create: {
            dealerId: asn.dealerId,
            warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'DAMAGED',
            qty: damagedQty,
            inwardDate: grnDate
          }
        });

        // Create TransitClaim for DAMAGED
        const claim = await tx.transitClaim.create({
          data: {
            dealerId: asn.dealerId,
            asnId: asn.id,
            asnLineId: line.id,
            skuId: line.skuId,
            claimType: 'DAMAGED',
            qty: damagedQty,
            reason: reason || 'Goods received damaged during primary transit',
            photoUrl,
            status: 'OPEN'
          }
        });
        createdClaims.push(claim);
      }

      // c) For SHORT variance: do NOT post to inventory. Create TransitClaim.
      if (shortQty > 0) {
        const claim = await tx.transitClaim.create({
          data: {
            dealerId: asn.dealerId,
            asnId: asn.id,
            asnLineId: line.id,
            skuId: line.skuId,
            claimType: 'SHORT',
            qty: shortQty,
            reason: reason || 'Short delivery relative to invoice quantity',
            photoUrl,
            status: 'OPEN'
          }
        });
        createdClaims.push(claim);
      }

      // d) For EXCESS variance: do NOT post to inventory. Create TransitClaim.
      if (excessQty > 0) {
        const claim = await tx.transitClaim.create({
          data: {
            dealerId: asn.dealerId,
            asnId: asn.id,
            asnLineId: line.id,
            skuId: line.skuId,
            claimType: 'EXCESS',
            qty: excessQty,
            reason: reason || 'Excess goods received over invoice quantity',
            photoUrl,
            status: 'OPEN'
          }
        });
        createdClaims.push(claim);
      }

      // Update line record
      await tx.asnLine.update({
        where: { id: line.id },
        data: {
          receivedGoodQty: goodQty,
          shortQty,
          excessQty,
          damagedQty,
          varianceReason: reason,
          photoUrl
        }
      });
    }

    // 6. Update ASN Header
    const finalStatus = hasVariance ? 'RECEIVED_WITH_VARIANCE' : 'RECEIVED';
    const updatedAsn = await tx.asn.update({
      where: { id: asn.id },
      data: {
        status: finalStatus,
        grnNumber,
        grnDate,
        erpAcknowledgedAt: grnDate,
        receivedWarehouseId: warehouseId,
        receivedByEmail: user?.email || null
      },
      include: {
        lines: { include: { sku: true } },
        receivedWarehouse: true
      }
    });

    return {
      idempotent: false,
      message: `GRN ${grnNumber} confirmed successfully. Status: ${finalStatus}. Acknowledgement transmitted to ERP.`,
      asn: {
        ...updatedAsn,
        claims: createdClaims
      }
    };
  });
}

/**
 * Inter-warehouse stock transfer within the same dealership.
 */
export async function executeStockTransferTransaction({
  dealerId,
  sourceWarehouseId,
  targetWarehouseId,
  lines = [],
  notes,
  user
}) {
  if (sourceWarehouseId === targetWarehouseId) {
    const err = new Error('Source and target warehouse cannot be the same.');
    err.status = 400;
    throw err;
  }

  if (!lines || lines.length === 0) {
    const err = new Error('At least one transfer line is required.');
    err.status = 400;
    throw err;
  }

  return await prisma.$transaction(async (tx) => {
    // Verify both warehouses belong to dealer
    const [sourceWh, targetWh] = await Promise.all([
      tx.warehouse.findUnique({ where: { id: sourceWarehouseId } }),
      tx.warehouse.findUnique({ where: { id: targetWarehouseId } })
    ]);

    if (!sourceWh || sourceWh.dealerId !== dealerId || !sourceWh.isActive) {
      const err = new Error('Source warehouse not found or invalid.');
      err.status = 404;
      throw err;
    }
    if (!targetWh || targetWh.dealerId !== dealerId || !targetWh.isActive) {
      const err = new Error('Target warehouse not found or invalid.');
      err.status = 404;
      throw err;
    }

    const transferNo = `TRF-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

    // Validate available stock for each line
    for (const line of lines) {
      const qty = parseInt(line.qty, 10);
      if (isNaN(qty) || qty <= 0) {
        const err = new Error('Transfer quantity must be a positive integer.');
        err.status = 400;
        throw err;
      }

      const stock = await tx.stockOnHand.findUnique({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId: sourceWarehouseId,
            skuId: line.skuId,
            batch: line.batch || 'DEFAULT',
            stockState: 'AVAILABLE'
          }
        }
      });

      if (!stock || stock.qty < qty) {
        const err = new Error(`Insufficient available stock for SKU in source warehouse. Available: ${stock?.qty || 0}, requested: ${qty}.`);
        err.status = 400;
        throw err;
      }
    }

    // Create Transfer record
    const transfer = await tx.stockTransfer.create({
      data: {
        dealerId,
        transferNo,
        sourceWarehouseId,
        targetWarehouseId,
        status: 'COMPLETED',
        notes: notes ? String(notes).trim() : null,
        transferredByEmail: user?.email || null,
        lines: {
          create: lines.map((l) => ({
            skuId: l.skuId,
            batch: l.batch || 'DEFAULT',
            qty: parseInt(l.qty, 10)
          }))
        }
      },
      include: {
        lines: { include: { sku: true } },
        sourceWarehouse: true,
        targetWarehouse: true
      }
    });

    // Execute atomic balance moves in ledger and stock_on_hand
    for (const line of lines) {
      const qty = parseInt(line.qty, 10);
      const batch = line.batch || 'DEFAULT';

      // 1. Source warehouse: OUT
      await tx.stockLedger.create({
        data: {
          dealerId,
          warehouseId: sourceWarehouseId,
          skuId: line.skuId,
          batch,
          stockState: 'AVAILABLE',
          qtyChange: -qty,
          sourceType: 'STOCK_TRANSFER_OUT',
          sourceId: transferNo,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.update({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId: sourceWarehouseId,
            skuId: line.skuId,
            batch,
            stockState: 'AVAILABLE'
          }
        },
        data: { qty: { decrement: qty } }
      });

      // 2. Target warehouse: IN
      await tx.stockLedger.create({
        data: {
          dealerId,
          warehouseId: targetWarehouseId,
          skuId: line.skuId,
          batch,
          stockState: 'AVAILABLE',
          qtyChange: qty,
          sourceType: 'STOCK_TRANSFER_IN',
          sourceId: transferNo,
          inwardDate: new Date(),
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId: targetWarehouseId,
            skuId: line.skuId,
            batch,
            stockState: 'AVAILABLE'
          }
        },
        update: {
          qty: { increment: qty }
        },
        create: {
          dealerId,
          warehouseId: targetWarehouseId,
          skuId: line.skuId,
          batch,
          stockState: 'AVAILABLE',
          qty,
          inwardDate: new Date()
        }
      });
    }

    return {
      message: `Stock transfer ${transferNo} completed successfully.`,
      transfer
    };
  });
}

/**
 * Purchase Return to Brand (DMS Request -> ERP Return Order).
 */
export async function executePurchaseReturnTransaction({
  dealerId,
  warehouseId,
  reason,
  lines = [],
  notes,
  user
}) {
  if (!reason || !reason.trim()) {
    const err = new Error('Return reason is required.');
    err.status = 400;
    throw err;
  }
  if (!lines || lines.length === 0) {
    const err = new Error('At least one return line item is required.');
    err.status = 400;
    throw err;
  }

  return await prisma.$transaction(async (tx) => {
    const warehouse = await tx.warehouse.findUnique({ where: { id: warehouseId } });
    if (!warehouse || warehouse.dealerId !== dealerId) {
      const err = new Error('Warehouse not found or invalid.');
      err.status = 404;
      throw err;
    }

    const returnNo = `PR-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
    const erpReturnOrderNo = `ERP-RO-${Date.now().toString().slice(-6)}`;

    // Validate stock for each line
    for (const line of lines) {
      const qty = parseInt(line.qty, 10);
      const fromStockState = line.fromStockState || 'DAMAGED';

      const stock = await tx.stockOnHand.findUnique({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId,
            skuId: line.skuId,
            batch: line.batch || 'DEFAULT',
            stockState: fromStockState
          }
        }
      });

      if (!stock || stock.qty < qty) {
        const err = new Error(`Insufficient ${fromStockState} stock to return for SKU. Available: ${stock?.qty || 0}, requested: ${qty}.`);
        err.status = 400;
        throw err;
      }
    }

    // Create PurchaseReturn record
    const purchaseReturn = await tx.purchaseReturn.create({
      data: {
        dealerId,
        warehouseId,
        returnNo,
        status: 'ERP_ACCEPTED',
        reason: reason.trim(),
        erpReturnOrderNo,
        notes: notes ? String(notes).trim() : null,
        createdByEmail: user?.email || null,
        submittedAt: new Date(),
        lines: {
          create: lines.map((l) => ({
            skuId: l.skuId,
            batch: l.batch || 'DEFAULT',
            qty: parseInt(l.qty, 10),
            fromStockState: l.fromStockState || 'DAMAGED'
          }))
        }
      },
      include: {
        lines: { include: { sku: true } },
        warehouse: true
      }
    });

    // Update ledger and stock on hand
    for (const line of lines) {
      const qty = parseInt(line.qty, 10);
      const batch = line.batch || 'DEFAULT';
      const fromStockState = line.fromStockState || 'DAMAGED';

      // Deduct from original state
      await tx.stockLedger.create({
        data: {
          dealerId,
          warehouseId,
          skuId: line.skuId,
          batch,
          stockState: fromStockState,
          qtyChange: -qty,
          sourceType: 'PURCHASE_RETURN',
          sourceId: returnNo,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.update({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId,
            skuId: line.skuId,
            batch,
            stockState: fromStockState
          }
        },
        data: { qty: { decrement: qty } }
      });

      // Post to RETURNED_TO_BRAND state for traceability
      await tx.stockLedger.create({
        data: {
          dealerId,
          warehouseId,
          skuId: line.skuId,
          batch,
          stockState: 'RETURNED_TO_BRAND',
          qtyChange: qty,
          sourceType: 'PURCHASE_RETURN',
          sourceId: returnNo,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId,
            warehouseId,
            skuId: line.skuId,
            batch,
            stockState: 'RETURNED_TO_BRAND'
          }
        },
        update: { qty: { increment: qty } },
        create: {
          dealerId,
          warehouseId,
          skuId: line.skuId,
          batch,
          stockState: 'RETURNED_TO_BRAND',
          qty
        }
      });
    }

    return {
      message: `Purchase return ${returnNo} submitted and accepted by ERP as ${erpReturnOrderNo}.`,
      purchaseReturn
    };
  });
}

/**
 * Periodic Physical Stock Count by barcode scanning.
 */
export async function createStockAudit({
  dealerId,
  warehouseId,
  lines = [],
  notes,
  user
}) {
  const warehouse = await prisma.warehouse.findUnique({ where: { id: warehouseId } });
  if (!warehouse || warehouse.dealerId !== dealerId) {
    const err = new Error('Warehouse not found or invalid.');
    err.status = 404;
    throw err;
  }

  const auditNo = `AUD-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

  // Look up book quantities for lines
  const auditLinesData = [];
  for (const line of lines) {
    const skuId = line.skuId;
    const batch = line.batch || 'DEFAULT';
    const countedQty = parseInt(line.countedQty ?? 0, 10);

    const stock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId,
          warehouseId,
          skuId,
          batch,
          stockState: 'AVAILABLE'
        }
      }
    });

    const bookQty = stock ? stock.qty : 0;
    const varianceQty = countedQty - bookQty;

    auditLinesData.push({
      skuId,
      batch,
      bookQty,
      countedQty,
      varianceQty,
      reasonCode: line.reasonCode || (varianceQty === 0 ? null : 'COUNTING_VARIANCE'),
      notes: line.notes || null
    });
  }

  const audit = await prisma.stockAudit.create({
    data: {
      dealerId,
      warehouseId,
      auditNo,
      status: 'PENDING_APPROVAL',
      notes: notes ? String(notes).trim() : null,
      conductedByEmail: user?.email || null,
      lines: {
        create: auditLinesData
      }
    },
    include: {
      lines: { include: { sku: true } },
      warehouse: true
    }
  });

  return {
    message: `Physical stock count ${auditNo} registered. Awaiting Dealer Owner approval.`,
    audit
  };
}

/**
 * Approve physical stock audit adjustment.
 */
export async function approveStockAuditTransaction({
  auditId,
  decision = 'APPROVE',
  rejectionReason,
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const audit = await tx.stockAudit.findUnique({
      where: { id: auditId },
      include: { lines: { include: { sku: true } }, warehouse: true }
    });

    if (!audit) {
      const err = new Error('Stock audit not found.');
      err.status = 404;
      throw err;
    }

    if (audit.status !== 'PENDING_APPROVAL') {
      const err = new Error(`Cannot review audit in ${audit.status} status.`);
      err.status = 400;
      throw err;
    }

    if (decision === 'REJECT') {
      const updated = await tx.stockAudit.update({
        where: { id: auditId },
        data: {
          status: 'REJECTED',
          rejectionReason: rejectionReason || 'Rejected by Dealer Owner'
        }
      });
      return { message: 'Stock audit rejected.', audit: updated };
    }

    // Approve & post adjustments
    for (const line of audit.lines) {
      if (line.varianceQty !== 0) {
        // Post adjustment to StockLedger
        await tx.stockLedger.create({
          data: {
            dealerId: audit.dealerId,
            warehouseId: audit.warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'AVAILABLE',
            qtyChange: line.varianceQty,
            sourceType: 'PHYSICAL_AUDIT_ADJUSTMENT',
            sourceId: audit.auditNo,
            createdByEmail: user?.email || null
          }
        });

        // Set StockOnHand to exact physical counted quantity
        await tx.stockOnHand.upsert({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId: audit.dealerId,
              warehouseId: audit.warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'AVAILABLE'
            }
          },
          update: {
            qty: line.countedQty
          },
          create: {
            dealerId: audit.dealerId,
            warehouseId: audit.warehouseId,
            skuId: line.skuId,
            batch: line.batch,
            stockState: 'AVAILABLE',
            qty: line.countedQty
          }
        });
      }
    }

    const updated = await tx.stockAudit.update({
      where: { id: auditId },
      data: {
        status: 'APPROVED',
        approvedByEmail: user?.email || null,
        approvedAt: new Date()
      },
      include: { lines: { include: { sku: true } }, warehouse: true }
    });

    return {
      message: `Stock audit ${audit.auditNo} approved and adjustments posted to ledger.`,
      audit: updated
    };
  });
}

/**
 * One-time opening stock initialization at go-live.
 */
export async function initializeOpeningStockTransaction({
  dealerId,
  warehouseId,
  lines = [],
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const warehouse = await tx.warehouse.findUnique({ where: { id: warehouseId } });
    if (!warehouse || warehouse.dealerId !== dealerId) {
      const err = new Error('Warehouse not found.');
      err.status = 404;
      throw err;
    }

    // Check if normal ASNs already exist for dealer
    const existingAsn = await tx.asn.findFirst({
      where: { dealerId, status: { in: ['RECEIVED', 'RECEIVED_WITH_VARIANCE'] } }
    });
    if (existingAsn) {
      const err = new Error('Opening stock can only be recorded at go-live before regular inward shipments.');
      err.status = 400;
      throw err;
    }

    for (const line of lines) {
      const qty = parseInt(line.qty, 10);
      const batch = line.batch || 'OPENING-BATCH';

      if (qty > 0) {
        await tx.stockLedger.create({
          data: {
            dealerId,
            warehouseId,
            skuId: line.skuId,
            batch,
            stockState: 'AVAILABLE',
            qtyChange: qty,
            sourceType: 'OPENING_STOCK',
            sourceId: 'GO_LIVE_INIT',
            inwardDate: new Date(),
            createdByEmail: user?.email || null
          }
        });

        await tx.stockOnHand.upsert({
          where: {
            dealerId_warehouseId_skuId_batch_stockState: {
              dealerId,
              warehouseId,
              skuId: line.skuId,
              batch,
              stockState: 'AVAILABLE'
            }
          },
          update: { qty: { increment: qty } },
          create: {
            dealerId,
            warehouseId,
            skuId: line.skuId,
            batch,
            stockState: 'AVAILABLE',
            qty,
            inwardDate: new Date()
          }
        });
      }
    }

    return { message: 'Go-live opening stock posted successfully to ledger.' };
  });
}

/**
 * Calculates inventory ageing by inward date, slow/non-moving flags, and reorder suggestions.
 */
export async function calculateInventoryAgeingAndReorders({ dealerId, warehouseId }) {
  const where = { dealerId };
  if (warehouseId) where.warehouseId = warehouseId;

  const [stockItems, configs, allSkus] = await Promise.all([
    prisma.stockOnHand.findMany({
      where,
      include: {
        sku: true,
        warehouse: { select: { id: true, code: true, name: true } }
      }
    }),
    prisma.dealerSkuConfig.findMany({ where: { dealerId } }),
    prisma.sku.findMany({ where: { isActive: true } })
  ]);

  const minStockMap = new Map();
  configs.forEach((c) => minStockMap.set(c.skuId, c.minStock));

  const now = Date.now();
  const ageingBuckets = {
    '0_30': { label: '0–30 Days', qty: 0, count: 0 },
    '31_60': { label: '31–60 Days', qty: 0, count: 0 },
    '61_90': { label: '61–90 Days (Slow)', qty: 0, count: 0 },
    '90_plus': { label: '90+ Days (Non-Moving)', qty: 0, count: 0 }
  };

  const enrichedStock = [];
  const skuTotalAvailable = new Map();

  for (const item of stockItems) {
    const ageDays = Math.max(0, Math.floor((now - new Date(item.inwardDate).getTime()) / (1000 * 60 * 60 * 24)));
    let bucket = '0_30';
    if (ageDays > 90) bucket = '90_plus';
    else if (ageDays > 60) bucket = '61_90';
    else if (ageDays > 30) bucket = '31_60';

    if (item.stockState === 'AVAILABLE') {
      ageingBuckets[bucket].qty += item.qty;
      ageingBuckets[bucket].count += 1;
      skuTotalAvailable.set(item.skuId, (skuTotalAvailable.get(item.skuId) || 0) + item.qty);
    }

    enrichedStock.push({
      ...item,
      ageDays,
      ageingBucket: bucket,
      isSlowMoving: ageDays > 60 && ageDays <= 90,
      isNonMoving: ageDays > 90
    });
  }

  // Calculate reorder suggestions for dealer
  const reorderSuggestions = [];
  let totalEstimatedOrderValue = 0;

  for (const sku of allSkus) {
    const minStock = minStockMap.get(sku.id) ?? 10;
    const currentAvailable = skuTotalAvailable.get(sku.id) || 0;

    if (currentAvailable <= minStock) {
      const suggestedQty = Math.max((minStock * 2) - currentAvailable, minStock);
      const landing = sku.landingPrice || (sku.mrp ? sku.mrp * 0.6 : 100);
      const estimatedValue = suggestedQty * landing;
      totalEstimatedOrderValue += estimatedValue;

      reorderSuggestions.push({
        skuId: sku.id,
        skuCode: sku.code,
        skuName: sku.name,
        category: sku.category,
        brand: sku.brand,
        size: sku.size,
        colour: sku.colour,
        currentAvailable,
        minStock,
        suggestedQty,
        landingPrice: landing,
        estimatedValue,
        shortfall: Math.max(0, minStock - currentAvailable)
      });
    }
  }

  return {
    stockItems: enrichedStock,
    ageingBuckets,
    reorderSuggestions,
    totalEstimatedOrderValue,
    slowMovingCount: enrichedStock.filter((i) => i.isSlowMoving).length,
    nonMovingCount: enrichedStock.filter((i) => i.isNonMoving).length
  };
}

