import { prisma } from '../config/database.js';
import { resolvePrice } from './pricing-resolver.service.js';
import {
  calculateInvoiceTaxes,
  INVOICE_ERROR_CODES,
  HEADER_DISCOUNT_REASON_THRESHOLD_PCT
} from '@dms/shared';

/**
 * Computes Indian financial year string for invoice numbering (e.g. 26-27 for 2026-2027)
 */
export function getInvoiceFinancialYear(date = new Date()) {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1-12
  if (month >= 4) {
    const start = String(year).slice(-2);
    const end = String(year + 1).slice(-2);
    return `${start}-${end}`;
  } else {
    const start = String(year - 1).slice(-2);
    const end = String(year).slice(-2);
    return `${start}-${end}`;
  }
}

/**
 * Verifies that the invoice date is strictly today (no back-dating or future-dating).
 */
export function validateInvoiceDateIsToday(dateInput) {
  if (!dateInput) return new Date();
  const d = new Date(dateInput);
  const now = new Date();
  const isSameDay =
    d.getUTCFullYear() === now.getUTCFullYear() &&
    d.getUTCMonth() === now.getUTCMonth() &&
    d.getUTCDate() === now.getUTCDate();

  if (!isSameDay) {
    const err = new Error(
      `Invoice date must be today (${now.toISOString().slice(0, 10)}). Back-dating or future-dating secondary invoices is strictly prohibited.`
    );
    err.status = 400;
    err.code = 'INVALID_INVOICE_DATE';
    throw err;
  }
  return d;
}

/**
 * Obtains the next gapless sequence number for a dealer in a given financial year.
 * Employs a row-level lock on the sequence table to ensure strictly gapless monotonically increasing numbers.
 */
export async function getNextInvoiceSequence(dealerId, financialYear, tx = prisma) {
  // Use upsert query with row lock
  const sequenceRecord = await tx.$queryRaw`
    INSERT INTO dealer_invoice_sequences (id, dealer_id, financial_year, current_value, updated_at)
    VALUES (gen_random_uuid(), ${dealerId}::uuid, ${financialYear}, 1, NOW())
    ON CONFLICT (dealer_id, financial_year)
    DO UPDATE SET current_value = dealer_invoice_sequences.current_value + 1, updated_at = NOW()
    RETURNING current_value;
  `;

  if (sequenceRecord && sequenceRecord.length > 0) {
    return sequenceRecord[0].current_value;
  }

  // Fallback if queryRaw returns empty
  const count = await tx.invoice.count({
    where: { dealerId, financialYear }
  });
  return count + 1;
}

/**
 * Previews billing calculation for selected orders and quantities.
 * Does not write to the database.
 */
export async function previewInvoiceCalculation({
  dealerId,
  retailerId,
  orderIds = [],
  billedItems = [], // [{ orderLineId, qty }]
  headerDiscountPct = 0,
  headerDiscountAmount = 0,
  headerDiscountReason = '',
  date = new Date(),
  tx = prisma
}) {
  if (!dealerId) throw new Error('dealerId is required.');
  if (!retailerId) throw new Error('retailerId is required.');
  if (!orderIds || orderIds.length === 0) throw new Error('At least one order must be selected.');

  // 1. Fetch dealer & retailer
  const [dealer, retailer] = await Promise.all([
    tx.dealer.findUnique({ where: { id: dealerId } }),
    tx.retailer.findUnique({ where: { id: retailerId }, include: { geoNode: true } })
  ]);

  if (!dealer) throw new Error('Dealer not found.');
  if (!retailer) throw new Error('Retailer not found.');
  if (retailer.dealerId !== dealerId) throw new Error('Retailer does not belong to this dealership.');

  // 2. Fetch approved/partially billed orders
  const orders = await tx.order.findMany({
    where: {
      id: { in: orderIds },
      dealerId,
      retailerId,
      status: { in: ['APPROVED', 'PARTIALLY_BILLED'] }
    },
    include: {
      lines: {
        include: { sku: true }
      },
      warehouse: true
    }
  });

  if (orders.length === 0) {
    const err = new Error('No eligible APPROVED or PARTIALLY_BILLED orders found for this retailer.');
    err.status = 400;
    throw err;
  }

  // Map order lines
  const allOrderLines = [];
  orders.forEach((o) => {
    o.lines.forEach((l) => {
      allOrderLines.push({
        ...l,
        orderNo: o.orderNo,
        warehouseId: o.warehouseId
      });
    });
  });

  const orderLineMap = new Map();
  allOrderLines.forEach((ol) => orderLineMap.set(ol.id, ol));

  // 3. Load approved price rules to re-verify price validity
  const approvedRules = await tx.priceRule.findMany({
    where: { priceList: { status: 'APPROVED' } },
    include: { priceList: true }
  });

  // Load HSN masters to resolve gst rates
  const hsns = await tx.hsn.findMany();
  const hsnMap = new Map();
  hsns.forEach((h) => hsnMap.set(h.code, h.gstRate));

  // 4. Process lines and propose quantities
  const proposedBilledLines = [];
  const billedQtyMap = new Map();
  if (billedItems && billedItems.length > 0) {
    billedItems.forEach((bi) => billedQtyMap.set(bi.orderLineId, bi.qty));
  }

  for (const ol of allOrderLines) {
    const reservedStock = ol.reservedQty;
    if (reservedStock <= 0) continue; // No stock reserved to bill

    const requestedQty = billedQtyMap.has(ol.id)
      ? parseInt(billedQtyMap.get(ol.id), 10)
      : reservedStock; // Propose all reserved stock by default

    if (isNaN(requestedQty) || requestedQty <= 0) {
      continue; // User reduced to 0 (excluded from this invoice)
    }

    if (requestedQty > reservedStock) {
      const err = new Error(
        `Quantity for SKU ${ol.sku.code} (${requestedQty}) exceeds reserved inventory (${reservedStock}).`
      );
      err.status = 400;
      err.code = INVOICE_ERROR_CODES.EXCEEDS_RESERVED_QTY;
      throw err;
    }

    // Re-verify price rule exists using resolvePrice
    const priceResolution = resolvePrice(
      {
        retailer,
        sku: ol.sku,
        date,
        landingPrice: ol.sku.landingPrice,
        rules: approvedRules
      },
      approvedRules
    );

    if (priceResolution.error || priceResolution.price == null) {
      const err = new Error(
        `Price rule for SKU "${ol.sku.code} - ${ol.sku.name}" no longer exists or is not approved. Invoicing is blocked.`
      );
      err.status = 400;
      err.code = INVOICE_ERROR_CODES.RULE_NOT_FOUND;
      throw err;
    }

    // Resolve GST Rate from SKU HSN
    let gstRate = 18.0; // Standard fallback
    if (ol.sku.hsnCode && hsnMap.has(ol.sku.hsnCode)) {
      gstRate = hsnMap.get(ol.sku.hsnCode);
    }

    proposedBilledLines.push({
      orderLineId: ol.id,
      orderId: ol.orderId,
      orderNo: ol.orderNo,
      skuId: ol.skuId,
      skuCode: ol.sku.code,
      skuName: ol.sku.name,
      hsnCode: ol.sku.hsnCode || '87082900',
      gstRate,
      qty: requestedQty,
      maxBillableQty: reservedStock,
      unitPrice: ol.unitPrice, // Strictly locked to order price!
      ruleId: ol.ruleId || priceResolution.ruleId
    });
  }

  if (proposedBilledLines.length === 0) {
    const err = new Error('No billable quantities specified. All lines have 0 or unreserved quantity.');
    err.status = 400;
    err.code = INVOICE_ERROR_CODES.NO_LINES;
    throw err;
  }

  // 5. Run pure tax calculation & discount pro-rating
  const taxCalculation = calculateInvoiceTaxes({
    lines: proposedBilledLines,
    dealerStateCode: dealer.stateCode,
    retailerStateCode: retailer.stateCode,
    headerDiscountPct,
    headerDiscountAmount,
    maxHeaderDiscountPct: dealer.maxHeaderDiscountPct,
    headerDiscountReason
  });

  return {
    dealer,
    retailer,
    orders,
    ...taxCalculation
  };
}

/**
 * Creates and posts a secondary tax invoice in ONE atomic database transaction.
 *
 * Rules:
 * - Validates invoice date is today (no back-dating).
 * - Generates gapless sequence number per dealer per FY.
 * - Re-prices and verifies rule existence (locked to order unitPrice).
 * - Applies capped header discount and pro-rates before tax.
 * - Calculates intra/inter state GST split and rounds to nearest rupee.
 * - Consumes RESERVED stock via StockLedger (-RESERVED, NO change to AVAILABLE).
 * - Updates order lines billedQty & reservedQty; updates Order status to PARTIALLY_BILLED or FULLY_BILLED.
 * - Posts debit LedgerEntry on retailer ledger.
 */
export async function createInvoiceTransaction({
  dealerId,
  retailerId,
  orderIds = [],
  billedItems = [],
  headerDiscountPct = 0,
  headerDiscountAmount = 0,
  headerDiscountReason = '',
  invoiceDate = new Date(),
  notes,
  user
}) {
  // 1. Enforce today's invoice date
  const validatedDate = validateInvoiceDateIsToday(invoiceDate);

  return await prisma.$transaction(async (tx) => {
    // 2. Compute preview & validate rules inside the transaction
    const preview = await previewInvoiceCalculation({
      dealerId,
      retailerId,
      orderIds,
      billedItems,
      headerDiscountPct,
      headerDiscountAmount,
      headerDiscountReason,
      date: validatedDate,
      tx
    });

    const { dealer, retailer, lines: calculatedLines } = preview;
    const fy = getInvoiceFinancialYear(validatedDate);

    // 3. Generate Gapless Sequence Number
    const seq = await getNextInvoiceSequence(dealer.id, fy, tx);
    const invoiceNo = `${dealer.code}/${fy}/${String(seq).padStart(6, '0')}`;

    // Warehouse resolution (from first order)
    const warehouseId = preview.orders[0]?.warehouseId || null;

    // 4. Create Invoice Header
    const invoice = await tx.invoice.create({
      data: {
        dealerId: dealer.id,
        retailerId: retailer.id,
        invoiceNo,
        financialYear: fy,
        invoiceDate: validatedDate,
        orderIds: orderIds,
        warehouseId,
        status: 'ISSUED',
        grossAmount: preview.grossAmount,
        headerDiscountAmount: preview.headerDiscountAmount,
        headerDiscountPct: preview.headerDiscountPct || null,
        headerDiscountReason: preview.headerDiscountReason || null,
        taxableTotal: preview.taxableTotal,
        cgstTotal: preview.cgstTotal,
        sgstTotal: preview.sgstTotal,
        igstTotal: preview.igstTotal,
        taxTotal: preview.taxTotal,
        rounding: preview.rounding,
        netTotal: preview.netTotal,
        notes: notes || null,
        createdByEmail: user?.email || null,
        lines: {
          create: calculatedLines.map((l) => ({
            orderLineId: l.orderLineId,
            orderId: l.orderId,
            skuId: l.skuId,
            qty: l.qty,
            unitPrice: l.unitPrice,
            ruleId: l.ruleId || null,
            hsnCode: l.hsnCode,
            gstRate: l.gstRate,
            grossAmount: l.grossAmount,
            discountShare: l.discountShare,
            taxableValue: l.taxableValue,
            cgstAmount: l.cgstAmount,
            sgstAmount: l.sgstAmount,
            igstAmount: l.igstAmount,
            lineTax: l.lineTax,
            lineTotal: l.lineTotal
          }))
        }
      },
      include: {
        lines: { include: { sku: true } },
        dealer: true,
        retailer: true,
        warehouse: true
      }
    });

    // 5. Consume RESERVED stock via append-only ledger (-RESERVED, NO change to AVAILABLE)
    for (const line of calculatedLines) {
      if (line.qty <= 0) continue;

      // Find reserved stock on hand batches for this warehouse and SKU
      const reservedBatches = await tx.stockOnHand.findMany({
        where: {
          dealerId: dealer.id,
          warehouseId,
          skuId: line.skuId,
          stockState: 'RESERVED',
          qty: { gt: 0 }
        },
        orderBy: { batch: 'asc' }
      });

      let remainingToConsume = line.qty;

      for (const b of reservedBatches) {
        if (remainingToConsume <= 0) break;
        const consumeFromBatch = Math.min(remainingToConsume, b.qty);

        if (consumeFromBatch > 0) {
          // Append StockLedger entry
          await tx.stockLedger.create({
            data: {
              dealerId: dealer.id,
              warehouseId,
              skuId: line.skuId,
              batch: b.batch,
              stockState: 'RESERVED',
              qtyChange: -consumeFromBatch,
              sourceType: 'INVOICE_CONSUME',
              sourceId: invoiceNo,
              createdByEmail: user?.email || null
            }
          });

          // Decrement RESERVED in StockOnHand (AVAILABLE remains unchanged!)
          await tx.stockOnHand.update({
            where: {
              dealerId_warehouseId_skuId_batch_stockState: {
                dealerId: dealer.id,
                warehouseId,
                skuId: line.skuId,
                batch: b.batch,
                stockState: 'RESERVED'
              }
            },
            data: {
              qty: { decrement: consumeFromBatch }
            }
          });

          remainingToConsume -= consumeFromBatch;
        }
      }
    }

    // 6. Update Order Lines and Order Statuses
    const affectedOrderIds = new Set();

    for (const line of calculatedLines) {
      await tx.orderLine.update({
        where: { id: line.orderLineId },
        data: {
          billedQty: { increment: line.qty },
          reservedQty: { decrement: line.qty }
        }
      });
      affectedOrderIds.add(line.orderId);
    }

    // Re-evaluate status of each affected order
    for (const ordId of affectedOrderIds) {
      const orderLines = await tx.orderLine.findMany({
        where: { orderId: ordId }
      });

      const allFullyBilled = orderLines.every((ol) => ol.billedQty >= ol.orderedQty);
      const someBilled = orderLines.some((ol) => ol.billedQty > 0);

      const nextStatus = allFullyBilled
        ? 'FULLY_BILLED'
        : (someBilled ? 'PARTIALLY_BILLED' : 'APPROVED');

      await tx.order.update({
        where: { id: ordId },
        data: { status: nextStatus }
      });
    }

    // 7. Create Debit LedgerEntry on Retailer Ledger
    await tx.ledgerEntry.create({
      data: {
        dealerId: dealer.id,
        retailerId: retailer.id,
        type: 'INVOICE',
        debit: preview.netTotal,
        credit: 0.0,
        refType: 'INVOICE',
        refId: invoice.id,
        date: validatedDate,
        notes: `Secondary Tax Invoice ${invoiceNo} against order(s) ${preview.orders.map((o) => o.orderNo).join(', ')}`,
        createdByEmail: user?.email || null
      }
    });

    return invoice;
  });
}

/**
 * Same-Day Invoice Cancellation.
 *
 * Rules:
 * - Allowed ONLY on the same calendar day of issuance.
 * - Reverses stock (-RESERVED consumed is restored to +RESERVED).
 * - Reverts order lines (billedQty decreased, reservedQty restored).
 * - Re-evaluates order status back to APPROVED or PARTIALLY_BILLED.
 * - Creates a credit LedgerEntry on the retailer ledger.
 */
export async function cancelInvoiceTransaction({
  invoiceId,
  reason,
  user
}) {
  if (!reason || !reason.trim()) {
    const err = new Error('Reason is required to cancel an invoice.');
    err.status = 400;
    throw err;
  }

  return await prisma.$transaction(async (tx) => {
    const invoice = await tx.invoice.findUnique({
      where: { id: invoiceId },
      include: {
        lines: true,
        dealer: true,
        retailer: true
      }
    });

    if (!invoice) {
      const err = new Error('Invoice not found.');
      err.status = 404;
      throw err;
    }

    if (invoice.status === 'CANCELLED') {
      return { invoice, message: 'Invoice is already cancelled.' };
    }

    // Check same-day cancellation rule
    const invDateStr = new Date(invoice.invoiceDate).toISOString().slice(0, 10);
    const todayStr = new Date().toISOString().slice(0, 10);

    if (invDateStr !== todayStr) {
      const err = new Error(
        `Invoice cancellation is strictly permitted only on the same day (${invDateStr}). Past-date cancellation requires a Credit Note.`
      );
      err.status = 400;
      err.code = INVOICE_ERROR_CODES.SAME_DAY_CANCEL_ONLY;
      throw err;
    }

    // 1. Mark Invoice as CANCELLED
    const cancelledInvoice = await tx.invoice.update({
      where: { id: invoice.id },
      data: {
        status: 'CANCELLED',
        cancelledAt: new Date(),
        cancelledByEmail: user?.email || null,
        cancelledReason: reason.trim()
      }
    });

    // 2. Restore RESERVED stock consumed by this invoice
    const warehouseId = invoice.warehouseId;
    const consumedLedgers = await tx.stockLedger.findMany({
      where: {
        dealerId: invoice.dealerId,
        sourceType: 'INVOICE_CONSUME',
        sourceId: invoice.invoiceNo,
        stockState: 'RESERVED'
      }
    });

    for (const entry of consumedLedgers) {
      const qtyToRestore = Math.abs(entry.qtyChange);
      if (qtyToRestore <= 0) continue;

      // Append StockLedger entry restoring RESERVED
      await tx.stockLedger.create({
        data: {
          dealerId: invoice.dealerId,
          warehouseId,
          skuId: entry.skuId,
          batch: entry.batch,
          stockState: 'RESERVED',
          qtyChange: qtyToRestore,
          sourceType: 'INVOICE_CANCEL_RESTORE',
          sourceId: invoice.invoiceNo,
          createdByEmail: user?.email || null
        }
      });

      // Increment RESERVED in StockOnHand
      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: invoice.dealerId,
            warehouseId,
            skuId: entry.skuId,
            batch: entry.batch,
            stockState: 'RESERVED'
          }
        },
        update: {
          qty: { increment: qtyToRestore }
        },
        create: {
          dealerId: invoice.dealerId,
          warehouseId,
          skuId: entry.skuId,
          batch: entry.batch,
          stockState: 'RESERVED',
          qty: qtyToRestore
        }
      });
    }

    // 3. Revert Order Line quantities and Order Statuses
    const affectedOrderIds = new Set();

    for (const line of invoice.lines) {
      if (line.orderLineId) {
        await tx.orderLine.update({
          where: { id: line.orderLineId },
          data: {
            billedQty: { decrement: line.qty },
            reservedQty: { increment: line.qty }
          }
        });
      }
      if (line.orderId) {
        affectedOrderIds.add(line.orderId);
      }
    }

    for (const ordId of affectedOrderIds) {
      const orderLines = await tx.orderLine.findMany({
        where: { orderId: ordId }
      });

      const allFullyBilled = orderLines.every((ol) => ol.billedQty >= ol.orderedQty);
      const someBilled = orderLines.some((ol) => ol.billedQty > 0);

      const revertedStatus = allFullyBilled
        ? 'FULLY_BILLED'
        : (someBilled ? 'PARTIALLY_BILLED' : 'APPROVED');

      await tx.order.update({
        where: { id: ordId },
        data: { status: revertedStatus }
      });
    }

    // 4. Create Reversal Credit Entry on Retailer Ledger
    await tx.ledgerEntry.create({
      data: {
        dealerId: invoice.dealerId,
        retailerId: invoice.retailerId,
        type: 'CREDIT_NOTE',
        debit: 0.0,
        credit: invoice.netTotal,
        refType: 'INVOICE_CANCEL',
        refId: invoice.id,
        date: new Date(),
        notes: `Reversal for cancelled Invoice ${invoice.invoiceNo}: ${reason.trim()}`,
        createdByEmail: user?.email || null
      }
    });

    return {
      invoice: cancelledInvoice,
      message: `Invoice ${invoice.invoiceNo} successfully cancelled. Stock and ledger entries reversed.`
    };
  });
}

