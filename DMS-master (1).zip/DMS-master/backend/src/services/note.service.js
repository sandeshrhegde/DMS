import { prisma } from '../config/database.js';
import {
  NOTE_TYPES,
  NOTE_REASON_CODES,
  NOTE_STATUSES,
  NOTE_ERROR_CODES,
  DEFAULT_NOTE_APPROVAL_THRESHOLD,
  getFinancialYear,
  calculateSalesReturnReversal,
  calculateFinancialNote,
  checkNoteApprovalRequirement,
  validateQuarantineInspection
} from '@dms/shared';
import { allocatePaymentFifo } from '@dms/shared';
import { getRetailerOpenInvoices } from './collection.service.js';

/**
 * Gapless sequence generator for Credit Notes (CN) per dealer per FY.
 */
export async function getNextCreditNoteSequence(dealerId, financialYear, tx = prisma) {
  const sequenceRecord = await tx.$queryRaw`
    INSERT INTO dealer_credit_note_sequences (id, dealer_id, financial_year, current_value, updated_at)
    VALUES (gen_random_uuid(), ${dealerId}::uuid, ${financialYear}, 1, NOW())
    ON CONFLICT (dealer_id, financial_year)
    DO UPDATE SET current_value = dealer_credit_note_sequences.current_value + 1, updated_at = NOW()
    RETURNING current_value;
  `;

  if (sequenceRecord && sequenceRecord.length > 0) {
    return sequenceRecord[0].current_value;
  }

  const count = await tx.note.count({
    where: {
      dealerId,
      financialYear,
      type: { in: [NOTE_TYPES.CREDIT_SALES_RETURN, NOTE_TYPES.CREDIT_FINANCIAL] }
    }
  });
  return count + 1;
}

/**
 * Gapless sequence generator for Debit Notes (DN) per dealer per FY.
 */
export async function getNextDebitNoteSequence(dealerId, financialYear, tx = prisma) {
  const sequenceRecord = await tx.$queryRaw`
    INSERT INTO dealer_debit_note_sequences (id, dealer_id, financial_year, current_value, updated_at)
    VALUES (gen_random_uuid(), ${dealerId}::uuid, ${financialYear}, 1, NOW())
    ON CONFLICT (dealer_id, financial_year)
    DO UPDATE SET current_value = dealer_debit_note_sequences.current_value + 1, updated_at = NOW()
    RETURNING current_value;
  `;

  if (sequenceRecord && sequenceRecord.length > 0) {
    return sequenceRecord[0].current_value;
  }

  const count = await tx.note.count({
    where: {
      dealerId,
      financialYear,
      type: NOTE_TYPES.DEBIT
    }
  });
  return count + 1;
}

/**
 * Helper to fetch an invoice with returnable quantity details per line.
 */
export async function getInvoiceReturnableDetails(dealerId, invoiceId, tx = prisma) {
  const invoice = await tx.invoice.findFirst({
    where: {
      id: invoiceId,
      dealerId
    },
    include: {
      dealer: true,
      retailer: true,
      lines: {
        include: {
          sku: true
        }
      }
    }
  });

  if (!invoice) {
    const err = new Error('Invoice not found.');
    err.code = NOTE_ERROR_CODES.INVOICE_NOT_FOUND;
    err.status = 404;
    throw err;
  }

  // Get all active note lines against this invoice
  const activeNoteLines = await tx.noteLine.findMany({
    where: {
      invoiceLineId: { in: invoice.lines.map((l) => l.id) },
      note: {
        dealerId,
        refInvoiceId: invoice.id,
        status: { in: [NOTE_STATUSES.DRAFT, NOTE_STATUSES.PENDING_APPROVAL, NOTE_STATUSES.APPROVED] }
      }
    }
  });

  const returnedQtyByLineId = new Map();
  for (const nl of activeNoteLines) {
    const current = returnedQtyByLineId.get(nl.invoiceLineId) || 0;
    returnedQtyByLineId.set(nl.invoiceLineId, current + nl.qty);
  }

  const linesWithLimits = invoice.lines.map((line) => {
    const cumulativeReturned = returnedQtyByLineId.get(line.id) || 0;
    const maxReturnableQty = Math.max(0, line.qty - cumulativeReturned);
    return {
      ...line,
      cumulativeReturnedQty: cumulativeReturned,
      maxReturnableQty
    };
  });

  return {
    invoice,
    lines: linesWithLimits
  };
}

/**
 * Creates a Sales Return Credit Note in a single atomic transaction.
 * Follows exact tax reversal, quarantine stock posting, and approval threshold rules.
 */
export async function createSalesReturnNoteTransaction({
  dealerId,
  retailerId,
  invoiceId,
  reasonCode = NOTE_REASON_CODES.RETURN_DAMAGED,
  lines = [],
  notes = '',
  user
}) {
  return await prisma.$transaction(async (tx) => {
    // 1. Fetch dealer settings and validate threshold
    const dealer = await tx.dealer.findUnique({
      where: { id: dealerId }
    });
    if (!dealer) {
      const err = new Error('Dealer not found.');
      err.status = 404;
      throw err;
    }

    // 2. Fetch invoice and compute return limits
    const { invoice, lines: invoiceLines } = await getInvoiceReturnableDetails(dealerId, invoiceId, tx);

    if (invoice.retailerId !== retailerId) {
      const err = new Error('Invoice does not belong to the selected retailer.');
      err.status = 400;
      throw err;
    }

    if (invoice.status !== 'ISSUED') {
      const err = new Error(`Cannot return against invoice with status '${invoice.status}'. Must be ISSUED.`);
      err.status = 400;
      throw err;
    }

    // Build map for maxReturnableQty check
    const returnableMap = new Map();
    invoiceLines.forEach((l) => returnableMap.set(l.id, l.maxReturnableQty));

    const enrichedLines = lines.map((req) => ({
      ...req,
      maxReturnableQty: returnableMap.get(req.invoiceLineId)
    }));

    // 3. Compute exact tax reversal
    const calculation = calculateSalesReturnReversal({
      requestedLines: enrichedLines,
      originalInvoice: invoice,
      dealerStateCode: dealer.stateCode,
      retailerStateCode: invoice.retailer.stateCode
    });

    const threshold = dealer.noteApprovalThreshold ?? DEFAULT_NOTE_APPROVAL_THRESHOLD;
    const { requiresApproval, initialStatus } = checkNoteApprovalRequirement({
      totalAmount: calculation.totalAmount,
      threshold
    });

    const isAutoApproved = initialStatus === NOTE_STATUSES.APPROVED;
    const financialYear = getFinancialYear();
    const nextSeq = await getNextCreditNoteSequence(dealerId, financialYear, tx);
    const noteNo = `CN-${financialYear}-${String(nextSeq).padStart(4, '0')}`;

    // 4. Resolve target warehouse (from invoice or dealer default)
    let warehouseId = invoice.warehouseId;
    if (!warehouseId) {
      const defaultWh = await tx.warehouse.findFirst({
        where: { dealerId, isDefault: true }
      }) || await tx.warehouse.findFirst({
        where: { dealerId }
      });
      warehouseId = defaultWh?.id || null;
    }

    // 5. Create Note record
    const createdNote = await tx.note.create({
      data: {
        dealerId,
        retailerId,
        noteNo,
        financialYear,
        type: NOTE_TYPES.CREDIT_SALES_RETURN,
        reasonCode,
        status: initialStatus,
        refInvoiceId: invoice.id,
        isTaxable: true,
        grossAmount: calculation.grossAmount,
        discountAmount: calculation.discountAmount,
        taxableAmount: calculation.taxableAmount,
        gstRate: calculation.lines[0]?.gstRate || 0,
        cgstAmount: calculation.cgstAmount,
        sgstAmount: calculation.sgstAmount,
        igstAmount: calculation.igstAmount,
        taxAmount: calculation.taxAmount,
        rounding: calculation.rounding,
        totalAmount: calculation.totalAmount,
        balanceAmount: isAutoApproved ? calculation.totalAmount : 0.0,
        allocatedAmount: 0.0,
        requiresApproval,
        approvedByEmail: isAutoApproved ? (user?.email || 'AUTO_APPROVED') : null,
        approvedAt: isAutoApproved ? new Date() : null,
        createdByEmail: user?.email || null,
        notes: notes || null,
        lines: {
          create: calculation.lines.map((l) => ({
            invoiceLineId: l.invoiceLineId,
            skuId: l.skuId,
            batch: l.batch,
            qty: l.qty,
            unitPrice: l.unitPrice,
            hsnCode: l.hsnCode,
            gstRate: l.gstRate,
            grossAmount: l.grossAmount,
            discountShare: l.discountShare,
            taxableValue: l.taxableValue,
            cgstAmount: l.cgstAmount,
            sgstAmount: l.sgstAmount,
            igstAmount: l.igstAmount,
            lineTax: l.lineTax,
            lineTotal: l.lineTotal,
            quarantinedQty: isAutoApproved ? l.qty : 0,
            inspectedGoodQty: 0,
            inspectedDamagedQty: 0,
            isInspected: false
          }))
        }
      },
      include: {
        lines: { include: { sku: true } },
        retailer: true,
        dealer: true,
        refInvoice: true
      }
    });

    // 6. If auto-approved, post stock to QUARANTINE and credit retailer ledger
    if (isAutoApproved) {
      if (warehouseId) {
        for (const line of createdNote.lines) {
          // Append to StockLedger (QUARANTINE)
          await tx.stockLedger.create({
            data: {
              dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'QUARANTINE',
              qtyChange: line.qty,
              sourceType: 'SALES_RETURN',
              sourceId: createdNote.id,
              createdByEmail: user?.email || null
            }
          });

          // Upsert StockOnHand
          await tx.stockOnHand.upsert({
            where: {
              dealerId_warehouseId_skuId_batch_stockState: {
                dealerId,
                warehouseId,
                skuId: line.skuId,
                batch: line.batch,
                stockState: 'QUARANTINE'
              }
            },
            update: {
              qty: { increment: line.qty }
            },
            create: {
              dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'QUARANTINE',
              qty: line.qty
            }
          });

          // Mark line quarantinedQty
          await tx.noteLine.update({
            where: { id: line.id },
            data: { quarantinedQty: line.qty }
          });
        }
      }

      // Retailer Ledger Entry (CREDIT)
      await tx.ledgerEntry.create({
        data: {
          dealerId,
          retailerId,
          type: 'CREDIT_NOTE',
          debit: 0.0,
          credit: createdNote.totalAmount,
          refType: 'CREDIT_NOTE',
          refId: createdNote.id,
          date: new Date(),
          notes: `Sales return ${noteNo} against invoice ${invoice.invoiceNo} (${reasonCode})`,
          createdByEmail: user?.email || null
        }
      });
    }

    return createdNote;
  });
}

/**
 * Creates a Financial Credit Note or Debit Note.
 */
export async function createFinancialNoteTransaction({
  dealerId,
  retailerId,
  type = NOTE_TYPES.CREDIT_FINANCIAL,
  reasonCode = NOTE_REASON_CODES.SCHEME_BENEFIT,
  amount,
  isTaxable = false,
  gstRate = 18.0,
  notes = '',
  user
}) {
  return await prisma.$transaction(async (tx) => {
    if (![NOTE_TYPES.CREDIT_FINANCIAL, NOTE_TYPES.DEBIT].includes(type)) {
      const err = new Error(`Invalid financial note type: ${type}`);
      err.code = NOTE_ERROR_CODES.INVALID_NOTE_TYPE;
      err.status = 400;
      throw err;
    }

    const dealer = await tx.dealer.findUnique({ where: { id: dealerId } });
    if (!dealer) {
      const err = new Error('Dealer not found.');
      err.status = 404;
      throw err;
    }

    const retailer = await tx.retailer.findFirst({
      where: { id: retailerId, dealerId }
    });
    if (!retailer) {
      const err = new Error('Retailer not found.');
      err.status = 404;
      throw err;
    }

    const calculation = calculateFinancialNote({
      type,
      amount,
      isTaxable,
      gstRate,
      dealerStateCode: dealer.stateCode,
      retailerStateCode: retailer.stateCode
    });

    const threshold = dealer.noteApprovalThreshold ?? DEFAULT_NOTE_APPROVAL_THRESHOLD;
    const { requiresApproval, initialStatus } = checkNoteApprovalRequirement({
      totalAmount: calculation.totalAmount,
      threshold
    });

    const isAutoApproved = initialStatus === NOTE_STATUSES.APPROVED;
    const financialYear = getFinancialYear();

    let noteNo;
    if (type === NOTE_TYPES.DEBIT) {
      const nextSeq = await getNextDebitNoteSequence(dealerId, financialYear, tx);
      noteNo = `DN-${financialYear}-${String(nextSeq).padStart(4, '0')}`;
    } else {
      const nextSeq = await getNextCreditNoteSequence(dealerId, financialYear, tx);
      noteNo = `CN-${financialYear}-${String(nextSeq).padStart(4, '0')}`;
    }

    const createdNote = await tx.note.create({
      data: {
        dealerId,
        retailerId,
        noteNo,
        financialYear,
        type,
        reasonCode,
        status: initialStatus,
        refInvoiceId: null,
        isTaxable: calculation.isTaxable,
        grossAmount: calculation.grossAmount,
        discountAmount: calculation.discountAmount,
        taxableAmount: calculation.taxableAmount,
        gstRate: calculation.gstRate,
        cgstAmount: calculation.cgstAmount,
        sgstAmount: calculation.sgstAmount,
        igstAmount: calculation.igstAmount,
        taxAmount: calculation.taxAmount,
        rounding: calculation.rounding,
        totalAmount: calculation.totalAmount,
        balanceAmount: (isAutoApproved && type !== NOTE_TYPES.DEBIT) ? calculation.totalAmount : 0.0,
        allocatedAmount: 0.0,
        requiresApproval,
        approvedByEmail: isAutoApproved ? (user?.email || 'AUTO_APPROVED') : null,
        approvedAt: isAutoApproved ? new Date() : null,
        createdByEmail: user?.email || null,
        notes: notes || null
      },
      include: {
        retailer: true,
        dealer: true
      }
    });

    // If auto-approved, post to retailer ledger
    if (isAutoApproved) {
      if (type === NOTE_TYPES.DEBIT) {
        await tx.ledgerEntry.create({
          data: {
            dealerId,
            retailerId,
            type: 'DEBIT_NOTE',
            debit: createdNote.totalAmount,
            credit: 0.0,
            refType: 'DEBIT_NOTE',
            refId: createdNote.id,
            date: new Date(),
            notes: `Debit Note ${noteNo} (${reasonCode})${notes ? ` - ${notes}` : ''}`,
            createdByEmail: user?.email || null
          }
        });
      } else {
        await tx.ledgerEntry.create({
          data: {
            dealerId,
            retailerId,
            type: 'CREDIT_NOTE',
            debit: 0.0,
            credit: createdNote.totalAmount,
            refType: 'CREDIT_NOTE',
            refId: createdNote.id,
            date: new Date(),
            notes: `Financial Credit Note ${noteNo} (${reasonCode})${notes ? ` - ${notes}` : ''}`,
            createdByEmail: user?.email || null
          }
        });
      }
    }

    return createdNote;
  });
}

/**
 * Approves a note in PENDING_APPROVAL status.
 * Accessible only by DEALER_OWNER or BRAND_ADMIN.
 * Posts stock to QUARANTINE and retailer LedgerEntry atomically.
 */
export async function approveNoteTransaction({ noteId, dealerId, user }) {
  return await prisma.$transaction(async (tx) => {
    const note = await tx.note.findUnique({
      where: { id: noteId },
      include: {
        lines: true,
        dealer: true,
        retailer: true,
        refInvoice: true
      }
    });

    if (!note) {
      const err = new Error('Note not found.');
      err.status = 404;
      throw err;
    }

    if (dealerId && note.dealerId !== dealerId && user?.role !== 'BRAND_ADMIN') {
      const err = new Error('Access denied: Note belongs to another dealership.');
      err.status = 403;
      throw err;
    }

    if (note.status !== NOTE_STATUSES.PENDING_APPROVAL) {
      const err = new Error(`Only notes with status 'PENDING_APPROVAL' can be approved (current: ${note.status}).`);
      err.status = 400;
      throw err;
    }

    const now = new Date();

    // 1. Update note status
    const updatedNote = await tx.note.update({
      where: { id: note.id },
      data: {
        status: NOTE_STATUSES.APPROVED,
        approvedByEmail: user?.email || 'DEALER_OWNER',
        approvedAt: now,
        balanceAmount: note.type !== NOTE_TYPES.DEBIT ? note.totalAmount : 0.0
      },
      include: {
        lines: { include: { sku: true } },
        retailer: true,
        dealer: true,
        refInvoice: true
      }
    });

    // 2. Post stock for sales return
    if (note.type === NOTE_TYPES.CREDIT_SALES_RETURN) {
      let warehouseId = note.refInvoice?.warehouseId;
      if (!warehouseId) {
        const defaultWh = await tx.warehouse.findFirst({
          where: { dealerId: note.dealerId, isDefault: true }
        }) || await tx.warehouse.findFirst({
          where: { dealerId: note.dealerId }
        });
        warehouseId = defaultWh?.id || null;
      }

      if (warehouseId) {
        for (const line of note.lines) {
          await tx.stockLedger.create({
            data: {
              dealerId: note.dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'QUARANTINE',
              qtyChange: line.qty,
              sourceType: 'SALES_RETURN',
              sourceId: note.id,
              createdByEmail: user?.email || null
            }
          });

          await tx.stockOnHand.upsert({
            where: {
              dealerId_warehouseId_skuId_batch_stockState: {
                dealerId: note.dealerId,
                warehouseId,
                skuId: line.skuId,
                batch: line.batch,
                stockState: 'QUARANTINE'
              }
            },
            update: {
              qty: { increment: line.qty }
            },
            create: {
              dealerId: note.dealerId,
              warehouseId,
              skuId: line.skuId,
              batch: line.batch,
              stockState: 'QUARANTINE',
              qty: line.qty
            }
          });

          await tx.noteLine.update({
            where: { id: line.id },
            data: { quarantinedQty: line.qty }
          });
        }
      }

      // Retailer Ledger Entry
      await tx.ledgerEntry.create({
        data: {
          dealerId: note.dealerId,
          retailerId: note.retailerId,
          type: 'CREDIT_NOTE',
          debit: 0.0,
          credit: note.totalAmount,
          refType: 'CREDIT_NOTE',
          refId: note.id,
          date: now,
          notes: `Sales return ${note.noteNo} against invoice ${note.refInvoice?.invoiceNo || 'N/A'} (Approved)`,
          createdByEmail: user?.email || null
        }
      });
    } else if (note.type === NOTE_TYPES.CREDIT_FINANCIAL) {
      await tx.ledgerEntry.create({
        data: {
          dealerId: note.dealerId,
          retailerId: note.retailerId,
          type: 'CREDIT_NOTE',
          debit: 0.0,
          credit: note.totalAmount,
          refType: 'CREDIT_NOTE',
          refId: note.id,
          date: now,
          notes: `Financial Credit Note ${note.noteNo} (${note.reasonCode}) (Approved)`,
          createdByEmail: user?.email || null
        }
      });
    } else if (note.type === NOTE_TYPES.DEBIT) {
      await tx.ledgerEntry.create({
        data: {
          dealerId: note.dealerId,
          retailerId: note.retailerId,
          type: 'DEBIT_NOTE',
          debit: note.totalAmount,
          credit: 0.0,
          refType: 'DEBIT_NOTE',
          refId: note.id,
          date: now,
          notes: `Debit Note ${note.noteNo} (${note.reasonCode}) (Approved)`,
          createdByEmail: user?.email || null
        }
      });
    }

    return updatedNote;
  });
}

/**
 * Rejects a note in PENDING_APPROVAL status.
 */
export async function rejectNoteTransaction({ noteId, dealerId, reason = 'Rejected by approver', user }) {
  return await prisma.$transaction(async (tx) => {
    const note = await tx.note.findUnique({ where: { id: noteId } });
    if (!note) {
      const err = new Error('Note not found.');
      err.status = 404;
      throw err;
    }

    if (dealerId && note.dealerId !== dealerId && user?.role !== 'BRAND_ADMIN') {
      const err = new Error('Access denied: Note belongs to another dealership.');
      err.status = 403;
      throw err;
    }

    if (note.status !== NOTE_STATUSES.PENDING_APPROVAL) {
      const err = new Error(`Only notes with status 'PENDING_APPROVAL' can be rejected (current: ${note.status}).`);
      err.status = 400;
      throw err;
    }

    return await tx.note.update({
      where: { id: note.id },
      data: {
        status: NOTE_STATUSES.CANCELLED,
        rejectionReason: reason,
        cancelledAt: new Date(),
        cancelledByEmail: user?.email || null,
        cancelledReason: `Rejected: ${reason}`
      }
    });
  });
}

/**
 * Allocates an approved credit note against open invoices (FIFO or manual).
 */
export async function allocateCreditNoteTransaction({
  noteId,
  dealerId,
  allocations = [],
  autoAllocateFifo = true,
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const note = await tx.note.findUnique({
      where: { id: noteId },
      include: { retailer: true, dealer: true }
    });

    if (!note) {
      const err = new Error('Credit Note not found.');
      err.status = 404;
      throw err;
    }

    if (dealerId && note.dealerId !== dealerId) {
      const err = new Error('Access denied: Note belongs to another dealership.');
      err.status = 403;
      throw err;
    }

    if (note.type === NOTE_TYPES.DEBIT) {
      const err = new Error('Debit notes cannot be allocated to invoices.');
      err.status = 400;
      throw err;
    }

    if (note.status !== NOTE_STATUSES.APPROVED) {
      const err = new Error(`Only APPROVED notes can be allocated (current: ${note.status}).`);
      err.status = 400;
      throw err;
    }

    const availableCredit = note.balanceAmount || 0;
    if (availableCredit <= 0.009) {
      const err = new Error('This credit note has already been fully allocated.');
      err.status = 400;
      throw err;
    }

    const openInvoices = await getRetailerOpenInvoices(note.dealerId, note.retailerId, tx);

    let resolvedAllocations = [];
    if (autoAllocateFifo) {
      const fifoResult = allocatePaymentFifo(availableCredit, openInvoices);
      resolvedAllocations = fifoResult.allocations;
    } else {
      let requestedTotal = 0;
      for (const a of allocations) {
        const amt = Math.round(Number(a.amount || 0) * 100) / 100;
        if (amt <= 0) continue;

        const inv = openInvoices.find((i) => i.id === a.invoiceId);
        if (!inv) {
          const err = new Error(`Invoice ${a.invoiceId} is not an open eligible invoice for this retailer.`);
          err.status = 400;
          throw err;
        }

        if (amt > (inv.openBalance + 0.009)) {
          const err = new Error(`Allocation ₹${amt} exceeds open balance ₹${inv.openBalance} on invoice ${inv.invoiceNo}.`);
          err.status = 400;
          throw err;
        }

        requestedTotal += amt;
        resolvedAllocations.push({
          invoiceId: inv.id,
          invoiceNo: inv.invoiceNo,
          amount: amt
        });
      }

      if (requestedTotal > (availableCredit + 0.009)) {
        const err = new Error(
          `Total manual allocation of ₹${requestedTotal.toFixed(2)} exceeds available note balance of ₹${availableCredit.toFixed(2)}.`
        );
        err.status = 400;
        throw err;
      }
    }

    if (resolvedAllocations.length === 0) {
      const err = new Error('No open invoices available for allocation.');
      err.status = 400;
      throw err;
    }

    let totalAllocatedNow = 0;
    for (const alloc of resolvedAllocations) {
      totalAllocatedNow += alloc.amount;

      // Create NoteAllocation
      await tx.noteAllocation.create({
        data: {
          noteId: note.id,
          invoiceId: alloc.invoiceId,
          amount: alloc.amount
        }
      });

      // Update invoice paid amount
      const currentInvoice = await tx.invoice.findUnique({
        where: { id: alloc.invoiceId }
      });
      if (currentInvoice) {
        const newPaidAmount = Math.round((currentInvoice.paidAmount + alloc.amount) * 100) / 100;
        const newStatus =
          newPaidAmount >= (currentInvoice.netTotal - 0.01)
            ? 'PAID'
            : 'PARTIALLY_PAID';

        await tx.invoice.update({
          where: { id: currentInvoice.id },
          data: {
            paidAmount: newPaidAmount,
            paymentStatus: newStatus
          }
        });
      }
    }

    totalAllocatedNow = Math.round(totalAllocatedNow * 100) / 100;
    const newAllocatedTotal = Math.round((note.allocatedAmount + totalAllocatedNow) * 100) / 100;
    const newBalance = Math.max(0, Math.round((note.totalAmount - newAllocatedTotal) * 100) / 100);

    const updatedNote = await tx.note.update({
      where: { id: note.id },
      data: {
        allocatedAmount: newAllocatedTotal,
        balanceAmount: newBalance
      },
      include: {
        allocations: { include: { invoice: true } }
      }
    });

    return updatedNote;
  });
}

/**
 * Quarantine resolution: inspects quarantined stock and moves it to AVAILABLE or DAMAGED.
 */
export async function inspectQuarantineStockTransaction({
  dealerId,
  noteId,
  noteLineId,
  warehouseId,
  goodQty = 0,
  damagedQty = 0,
  notes = '',
  user
}) {
  return await prisma.$transaction(async (tx) => {
    const note = await tx.note.findUnique({
      where: { id: noteId },
      include: {
        lines: { include: { sku: true } },
        refInvoice: true
      }
    });

    if (!note) {
      const err = new Error('Note not found.');
      err.status = 404;
      throw err;
    }

    if (dealerId && note.dealerId !== dealerId) {
      const err = new Error('Access denied: Note belongs to another dealership.');
      err.status = 403;
      throw err;
    }

    if (note.type !== NOTE_TYPES.CREDIT_SALES_RETURN) {
      const err = new Error('Quarantine inspection is only applicable to Sales Return notes.');
      err.status = 400;
      throw err;
    }

    if (note.status !== NOTE_STATUSES.APPROVED) {
      const err = new Error('Note must be APPROVED to inspect quarantined stock.');
      err.status = 400;
      throw err;
    }

    const noteLine = note.lines.find((l) => l.id === noteLineId);
    if (!noteLine) {
      const err = new Error('Note line not found.');
      err.status = 404;
      throw err;
    }

    const inspectedSoFar = noteLine.inspectedGoodQty + noteLine.inspectedDamagedQty;
    const pendingQuarantineQty = Math.max(0, noteLine.quarantinedQty - inspectedSoFar);

    if (pendingQuarantineQty <= 0) {
      const err = new Error('This note line has already been fully inspected.');
      err.code = NOTE_ERROR_CODES.ALREADY_INSPECTED;
      err.status = 400;
      throw err;
    }

    const validated = validateQuarantineInspection({
      pendingQuarantineQty,
      goodQty,
      damagedQty
    });

    // Resolve warehouse
    let targetWhId = warehouseId || note.refInvoice?.warehouseId;
    if (!targetWhId) {
      const defaultWh = await tx.warehouse.findFirst({
        where: { dealerId: note.dealerId, isDefault: true }
      }) || await tx.warehouse.findFirst({
        where: { dealerId: note.dealerId }
      });
      targetWhId = defaultWh?.id;
    }

    if (!targetWhId) {
      const err = new Error('Warehouse is required for stock inspection posting.');
      err.status = 400;
      throw err;
    }

    // 1. Record QuarantineInspection
    const inspection = await tx.quarantineInspection.create({
      data: {
        dealerId: note.dealerId,
        noteId: note.id,
        noteLineId: noteLine.id,
        warehouseId: targetWhId,
        skuId: noteLine.skuId,
        batch: noteLine.batch,
        goodQty: validated.good,
        damagedQty: validated.damaged,
        inspectedByEmail: user?.email || null,
        notes: notes || null
      }
    });

    // 2. Post Good Qty: QUARANTINE -> AVAILABLE
    if (validated.good > 0) {
      await tx.stockLedger.create({
        data: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'QUARANTINE',
          qtyChange: -validated.good,
          sourceType: 'QUARANTINE_RELEASE',
          sourceId: inspection.id,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: note.dealerId,
            warehouseId: targetWhId,
            skuId: noteLine.skuId,
            batch: noteLine.batch,
            stockState: 'QUARANTINE'
          }
        },
        update: {
          qty: { decrement: validated.good }
        },
        create: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'QUARANTINE',
          qty: -validated.good
        }
      });

      await tx.stockLedger.create({
        data: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'AVAILABLE',
          qtyChange: validated.good,
          sourceType: 'QUARANTINE_RELEASE',
          sourceId: inspection.id,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: note.dealerId,
            warehouseId: targetWhId,
            skuId: noteLine.skuId,
            batch: noteLine.batch,
            stockState: 'AVAILABLE'
          }
        },
        update: {
          qty: { increment: validated.good }
        },
        create: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'AVAILABLE',
          qty: validated.good
        }
      });
    }

    // 3. Post Damaged Qty: QUARANTINE -> DAMAGED
    if (validated.damaged > 0) {
      await tx.stockLedger.create({
        data: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'QUARANTINE',
          qtyChange: -validated.damaged,
          sourceType: 'QUARANTINE_DAMAGE',
          sourceId: inspection.id,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: note.dealerId,
            warehouseId: targetWhId,
            skuId: noteLine.skuId,
            batch: noteLine.batch,
            stockState: 'QUARANTINE'
          }
        },
        update: {
          qty: { decrement: validated.damaged }
        },
        create: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'QUARANTINE',
          qty: -validated.damaged
        }
      });

      await tx.stockLedger.create({
        data: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'DAMAGED',
          qtyChange: validated.damaged,
          sourceType: 'QUARANTINE_DAMAGE',
          sourceId: inspection.id,
          createdByEmail: user?.email || null
        }
      });

      await tx.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: note.dealerId,
            warehouseId: targetWhId,
            skuId: noteLine.skuId,
            batch: noteLine.batch,
            stockState: 'DAMAGED'
          }
        },
        update: {
          qty: { increment: validated.damaged }
        },
        create: {
          dealerId: note.dealerId,
          warehouseId: targetWhId,
          skuId: noteLine.skuId,
          batch: noteLine.batch,
          stockState: 'DAMAGED',
          qty: validated.damaged
        }
      });
    }

    // 4. Update NoteLine inspection counts
    const newGood = noteLine.inspectedGoodQty + validated.good;
    const newDamaged = noteLine.inspectedDamagedQty + validated.damaged;
    const isInspected = (newGood + newDamaged) >= noteLine.quarantinedQty;

    const updatedLine = await tx.noteLine.update({
      where: { id: noteLine.id },
      data: {
        inspectedGoodQty: newGood,
        inspectedDamagedQty: newDamaged,
        isInspected
      }
    });

    return {
      inspection,
      updatedLine
    };
  });
}

/**
 * Lists notes with filtering and pagination.
 */
export async function getNotesList({
  dealerId,
  retailerId,
  type,
  status,
  search,
  page = 1,
  limit = 25
}) {
  const where = {};
  if (dealerId) where.dealerId = dealerId;
  if (retailerId) where.retailerId = retailerId;
  if (type) where.type = type;
  if (status) where.status = status;

  if (search) {
    where.OR = [
      { noteNo: { contains: search, mode: 'insensitive' } },
      { retailer: { legalName: { contains: search, mode: 'insensitive' } } },
      { retailer: { tradeName: { contains: search, mode: 'insensitive' } } }
    ];
  }

  const skip = (Math.max(1, parseInt(page, 10)) - 1) * parseInt(limit, 10);
  const take = parseInt(limit, 10);

  const [total, notes] = await Promise.all([
    prisma.note.count({ where }),
    prisma.note.findMany({
      where,
      skip,
      take,
      orderBy: { createdAt: 'desc' },
      include: {
        retailer: true,
        refInvoice: true,
        lines: { include: { sku: true } }
      }
    })
  ]);

  return {
    notes,
    pagination: {
      total,
      page: parseInt(page, 10),
      limit: take,
      totalPages: Math.ceil(total / take)
    }
  };
}

/**
 * Gets details of a single note.
 */
export async function getNoteById(id, dealerId) {
  const where = { id };
  if (dealerId) where.dealerId = dealerId;

  const note = await prisma.note.findFirst({
    where,
    include: {
      retailer: true,
      dealer: true,
      refInvoice: {
        include: {
          lines: { include: { sku: true } }
        }
      },
      lines: {
        include: {
          sku: true,
          invoiceLine: true
        }
      },
      allocations: {
        include: {
          invoice: true
        }
      },
      quarantineInspections: {
        include: {
          warehouse: true
        }
      }
    }
  });

  return note;
}

/**
 * Lists stock currently in quarantine for inspection.
 */
export async function getPendingQuarantineLines(dealerId) {
  const noteLines = await prisma.noteLine.findMany({
    where: {
      note: {
        dealerId,
        status: NOTE_STATUSES.APPROVED,
        type: NOTE_TYPES.CREDIT_SALES_RETURN
      },
      isInspected: false,
      quarantinedQty: { gt: 0 }
    },
    include: {
      sku: true,
      note: {
        include: {
          retailer: true,
          refInvoice: true
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  });

  return noteLines.map((line) => {
    const inspected = line.inspectedGoodQty + line.inspectedDamagedQty;
    const pendingQty = Math.max(0, line.quarantinedQty - inspected);
    return {
      ...line,
      pendingQty
    };
  }).filter((line) => line.pendingQty > 0);
}
