import { env } from './env.js';

// Loading Prisma only when a database URL exists lets low-resource development
// environments run the mock API without a local PostgreSQL installation.
export let prisma = null;

export async function initializeDatabase() {
  if (!env.databaseEnabled) return false;

  const { PrismaClient } = await import('@prisma/client');
  prisma = new PrismaClient({
    log: env.nodeEnv === 'development' ? ['warn', 'error'] : ['error']
  });
  await prisma.$queryRaw`SELECT 1`;
  return true;
}

export async function disconnectDatabase() {
  if (prisma) await prisma.$disconnect();
}
