import 'dotenv/config';

const databaseMode = process.env.DATABASE_MODE ?? 'auto';

export const env = {
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 4000),
  databaseUrl: process.env.DATABASE_URL,
  databaseEnabled: databaseMode !== 'mock' && Boolean(process.env.DATABASE_URL),
  corsOrigins: (process.env.CORS_ORIGIN ?? 'http://localhost:5173').split(',').map((origin) => origin.trim())
};
