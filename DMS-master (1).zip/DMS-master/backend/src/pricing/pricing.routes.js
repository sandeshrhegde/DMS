import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, requireBrandAdmin } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  resolvePrice,
  validateGuardrails,
  calculatePriceFromRule
} from '../services/pricing-resolver.service.js';

export const pricingRouter = Router();

/**
 * Middleware ensuring user is authenticated.
 */
function ensureAuthenticated(req, res, next) {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  req.currentUser = user;
  next();
}

pricingRouter.use(ensureAuthenticated);

/**
 * Helper to fetch global minMarginPct setting.
 */
async function getMinMarginPct() {
  try {
    const setting = await prisma.systemSetting.findUnique({
      where: { key: 'minMarginPct' }
    });
    if (setting && !isNaN(parseFloat(setting.value))) {
      return parseFloat(setting.value);
    }
  } catch (err) {
    // fallback
  }
  return 10.0;
}

/**
 * Helper to fetch retailer enriched with ancestor GeoNodes.
 */
async function getEnrichedRetailer(retailerId) {
  const retailer = await prisma.retailer.findUnique({
    where: { id: retailerId },
    include: {
      geoNode: true
    }
  });
  if (!retailer) return null;

  const geoAncestors = {
    clusterId: null,
    clusterName: null,
    cityId: null,
    cityName: null,
    regionId: null,
    regionName: null,
    stateId: null,
    stateName: null,
    zoneId: null,
    zoneName: null
  };

  if (retailer.geoNode) {
    let curr = retailer.geoNode;
    while (curr) {
      const type = curr.type?.toUpperCase();
      if (type === 'CLUSTER') {
        geoAncestors.clusterId = curr.id;
        geoAncestors.clusterName = curr.name;
      } else if (type === 'CITY') {
        geoAncestors.cityId = curr.id;
        geoAncestors.cityName = curr.name;
      } else if (type === 'REGION') {
        geoAncestors.regionId = curr.id;
        geoAncestors.regionName = curr.name;
      } else if (type === 'STATE') {
        geoAncestors.stateId = curr.id;
        geoAncestors.stateName = curr.name;
      } else if (type === 'ZONE') {
        geoAncestors.zoneId = curr.id;
        geoAncestors.zoneName = curr.name;
      }

      if (curr.parentId) {
        curr = await prisma.geoNode.findUnique({ where: { id: curr.parentId } });
      } else {
        curr = null;
      }
    }
  }

  return {
    ...retailer,
    clusterId: geoAncestors.clusterId || retailer.geoNodeId,
    cityId: geoAncestors.cityId,
    regionId: geoAncestors.regionId,
    stateId: geoAncestors.stateId,
    zoneId: geoAncestors.zoneId,
    geoAncestors
  };
}

/**
 * GET /api/pricing/settings
 * Retrieves global pricing settings (e.g. minMarginPct).
 */
pricingRouter.get('/settings', async (req, res, next) => {
  try {
    const minMarginPct = await getMinMarginPct();
    res.json({ minMarginPct });
  } catch (error) {
    next(error);
  }
});

/**
 * PATCH /api/pricing/settings
 * Updates global pricing settings (BRAND_ADMIN only).
 */
pricingRouter.patch('/settings', requireBrandAdmin, async (req, res, next) => {
  try {
    const { minMarginPct } = req.body;
    if (minMarginPct === undefined || isNaN(parseFloat(minMarginPct))) {
      return res.status(400).json({ error: 'Valid minMarginPct number is required.' });
    }

    const val = parseFloat(minMarginPct);
    if (val < 0 || val > 100) {
      return res.status(400).json({ error: 'minMarginPct must be between 0 and 100.' });
    }

    const setting = await prisma.systemSetting.upsert({
      where: { key: 'minMarginPct' },
      update: { value: String(val) },
      create: {
        key: 'minMarginPct',
        value: String(val),
        description: 'Configured global minimum margin % over landing price'
      }
    });

    res.json({ minMarginPct: parseFloat(setting.value) });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/resolve (and /pricing/resolve)
 * Resolves secondary price for a given retailer and SKU on a specified date.
 * Uses the pure resolvePrice function.
 */
pricingRouter.post('/resolve', async (req, res, next) => {
  try {
    const { retailerId, skuId, date = new Date(), landingPrice, retailer: directRetailer, sku: directSku } = req.body;

    let targetRetailer = directRetailer;
    if (!targetRetailer && retailerId) {
      targetRetailer = await getEnrichedRetailer(retailerId);
      if (!targetRetailer) {
        return res.status(404).json({ error: 'Retailer not found.' });
      }
    }

    let targetSku = directSku;
    if (!targetSku && skuId) {
      targetSku = await prisma.sku.findUnique({
        where: { id: skuId }
      });
      if (!targetSku) {
        return res.status(404).json({ error: 'SKU not found.' });
      }
    }

    if (!targetRetailer || !targetSku) {
      return res.status(400).json({
        error: 'Both retailer (or retailerId) and sku (or skuId) are required.'
      });
    }

    // Load all approved price rules for this SKU
    const dbRules = await prisma.priceRule.findMany({
      where: {
        skuId: targetSku.id,
        priceList: {
          status: 'APPROVED'
        }
      },
      include: {
        priceList: {
          select: {
            id: true,
            name: true,
            version: true,
            status: true,
            validFrom: true,
            validTo: true
          }
        }
      }
    });

    const targetDate = new Date(date);
    const resolution = resolvePrice({
      retailer: targetRetailer,
      sku: targetSku,
      date: targetDate,
      landingPrice: landingPrice !== undefined ? parseFloat(landingPrice) : targetSku.landingPrice,
      rules: dbRules
    });

    if (resolution.error) {
      return res.json({
        status: 'NO_PRICE',
        error: resolution.error,
        message: resolution.message,
        retailer: { id: targetRetailer.id, name: targetRetailer.legalName || targetRetailer.name },
        sku: { id: targetSku.id, code: targetSku.code, name: targetSku.name, mrp: targetSku.mrp },
        date: targetDate.toISOString()
      });
    }

    const minMarginPct = await getMinMarginPct();
    const guardrailCheck = validateGuardrails({
      method: resolution.method,
      value: resolution.value,
      sku: targetSku,
      landingPrice: landingPrice !== undefined ? parseFloat(landingPrice) : targetSku.landingPrice,
      minMarginPct
    });

    res.json({
      status: 'RESOLVED',
      price: resolution.price,
      ruleId: resolution.ruleId,
      level: resolution.level,
      method: resolution.method,
      value: resolution.value,
      rule: resolution.rule,
      priceListId: resolution.priceListId,
      guardrailCheck,
      retailer: {
        id: targetRetailer.id,
        name: targetRetailer.legalName || targetRetailer.name,
        retailerClass: targetRetailer.retailerClass,
        channelType: targetRetailer.channelType,
        stateCode: targetRetailer.stateCode,
        cluster: targetRetailer.geoNode?.name || null
      },
      sku: {
        id: targetSku.id,
        code: targetSku.code,
        name: targetSku.name,
        mrp: targetSku.mrp,
        landingPrice: targetSku.landingPrice
      },
      date: targetDate.toISOString()
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/pricing/lists
 * List all price lists with rule count.
 */
pricingRouter.get('/lists', async (req, res, next) => {
  try {
    const { status, search } = req.query;
    const where = {};

    if (status) {
      where.status = status;
    }
    if (search) {
      where.name = { contains: search.trim(), mode: 'insensitive' };
    }

    const priceLists = await prisma.priceList.findMany({
      where,
      include: {
        _count: {
          select: { rules: true }
        }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ priceLists });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists
 * Create draft price list (BRAND_ADMIN only).
 */
pricingRouter.post('/lists', requireBrandAdmin, async (req, res, next) => {
  try {
    const { name, version = 1, validFrom, validTo } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Price list name is required.' });
    }
    if (!validFrom) {
      return res.status(400).json({ error: 'validFrom date is required.' });
    }

    const created = await prisma.priceList.create({
      data: {
        name: name.trim(),
        version: parseInt(version, 10) || 1,
        status: 'DRAFT',
        validFrom: new Date(validFrom),
        validTo: validTo ? new Date(validTo) : null,
        createdById: req.currentUser.id || null,
        createdByEmail: req.currentUser.email
      }
    });

    res.status(201).json(created);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/pricing/lists/:id
 * Retrieve price list with its rules and SKU details.
 */
pricingRouter.get('/lists/:id', async (req, res, next) => {
  try {
    const priceList = await prisma.priceList.findUnique({
      where: { id: req.params.id },
      include: {
        rules: {
          include: {
            sku: {
              select: {
                id: true,
                code: true,
                name: true,
                mrp: true,
                landingPrice: true,
                category: true,
                brand: true
              }
            }
          },
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }

    res.json(priceList);
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/pricing/lists/:id
 * Update price list header. Only permitted when DRAFT.
 */
pricingRouter.put('/lists/:id', requireBrandAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!existing) {
      return res.status(404).json({ error: 'Price list not found.' });
    }
    if (existing.status !== 'DRAFT') {
      return res.status(400).json({
        error: `Only DRAFT price lists can be edited. Current status is ${existing.status}.`
      });
    }

    const { name, version, validFrom, validTo } = req.body;
    const updated = await prisma.priceList.update({
      where: { id: req.params.id },
      data: {
        ...(name && { name: name.trim() }),
        ...(version !== undefined && { version: parseInt(version, 10) || 1 }),
        ...(validFrom && { validFrom: new Date(validFrom) }),
        ...(validTo !== undefined && { validTo: validTo ? new Date(validTo) : null })
      }
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/submit
 * Submit price list for approval (DRAFT -> PENDING_APPROVAL).
 */
pricingRouter.post('/lists/:id/submit', requireBrandAdmin, async (req, res, next) => {
  try {
    const existing = await prisma.priceList.findUnique({
      where: { id: req.params.id },
      include: { _count: { select: { rules: true } } }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Price list not found.' });
    }
    if (existing.status !== 'DRAFT') {
      return res.status(400).json({
        error: `Only DRAFT price lists can be submitted. Current status is ${existing.status}.`
      });
    }
    if (existing._count.rules === 0) {
      return res.status(400).json({
        error: 'Price list must have at least one pricing rule before submitting for approval.'
      });
    }

    const updated = await prisma.priceList.update({
      where: { id: req.params.id },
      data: { status: 'PENDING_APPROVAL', rejectionReason: null }
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/approve
 * Maker–checker requirement: the creator cannot approve their own price list.
 */
pricingRouter.post('/lists/:id/approve', requireBrandAdmin, async (req, res, next) => {
  try {
    const priceList = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }

    if (priceList.status !== 'PENDING_APPROVAL') {
      return res.status(400).json({
        error: `Only PENDING_APPROVAL price lists can be approved. Current status is ${priceList.status}.`
      });
    }

    // Maker–Checker enforcement
    const approverEmail = req.currentUser.email?.toLowerCase();
    const creatorEmail = priceList.createdByEmail?.toLowerCase();

    if (creatorEmail && approverEmail && creatorEmail === approverEmail) {
      return res.status(403).json({
        error: 'Maker–checker violation: The creator of a price list cannot approve it. Another Brand Admin must review and approve.',
        code: 'MAKER_CHECKER_VIOLATION'
      });
    }

    const approved = await prisma.priceList.update({
      where: { id: req.params.id },
      data: {
        status: 'APPROVED',
        approvedById: req.currentUser.id || null,
        approvedByEmail: req.currentUser.email,
        approvedAt: new Date(),
        rejectionReason: null
      }
    });

    res.json({
      message: 'Price list approved successfully.',
      priceList: approved
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/reject
 * Checker rejects price list back to DRAFT with reason.
 */
pricingRouter.post('/lists/:id/reject', requireBrandAdmin, async (req, res, next) => {
  try {
    const { reason } = req.body;
    if (!reason || !reason.trim()) {
      return res.status(400).json({ error: 'Rejection reason is required.' });
    }

    const priceList = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }

    if (priceList.status !== 'PENDING_APPROVAL') {
      return res.status(400).json({
        error: `Only PENDING_APPROVAL price lists can be rejected. Current status is ${priceList.status}.`
      });
    }

    const rejected = await prisma.priceList.update({
      where: { id: req.params.id },
      data: {
        status: 'DRAFT',
        rejectionReason: reason.trim()
      }
    });

    res.json({
      message: 'Price list returned to DRAFT.',
      priceList: rejected
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/deactivate
 * Deactivate an approved price list.
 */
pricingRouter.post('/lists/:id/deactivate', requireBrandAdmin, async (req, res, next) => {
  try {
    const deactivated = await prisma.priceList.update({
      where: { id: req.params.id },
      data: { status: 'INACTIVE' }
    });
    res.json(deactivated);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/rules
 * Add a price rule with guardrail validation (price <= MRP and >= landingPrice + minMarginPct).
 */
pricingRouter.post('/lists/:id/rules', requireBrandAdmin, async (req, res, next) => {
  try {
    const priceList = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }
    if (priceList.status !== 'DRAFT') {
      return res.status(400).json({
        error: `Rules can only be added to DRAFT price lists. Current status is ${priceList.status}.`
      });
    }

    const {
      skuId,
      targetType,
      targetId,
      method,
      value,
      validFrom,
      validTo
    } = req.body;

    if (!skuId) return res.status(400).json({ error: 'skuId is required.' });
    if (!targetType) return res.status(400).json({ error: 'targetType is required.' });
    if (!method) return res.status(400).json({ error: 'method is required.' });
    if (value === undefined || isNaN(parseFloat(value))) {
      return res.status(400).json({ error: 'Valid numeric value is required.' });
    }

    const sku = await prisma.sku.findUnique({ where: { id: skuId } });
    if (!sku) return res.status(404).json({ error: 'SKU not found.' });

    // Validate Guardrails at save time
    const minMarginPct = await getMinMarginPct();
    const guardrail = validateGuardrails({
      method,
      value: parseFloat(value),
      sku,
      landingPrice: sku.landingPrice,
      minMarginPct
    });

    if (!guardrail.valid) {
      return res.status(400).json({
        error: guardrail.error,
        code: guardrail.code,
        calculatedPrice: guardrail.calculatedPrice,
        minAllowedPrice: guardrail.minAllowedPrice,
        maxAllowedPrice: guardrail.maxAllowedPrice
      });
    }

    const created = await prisma.priceRule.create({
      data: {
        priceListId: priceList.id,
        skuId: sku.id,
        targetType,
        targetId: targetId ? String(targetId).trim() : null,
        method,
        value: parseFloat(value),
        validFrom: validFrom ? new Date(validFrom) : null,
        validTo: validTo ? new Date(validTo) : null
      },
      include: {
        sku: {
          select: {
            id: true,
            code: true,
            name: true,
            mrp: true,
            landingPrice: true
          }
        }
      }
    });

    res.status(201).json({
      rule: created,
      calculatedPrice: guardrail.calculatedPrice
    });
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/pricing/lists/:id/rules/:ruleId
 * Remove a rule from draft price list.
 */
pricingRouter.delete('/lists/:id/rules/:ruleId', requireBrandAdmin, async (req, res, next) => {
  try {
    const priceList = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }
    if (priceList.status !== 'DRAFT') {
      return res.status(400).json({
        error: `Rules can only be removed from DRAFT price lists. Current status is ${priceList.status}.`
      });
    }

    await prisma.priceRule.delete({ where: { id: req.params.ruleId } });
    res.json({ success: true, message: 'Rule deleted.' });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/pricing/lists/:id/rules/csv-import
 * Bulk add rules via CSV with guardrail validation.
 */
pricingRouter.post('/lists/:id/rules/csv-import', requireBrandAdmin, async (req, res, next) => {
  try {
    const priceList = await prisma.priceList.findUnique({ where: { id: req.params.id } });
    if (!priceList) {
      return res.status(404).json({ error: 'Price list not found.' });
    }
    if (priceList.status !== 'DRAFT') {
      return res.status(400).json({
        error: `Rules can only be imported into DRAFT price lists. Current status is ${priceList.status}.`
      });
    }

    const { rows = [], mode = 'skip_bad_rows' } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'Valid rows array is required for CSV import.' });
    }

    // Cache SKUs by code and id
    const allSkus = await prisma.sku.findMany();
    const skuMap = new Map();
    allSkus.forEach((s) => {
      skuMap.set(s.id.toLowerCase(), s);
      skuMap.set(s.code.toLowerCase(), s);
    });

    const minMarginPct = await getMinMarginPct();
    const validRulesToCreate = [];
    const rejectedRows = [];

    rows.forEach((row, index) => {
      const rowNum = index + 1;
      const skuIdentifier = (row.skuCode || row.skuId || '').trim();
      const targetType = (row.targetType || '').trim().toUpperCase();
      const targetId = row.targetId ? String(row.targetId).trim() : null;
      const method = (row.method || '').trim().toUpperCase();
      const valNum = parseFloat(row.value);

      if (!skuIdentifier) {
        rejectedRows.push({ row: rowNum, data: row, reason: 'Missing skuCode or skuId.' });
        return;
      }

      const sku = skuMap.get(skuIdentifier.toLowerCase());
      if (!sku) {
        rejectedRows.push({ row: rowNum, data: row, reason: `SKU '${skuIdentifier}' not found.` });
        return;
      }

      const validTargetTypes = [
        'RETAILER', 'RETAILER_CLASS', 'CLUSTER', 'CITY',
        'REGION', 'STATE', 'ZONE', 'NATIONAL'
      ];
      if (!validTargetTypes.includes(targetType)) {
        rejectedRows.push({ row: rowNum, data: row, reason: `Invalid targetType '${targetType}'.` });
        return;
      }

      if (targetType !== 'NATIONAL' && !targetId) {
        rejectedRows.push({ row: rowNum, data: row, reason: `targetId is required for level '${targetType}'.` });
        return;
      }

      const validMethods = ['FIXED', 'PERCENT_OFF_MRP', 'MARKUP_ON_LANDING'];
      if (!validMethods.includes(method)) {
        rejectedRows.push({ row: rowNum, data: row, reason: `Invalid method '${method}'. Must be FIXED, PERCENT_OFF_MRP, or MARKUP_ON_LANDING.` });
        return;
      }

      if (isNaN(valNum) || valNum <= 0) {
        rejectedRows.push({ row: rowNum, data: row, reason: 'Value must be a positive number.' });
        return;
      }

      // Guardrail validation
      const guardrail = validateGuardrails({
        method,
        value: valNum,
        sku,
        landingPrice: sku.landingPrice,
        minMarginPct
      });

      if (!guardrail.valid) {
        rejectedRows.push({ row: rowNum, data: row, reason: guardrail.error });
        return;
      }

      validRulesToCreate.push({
        priceListId: priceList.id,
        skuId: sku.id,
        targetType,
        targetId: targetType === 'NATIONAL' ? null : targetId,
        method,
        value: valNum,
        validFrom: row.validFrom ? new Date(row.validFrom) : null,
        validTo: row.validTo ? new Date(row.validTo) : null
      });
    });

    if (mode === 'all_or_nothing' && rejectedRows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Import rejected in all-or-nothing mode due to errors.',
        totalRows: rows.length,
        createdCount: 0,
        rejectedCount: rejectedRows.length,
        rejectedRows
      });
    }

    if (validRulesToCreate.length > 0) {
      await prisma.priceRule.createMany({
        data: validRulesToCreate
      });
    }

    res.json({
      success: true,
      message: `Processed ${rows.length} rows. Created: ${validRulesToCreate.length}, Rejected: ${rejectedRows.length}.`,
      totalRows: rows.length,
      createdCount: validRulesToCreate.length,
      rejectedCount: rejectedRows.length,
      rejectedRows
    });
  } catch (error) {
    next(error);
  }
});

