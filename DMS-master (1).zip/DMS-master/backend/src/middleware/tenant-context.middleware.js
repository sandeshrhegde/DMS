/**
 * Resolves the tenant for a request. Authentication will eventually supply
 * req.user.tenantId; the temporary x-tenant-id header only enables early API work.
 */
export function tenantContext(req, res, next) {
  const tenantId = req.user?.tenantId ?? req.get('x-tenant-id');

  if (req.path === '/health') return next();
  if (!tenantId) {
    return res.status(400).json({ error: 'Tenant context is required.' });
  }

  req.tenantId = tenantId;
  return next();
}
