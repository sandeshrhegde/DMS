import { verifyAccessToken } from '../auth/token.service.js';
import { DASHBOARD_ROLES, DEALER_ROLES } from '@dms/shared';

import { prisma } from '../config/database.js';

export function getAuthUser(req) {
  const authHeader = req.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      const token = authHeader.replace(/^Bearer\s+/i, '').trim();
      const decoded = verifyAccessToken(token);
      req.user = decoded;
      return decoded;
    } catch {
      return null;
    }
  }

  const demoRole = req.get('x-demo-role') || req.get('x-user-role') || req.user?.role;
  if (demoRole) {
    return {
      role: demoRole,
      email: req.get('x-demo-email') || req.get('x-user-email') || 'demo@local',
      dealerId: req.get('x-tenant-id') || req.get('x-dealer-id') || req.user?.dealerId || null
    };
  }

  return null;
}

/**
 * Resolves the effective dealerId for the request, supporting:
 * 1. Explicit headers (x-dealer-id, x-tenant-id) or query/body parameters
 * 2. Authenticated user's direct dealerId
 * 3. Lookup in User database table by email
 * 4. Fallback to primary active dealership (DEMO-001 or first active)
 */
export async function resolveRequestDealerId(req, user) {
  let resolvedDealerId =
    req.get('x-dealer-id') ||
    req.get('x-tenant-id') ||
    req.query?.dealerId ||
    req.body?.dealerId ||
    user?.dealerId;

  if (!resolvedDealerId && user?.email && prisma?.user) {
    try {
      const dbUser = await prisma.user.findUnique({
        where: { email: user.email },
        select: { dealerId: true }
      });
      if (dbUser?.dealerId) {
        resolvedDealerId = dbUser.dealerId;
      }
    } catch {
      // Ignore database lookup errors in test environments
    }
  }

  if (!resolvedDealerId && prisma?.dealer) {
    try {
      const defaultDealer =
        (await prisma.dealer.findFirst({ where: { code: 'DEMO-001', isActive: true } })) ||
        (await prisma.dealer.findFirst({ where: { isActive: true }, orderBy: { createdAt: 'asc' } }));
      if (defaultDealer) {
        resolvedDealerId = defaultDealer.id;
      }
    } catch {
      // Ignore database lookup errors in test environments
    }
  }

  return resolvedDealerId || null;
}

/**
 * Middleware requiring BRAND_ADMIN role for any operation.
 */
export function requireBrandAdmin(req, res, next) {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }

  if (user.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
    return res.status(403).json({ error: 'Brand Admin role required.' });
  }

  req.currentUser = user;
  next();
}

/**
 * Middleware allowing dealers and brand admin to read (GET),
 * but restricting writes (POST, PUT, DELETE, PATCH) to BRAND_ADMIN only.
 */
export function allowDealerReadOnly(req, res, next) {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }

  const isWrite = ['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method.toUpperCase());

  if (isWrite) {
    if (user.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(403).json({
        error: 'Brand Admin role required for write operations. Dealers have read-only access.'
      });
    }
  } else {
    // Read operation (GET)
    const allowed = [DASHBOARD_ROLES.BRAND_ADMIN, ...DEALER_ROLES];
    if (!allowed.includes(user.role)) {
      return res.status(403).json({ error: 'Access denied.' });
    }
  }

  req.currentUser = user;
  next();
}

