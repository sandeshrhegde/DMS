import { verifyAccessToken } from '../auth/token.service.js';
export function jwtAuthGuard(req, res, next) {
  const token = req.get('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Authentication required.' });
  try { req.user = verifyAccessToken(token); return next(); } catch { return res.status(401).json({ error: 'Invalid or expired access token.' }); }
}
