export function notFound(req, res) {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
}

export function errorHandler(error, req, res, next) { // eslint-disable-line no-unused-vars
  console.error(error);
  let status = error.statusCode || error.status;
  if (!status && error.code) {
    status = 400;
  }
  if (!status) {
    status = 500;
  }
  res.status(status).json({
    error: error.message || 'Internal server error.',
    code: error.code || undefined
  });
}
