import { env } from '../config/env.js';

export function healthCheck(req, res) {
  res.status(200).json({
    status: 'ok',
    service: 'dms-api',
    database: env.databaseEnabled ? 'configured' : 'mock mode',
    timestamp: new Date().toISOString()
  });
}
