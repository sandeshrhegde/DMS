import { getMockDashboard, getMockTenants } from '../services/mock-dashboard.service.js';

export function getDashboard(req, res) {
  res.status(200).json(getMockDashboard(req.get('x-tenant-id')));
}

export function listMockTenants(req, res) { // eslint-disable-line no-unused-vars
  res.status(200).json({ mode: 'mock', tenants: getMockTenants() });
}
