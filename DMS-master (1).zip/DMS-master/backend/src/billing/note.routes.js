import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, resolveRequestDealerId } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  createSalesReturnNoteTransaction,
  createFinancialNoteTransaction,
  approveNoteTransaction,
  rejectNoteTransaction,
  allocateCreditNoteTransaction,
  inspectQuarantineStockTransaction,
  getNotesList,
  getNoteById,
  getInvoiceReturnableDetails,
  getPendingQuarantineLines
} from '../services/note.service.js';

export const noteRouter = Router();

/**
 * Middleware ensuring user is authenticated and attaching dealer context.
 */
async function ensureAuthenticated(req, res, next) {
  try {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const resolvedDealerId = await resolveRequestDealerId(req, user);
    req.effectiveDealerId = resolvedDealerId;
    if (!user.dealerId && resolvedDealerId) {
      user.dealerId = resolvedDealerId;
    }

    req.currentUser = user;
    next();
  } catch (err) {
    next(err);
  }
}

noteRouter.use(ensureAuthenticated);

/**
 * Helper to resolve target dealerId.
 */
function getTargetDealerId(req) {
  return (
    req.query.dealerId ||
    req.body?.dealerId ||
    req.get('x-dealer-id') ||
    req.get('x-tenant-id') ||
    req.effectiveDealerId ||
    req.currentUser?.dealerId
  );
}

/**
 * GET /notes
 * Lists credit and debit notes with filters.
 */
noteRouter.get('/', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, type, status, search, page, limit } = req.query;
    const result = await getNotesList({
      dealerId,
      retailerId,
      type,
      status,
      search,
      page,
      limit
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /notes/returnable-invoice/:invoiceId
 * Previews an invoice with lines and max returnable quantities.
 */
noteRouter.get('/returnable-invoice/:invoiceId', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { invoiceId } = req.params;
    const details = await getInvoiceReturnableDetails(dealerId, invoiceId);
    res.json(details);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /notes/quarantine/pending
 * Lists stock in QUARANTINE pending inspection.
 */
noteRouter.get('/quarantine/pending', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const pendingLines = await getPendingQuarantineLines(dealerId);
    res.json({ lines: pendingLines });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/quarantine/inspect
 * Inspects quarantined stock, releasing to AVAILABLE or DAMAGED.
 */
noteRouter.post('/quarantine/inspect', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { noteId, noteLineId, warehouseId, goodQty, damagedQty, notes } = req.body;
    if (!noteId || !noteLineId) {
      return res.status(400).json({ error: 'noteId and noteLineId are required.' });
    }

    const result = await inspectQuarantineStockTransaction({
      dealerId,
      noteId,
      noteLineId,
      warehouseId,
      goodQty: parseInt(goodQty || 0, 10),
      damagedQty: parseInt(damagedQty || 0, 10),
      notes,
      user: req.currentUser
    });

    res.json({
      message: 'Quarantine stock inspected and inventory updated successfully.',
      ...result
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /notes/approvals/pending
 * Lists notes requiring approval.
 */
noteRouter.get('/approvals/pending', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const result = await getNotesList({
      dealerId,
      status: 'PENDING_APPROVAL',
      limit: 100
    });

    res.json(result);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/sales-return
 * Creates a sales return credit note.
 */
noteRouter.post('/sales-return', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, invoiceId, reasonCode, lines, notes } = req.body;

    if (!retailerId) {
      return res.status(400).json({ error: 'Retailer ID is required.' });
    }
    if (!invoiceId) {
      return res.status(400).json({ error: 'Referenced Invoice ID is required for sales return.' });
    }
    if (!lines || !Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'At least one return line is required.' });
    }

    const note = await createSalesReturnNoteTransaction({
      dealerId,
      retailerId,
      invoiceId,
      reasonCode,
      lines,
      notes,
      user: req.currentUser
    });

    res.status(201).json({
      message: note.status === 'APPROVED'
        ? `Sales return ${note.noteNo} created and auto-approved.`
        : `Sales return ${note.noteNo} created and pending DEALER_OWNER approval.`,
      note
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/financial
 * Creates a financial credit or debit note.
 */
noteRouter.post('/financial', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, type, reasonCode, amount, isTaxable, gstRate, notes } = req.body;

    if (!retailerId) {
      return res.status(400).json({ error: 'Retailer ID is required.' });
    }
    if (!type) {
      return res.status(400).json({ error: 'Note type (CREDIT_FINANCIAL or DEBIT) is required.' });
    }
    if (!amount || Number(amount) <= 0) {
      return res.status(400).json({ error: 'Valid positive amount is required.' });
    }

    const note = await createFinancialNoteTransaction({
      dealerId,
      retailerId,
      type,
      reasonCode,
      amount: Number(amount),
      isTaxable: Boolean(isTaxable),
      gstRate: Number(gstRate || 18),
      notes,
      user: req.currentUser
    });

    res.status(201).json({
      message: note.status === 'APPROVED'
        ? `${note.type === 'DEBIT' ? 'Debit' : 'Financial Credit'} Note ${note.noteNo} created and auto-approved.`
        : `Note ${note.noteNo} created and pending DEALER_OWNER approval.`,
      note
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/:id/approve
 * Approves a note in PENDING_APPROVAL. Requires DEALER_OWNER or BRAND_ADMIN.
 */
noteRouter.post('/:id/approve', async (req, res, next) => {
  try {
    const { role } = req.currentUser;
    if (role !== DASHBOARD_ROLES.DEALER_OWNER && role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(403).json({
        error: 'Only dealer owners or brand administrators can approve notes.'
      });
    }

    const dealerId = getTargetDealerId(req);
    const { id } = req.params;

    const approvedNote = await approveNoteTransaction({
      noteId: id,
      dealerId,
      user: req.currentUser
    });

    res.json({
      message: `Note ${approvedNote.noteNo} approved successfully and posted to ledger.`,
      note: approvedNote
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/:id/reject
 * Rejects a note in PENDING_APPROVAL. Requires DEALER_OWNER or BRAND_ADMIN.
 */
noteRouter.post('/:id/reject', async (req, res, next) => {
  try {
    const { role } = req.currentUser;
    if (role !== DASHBOARD_ROLES.DEALER_OWNER && role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(403).json({
        error: 'Only dealer owners or brand administrators can reject notes.'
      });
    }

    const dealerId = getTargetDealerId(req);
    const { id } = req.params;
    const { reason } = req.body;

    const rejected = await rejectNoteTransaction({
      noteId: id,
      dealerId,
      reason: reason || 'Rejected by approver',
      user: req.currentUser
    });

    res.json({
      message: `Note ${rejected.noteNo} has been rejected.`,
      note: rejected
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /notes/:id/allocate
 * Allocates an approved credit note to open invoices.
 */
noteRouter.post('/:id/allocate', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { id } = req.params;
    const { allocations = [], autoAllocateFifo = true } = req.body;

    const updatedNote = await allocateCreditNoteTransaction({
      noteId: id,
      dealerId,
      allocations,
      autoAllocateFifo: Boolean(autoAllocateFifo),
      user: req.currentUser
    });

    res.json({
      message: `Credit note ${updatedNote.noteNo} successfully allocated to open invoices.`,
      note: updatedNote
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /notes/:id
 * Fetches full details of a note.
 */
noteRouter.get('/:id', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { id } = req.params;

    const note = await getNoteById(id, dealerId);
    if (!note) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    res.json(note);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /notes/:id/print
 * Formatted printable view data.
 */
noteRouter.get('/:id/print', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { id } = req.params;

    const note = await getNoteById(id, dealerId);
    if (!note) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    const isCredit = note.type !== 'DEBIT';
    const title = isCredit
      ? (note.type === 'CREDIT_SALES_RETURN' ? 'CREDIT NOTE (SALES RETURN)' : 'CREDIT NOTE (FINANCIAL)')
      : 'DEBIT NOTE';

    const printPayload = {
      title,
      noteNo: note.noteNo,
      date: note.date,
      financialYear: note.financialYear,
      type: note.type,
      reasonCode: note.reasonCode,
      status: note.status,
      dealer: {
        name: note.dealer.name,
        code: note.dealer.code,
        gstin: note.dealer.gstin,
        stateCode: note.dealer.stateCode
      },
      retailer: {
        legalName: note.retailer.legalName,
        tradeName: note.retailer.tradeName,
        gstin: note.retailer.gstin,
        pan: note.retailer.pan,
        stateCode: note.retailer.stateCode,
        mobile: note.retailer.mobile,
        billingAddress: note.retailer.billingAddress
      },
      refInvoice: note.refInvoice ? {
        id: note.refInvoice.id,
        invoiceNo: note.refInvoice.invoiceNo,
        invoiceDate: note.refInvoice.invoiceDate,
        netTotal: note.refInvoice.netTotal
      } : null,
      lines: note.lines.map((l) => ({
        skuCode: l.sku?.code,
        skuName: l.sku?.name,
        batch: l.batch,
        qty: l.qty,
        unitPrice: l.unitPrice,
        hsnCode: l.hsnCode,
        gstRate: l.gstRate,
        grossAmount: l.grossAmount,
        discountShare: l.discountShare,
        taxableValue: l.taxableValue,
        cgstAmount: l.cgstAmount,
        sgstAmount: l.sgstAmount,
        igstAmount: l.igstAmount,
        lineTax: l.lineTax,
        lineTotal: l.lineTotal
      })),
      totals: {
        grossAmount: note.grossAmount,
        discountAmount: note.discountAmount,
        taxableAmount: note.taxableAmount,
        cgstAmount: note.cgstAmount,
        sgstAmount: note.sgstAmount,
        igstAmount: note.igstAmount,
        taxAmount: note.taxAmount,
        rounding: note.rounding,
        totalAmount: note.totalAmount,
        allocatedAmount: note.allocatedAmount,
        balanceAmount: note.balanceAmount
      },
      notes: note.notes,
      approval: {
        requiresApproval: note.requiresApproval,
        approvedByEmail: note.approvedByEmail,
        approvedAt: note.approvedAt
      }
    };

    res.json(printPayload);
  } catch (err) {
    next(err);
  }
});

