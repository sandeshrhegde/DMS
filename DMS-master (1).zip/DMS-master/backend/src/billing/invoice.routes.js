import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, resolveRequestDealerId } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  previewInvoiceCalculation,
  createInvoiceTransaction,
  cancelInvoiceTransaction
} from '../services/invoice.service.js';
import {
  createCollectionTransaction,
  bounceChequeTransaction,
  getRetailerLedgerData,
  getDealerOutstandingOverview,
  getRetailerOpenInvoices,
  getCollectionReceiptData
} from '../services/collection.service.js';

export const invoiceRouter = Router();

/**
 * Middleware ensuring user is authenticated and attaching dealer context.
 */
async function ensureAuthenticated(req, res, next) {
  try {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const resolvedDealerId = await resolveRequestDealerId(req, user);
    req.effectiveDealerId = resolvedDealerId;
    if (!user.dealerId && resolvedDealerId) {
      user.dealerId = resolvedDealerId;
    }

    req.currentUser = user;
    next();
  } catch (err) {
    next(err);
  }
}

invoiceRouter.use(ensureAuthenticated);

/**
 * Helper to get the effective dealerId for the request.
 */
function getTargetDealerId(req) {
  return (
    req.query.dealerId ||
    req.body?.dealerId ||
    req.get('x-dealer-id') ||
    req.get('x-tenant-id') ||
    req.effectiveDealerId ||
    req.currentUser?.dealerId
  );
}

/**
 * GET /api/billing/pending-orders
 * List APPROVED or PARTIALLY_BILLED orders with reserved quantities ready for billing.
 */
invoiceRouter.get('/pending-orders', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId } = req.query;
    const where = {
      dealerId,
      status: { in: ['APPROVED', 'PARTIALLY_BILLED'] }
    };
    if (retailerId) {
      where.retailerId = retailerId;
    }

    const orders = await prisma.order.findMany({
      where,
      include: {
        retailer: {
          select: { id: true, legalName: true, tradeName: true, creditLimit: true, stateCode: true }
        },
        warehouse: {
          select: { id: true, code: true, name: true }
        },
        lines: {
          include: { sku: true },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    // Filter to orders that have at least one line with reservedQty > 0
    const billableOrders = orders.filter((o) =>
      o.lines.some((l) => l.reservedQty > 0)
    );

    res.json({ orders: billableOrders });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/billing/calculate
 * Previews billing totals, pro-rated header discount, and GST calculation.
 */
invoiceRouter.post('/calculate', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const {
      retailerId,
      orderIds,
      billedItems,
      headerDiscountPct,
      headerDiscountAmount,
      headerDiscountReason
    } = req.body;

    const calculation = await previewInvoiceCalculation({
      dealerId,
      retailerId,
      orderIds,
      billedItems,
      headerDiscountPct,
      headerDiscountAmount,
      headerDiscountReason,
      date: new Date()
    });

    res.json({ success: true, ...calculation });
  } catch (err) {
    if (err.code || err.status) {
      return res.status(err.status || 400).json({
        error: err.message,
        code: err.code
      });
    }
    next(err);
  }
});

/**
 * POST /api/billing/invoices
 * Issues and posts a tax invoice in one atomic transaction.
 */
invoiceRouter.post('/invoices', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const {
      retailerId,
      orderIds,
      billedItems,
      headerDiscountPct,
      headerDiscountAmount,
      headerDiscountReason,
      invoiceDate,
      notes
    } = req.body;

    const invoice = await createInvoiceTransaction({
      dealerId,
      retailerId,
      orderIds,
      billedItems,
      headerDiscountPct,
      headerDiscountAmount,
      headerDiscountReason,
      invoiceDate: invoiceDate ? new Date(invoiceDate) : new Date(),
      notes,
      user: req.currentUser
    });

    res.status(201).json(invoice);
  } catch (err) {
    if (err.code || err.status) {
      return res.status(err.status || 400).json({
        error: err.message,
        code: err.code
      });
    }
    next(err);
  }
});

/**
 * GET /api/billing/invoices
 * List issued invoices with status, retailer, date, and search filters.
 */
invoiceRouter.get('/invoices', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const explicitDealerId = req.query.dealerId || req.get('x-dealer-id') || req.get('x-tenant-id');
    const targetDealerId = isBrand ? explicitDealerId : (req.effectiveDealerId || req.currentUser.dealerId);

    const {
      status,
      retailerId,
      dateFrom,
      dateTo,
      search,
      page = 1,
      limit = 25
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const take = Math.min(100, Math.max(1, parseInt(limit, 10) || 25));
    const skip = (pageNum - 1) * take;

    const where = {};

    if (!isBrand) {
      if (targetDealerId) where.dealerId = targetDealerId;
    } else if (targetDealerId) {
      where.dealerId = targetDealerId;
    }

    if (status) {
      where.status = status;
    }

    if (retailerId) {
      where.retailerId = retailerId;
    }

    if (dateFrom || dateTo) {
      where.invoiceDate = {};
      if (dateFrom) where.invoiceDate.gte = new Date(dateFrom);
      if (dateTo) {
        const toDate = new Date(dateTo);
        toDate.setHours(23, 59, 59, 999);
        where.invoiceDate.lte = toDate;
      }
    }

    if (search && String(search).trim()) {
      const q = String(search).trim();
      where.OR = [
        { invoiceNo: { contains: q, mode: 'insensitive' } },
        { retailer: { legalName: { contains: q, mode: 'insensitive' } } },
        { retailer: { tradeName: { contains: q, mode: 'insensitive' } } }
      ];
    }

    const [invoices, totalCount] = await Promise.all([
      prisma.invoice.findMany({
        where,
        include: {
          retailer: {
            select: {
              id: true,
              legalName: true,
              tradeName: true,
              gstin: true,
              stateCode: true
            }
          },
          dealer: {
            select: { id: true, code: true, name: true, stateCode: true, maxHeaderDiscountPct: true }
          },
          warehouse: {
            select: { id: true, code: true, name: true }
          },
          _count: {
            select: { lines: true }
          }
        },
        orderBy: { invoiceDate: 'desc' },
        skip,
        take
      }),
      prisma.invoice.count({ where })
    ]);

    res.json({
      invoices: invoices.map((i) => ({
        ...i,
        lineCount: i._count.lines
      })),
      totalCount,
      page: pageNum,
      limit: take,
      totalPages: Math.ceil(totalCount / take)
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/billing/invoices/:id
 * Retrieve invoice details with complete HSN tax breakdown.
 */
invoiceRouter.get('/invoices/:id', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const invoice = await prisma.invoice.findUnique({
      where: { id: req.params.id },
      include: {
        retailer: true,
        dealer: true,
        warehouse: true,
        lines: {
          include: {
            sku: true,
            orderLine: {
              include: { order: true }
            }
          },
          orderBy: { createdAt: 'asc' }
        }
      }
    });

    if (!invoice) {
      return res.status(404).json({ error: 'Invoice not found.' });
    }

    if (!isBrand && invoice.dealerId !== req.currentUser.dealerId) {
      return res.status(403).json({ error: 'Access denied to invoice belonging to another dealership.' });
    }

    res.json(invoice);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/billing/invoices/:id/cancel
 * Cancel invoice (same-day only, reverses stock and ledger entries).
 */
invoiceRouter.post('/invoices/:id/cancel', async (req, res, next) => {
  try {
    const { reason } = req.body;
    const result = await cancelInvoiceTransaction({
      invoiceId: req.params.id,
      reason,
      user: req.currentUser
    });

    res.json(result);
  } catch (err) {
    if (err.code || err.status) {
      return res.status(err.status || 400).json({
        error: err.message,
        code: err.code
      });
    }
    next(err);
  }
});

/**
 * GET /api/billing/retailer-ledger
 * Retailer ledger view displaying debit and credit entries with running balance and ageing.
 */
invoiceRouter.get('/retailer-ledger', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { retailerId } = req.query;

    if (!retailerId) {
      return res.status(400).json({ error: 'retailerId is required.' });
    }

    const ledgerData = await getRetailerLedgerData({
      dealerId,
      retailerId
    });

    res.json(ledgerData);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * GET /api/billing/retailers/:retailerId/ledger
 * Full retailer ledger statement with ageing buckets and running balances.
 */
invoiceRouter.get('/retailers/:retailerId/ledger', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { retailerId } = req.params;

    const ledgerData = await getRetailerLedgerData({
      dealerId,
      retailerId
    });

    res.json(ledgerData);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * GET /api/billing/retailers/:retailerId/open-invoices
 * Open invoices with outstanding balances available for payment allocation.
 */
invoiceRouter.get('/retailers/:retailerId/open-invoices', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { retailerId } = req.params;

    const openInvoices = await getRetailerOpenInvoices(dealerId, retailerId);
    res.json({ openInvoices });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/billing/outstanding
 * Dealership-wide outstanding overview across all retailers with ageing and utilisation.
 */
invoiceRouter.get('/outstanding', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { search, filter } = req.query;
    const overview = await getDealerOutstandingOverview({
      dealerId,
      search,
      filter
    });

    res.json(overview);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * GET /api/billing/ageing
 * Ageing breakdown overview.
 */
invoiceRouter.get('/ageing', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const overview = await getDealerOutstandingOverview({ dealerId });
    res.json({
      summary: overview.summary,
      retailers: overview.retailers
    });
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * GET /api/billing/collections
 * List payment collections with filters.
 */
invoiceRouter.get('/collections', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, mode, status, startDate, endDate } = req.query;
    const where = { dealerId };
    if (retailerId) where.retailerId = retailerId;
    if (mode) where.mode = mode;
    if (status) where.status = status;
    if (startDate || endDate) {
      where.date = {};
      if (startDate) where.date.gte = new Date(startDate);
      if (endDate) where.date.lte = new Date(endDate);
    }

    const collections = await prisma.collection.findMany({
      where,
      include: {
        retailer: {
          select: { id: true, legalName: true, tradeName: true, gstin: true, mobile: true }
        },
        allocations: {
          include: {
            invoice: {
              select: { id: true, invoiceNo: true, invoiceDate: true, netTotal: true }
            }
          }
        }
      },
      orderBy: { date: 'desc' }
    });

    res.json({ collections });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/billing/collections/:id
 * Single collection detail.
 */
invoiceRouter.get('/collections/:id', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const collection = await prisma.collection.findUnique({
      where: { id: req.params.id },
      include: {
        retailer: true,
        dealer: true,
        allocations: {
          include: {
            invoice: true
          }
        }
      }
    });

    if (!collection) {
      return res.status(404).json({ error: 'Collection receipt not found.' });
    }

    if (dealerId && collection.dealerId !== dealerId && req.currentUser.role !== DASHBOARD_ROLES.BRAND_ADMIN) {
      return res.status(403).json({ error: 'Access denied.' });
    }

    res.json(collection);
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/billing/collections/:id/receipt
 * Receipt data formatted for print.
 */
invoiceRouter.get('/collections/:id/receipt', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const receipt = await getCollectionReceiptData(req.params.id, dealerId);
    res.json(receipt);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * POST /api/billing/collections
 * Record a payment collection with FIFO or manual allocation.
 */
invoiceRouter.post('/collections', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const {
      retailerId,
      date,
      mode,
      amount,
      reference,
      chequeDate,
      bankName,
      collectedBy,
      notes,
      allocations,
      autoAllocateFifo
    } = req.body;

    const collection = await createCollectionTransaction({
      dealerId,
      retailerId,
      date: date ? new Date(date) : new Date(),
      mode,
      amount,
      reference,
      chequeDate,
      bankName,
      collectedBy,
      notes,
      allocations,
      autoAllocateFifo: autoAllocateFifo !== false,
      user: req.currentUser
    });

    res.status(201).json(collection);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

/**
 * POST /api/billing/collections/:id/bounce
 * Mark a cheque collection as bounced, reverse allocations and ledger, apply penalty charge.
 */
invoiceRouter.post('/collections/:id/bounce', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    const { reason, bounceCharge } = req.body;

    const result = await bounceChequeTransaction({
      collectionId: req.params.id,
      dealerId,
      reason,
      bounceCharge,
      user: req.currentUser
    });

    res.json(result);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({ error: err.message, code: err.code });
    }
    next(err);
  }
});

