import { Router } from 'express';
import { prisma } from '../config/database.js';
import { allowDealerReadOnly } from '../middleware/auth.middleware.js';
import { parseCsv, getSampleCsv } from '../services/csv.service.js';

export const skuRouter = Router();
skuRouter.use(allowDealerReadOnly);

/**
 * Computes whether a SKU is billable.
 * Blocks a SKU from being used if HSN or MRP is missing.
 */
export function computeIsBillable(sku) {
  const hasHsn = Boolean(sku.hsnCode && String(sku.hsnCode).trim().length >= 6);
  const hasMrp = sku.mrp != null && !isNaN(sku.mrp) && Number(sku.mrp) > 0;
  const isActive = Boolean(sku.isActive);
  return Boolean(isActive && hasHsn && hasMrp);
}

export function formatSku(sku) {
  if (!sku) return null;
  return {
    ...sku,
    isBillable: computeIsBillable(sku)
  };
}

/**
 * GET /api/skus/sample-csv
 * Returns the sample SKUs CSV with 100+ rows.
 */
skuRouter.get('/sample-csv', (req, res) => {
  const csv = getSampleCsv('sample_skus.csv');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="sample_skus.csv"');
  res.send(csv);
});

/**
 * GET /api/skus
 * List SKUs with search, filters (category, brand, isActive, isBillable), and pagination.
 */
skuRouter.get('/', async (req, res, next) => {
  try {
    const {
      search,
      category,
      brand,
      isActive,
      isBillable,
      page = 1,
      limit = 20
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const take = Math.min(200, Math.max(1, parseInt(limit, 10) || 20));
    const skip = (pageNum - 1) * take;

    const where = {};

    if (search) {
      const q = search.trim();
      where.OR = [
        { code: { contains: q, mode: 'insensitive' } },
        { name: { contains: q, mode: 'insensitive' } },
        { barcode: { contains: q, mode: 'insensitive' } },
        { article: { contains: q, mode: 'insensitive' } },
        { brand: { contains: q, mode: 'insensitive' } }
      ];
    }

    if (category) {
      where.category = category;
    }

    if (brand) {
      where.brand = brand;
    }

    if (isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true' || isActive === true;
    }

    // Direct database query
    const [rawItems, totalCount, categoriesRaw, brandsRaw] = await Promise.all([
      prisma.sku.findMany({
        where,
        orderBy: { code: 'asc' },
        skip,
        take
      }),
      prisma.sku.count({ where }),
      prisma.sku.findMany({
        select: { category: true },
        distinct: ['category'],
        orderBy: { category: 'asc' }
      }),
      prisma.sku.findMany({
        select: { brand: true },
        distinct: ['brand'],
        orderBy: { brand: 'asc' }
      })
    ]);

    let items = rawItems.map(formatSku);

    if (isBillable !== undefined && isBillable !== '') {
      const targetBillable = isBillable === 'true' || isBillable === true;
      items = items.filter((item) => item.isBillable === targetBillable);
    }

    res.json({
      items,
      skus: items,
      total: totalCount,
      page: pageNum,
      limit: take,
      totalPages: Math.ceil(totalCount / take),
      categories: categoriesRaw.map((c) => c.category).filter(Boolean),
      brands: brandsRaw.map((b) => b.brand).filter(Boolean)
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/skus/:id
 */
skuRouter.get('/:id', async (req, res, next) => {
  try {
    const sku = await prisma.sku.findUnique({
      where: { id: req.params.id }
    });

    if (!sku) {
      return res.status(404).json({ error: 'SKU not found.' });
    }

    res.json(formatSku(sku));
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/skus
 * BRAND_ADMIN only: create SKU.
 */
skuRouter.post('/', async (req, res, next) => {
  try {
    const {
      code,
      name,
      brand,
      category,
      article,
      size,
      colour,
      uom = 'PCS',
      mrp,
      hsnCode,
      barcode,
      isActive = true
    } = req.body;

    if (!code || !code.trim()) {
      return res.status(400).json({ error: 'SKU code is required.' });
    }

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Product name is required.' });
    }

    if (!barcode || !barcode.trim()) {
      return res.status(400).json({ error: 'Barcode is required and must be unique.' });
    }

    const cleanedCode = code.trim();
    const cleanedBarcode = barcode.trim();

    const [existingCode, existingBarcode] = await Promise.all([
      prisma.sku.findUnique({ where: { code: cleanedCode } }),
      prisma.sku.findUnique({ where: { barcode: cleanedBarcode } })
    ]);

    if (existingCode) {
      return res.status(409).json({ error: `SKU code '${cleanedCode}' already exists.` });
    }

    if (existingBarcode) {
      return res.status(409).json({ error: `Barcode '${cleanedBarcode}' is already assigned to SKU '${existingBarcode.code}'.` });
    }

    const created = await prisma.sku.create({
      data: {
        code: cleanedCode,
        name: name.trim(),
        brand: brand ? brand.trim() : 'Generic',
        category: category ? category.trim() : 'General',
        article: article ? article.trim() : null,
        size: size ? size.trim() : null,
        colour: colour ? colour.trim() : null,
        uom: uom ? uom.trim() : 'PCS',
        mrp: mrp != null && mrp !== '' ? parseFloat(mrp) : null,
        hsnCode: hsnCode ? hsnCode.trim() : null,
        barcode: cleanedBarcode,
        isActive: Boolean(isActive)
      }
    });

    res.status(201).json(formatSku(created));
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/skus/:id
 * BRAND_ADMIN only: update SKU.
 */
skuRouter.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.sku.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'SKU not found.' });
    }

    const {
      code,
      name,
      brand,
      category,
      article,
      size,
      colour,
      uom,
      mrp,
      hsnCode,
      barcode,
      isActive
    } = req.body;

    if (barcode && barcode.trim() !== existing.barcode) {
      const barcodeInUse = await prisma.sku.findUnique({ where: { barcode: barcode.trim() } });
      if (barcodeInUse) {
        return res.status(409).json({
          error: `Barcode '${barcode.trim()}' is already assigned to SKU '${barcodeInUse.code}'.`
        });
      }
    }

    if (code && code.trim() !== existing.code) {
      const codeInUse = await prisma.sku.findUnique({ where: { code: code.trim() } });
      if (codeInUse) {
        return res.status(409).json({ error: `SKU code '${code.trim()}' already exists.` });
      }
    }

    const updated = await prisma.sku.update({
      where: { id },
      data: {
        code: code !== undefined ? code.trim() : existing.code,
        name: name !== undefined ? name.trim() : existing.name,
        brand: brand !== undefined ? brand.trim() : existing.brand,
        category: category !== undefined ? category.trim() : existing.category,
        article: article !== undefined ? (article ? article.trim() : null) : existing.article,
        size: size !== undefined ? (size ? size.trim() : null) : existing.size,
        colour: colour !== undefined ? (colour ? colour.trim() : null) : existing.colour,
        uom: uom !== undefined ? (uom ? uom.trim() : 'PCS') : existing.uom,
        mrp: mrp !== undefined ? (mrp !== '' && mrp != null ? parseFloat(mrp) : null) : existing.mrp,
        hsnCode: hsnCode !== undefined ? (hsnCode ? hsnCode.trim() : null) : existing.hsnCode,
        barcode: barcode !== undefined ? barcode.trim() : existing.barcode,
        isActive: isActive !== undefined ? Boolean(isActive) : existing.isActive
      }
    });

    res.json(formatSku(updated));
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/skus/:id
 * BRAND_ADMIN only: delete SKU.
 */
skuRouter.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.sku.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'SKU not found.' });
    }

    await prisma.sku.delete({ where: { id } });
    res.json({ message: 'SKU deleted successfully.', id });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/skus/import-csv
 * BRAND_ADMIN only: bulk import SKUs via CSV with detailed validation report.
 * Supports mode: 'all-or-nothing' or 'skip-bad-rows'.
 */
skuRouter.post('/import-csv', async (req, res, next) => {
  try {
    const mode = req.body.mode === 'all-or-nothing' ? 'all-or-nothing' : 'skip-bad-rows';
    const csvContent = req.body.csvText || req.body.csv || '';

    if (!csvContent || typeof csvContent !== 'string') {
      return res.status(400).json({ error: 'CSV content is required (provide csvText string).' });
    }

    const { records } = parseCsv(csvContent);
    if (!records || records.length === 0) {
      return res.status(400).json({ error: 'The provided CSV file contains no data rows.' });
    }

    // Fetch existing SKUs by code and barcode to detect updates vs collisions
    const [allExistingSkus] = await Promise.all([
      prisma.sku.findMany({ select: { id: true, code: true, barcode: true } })
    ]);

    const codeToSkuMap = new Map(allExistingSkus.map((s) => [s.code.toLowerCase(), s]));
    const barcodeToSkuMap = new Map(allExistingSkus.map((s) => [s.barcode.toLowerCase(), s]));

    const barcodeSeenInCsv = new Map();
    const validatedRows = [];
    const rejected = [];

    for (const record of records) {
      const { rowNumber, data } = record;
      const reasons = [];

      const code = data.code?.trim();
      const name = data.name?.trim();
      const barcode = data.barcode?.trim();
      const brand = data.brand?.trim() || 'Generic';
      const category = data.category?.trim() || 'General';
      const article = data.article?.trim() || null;
      const size = data.size?.trim() || null;
      const colour = data.colour?.trim() || null;
      const uom = data.uom?.trim() || 'PCS';
      const hsnCode = data.hsnCode?.trim() || null;
      const mrpRaw = data.mrp?.trim();
      const isActiveRaw = data.isActive?.trim();

      if (!code) {
        reasons.push('Missing required field: code');
      }

      if (!name) {
        reasons.push('Missing required field: name');
      }

      if (!barcode) {
        reasons.push('Missing required field: barcode');
      } else {
        const lowerBarcode = barcode.toLowerCase();
        if (barcodeSeenInCsv.has(lowerBarcode) && barcodeSeenInCsv.get(lowerBarcode) !== code?.toLowerCase()) {
          reasons.push(`Duplicate barcode '${barcode}' repeated in CSV at row ${rowNumber}.`);
        } else {
          barcodeSeenInCsv.set(lowerBarcode, code?.toLowerCase());
        }

        const existingBarcodeOwner = barcodeToSkuMap.get(lowerBarcode);
        if (existingBarcodeOwner && existingBarcodeOwner.code.toLowerCase() !== code?.toLowerCase()) {
          reasons.push(`Barcode '${barcode}' is already in use by database SKU '${existingBarcodeOwner.code}'.`);
        }
      }

      let parsedMrp = null;
      if (mrpRaw !== undefined && mrpRaw !== '') {
        const num = parseFloat(mrpRaw);
        if (isNaN(num) || num < 0) {
          reasons.push(`Invalid MRP '${mrpRaw}'. Must be a non-negative number.`);
        } else {
          parsedMrp = num;
        }
      }

      if (hsnCode && !/^\d{6}(\d{2})?$/.test(hsnCode)) {
        reasons.push(`Invalid HSN code '${hsnCode}'. Must be 6 or 8 digits.`);
      }

      const isActive =
        isActiveRaw !== undefined && isActiveRaw !== ''
          ? ['true', '1', 'yes', 'y'].includes(isActiveRaw.toLowerCase())
          : true;

      if (reasons.length > 0) {
        rejected.push({
          rowNumber,
          code: code || `Row-${rowNumber}`,
          barcode: barcode || '—',
          name: name || '—',
          reasons
        });
      } else {
        const existing = code ? codeToSkuMap.get(code.toLowerCase()) : null;
        validatedRows.push({
          rowNumber,
          isUpdate: Boolean(existing),
          existingId: existing?.id,
          skuData: {
            code,
            name,
            brand,
            category,
            article,
            size,
            colour,
            uom,
            mrp: parsedMrp,
            hsnCode,
            barcode,
            isActive
          }
        });
      }
    }

    // Check all-or-nothing rollback condition
    if (mode === 'all-or-nothing' && rejected.length > 0) {
      return res.status(422).json({
        success: false,
        mode: 'all-or-nothing',
        totalRows: records.length,
        createdCount: 0,
        updatedCount: 0,
        rejectedCount: rejected.length,
        created: [],
        updated: [],
        rejected,
        message: `Import failed in all-or-nothing mode. ${rejected.length} invalid row(s) detected. No changes made to database.`
      });
    }

    // Perform database operations for validated rows
    const created = [];
    const updated = [];

    for (const item of validatedRows) {
      const { rowNumber, isUpdate, existingId, skuData } = item;
      if (isUpdate && existingId) {
        const resSku = await prisma.sku.update({
          where: { id: existingId },
          data: skuData
        });
        updated.push({
          rowNumber,
          code: resSku.code,
          name: resSku.name,
          barcode: resSku.barcode,
          isBillable: computeIsBillable(resSku)
        });
      } else {
        const resSku = await prisma.sku.create({
          data: skuData
        });
        created.push({
          rowNumber,
          code: resSku.code,
          name: resSku.name,
          barcode: resSku.barcode,
          isBillable: computeIsBillable(resSku)
        });
      }
    }

    res.json({
      success: true,
      mode,
      totalRows: records.length,
      createdCount: created.length,
      updatedCount: updated.length,
      rejectedCount: rejected.length,
      created,
      updated,
      rejected,
      message: `Import processed. ${created.length} created, ${updated.length} updated, ${rejected.length} rejected.`
    });
  } catch (error) {
    next(error);
  }
});

