import { Router } from 'express';
import { prisma } from '../config/database.js';
import { allowDealerReadOnly } from '../middleware/auth.middleware.js';

export const hsnRouter = Router();
hsnRouter.use(allowDealerReadOnly);

/**
 * Validates HSN code format (must be 6 or 8 digits).
 */
export function validateHsnCode(code) {
  if (!code || typeof code !== 'string') return false;
  const cleaned = code.trim();
  return /^\d{6}(\d{2})?$/.test(cleaned);
}

/**
 * GET /api/hsn
 * List all HSN codes with optional search query.
 */
hsnRouter.get('/', async (req, res, next) => {
  try {
    const { search } = req.query;
    const where = {};

    if (search) {
      where.OR = [
        { code: { contains: search.trim(), mode: 'insensitive' } },
        { description: { contains: search.trim(), mode: 'insensitive' } }
      ];
    }

    const items = await prisma.hsn.findMany({
      where,
      orderBy: { code: 'asc' }
    });

    res.json({ items, total: items.length });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/hsn/:code
 */
hsnRouter.get('/:code', async (req, res, next) => {
  try {
    const item = await prisma.hsn.findUnique({
      where: { code: req.params.code.trim() }
    });

    if (!item) {
      return res.status(404).json({ error: 'HSN code not found.' });
    }

    res.json(item);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/hsn
 * BRAND_ADMIN only: create new HSN master.
 */
hsnRouter.post('/', async (req, res, next) => {
  try {
    const { code, description, gstRate, effectiveFrom } = req.body;

    if (!validateHsnCode(code)) {
      return res.status(400).json({
        error: 'Invalid HSN code. HSN code must be exactly 6 or 8 digits (e.g. 870829 or 87082900).'
      });
    }

    if (!description || !description.trim()) {
      return res.status(400).json({ error: 'Description is required.' });
    }

    if (gstRate == null || isNaN(gstRate) || Number(gstRate) < 0) {
      return res.status(400).json({ error: 'GST Rate must be a non-negative number.' });
    }

    const cleanedCode = code.trim();
    const existing = await prisma.hsn.findUnique({ where: { code: cleanedCode } });
    if (existing) {
      return res.status(409).json({ error: `HSN code ${cleanedCode} already exists.` });
    }

    const item = await prisma.hsn.create({
      data: {
        code: cleanedCode,
        description: description.trim(),
        gstRate: Number(gstRate),
        effectiveFrom: effectiveFrom ? new Date(effectiveFrom) : new Date()
      }
    });

    res.status(201).json(item);
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/hsn/:id
 * BRAND_ADMIN only: update HSN master.
 */
hsnRouter.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { code, description, gstRate, effectiveFrom } = req.body;

    const existing = await prisma.hsn.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'HSN record not found.' });
    }

    if (code && !validateHsnCode(code)) {
      return res.status(400).json({
        error: 'Invalid HSN code. HSN code must be exactly 6 or 8 digits.'
      });
    }

    if (code && code.trim() !== existing.code) {
      const duplicate = await prisma.hsn.findUnique({ where: { code: code.trim() } });
      if (duplicate) {
        return res.status(409).json({ error: `HSN code ${code.trim()} already in use.` });
      }
    }

    const updated = await prisma.hsn.update({
      where: { id },
      data: {
        code: code ? code.trim() : existing.code,
        description: description ? description.trim() : existing.description,
        gstRate: gstRate != null ? Number(gstRate) : existing.gstRate,
        effectiveFrom: effectiveFrom ? new Date(effectiveFrom) : existing.effectiveFrom
      }
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/hsn/:id
 * BRAND_ADMIN only: delete HSN master.
 */
hsnRouter.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.hsn.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'HSN record not found.' });
    }

    // Check if any SKUs reference this HSN code
    const skuCount = await prisma.sku.count({ where: { hsnCode: existing.code } });
    if (skuCount > 0) {
      return res.status(400).json({
        error: `Cannot delete HSN code ${existing.code}: currently referenced by ${skuCount} SKU(s).`
      });
    }

    await prisma.hsn.delete({ where: { id } });
    res.json({ message: 'HSN code deleted successfully.', id });
  } catch (error) {
    next(error);
  }
});

