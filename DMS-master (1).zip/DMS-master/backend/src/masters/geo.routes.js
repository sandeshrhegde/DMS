import { Router } from 'express';
import { prisma } from '../config/database.js';
import { allowDealerReadOnly } from '../middleware/auth.middleware.js';

export const geoRouter = Router();
geoRouter.use(allowDealerReadOnly);

export const GEO_LEVEL_ORDER = ['ZONE', 'STATE', 'REGION', 'CITY', 'CLUSTER'];

export function getExpectedChildType(parentType) {
  const idx = GEO_LEVEL_ORDER.indexOf(parentType);
  if (idx === -1 || idx === GEO_LEVEL_ORDER.length - 1) return null;
  return GEO_LEVEL_ORDER[idx + 1];
}

/**
 * Builds nested hierarchy tree from a flat list of GeoNodes.
 */
function buildGeoTree(nodes) {
  const map = new Map();
  nodes.forEach((n) => map.set(n.id, { ...n, children: [] }));

  const roots = [];
  nodes.forEach((n) => {
    const node = map.get(n.id);
    if (n.parentId && map.has(n.parentId)) {
      map.get(n.parentId).children.push(node);
    } else {
      roots.push(node);
    }
  });

  return roots;
}

/**
 * Recursively updates paths for all descendants of a node.
 */
async function updateDescendantPaths(nodeId, newParentPath) {
  const children = await prisma.geoNode.findMany({ where: { parentId: nodeId } });
  for (const child of children) {
    const childPath = `${newParentPath}/${child.name}`;
    await prisma.geoNode.update({
      where: { id: child.id },
      data: { path: childPath }
    });
    await updateDescendantPaths(child.id, childPath);
  }
}

/**
 * GET /api/geography/tree
 * Returns full geography tree starting from ZONE root nodes.
 */
geoRouter.get('/tree', async (req, res, next) => {
  try {
    const nodes = await prisma.geoNode.findMany({
      orderBy: [{ type: 'asc' }, { name: 'asc' }],
      include: {
        _count: {
          select: { dealers: true }
        }
      }
    });

    const tree = buildGeoTree(nodes);
    res.json({ tree, totalNodes: nodes.length });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/geography
 * List all geography nodes (supports optional type and parentId query filters).
 */
geoRouter.get('/', async (req, res, next) => {
  try {
    const { type, parentId } = req.query;
    const where = {};
    if (type) where.type = type;
    if (parentId !== undefined) where.parentId = parentId || null;

    const nodes = await prisma.geoNode.findMany({
      where,
      orderBy: [{ type: 'asc' }, { name: 'asc' }],
      include: {
        parent: { select: { id: true, name: true, type: true } },
        _count: { select: { children: true, dealers: true } }
      }
    });

    res.json({ nodes });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/geography/:id
 */
geoRouter.get('/:id', async (req, res, next) => {
  try {
    const node = await prisma.geoNode.findUnique({
      where: { id: req.params.id },
      include: {
        parent: true,
        children: true,
        dealers: { select: { id: true, code: true, name: true } }
      }
    });

    if (!node) {
      return res.status(404).json({ error: 'Geography node not found.' });
    }

    res.json(node);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/geography
 * BRAND_ADMIN only: create new geography node with strict level hierarchy validation.
 */
geoRouter.post('/', async (req, res, next) => {
  try {
    const { name, type, parentId } = req.body;

    if (!name || typeof name !== 'string' || !name.trim()) {
      return res.status(400).json({ error: 'Geography node name is required.' });
    }

    if (!type || !GEO_LEVEL_ORDER.includes(type)) {
      return res.status(400).json({
        error: `Invalid geography type '${type}'. Must be one of: ${GEO_LEVEL_ORDER.join(', ')}`
      });
    }

    const trimmedName = name.trim();
    let calculatedPath = `/${trimmedName}`;

    if (!parentId) {
      // Root node must be ZONE
      if (type !== 'ZONE') {
        return res.status(400).json({
          error: `Root geography node must be of type 'ZONE'. Received '${type}'.`
        });
      }
    } else {
      // Child node validation
      const parent = await prisma.geoNode.findUnique({ where: { id: parentId } });
      if (!parent) {
        return res.status(404).json({ error: 'Parent geography node not found.' });
      }

      if (parent.type === 'CLUSTER') {
        return res.status(400).json({
          error: "CLUSTER nodes cannot have child nodes."
        });
      }

      const expectedType = getExpectedChildType(parent.type);
      if (type !== expectedType) {
        return res.status(400).json({
          error: `Invalid child type '${type}'. A child of '${parent.type}' must be '${expectedType}'.`
        });
      }

      const parentPath = parent.path || `/${parent.name}`;
      calculatedPath = `${parentPath}/${trimmedName}`;
    }

    const newNode = await prisma.geoNode.create({
      data: {
        name: trimmedName,
        type,
        parentId: parentId || null,
        path: calculatedPath
      }
    });

    res.status(201).json(newNode);
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/geography/:id
 * BRAND_ADMIN only: update geography node.
 */
geoRouter.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name, type, parentId } = req.body;

    const existing = await prisma.geoNode.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'Geography node not found.' });
    }

    const updatedName = name !== undefined ? name.trim() : existing.name;
    const updatedType = type !== undefined ? type : existing.type;
    const updatedParentId = parentId !== undefined ? parentId : existing.parentId;

    let newPath = `/${updatedName}`;

    if (!updatedParentId) {
      if (updatedType !== 'ZONE') {
        return res.status(400).json({
          error: `Root geography node must be of type 'ZONE'. Received '${updatedType}'.`
        });
      }
    } else {
      if (updatedParentId === id) {
        return res.status(400).json({ error: 'A geography node cannot be its own parent.' });
      }

      const parent = await prisma.geoNode.findUnique({ where: { id: updatedParentId } });
      if (!parent) {
        return res.status(404).json({ error: 'Parent geography node not found.' });
      }

      const expectedType = getExpectedChildType(parent.type);
      if (updatedType !== expectedType) {
        return res.status(400).json({
          error: `Invalid child type '${updatedType}'. A child of '${parent.type}' must be '${expectedType}'.`
        });
      }

      const parentPath = parent.path || `/${parent.name}`;
      newPath = `${parentPath}/${updatedName}`;
    }

    const updatedNode = await prisma.geoNode.update({
      where: { id },
      data: {
        name: updatedName,
        type: updatedType,
        parentId: updatedParentId || null,
        path: newPath
      }
    });

    // Cascade path update to children
    if (newPath !== existing.path) {
      await updateDescendantPaths(id, newPath);
    }

    res.json(updatedNode);
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/geography/:id
 * BRAND_ADMIN only: delete geography node.
 */
geoRouter.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;

    const existing = await prisma.geoNode.findUnique({
      where: { id },
      include: { _count: { select: { dealers: true } } }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Geography node not found.' });
    }

    if (existing._count.dealers > 0) {
      return res.status(400).json({
        error: `Cannot delete geography node: ${existing._count.dealers} dealer(s) are associated with this location.`
      });
    }

    await prisma.geoNode.delete({ where: { id } });
    res.status(200).json({ message: 'Geography node deleted successfully.', id });
  } catch (error) {
    next(error);
  }
});

