import { Router } from 'express';
import { prisma } from '../config/database.js';
import { requireBrandAdmin } from '../middleware/auth.middleware.js';
import { parseCsv, getSampleCsv } from '../services/csv.service.js';

export const dealerRouter = Router();

/**
 * GET /api/dealers/sample-csv
 * Returns the sample Dealers CSV.
 */
dealerRouter.get('/sample-csv', (req, res) => {
  const csv = getSampleCsv('sample_dealers.csv');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="sample_dealers.csv"');
  res.send(csv);
});

// All dealer master endpoints require BRAND_ADMIN
dealerRouter.use(requireBrandAdmin);

/**
 * GET /api/dealers
 * List dealers with search and pagination, including linked geography node.
 */
dealerRouter.get('/', async (req, res, next) => {
  try {
    const { search, geoNodeId, isActive, page = 1, limit = 50 } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const take = Math.min(200, Math.max(1, parseInt(limit, 10) || 50));
    const skip = (pageNum - 1) * take;

    const where = {};

    if (search) {
      const q = search.trim();
      where.OR = [
        { code: { contains: q, mode: 'insensitive' } },
        { name: { contains: q, mode: 'insensitive' } },
        { gstin: { contains: q, mode: 'insensitive' } },
        { contactName: { contains: q, mode: 'insensitive' } },
        { contactEmail: { contains: q, mode: 'insensitive' } },
        { contactPhone: { contains: q, mode: 'insensitive' } }
      ];
    }

    if (geoNodeId) {
      where.geoNodeId = geoNodeId;
    }

    if (isActive !== undefined && isActive !== '') {
      where.isActive = isActive === 'true' || isActive === true;
    }

    const [dealers, total] = await Promise.all([
      prisma.dealer.findMany({
        where,
        include: {
          geoNode: {
            select: { id: true, name: true, type: true, path: true }
          },
          _count: {
            select: { users: true }
          }
        },
        orderBy: { code: 'asc' },
        skip,
        take
      }),
      prisma.dealer.count({ where })
    ]);

    res.json({
      dealers,
      total,
      page: pageNum,
      limit: take,
      totalPages: Math.ceil(total / take)
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/dealers/:id
 */
dealerRouter.get('/:id', async (req, res, next) => {
  try {
    const dealer = await prisma.dealer.findUnique({
      where: { id: req.params.id },
      include: {
        geoNode: true,
        users: { select: { id: true, name: true, email: true, role: true, isActive: true } }
      }
    });

    if (!dealer) {
      return res.status(404).json({ error: 'Dealer not found.' });
    }

    res.json(dealer);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/dealers
 * Create a new dealer.
 */
dealerRouter.post('/', async (req, res, next) => {
  try {
    const {
      code,
      name,
      gstin,
      stateCode,
      contactName,
      contactEmail,
      contactPhone,
      address,
      pincode,
      creditDays = 30,
      maxHeaderDiscountPct = 0,
      eInvoiceEnabled = false,
      geoNodeId,
      isActive = true
    } = req.body;

    if (!code || !code.trim()) {
      return res.status(400).json({ error: 'Dealer code is required.' });
    }

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'Dealer name is required.' });
    }

    if (!stateCode || !stateCode.trim()) {
      return res.status(400).json({ error: 'State code is required.' });
    }

    const cleanedCode = code.trim();
    const existing = await prisma.dealer.findUnique({ where: { code: cleanedCode } });
    if (existing) {
      return res.status(409).json({ error: `Dealer with code '${cleanedCode}' already exists.` });
    }

    if (gstin && gstin.trim()) {
      const gstinExisting = await prisma.dealer.findUnique({ where: { gstin: gstin.trim() } });
      if (gstinExisting) {
        return res.status(409).json({ error: `GSTIN '${gstin.trim()}' is already in use by dealer '${gstinExisting.name}'.` });
      }
    }

    if (geoNodeId) {
      const node = await prisma.geoNode.findUnique({ where: { id: geoNodeId } });
      if (!node) {
        return res.status(400).json({ error: 'Specified geography node not found.' });
      }
    }

    const created = await prisma.dealer.create({
      data: {
        code: cleanedCode,
        name: name.trim(),
        gstin: gstin ? gstin.trim() : null,
        stateCode: stateCode.trim(),
        contactName: contactName ? contactName.trim() : null,
        contactEmail: contactEmail ? contactEmail.trim() : null,
        contactPhone: contactPhone ? contactPhone.trim() : null,
        address: address ? address.trim() : null,
        pincode: pincode ? pincode.trim() : null,
        creditDays: parseInt(creditDays, 10) || 30,
        maxHeaderDiscountPct: parseFloat(maxHeaderDiscountPct) || 0,
        eInvoiceEnabled: Boolean(eInvoiceEnabled),
        geoNodeId: geoNodeId || null,
        isActive: Boolean(isActive)
      },
      include: { geoNode: true }
    });

    res.status(201).json(created);
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/dealers/:id
 * Update an existing dealer.
 */
dealerRouter.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.dealer.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'Dealer not found.' });
    }

    const {
      code,
      name,
      gstin,
      stateCode,
      contactName,
      contactEmail,
      contactPhone,
      address,
      pincode,
      creditDays,
      maxHeaderDiscountPct,
      eInvoiceEnabled,
      geoNodeId,
      isActive
    } = req.body;

    if (code && code.trim() !== existing.code) {
      const duplicateCode = await prisma.dealer.findUnique({ where: { code: code.trim() } });
      if (duplicateCode) {
        return res.status(409).json({ error: `Dealer code '${code.trim()}' already in use.` });
      }
    }

    if (gstin && gstin.trim() !== (existing.gstin || '')) {
      const duplicateGstin = await prisma.dealer.findUnique({ where: { gstin: gstin.trim() } });
      if (duplicateGstin) {
        return res.status(409).json({ error: `GSTIN '${gstin.trim()}' already in use by dealer '${duplicateGstin.name}'.` });
      }
    }

    if (geoNodeId && geoNodeId !== existing.geoNodeId) {
      const node = await prisma.geoNode.findUnique({ where: { id: geoNodeId } });
      if (!node) {
        return res.status(400).json({ error: 'Specified geography node not found.' });
      }
    }

    const updated = await prisma.dealer.update({
      where: { id },
      data: {
        code: code !== undefined ? code.trim() : existing.code,
        name: name !== undefined ? name.trim() : existing.name,
        gstin: gstin !== undefined ? (gstin ? gstin.trim() : null) : existing.gstin,
        stateCode: stateCode !== undefined ? stateCode.trim() : existing.stateCode,
        contactName: contactName !== undefined ? (contactName ? contactName.trim() : null) : existing.contactName,
        contactEmail: contactEmail !== undefined ? (contactEmail ? contactEmail.trim() : null) : existing.contactEmail,
        contactPhone: contactPhone !== undefined ? (contactPhone ? contactPhone.trim() : null) : existing.contactPhone,
        address: address !== undefined ? (address ? address.trim() : null) : existing.address,
        pincode: pincode !== undefined ? (pincode ? pincode.trim() : null) : existing.pincode,
        creditDays: creditDays !== undefined ? parseInt(creditDays, 10) : existing.creditDays,
        maxHeaderDiscountPct:
          maxHeaderDiscountPct !== undefined ? parseFloat(maxHeaderDiscountPct) : existing.maxHeaderDiscountPct,
        eInvoiceEnabled: eInvoiceEnabled !== undefined ? Boolean(eInvoiceEnabled) : existing.eInvoiceEnabled,
        geoNodeId: geoNodeId !== undefined ? geoNodeId || null : existing.geoNodeId,
        isActive: isActive !== undefined ? Boolean(isActive) : existing.isActive
      },
      include: { geoNode: true }
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/dealers/:id
 * Delete or deactivate dealer.
 */
dealerRouter.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const existing = await prisma.dealer.findUnique({
      where: { id },
      include: { _count: { select: { users: true } } }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Dealer not found.' });
    }

    if (existing._count.users > 0) {
      // Safely deactivate instead of breaking user foreign keys
      const deactivated = await prisma.dealer.update({
        where: { id },
        data: { isActive: false }
      });
      return res.json({
        message: `Dealer has ${existing._count.users} user(s); deactivated instead of deleted.`,
        dealer: deactivated
      });
    }

    await prisma.dealer.delete({ where: { id } });
    res.json({ message: 'Dealer deleted successfully.', id });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/dealers/import-csv
 * Bulk import dealers via CSV with row-by-row validation report.
 * Supports mode: 'all-or-nothing' or 'skip-bad-rows'.
 */
dealerRouter.post('/import-csv', async (req, res, next) => {
  try {
    const mode = req.body.mode === 'all-or-nothing' ? 'all-or-nothing' : 'skip-bad-rows';
    const csvContent = req.body.csvText || req.body.csv || '';

    if (!csvContent || typeof csvContent !== 'string') {
      return res.status(400).json({ error: 'CSV content is required (provide csvText string).' });
    }

    const { records } = parseCsv(csvContent);
    if (!records || records.length === 0) {
      return res.status(400).json({ error: 'The provided CSV file contains no data rows.' });
    }

    const [allExistingDealers, allGeoNodes] = await Promise.all([
      prisma.dealer.findMany({ select: { id: true, code: true, gstin: true } }),
      prisma.geoNode.findMany({ select: { id: true, name: true } })
    ]);

    const codeToDealerMap = new Map(allExistingDealers.map((d) => [d.code.toLowerCase(), d]));
    const gstinToDealerMap = new Map(
      allExistingDealers.filter((d) => d.gstin).map((d) => [d.gstin.toLowerCase(), d])
    );
    const geoNameToNodeMap = new Map(allGeoNodes.map((g) => [g.name.toLowerCase(), g]));
    const geoIdToNodeMap = new Map(allGeoNodes.map((g) => [g.id.toLowerCase(), g]));

    const codeSeenInCsv = new Set();
    const validatedRows = [];
    const rejected = [];

    for (const record of records) {
      const { rowNumber, data } = record;
      const reasons = [];

      const code = data.code?.trim();
      const name = data.name?.trim();
      const gstin = data.gstin?.trim() || null;
      const stateCode = data.stateCode?.trim();
      const contactName = data.contactName?.trim() || null;
      const contactEmail = data.contactEmail?.trim() || null;
      const contactPhone = data.contactPhone?.trim() || null;
      const address = data.address?.trim() || null;
      const pincode = data.pincode?.trim() || null;
      const creditDaysRaw = data.creditDays?.trim();
      const maxDiscountRaw = data.maxHeaderDiscountPct?.trim();
      const eInvoiceRaw = data.eInvoiceEnabled?.trim();
      const geoRef = data.geoNodeName?.trim() || data.geoNodeId?.trim() || null;
      const isActiveRaw = data.isActive?.trim();

      if (!code) {
        reasons.push('Missing required field: code');
      } else {
        const lowerCode = code.toLowerCase();
        if (codeSeenInCsv.has(lowerCode)) {
          reasons.push(`Duplicate dealer code '${code}' repeated in CSV.`);
        } else {
          codeSeenInCsv.add(lowerCode);
        }
      }

      if (!name) {
        reasons.push('Missing required field: name');
      }

      if (!stateCode) {
        reasons.push('Missing required field: stateCode');
      }

      if (gstin) {
        const lowerGstin = gstin.toLowerCase();
        const existingGstinOwner = gstinToDealerMap.get(lowerGstin);
        if (existingGstinOwner && existingGstinOwner.code.toLowerCase() !== code?.toLowerCase()) {
          reasons.push(`GSTIN '${gstin}' is already in use by dealer '${existingGstinOwner.code}'.`);
        }
      }

      let parsedCreditDays = 30;
      if (creditDaysRaw !== undefined && creditDaysRaw !== '') {
        const cDays = parseInt(creditDaysRaw, 10);
        if (isNaN(cDays) || cDays < 0) {
          reasons.push(`Invalid creditDays '${creditDaysRaw}'. Must be a non-negative integer.`);
        } else {
          parsedCreditDays = cDays;
        }
      }

      let parsedMaxDiscount = 0;
      if (maxDiscountRaw !== undefined && maxDiscountRaw !== '') {
        const disc = parseFloat(maxDiscountRaw);
        if (isNaN(disc) || disc < 0 || disc > 100) {
          reasons.push(`Invalid maxHeaderDiscountPct '${maxDiscountRaw}'. Must be between 0 and 100.`);
        } else {
          parsedMaxDiscount = disc;
        }
      }

      let resolvedGeoNodeId = null;
      if (geoRef) {
        const matchedNode = geoNameToNodeMap.get(geoRef.toLowerCase()) || geoIdToNodeMap.get(geoRef.toLowerCase());
        if (matchedNode) {
          resolvedGeoNodeId = matchedNode.id;
        } else {
          reasons.push(`Geography node '${geoRef}' not found in system.`);
        }
      }

      const eInvoiceEnabled =
        eInvoiceRaw !== undefined && eInvoiceRaw !== ''
          ? ['true', '1', 'yes', 'y'].includes(eInvoiceRaw.toLowerCase())
          : false;

      const isActive =
        isActiveRaw !== undefined && isActiveRaw !== ''
          ? ['true', '1', 'yes', 'y'].includes(isActiveRaw.toLowerCase())
          : true;

      if (reasons.length > 0) {
        rejected.push({
          rowNumber,
          code: code || `Row-${rowNumber}`,
          name: name || '—',
          reasons
        });
      } else {
        const existing = code ? codeToDealerMap.get(code.toLowerCase()) : null;
        validatedRows.push({
          rowNumber,
          isUpdate: Boolean(existing),
          existingId: existing?.id,
          dealerData: {
            code,
            name,
            gstin,
            stateCode,
            contactName,
            contactEmail,
            contactPhone,
            address,
            pincode,
            creditDays: parsedCreditDays,
            maxHeaderDiscountPct: parsedMaxDiscount,
            eInvoiceEnabled,
            geoNodeId: resolvedGeoNodeId,
            isActive
          }
        });
      }
    }

    if (mode === 'all-or-nothing' && rejected.length > 0) {
      return res.status(422).json({
        success: false,
        mode: 'all-or-nothing',
        totalRows: records.length,
        createdCount: 0,
        updatedCount: 0,
        rejectedCount: rejected.length,
        created: [],
        updated: [],
        rejected,
        message: `Import failed in all-or-nothing mode. ${rejected.length} invalid row(s) detected. No changes made to database.`
      });
    }

    const created = [];
    const updated = [];

    for (const item of validatedRows) {
      const { rowNumber, isUpdate, existingId, dealerData } = item;
      if (isUpdate && existingId) {
        const resDealer = await prisma.dealer.update({
          where: { id: existingId },
          data: dealerData
        });
        updated.push({
          rowNumber,
          code: resDealer.code,
          name: resDealer.name
        });
      } else {
        const resDealer = await prisma.dealer.create({
          data: dealerData
        });
        created.push({
          rowNumber,
          code: resDealer.code,
          name: resDealer.name
        });
      }
    }

    res.json({
      success: true,
      mode,
      totalRows: records.length,
      createdCount: created.length,
      updatedCount: updated.length,
      rejectedCount: rejected.length,
      created,
      updated,
      rejected,
      message: `Import processed. ${created.length} created, ${updated.length} updated, ${rejected.length} rejected.`
    });
  } catch (error) {
    next(error);
  }
});

