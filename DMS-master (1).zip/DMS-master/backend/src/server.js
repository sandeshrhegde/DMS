import { app } from './app.js';
import { env } from './config/env.js';
import { disconnectDatabase, initializeDatabase } from './config/database.js';

async function start() {
  const databaseConnected = await initializeDatabase();
  const server = app.listen(env.port, () => {
    const mode = databaseConnected ? 'PostgreSQL mode' : 'mock mode (no database configured)';
    console.log(`DMS API listening on http://localhost:${env.port} — ${mode}`);
  });

  const shutdown = async () => {
    server.close(async () => {
      await disconnectDatabase();
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

start().catch(async (error) => {
  console.error('Unable to start API:', error);
  await disconnectDatabase();
  process.exit(1);
});
