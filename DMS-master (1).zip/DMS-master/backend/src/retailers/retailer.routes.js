import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, requireBrandAdmin, resolveRequestDealerId } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  validateGstin,
  validatePan,
  validateMobile,
  checkRetailerDuplicates,
  calculateGstinChecksumChar
} from '../services/retailer-validation.service.js';

export const retailerRouter = Router();

/**
 * Middleware ensuring user is authenticated and attaching dealer scope.
 */
async function ensureAuthenticated(req, res, next) {
  try {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }
    const resolvedDealerId = await resolveRequestDealerId(req, user);
    req.effectiveDealerId = resolvedDealerId;
    if (!user.dealerId && resolvedDealerId) {
      user.dealerId = resolvedDealerId;
    }
    req.currentUser = user;
    next();
  } catch (err) {
    next(err);
  }
}

retailerRouter.use(ensureAuthenticated);

/**
 * GET /api/retailers/validate-gstin?gstin=...
 * Utility endpoint for client-side live validation and checksum computation.
 */
retailerRouter.get('/validate-gstin', (req, res) => {
  const { gstin } = req.query;
  if (!gstin) {
    return res.json({ valid: false, error: 'No GSTIN provided.' });
  }
  const result = validateGstin(gstin);
  const checkChar = calculateGstinChecksumChar(gstin.slice(0, 14));
  res.json({ ...result, expectedChecksumChar: checkChar });
});

/**
 * GET /api/retailers/pending-approvals
 * BRAND_ADMIN only: retrieves all retailers requiring approval or re-approval.
 */
retailerRouter.get('/pending-approvals', requireBrandAdmin, async (req, res, next) => {
  try {
    const [proposedRetailers, approvedWithPendingChanges] = await Promise.all([
      // 1. Initial proposals awaiting approval
      prisma.retailer.findMany({
        where: { status: 'PROPOSED' },
        include: {
          dealer: { select: { id: true, code: true, name: true } },
          geoNode: { select: { id: true, name: true, type: true, path: true } }
        },
        orderBy: { createdAt: 'desc' }
      }),
      // 2. Approved retailers with pending change requests
      prisma.retailer.findMany({
        where: {
          status: 'APPROVED',
          changeRequests: { some: { status: 'PENDING' } }
        },
        include: {
          dealer: { select: { id: true, code: true, name: true } },
          geoNode: { select: { id: true, name: true, type: true, path: true } },
          changeRequests: {
            where: { status: 'PENDING' },
            orderBy: { createdAt: 'desc' },
            take: 1
          }
        },
        orderBy: { updatedAt: 'desc' }
      })
    ]);

    // Attach duplicate warnings to each proposed retailer
    const proposedWithWarnings = await Promise.all(
      proposedRetailers.map(async (ret) => {
        const warnings = await checkRetailerDuplicates({
          gstin: ret.gstin,
          pan: ret.pan,
          mobile: ret.mobile,
          excludeRetailerId: ret.id
        });
        return {
          ...ret,
          canOrder: false,
          duplicateWarnings: warnings
        };
      })
    );

    const changesWithDetails = await Promise.all(
      approvedWithPendingChanges.map(async (ret) => {
        const pendingReq = ret.changeRequests[0];
        let geoNodeChange = null;
        if (pendingReq?.changes?.geoNodeId) {
          geoNodeChange = await prisma.geoNode.findUnique({
            where: { id: pendingReq.changes.geoNodeId },
            select: { id: true, name: true, type: true, path: true }
          });
        }
        return {
          ...ret,
          canOrder: true,
          pendingChangeRequest: pendingReq
            ? { ...pendingReq, geoNodeDetails: geoNodeChange }
            : null
        };
      })
    );

    res.json({
      proposedRetailers: proposedWithWarnings,
      pendingChangesRetailers: changesWithDetails,
      totalPending: proposedWithWarnings.length + changesWithDetails.length
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/retailers
 * List retailers scoped to the authenticated dealer (or all for BRAND_ADMIN).
 */
retailerRouter.get('/', async (req, res, next) => {
  try {
    const { user } = req;
    const currentUser = req.currentUser;
    const isBrand = currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;

    const { status, search, dealerId, page = 1, limit = 50 } = req.query;
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const take = Math.min(200, Math.max(1, parseInt(limit, 10) || 50));
    const skip = (pageNum - 1) * take;

    const where = {};

    // Dealer Scoping: dealers can only see their own retailers!
    if (!isBrand) {
      if (!currentUser.dealerId) {
        return res.status(403).json({ error: 'Dealer context missing from session.' });
      }
      where.dealerId = currentUser.dealerId;
    } else if (dealerId) {
      where.dealerId = dealerId;
    }

    if (status) {
      where.status = status;
    }

    if (search) {
      const q = search.trim();
      where.OR = [
        { legalName: { contains: q, mode: 'insensitive' } },
        { tradeName: { contains: q, mode: 'insensitive' } },
        { gstin: { contains: q, mode: 'insensitive' } },
        { pan: { contains: q, mode: 'insensitive' } },
        { mobile: { contains: q } }
      ];
    }

    const [retailersRaw, total] = await Promise.all([
      prisma.retailer.findMany({
        where,
        include: {
          dealer: { select: { id: true, code: true, name: true } },
          geoNode: { select: { id: true, name: true, type: true, path: true } },
          changeRequests: {
            where: { status: 'PENDING' },
            orderBy: { createdAt: 'desc' },
            take: 1
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take
      }),
      prisma.retailer.count({ where })
    ]);

    const retailers = retailersRaw.map((r) => {
      const pendingReq = r.changeRequests[0] || null;
      return {
        ...r,
        canOrder: r.status === 'APPROVED',
        hasPendingChanges: Boolean(pendingReq),
        pendingChanges: pendingReq?.changes || null,
        changeRequestId: pendingReq?.id || null
      };
    });

    res.json({
      retailers,
      total,
      page: pageNum,
      limit: take,
      totalPages: Math.ceil(total / take)
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/retailers/:id
 * Retrieve single retailer with duplicate warnings, audit logs, and pending changes.
 */
retailerRouter.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const currentUser = req.currentUser;
    const isBrand = currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;

    const retailer = await prisma.retailer.findUnique({
      where: { id },
      include: {
        dealer: { select: { id: true, code: true, name: true, stateCode: true } },
        geoNode: { select: { id: true, name: true, type: true, path: true } },
        changeRequests: {
          orderBy: { createdAt: 'desc' }
        },
        auditLogs: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!retailer) {
      return res.status(404).json({ error: 'Retailer not found.' });
    }

    // Dealer tenant isolation check
    if (!isBrand && retailer.dealerId !== currentUser.dealerId) {
      return res.status(403).json({ error: 'Access denied. You can only view your own dealership retailers.' });
    }

    const duplicateWarnings = await checkRetailerDuplicates({
      gstin: retailer.gstin,
      pan: retailer.pan,
      mobile: retailer.mobile,
      excludeRetailerId: retailer.id
    });

    const pendingReq = retailer.changeRequests.find((c) => c.status === 'PENDING') || null;

    res.json({
      ...retailer,
      canOrder: retailer.status === 'APPROVED',
      hasPendingChanges: Boolean(pendingReq),
      pendingChanges: pendingReq?.changes || null,
      duplicateWarnings
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/retailers/:id/can-order
 * Requirement 4: Only APPROVED retailers can be used for orders.
 */
retailerRouter.get('/:id/can-order', async (req, res, next) => {
  try {
    const retailer = await prisma.retailer.findUnique({
      where: { id: req.params.id },
      select: { id: true, legalName: true, status: true }
    });

    if (!retailer) {
      return res.status(404).json({ error: 'Retailer not found.' });
    }

    const canOrder = retailer.status === 'APPROVED';
    res.json({
      retailerId: retailer.id,
      legalName: retailer.legalName,
      status: retailer.status,
      canOrder,
      message: canOrder
        ? 'Retailer is APPROVED and eligible for commercial orders.'
        : `Retailer status is ${retailer.status}. Only APPROVED retailers can be used for orders.`
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/retailers/:id/audit
 * Requirement 5: Audit: store who/when/what changed for approval decisions.
 */
retailerRouter.get('/:id/audit', async (req, res, next) => {
  try {
    const logs = await prisma.retailerAuditLog.findMany({
      where: { retailerId: req.params.id },
      orderBy: { createdAt: 'desc' }
    });
    res.json({ logs });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/retailers
 * Dealer owner/operator/salesman proposes a new retailer (initial status PROPOSED).
 */
retailerRouter.post('/', async (req, res, next) => {
  try {
    const currentUser = req.currentUser;
    const isBrand = currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;

    const {
      legalName,
      tradeName,
      gstin,
      isUnregistered = false,
      pan,
      mobile,
      billingAddress,
      shippingAddress,
      stateCode,
      geoNodeId,
      retailerClass = 'C',
      channelType = 'MBO',
      creditLimit = 0,
      creditDays = 0,
      dealerId: explicitDealerId
    } = req.body;

    // 1. Mandatory base fields
    if (!legalName || !legalName.trim()) {
      return res.status(400).json({ error: 'Legal business name is required.' });
    }

    if (!billingAddress || !billingAddress.trim()) {
      return res.status(400).json({ error: 'Billing address is required.' });
    }

    if (!shippingAddress || !shippingAddress.trim()) {
      return res.status(400).json({ error: 'Shipping address is required.' });
    }

    if (!stateCode || !stateCode.trim()) {
      return res.status(400).json({ error: 'State code is required.' });
    }

    // 2. Validate Mobile
    const mobileRes = validateMobile(mobile);
    if (!mobileRes.valid) {
      return res.status(400).json({ error: mobileRes.error });
    }

    // 3. Validate GSTIN and PAN
    let validatedGstin = null;
    let validatedPan = null;

    if (isUnregistered) {
      // Unregistered entity has no GSTIN
      if (pan) {
        const panRes = validatePan(pan);
        if (!panRes.valid) return res.status(400).json({ error: panRes.error });
        validatedPan = panRes.pan;
      }
    } else {
      // Registered entity: validate GSTIN format and checksum
      const gstinRes = validateGstin(gstin);
      if (!gstinRes.valid) {
        return res.status(400).json({ error: gstinRes.error });
      }
      validatedGstin = gstinRes.gstin;

      // Extract PAN from GSTIN (chars 2-12)
      const extractedPan = validatedGstin.slice(2, 12);
      if (pan && pan.trim().toUpperCase() !== extractedPan) {
        return res.status(400).json({
          error: `Provided PAN '${pan}' does not match the PAN inside GSTIN ('${extractedPan}').`
        });
      }
      validatedPan = extractedPan;
    }

    // 4. Resolve Dealer ID
    let targetDealerId = currentUser.dealerId;
    if (isBrand && explicitDealerId) {
      targetDealerId = explicitDealerId;
    }

    if (!targetDealerId) {
      // Fallback to first active demo dealer if not bound to token
      const defaultDealer = await prisma.dealer.findFirst({ where: { isActive: true } });
      targetDealerId = defaultDealer?.id;
    }

    if (!targetDealerId) {
      return res.status(400).json({ error: 'Dealer ID is required to propose a retailer.' });
    }

    // 5. Cross-Dealer Duplicate Check (flagged as warning, does not block creation)
    const duplicateWarnings = await checkRetailerDuplicates({
      gstin: validatedGstin,
      pan: validatedPan,
      mobile: mobileRes.mobile
    });

    // 6. Create Retailer in DB (status: PROPOSED)
    const created = await prisma.retailer.create({
      data: {
        dealerId: targetDealerId,
        legalName: legalName.trim(),
        tradeName: tradeName ? tradeName.trim() : null,
        gstin: validatedGstin,
        isUnregistered: Boolean(isUnregistered),
        pan: validatedPan,
        mobile: mobileRes.mobile,
        billingAddress: billingAddress.trim(),
        shippingAddress: shippingAddress.trim(),
        stateCode: stateCode.trim(),
        geoNodeId: geoNodeId || null,
        retailerClass,
        channelType,
        creditLimit: parseFloat(creditLimit) || 0,
        creditDays: parseInt(creditDays, 10) || 0,
        status: 'PROPOSED'
      },
      include: {
        dealer: { select: { id: true, code: true, name: true } },
        geoNode: { select: { id: true, name: true, type: true } }
      }
    });

    // 7. Audit log creation
    await prisma.retailerAuditLog.create({
      data: {
        retailerId: created.id,
        action: 'PROPOSED',
        performedByUserId: currentUser.id || null,
        performedByRole: currentUser.role,
        performedByEmail: currentUser.email || null,
        details: {
          initialStatus: 'PROPOSED',
          legalName: created.legalName,
          gstin: created.gstin,
          creditLimit: created.creditLimit,
          warningsCount: duplicateWarnings.length
        }
      }
    });

    res.status(201).json({
      ...created,
      canOrder: false,
      duplicateWarnings,
      message: 'Retailer proposed successfully. Awaiting Brand Admin approval.'
    });
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/retailers/:id
 * Edit retailer.
 * - If status is PROPOSED or REJECTED: edits apply directly; if REJECTED, status resets to PROPOSED.
 * - If status is APPROVED: changes to gstin, creditLimit, or geoNodeId create a pending RetailerChangeRequest!
 */
retailerRouter.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const currentUser = req.currentUser;
    const isBrand = currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;

    const existing = await prisma.retailer.findUnique({
      where: { id },
      include: {
        changeRequests: { where: { status: 'PENDING' } }
      }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Retailer not found.' });
    }

    if (!isBrand && existing.dealerId !== currentUser.dealerId) {
      return res.status(403).json({ error: 'Access denied. You can only edit your own dealership retailers.' });
    }

    const {
      legalName,
      tradeName,
      gstin,
      isUnregistered,
      pan,
      mobile,
      billingAddress,
      shippingAddress,
      stateCode,
      geoNodeId,
      retailerClass,
      channelType,
      creditLimit,
      creditDays
    } = req.body;

    // Validate mobile if supplied
    let normalizedMobile = existing.mobile;
    if (mobile !== undefined) {
      const mobRes = validateMobile(mobile);
      if (!mobRes.valid) return res.status(400).json({ error: mobRes.error });
      normalizedMobile = mobRes.mobile;
    }

    // Validate GSTIN & PAN
    let newGstin = existing.gstin;
    let newPan = existing.pan;
    const effectiveUnregistered =
      isUnregistered !== undefined ? Boolean(isUnregistered) : existing.isUnregistered;

    if (effectiveUnregistered) {
      newGstin = null;
      if (pan) {
        const panRes = validatePan(pan);
        if (!panRes.valid) return res.status(400).json({ error: panRes.error });
        newPan = panRes.pan;
      }
    } else if (gstin !== undefined && gstin !== existing.gstin) {
      const gstinRes = validateGstin(gstin);
      if (!gstinRes.valid) return res.status(400).json({ error: gstinRes.error });
      newGstin = gstinRes.gstin;
      newPan = newGstin.slice(2, 12);
    }

    // CASE 1: Retailer is PROPOSED or REJECTED
    if (existing.status === 'PROPOSED' || existing.status === 'REJECTED') {
      const updated = await prisma.retailer.update({
        where: { id },
        data: {
          legalName: legalName !== undefined ? legalName.trim() : existing.legalName,
          tradeName: tradeName !== undefined ? (tradeName ? tradeName.trim() : null) : existing.tradeName,
          gstin: newGstin,
          isUnregistered: effectiveUnregistered,
          pan: newPan,
          mobile: normalizedMobile,
          billingAddress: billingAddress !== undefined ? billingAddress.trim() : existing.billingAddress,
          shippingAddress: shippingAddress !== undefined ? shippingAddress.trim() : existing.shippingAddress,
          stateCode: stateCode !== undefined ? stateCode.trim() : existing.stateCode,
          geoNodeId: geoNodeId !== undefined ? geoNodeId || null : existing.geoNodeId,
          retailerClass: retailerClass !== undefined ? retailerClass : existing.retailerClass,
          channelType: channelType !== undefined ? channelType : existing.channelType,
          creditLimit: creditLimit !== undefined ? parseFloat(creditLimit) : existing.creditLimit,
          creditDays: creditDays !== undefined ? parseInt(creditDays, 10) : existing.creditDays,
          status: 'PROPOSED', // Re-propose if was REJECTED
          rejectionReason: null
        },
        include: {
          dealer: { select: { id: true, code: true, name: true } },
          geoNode: { select: { id: true, name: true, type: true } }
        }
      });

      await prisma.retailerAuditLog.create({
        data: {
          retailerId: id,
          action: 'EDITED',
          performedByUserId: currentUser.id || null,
          performedByRole: currentUser.role,
          performedByEmail: currentUser.email || null,
          details: {
            wasStatus: existing.status,
            newStatus: 'PROPOSED',
            legalName: updated.legalName
          }
        }
      });

      const duplicateWarnings = await checkRetailerDuplicates({
        gstin: updated.gstin,
        pan: updated.pan,
        mobile: updated.mobile,
        excludeRetailerId: id
      });

      return res.json({
        ...updated,
        canOrder: false,
        duplicateWarnings,
        message: 'Retailer updated and submitted for approval.'
      });
    }

    // CASE 2: Retailer is APPROVED
    // Requirement 2: Changes to gstin, creditLimit or geo node on an APPROVED retailer create a pending change request
    // that needs re-approval (keep the old values live until approved).
    const parsedNewCreditLimit =
      creditLimit !== undefined ? parseFloat(creditLimit) : existing.creditLimit;
    const newGeoNodeId = geoNodeId !== undefined ? geoNodeId || null : existing.geoNodeId;

    const hasGstinChange = newGstin !== existing.gstin || effectiveUnregistered !== existing.isUnregistered;
    const hasCreditLimitChange = parsedNewCreditLimit !== existing.creditLimit;
    const hasGeoNodeChange = newGeoNodeId !== existing.geoNodeId;

    const requestedChanges = {};
    if (hasGstinChange) {
      requestedChanges.gstin = newGstin;
      requestedChanges.isUnregistered = effectiveUnregistered;
      requestedChanges.pan = newPan;
    }
    if (hasCreditLimitChange) {
      requestedChanges.creditLimit = parsedNewCreditLimit;
    }
    if (hasGeoNodeChange) {
      requestedChanges.geoNodeId = newGeoNodeId;
    }

    // Direct update of non-sensitive fields
    const updated = await prisma.retailer.update({
      where: { id },
      data: {
        legalName: legalName !== undefined ? legalName.trim() : existing.legalName,
        tradeName: tradeName !== undefined ? (tradeName ? tradeName.trim() : null) : existing.tradeName,
        mobile: normalizedMobile,
        billingAddress: billingAddress !== undefined ? billingAddress.trim() : existing.billingAddress,
        shippingAddress: shippingAddress !== undefined ? shippingAddress.trim() : existing.shippingAddress,
        stateCode: stateCode !== undefined ? stateCode.trim() : existing.stateCode,
        retailerClass: retailerClass !== undefined ? retailerClass : existing.retailerClass,
        channelType: channelType !== undefined ? channelType : existing.channelType,
        creditDays: creditDays !== undefined ? parseInt(creditDays, 10) : existing.creditDays
      },
      include: {
        dealer: { select: { id: true, code: true, name: true } },
        geoNode: { select: { id: true, name: true, type: true } }
      }
    });

    let pendingReq = null;

    if (Object.keys(requestedChanges).length > 0) {
      // Check if there is already an existing pending request; update it or create new
      if (existing.changeRequests.length > 0) {
        pendingReq = await prisma.retailerChangeRequest.update({
          where: { id: existing.changeRequests[0].id },
          data: {
            changes: {
              ...(existing.changeRequests[0].changes || {}),
              ...requestedChanges
            },
            updatedAt: new Date()
          }
        });
      } else {
        pendingReq = await prisma.retailerChangeRequest.create({
          data: {
            retailerId: id,
            proposedByUserId: currentUser.id || null,
            proposedByDealerId: existing.dealerId,
            changes: requestedChanges,
            status: 'PENDING'
          }
        });
      }

      await prisma.retailerAuditLog.create({
        data: {
          retailerId: id,
          action: 'CHANGE_PROPOSED',
          performedByUserId: currentUser.id || null,
          performedByRole: currentUser.role,
          performedByEmail: currentUser.email || null,
          details: {
            changes: requestedChanges,
            currentValues: {
              gstin: existing.gstin,
              creditLimit: existing.creditLimit,
              geoNodeId: existing.geoNodeId
            }
          }
        }
      });
    }

    res.json({
      ...updated,
      canOrder: true,
      hasPendingChanges: Boolean(pendingReq),
      pendingChanges: pendingReq?.changes || null,
      message:
        Object.keys(requestedChanges).length > 0
          ? 'Changes to GSTIN, Credit Limit, or Geography submitted for Brand re-approval. Live values remain unchanged until approved.'
          : 'Retailer updated successfully.'
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/retailers/:id/approve
 * BRAND_ADMIN only: approve proposed retailer.
 */
retailerRouter.post('/:id/approve', requireBrandAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const currentUser = req.currentUser;

    const existing = await prisma.retailer.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'Retailer not found.' });
    }

    if (existing.status !== 'PROPOSED') {
      return res.status(400).json({
        error: `Only PROPOSED retailers can be approved. Current status is ${existing.status}.`
      });
    }

    const approved = await prisma.retailer.update({
      where: { id },
      data: {
        status: 'APPROVED',
        rejectionReason: null
      },
      include: {
        dealer: { select: { id: true, code: true, name: true } },
        geoNode: { select: { id: true, name: true, type: true } }
      }
    });

    await prisma.retailerAuditLog.create({
      data: {
        retailerId: id,
        action: 'APPROVED',
        performedByUserId: currentUser.id || null,
        performedByRole: currentUser.role,
        performedByEmail: currentUser.email || null,
        details: {
          previousStatus: 'PROPOSED',
          newStatus: 'APPROVED'
        }
      }
    });

    res.json({
      ...approved,
      canOrder: true,
      message: 'Retailer approved successfully and is now active for commercial orders.'
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/retailers/:id/reject
 * BRAND_ADMIN only: reject proposed retailer with mandatory reason.
 */
retailerRouter.post('/:id/reject', requireBrandAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const currentUser = req.currentUser;

    if (!reason || !reason.trim()) {
      return res.status(400).json({ error: 'Rejection reason is required.' });
    }

    const existing = await prisma.retailer.findUnique({ where: { id } });
    if (!existing) {
      return res.status(404).json({ error: 'Retailer not found.' });
    }

    const rejected = await prisma.retailer.update({
      where: { id },
      data: {
        status: 'REJECTED',
        rejectionReason: reason.trim()
      },
      include: {
        dealer: { select: { id: true, code: true, name: true } },
        geoNode: { select: { id: true, name: true, type: true } }
      }
    });

    await prisma.retailerAuditLog.create({
      data: {
        retailerId: id,
        action: 'REJECTED',
        performedByUserId: currentUser.id || null,
        performedByRole: currentUser.role,
        performedByEmail: currentUser.email || null,
        details: {
          reason: reason.trim(),
          previousStatus: existing.status
        }
      }
    });

    res.json({
      ...rejected,
      canOrder: false,
      message: 'Retailer rejected.'
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/retailers/:id/changes/:changeId/approve
 * BRAND_ADMIN only: approve pending change request on an approved retailer.
 */
retailerRouter.post('/:id/changes/:changeId/approve', requireBrandAdmin, async (req, res, next) => {
  try {
    const { id, changeId } = req.params;
    const currentUser = req.currentUser;

    const changeReq = await prisma.retailerChangeRequest.findUnique({
      where: { id: changeId },
      include: { retailer: true }
    });

    if (!changeReq || changeReq.retailerId !== id) {
      return res.status(404).json({ error: 'Change request not found.' });
    }

    if (changeReq.status !== 'PENDING') {
      return res.status(400).json({
        error: `Change request is already ${changeReq.status}.`
      });
    }

    const changes = changeReq.changes || {};

    // Apply changes to live retailer
    const updateData = {};
    if (changes.gstin !== undefined) updateData.gstin = changes.gstin;
    if (changes.isUnregistered !== undefined) updateData.isUnregistered = changes.isUnregistered;
    if (changes.pan !== undefined) updateData.pan = changes.pan;
    if (changes.creditLimit !== undefined) updateData.creditLimit = changes.creditLimit;
    if (changes.geoNodeId !== undefined) updateData.geoNodeId = changes.geoNodeId;

    const [updatedRetailer, updatedReq] = await prisma.$transaction([
      prisma.retailer.update({
        where: { id },
        data: updateData,
        include: {
          dealer: { select: { id: true, code: true, name: true } },
          geoNode: { select: { id: true, name: true, type: true } }
        }
      }),
      prisma.retailerChangeRequest.update({
        where: { id: changeId },
        data: {
          status: 'APPROVED',
          reviewedByUserId: currentUser.id || null,
          reviewedAt: new Date()
        }
      }),
      prisma.retailerAuditLog.create({
        data: {
          retailerId: id,
          action: 'CHANGE_APPROVED',
          performedByUserId: currentUser.id || null,
          performedByRole: currentUser.role,
          performedByEmail: currentUser.email || null,
          details: {
            changeRequestId: changeId,
            appliedChanges: changes
          }
        }
      })
    ]);

    res.json({
      retailer: updatedRetailer,
      changeRequest: updatedReq,
      message: 'Pending change request approved and live retailer updated.'
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/retailers/:id/changes/:changeId/reject
 * BRAND_ADMIN only: reject pending change request.
 */
retailerRouter.post('/:id/changes/:changeId/reject', requireBrandAdmin, async (req, res, next) => {
  try {
    const { id, changeId } = req.params;
    const { reason } = req.body;
    const currentUser = req.currentUser;

    const changeReq = await prisma.retailerChangeRequest.findUnique({
      where: { id: changeId }
    });

    if (!changeReq || changeReq.retailerId !== id) {
      return res.status(404).json({ error: 'Change request not found.' });
    }

    if (changeReq.status !== 'PENDING') {
      return res.status(400).json({
        error: `Change request is already ${changeReq.status}.`
      });
    }

    const updatedReq = await prisma.retailerChangeRequest.update({
      where: { id: changeId },
      data: {
        status: 'REJECTED',
        rejectionReason: reason ? reason.trim() : null,
        reviewedByUserId: currentUser.id || null,
        reviewedAt: new Date()
      }
    });

    await prisma.retailerAuditLog.create({
      data: {
        retailerId: id,
        action: 'CHANGE_REJECTED',
        performedByUserId: currentUser.id || null,
        performedByRole: currentUser.role,
        performedByEmail: currentUser.email || null,
        details: {
          changeRequestId: changeId,
          reason: reason ? reason.trim() : 'Rejected by Brand Admin'
        }
      }
    });

    res.json({
      changeRequest: updatedReq,
      message: 'Pending change request rejected. Live retailer values remain unchanged.'
    });
  } catch (error) {
    next(error);
  }
});

