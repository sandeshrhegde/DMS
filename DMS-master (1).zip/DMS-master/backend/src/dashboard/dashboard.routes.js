import { Router } from 'express';
import { verifyAccessToken } from '../auth/token.service.js';
import { dashboardDataSource } from './dashboard.datasource.js';
import { DEALER_ROLES, DASHBOARD_ROLES } from '@dms/shared';
import { getMockDashboard, getMockTenants } from '../services/mock-dashboard.service.js';

export const dashboardRouter = Router();

function authenticateDashboardRole(req, res, allowedRoles, forbiddenMessage) {
  // 1. Try Bearer JWT token if provided
  const authHeader = req.get('authorization');
  let role = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      const token = authHeader.replace(/^Bearer\s+/i, '').trim();
      const decoded = verifyAccessToken(token);
      role = decoded.role;
      req.user = decoded;
    } catch {
      res.status(401).json({ error: 'Invalid or expired access token.' });
      return null;
    }
  }

  // 2. Try demo role header if no token (or alongside)
  if (!role) {
    role = req.get('x-demo-role') || req.get('x-user-role') || req.user?.role;
  }

  if (!role) {
    res.status(401).json({ error: 'Authentication required.' });
    return null;
  }

  if (!allowedRoles.includes(role)) {
    res.status(403).json({ error: forbiddenMessage });
    return null;
  }

  return role;
}

/**
 * GET /dashboard/brand (BRAND_ADMIN only)
 */
dashboardRouter.get('/brand', async (req, res, next) => {
  try {
    const role = authenticateDashboardRole(
      req,
      res,
      [DASHBOARD_ROLES.BRAND_ADMIN],
      'Brand Admin role required.'
    );
    if (!role) return;

    const data = await dashboardDataSource.getBrandDashboard();
    res.status(200).json(data);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /dashboard/dealer (Dealer roles: DEALER_OWNER, DEALER_OPERATOR, SALESMAN)
 */
dashboardRouter.get('/dealer', async (req, res, next) => {
  try {
    const role = authenticateDashboardRole(
      req,
      res,
      DEALER_ROLES,
      'Dealer role required.'
    );
    if (!role) return;

    const dealerId = req.user?.dealerId || req.get('x-tenant-id') || undefined;
    const data = await dashboardDataSource.getDealerDashboard(dealerId);
    res.status(200).json(data);
  } catch (error) {
    next(error);
  }
});

// Backward-compatible routes for older mock endpoints if requested
dashboardRouter.get('/', (req, res) => {
  res.status(200).json(getMockDashboard(req.get('x-tenant-id')));
});

dashboardRouter.get('/mock/tenants', (req, res) => {
  res.status(200).json({ mode: 'mock', tenants: getMockTenants() });
});

