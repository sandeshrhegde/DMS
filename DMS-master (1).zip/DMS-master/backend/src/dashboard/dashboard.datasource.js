/**
 * Dashboard DataSource Interface and Mock Provider.
 * Allows switching to a real Prisma-backed database data source in Prompt 9
 * with a single provider change.
 */

function generate30DayTrend(baseValue, variance) {
  const points = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().slice(0, 10);
    const dayOfWeek = d.getDay();
    const weekendMultiplier = dayOfWeek === 0 || dayOfWeek === 6 ? 0.78 : 1.08;
    const sineFactor = Math.sin((29 - i) / 3.2) * 0.12;
    const pseudoVariation = (((i * 7919 + 1013) % 1000) / 1000 - 0.5) * variance;
    const value = Math.max(1000, Math.round((baseValue * (1 + sineFactor) * weekendMultiplier) + pseudoVariation));
    points.push({ date: dateStr, value });
  }
  return points;
}

/**
 * Interface contract for Dashboard Data Sources.
 */
export class DashboardDataSource {
  /**
   * Retrieves high-level aggregated brand dashboard metrics.
   * @returns {Promise<import('@dms/shared').BrandDashboardResponse>}
   */
  async getBrandDashboard() {
    throw new Error('Method getBrandDashboard() not implemented.');
  }

  /**
   * Retrieves operational dealer dashboard metrics.
   * @param {string} [dealerId]
   * @returns {Promise<import('@dms/shared').DealerDashboardResponse>}
   */
  async getDealerDashboard(dealerId) { // eslint-disable-line no-unused-vars
    throw new Error('Method getDealerDashboard() not implemented.');
  }

  // Convenient alias methods matching shorthand interface calls
  async brand() {
    return this.getBrandDashboard();
  }

  async dealer(dealerId) {
    return this.getDealerDashboard(dealerId);
  }
}

/**
 * Mock implementation of DashboardDataSource returning realistic business numbers.
 */
export class MockDashboardDataSource extends DashboardDataSource {
  async getBrandDashboard() {
    const brandSalesTrend = generate30DayTrend(320000, 45000);

    const totalSecondarySales = {
      today: 428500,
      monthToDate: 9246800,
      vsLastMonthPercent: 12.4
    };

    const activeDealersCount = 42;
    const pendingRetailerApprovalsCount = 17;

    const salesByDealer = [
      { dealerId: 'dlr-001', name: 'Demo Motors Pvt Ltd', value: 1820000 },
      { dealerId: 'dlr-002', name: 'City Auto Group Mumbai', value: 1475000 },
      { dealerId: 'dlr-003', name: 'Metro Wheels Bangalore', value: 1190000 },
      { dealerId: 'dlr-004', name: 'Prime Automotive Delhi', value: 955000 },
      { dealerId: 'dlr-005', name: 'North Star Mobility Pune', value: 781000 },
      { dealerId: 'dlr-006', name: 'Apex Automotive Hyderabad', value: 712000 },
      { dealerId: 'dlr-007', name: 'Summit Motors Chennai', value: 645000 },
      { dealerId: 'dlr-008', name: 'Horizon Wheels Kolkata', value: 589000 },
      { dealerId: 'dlr-009', name: 'Silverline Auto Ahmedabad', value: 521000 },
      { dealerId: 'dlr-010', name: 'Prestige Cars Jaipur', value: 465000 }
    ];

    const dealersWithLowStock = [
      { dealerId: 'dlr-003', dealer: 'Metro Wheels Bangalore', skus: 8, status: 'Critical', minimumThreshold: 15 },
      { dealerId: 'dlr-005', dealer: 'North Star Mobility Pune', skus: 5, status: 'Low', minimumThreshold: 12 },
      { dealerId: 'dlr-007', dealer: 'Summit Motors Chennai', skus: 4, status: 'Low', minimumThreshold: 10 },
      { dealerId: 'dlr-010', dealer: 'Prestige Cars Jaipur', skus: 2, status: 'Warning', minimumThreshold: 8 }
    ];

    const kpis = [
      {
        label: 'Secondary sales today',
        value: totalSecondarySales.today,
        change: totalSecondarySales.vsLastMonthPercent,
        changeType: 'increase',
        format: 'currency',
        helperText: `+${totalSecondarySales.vsLastMonthPercent}% vs last month`
      },
      {
        label: 'Month-to-date sales',
        value: totalSecondarySales.monthToDate,
        change: 8.7,
        changeType: 'increase',
        format: 'currency',
        helperText: '+8.7% vs last month'
      },
      {
        label: 'Active dealers',
        value: activeDealersCount,
        change: 3,
        changeType: 'increase',
        format: 'number',
        helperText: 'Across all zones'
      },
      {
        label: 'Pending retailer approvals',
        value: pendingRetailerApprovalsCount,
        change: -2,
        changeType: 'decrease',
        format: 'number',
        helperText: 'In review queue'
      }
    ];

    return {
      totalSecondarySales,
      activeDealersCount,
      salesByDealer,
      dealersWithLowStock,
      pendingRetailerApprovalsCount,
      salesTrend: brandSalesTrend,
      kpis
    };
  }

  async getDealerDashboard(dealerId) { // eslint-disable-line no-unused-vars
    const dealerSalesTrend = generate30DayTrend(110000, 22000);

    const todaysSales = 128500;
    const monthToDateSales = 2146800;
    const collectionsToday = 97200;
    const pendingOrdersCount = 14;
    const outstandingTotal = 678400;

    const stockAlerts = [
      { sku: 'BRK-204', name: 'Front Brake Pads (Ceramic)', available: 2, minimum: 8, category: 'Braking' },
      { sku: 'OIL-5W30', name: 'Synthetic Engine Oil 5W-30 (1L)', available: 4, minimum: 15, category: 'Lubricants' },
      { sku: 'FLT-113', name: 'Engine Air Filter Element', available: 1, minimum: 6, category: 'Filters' },
      { sku: 'SPK-401', name: 'Iridium Spark Plug Set (x4)', available: 3, minimum: 10, category: 'Ignition' },
      { sku: 'ROTR-09', name: 'Ventilated Disc Brake Rotor', available: 1, minimum: 5, category: 'Braking' },
      { sku: 'CLT-302', name: 'Clutch Plate & Disc Assembly', available: 0, minimum: 4, category: 'Transmission' },
      { sku: 'BAT-12V', name: '12V 45Ah Maintenance Battery', available: 2, minimum: 6, category: 'Electrical' },
      { sku: 'WPR-22', name: 'All-Weather Wiper Blades 22"', available: 5, minimum: 12, category: 'Accessories' },
      { sku: 'COOL-50', name: 'Premixed Long-Life Coolant (1L)', available: 3, minimum: 8, category: 'Fluids' },
      { sku: 'FUSE-10', name: 'Mini Blade Fuse Assortment Pack', available: 4, minimum: 10, category: 'Electrical' }
    ];

    const kpis = [
      {
        label: "Today's sales",
        value: todaysSales,
        change: 9.8,
        changeType: 'increase',
        format: 'currency',
        helperText: '+9.8% vs yesterday'
      },
      {
        label: 'Month-to-date sales',
        value: monthToDateSales,
        change: 6.4,
        changeType: 'increase',
        format: 'currency',
        helperText: '+6.4% vs last month'
      },
      {
        label: 'Collections today',
        value: collectionsToday,
        change: 4.1,
        changeType: 'increase',
        format: 'currency',
        helperText: '+4.1% vs yesterday'
      },
      {
        label: 'Pending orders',
        value: pendingOrdersCount,
        format: 'number',
        helperText: 'Awaiting fulfillment'
      },
      {
        label: 'Outstanding total',
        value: outstandingTotal,
        format: 'currency',
        helperText: 'Accounts receivable balance'
      }
    ];

    return {
      todaysSales,
      monthToDateSales,
      collectionsToday,
      pendingOrdersCount,
      outstandingTotal,
      stockAlerts,
      salesTrend: dealerSalesTrend,
      kpis
    };
  }
}

/**
 * Active Dashboard Data Source provider instance.
 * In Prompt 9, swap this one provider instance with PrismaDashboardDataSource
 * or call setDashboardDataSource() to use live database data.
 */
let activeProvider = new MockDashboardDataSource();

export const dashboardDataSource = new Proxy({}, {
  get(target, prop) {
    return activeProvider[prop]?.bind(activeProvider);
  }
});

export function getDashboardDataSource() {
  return activeProvider;
}

export function setDashboardDataSource(newProvider) {
  if (!newProvider) {
    throw new Error('Cannot set null or undefined DashboardDataSource provider.');
  }
  activeProvider = newProvider;
}
