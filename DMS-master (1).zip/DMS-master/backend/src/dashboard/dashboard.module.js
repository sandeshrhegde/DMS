import {
  DashboardDataSource,
  MockDashboardDataSource,
  dashboardDataSource,
  getDashboardDataSource,
  setDashboardDataSource
} from './dashboard.datasource.js';
import { dashboardRouter } from './dashboard.routes.js';

export class DashboardModule {
  static get DataSource() {
    return DashboardDataSource;
  }

  static get MockDataSource() {
    return MockDashboardDataSource;
  }

  static get provider() {
    return getDashboardDataSource();
  }

  static setProvider(newProvider) {
    setDashboardDataSource(newProvider);
  }

  static get router() {
    return dashboardRouter;
  }
}

export {
  DashboardDataSource,
  MockDashboardDataSource,
  dashboardDataSource,
  getDashboardDataSource,
  setDashboardDataSource,
  dashboardRouter
};

