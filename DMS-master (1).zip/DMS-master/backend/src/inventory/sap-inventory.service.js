import { prisma } from '../config/database.js';

/**
 * Runtime SAP S/4HANA Connection Configuration
 * Allows dynamic URL update at runtime or fallback to process.env.SAP_S4HANA_ENDPOINT_URL
 */
let runtimeSapConfig = {
  endpointUrl: process.env.SAP_S4HANA_ENDPOINT_URL || '',
  apiKey: process.env.SAP_S4HANA_API_KEY || '',
  timeoutMs: Number(process.env.SAP_S4HANA_TIMEOUT_MS || 10000),
  lastUpdated: new Date().toISOString()
};

/**
 * Production-grade sample SAP S/4HANA Feeds
 * Incorporates exact fabric.json and garmet.json structures with realistic textile & apparel dispatches.
 */
export const SAMPLE_FABRIC_ITEMS = [
  {
    Section: "FABRIC",
    "sub section": "SHIRTING",
    ARTICLE: "HUNTERZ CS-00102",
    para1: "102",
    para2: "14.000 MTR",
    para3: "0",
    para4: "HUNTERZ CS-00102",
    para5: "14",
    para6: "",
    purchase_price: "0.0",
    MRP: "235.0",
    WHOLE_SALE: "317.0",
    "BILL RATE": "235.0",
    codescheme: "2",
    Itemcode: "10040070102003944953",
    UOM: "MTR",
    BRAND: "CADINI",
    CATEGORY: "CADINI Fabrics",
    department: "MEN WEAR",
    pattern: "TEXTURE",
    SLEEVE: "",
    collar: "",
    fabric: "147",
    Weave: "TWILL",
    FIT: "",
    CUFF: "",
    Collection: "AUTUMN DELIGHT",
    Length: "14.00",
    Neck: "",
    Packs: "1",
    PLEATS: "",
    Reversibilty: "NO",
    Width: "58.0",
    EXMILL: "235.0",
    Sold_To_Party: "5009429",
    Bill_No: "9070171639",
    Bill_Date: "2026-10-06",
    Serial: "1004007010",
    batch: "2003944953",
    Qty: "14.0",
    Chalan: "8011124037",
    CUSTOMER_NAME: "AGRAWAL TEXTILES",
    TRNSPRTR: "310241.0",
    TRNSPRTR_NAME: "RAJDHANI INTERSTATE TRANSPORT PVT L",
    LR_NO: "26232051",
    LR_DATE: "2026-10-06",
    BILL_AMT: "3309.74",
    "MARK UP": "0.0",
    "HSN CODE": "52103110",
    "CGST RATE": "0",
    "CGST AMT": "0.0",
    "SGST RATE": "0",
    "SGST AMT": "0.0",
    "IGST RATE": "5",
    "IGST AMT": "165.49",
    "UGST RATE": "0",
    "UGST AMT": "0.0",
    "BUSINESS PLACE": "TARAPUR PLANT",
    "BUSINESS CODE": "1000",
    TRADEDISC: "0.0",
    Cancelled: "",
    "TYPE OF FIBRE": "100% LYOCELL",
    TCS: "0.0",
    DISCOUNT: "0.0",
    PACKING: "19.74",
    DIVISION: "CADINI-SHIRTING",
    "PACK DATE": "2026-10-06"
  },
  {
    Section: "FABRIC",
    "sub section": "SUITING",
    ARTICLE: "ROYAL CHECKS RC-409",
    para1: "409",
    para2: "30.000 MTR",
    para3: "0",
    para4: "ROYAL CHECKS RC-409",
    para5: "30",
    para6: "",
    purchase_price: "0.0",
    MRP: "540.0",
    WHOLE_SALE: "620.0",
    "BILL RATE": "485.0",
    codescheme: "2",
    Itemcode: "10040070102003948812",
    UOM: "MTR",
    BRAND: "SIYARAM",
    CATEGORY: "Siyaram Suiting",
    department: "FORMAL WEAR",
    pattern: "MICRO CHECKS",
    SLEEVE: "",
    collar: "",
    fabric: "152",
    Weave: "DOBBY",
    FIT: "",
    CUFF: "",
    Collection: "ROYAL CLUB",
    Length: "30.00",
    Neck: "",
    Packs: "1",
    PLEATS: "",
    Reversibilty: "NO",
    Width: "58.0",
    EXMILL: "485.0",
    Sold_To_Party: "5009429",
    Bill_No: "9070171640",
    Bill_Date: "2026-10-06",
    Serial: "1004007011",
    batch: "2003948812",
    Qty: "30.0",
    Chalan: "8011124038",
    CUSTOMER_NAME: "AGRAWAL TEXTILES",
    TRNSPRTR: "310241.0",
    TRNSPRTR_NAME: "RAJDHANI INTERSTATE TRANSPORT PVT L",
    LR_NO: "26232052",
    LR_DATE: "2026-10-06",
    BILL_AMT: "14550.00",
    "MARK UP": "0.0",
    "HSN CODE": "55121900",
    "CGST RATE": "2.5",
    "CGST AMT": "363.75",
    "SGST RATE": "2.5",
    "SGST AMT": "363.75",
    "IGST RATE": "0",
    "IGST AMT": "0.0",
    "UGST RATE": "0",
    "UGST AMT": "0.0",
    "BUSINESS PLACE": "SILVASSA PLANT",
    "BUSINESS CODE": "1000",
    TRADEDISC: "0.0",
    Cancelled: "",
    "TYPE OF FIBRE": "POLY-VISCOSE (PV)",
    TCS: "0.0",
    DISCOUNT: "0.0",
    PACKING: "45.00",
    DIVISION: "SIYARAM-SUITING",
    "PACK DATE": "2026-10-06"
  },
  {
    Section: "FABRIC",
    "sub section": "LINEN SHIRTING",
    ARTICLE: "J.HAMPSTEAD PURE LINEN 60 LEA",
    para1: "018",
    para2: "22.500 MTR",
    para3: "0",
    para4: "J.HAMPSTEAD PURE LINEN 60 LEA",
    para5: "22.5",
    para6: "",
    purchase_price: "0.0",
    MRP: "795.0",
    WHOLE_SALE: "950.0",
    "BILL RATE": "680.0",
    codescheme: "2",
    Itemcode: "10040070102003951194",
    UOM: "MTR",
    BRAND: "J.HAMPSTEAD",
    CATEGORY: "Premium Linen",
    department: "LUXURY LINEN",
    pattern: "PLAIN WEAVE",
    SLEEVE: "",
    collar: "",
    fabric: "160",
    Weave: "PLAIN",
    FIT: "",
    CUFF: "",
    Collection: "ITALIAN TOUCH",
    Length: "22.50",
    Neck: "",
    Packs: "1",
    PLEATS: "",
    Reversibilty: "NO",
    Width: "58.0",
    EXMILL: "680.0",
    Sold_To_Party: "DEMO-001",
    Bill_No: "9070171641",
    Bill_Date: "2026-10-07",
    Serial: "1004007012",
    batch: "2003951194",
    Qty: "22.5",
    Chalan: "8011124039",
    CUSTOMER_NAME: "DEMO MOTORS MUMBAI",
    TRNSPRTR: "310550.0",
    TRNSPRTR_NAME: "V-TRANS LOGISTICS INDIA",
    LR_NO: "99182310",
    LR_DATE: "2026-10-07",
    BILL_AMT: "15300.00",
    "MARK UP": "0.0",
    "HSN CODE": "53091900",
    "CGST RATE": "0",
    "CGST AMT": "0.0",
    "SGST RATE": "0",
    "SGST AMT": "0.0",
    "IGST RATE": "5",
    "IGST AMT": "765.00",
    "UGST RATE": "0",
    "UGST AMT": "0.0",
    "BUSINESS PLACE": "TARAPUR PLANT",
    "BUSINESS CODE": "1000",
    TRADEDISC: "0.0",
    Cancelled: "",
    "TYPE OF FIBRE": "100% PURE EUROPEAN FLAX LINEN",
    TCS: "0.0",
    DISCOUNT: "0.0",
    PACKING: "35.00",
    DIVISION: "JHAMPSTEAD-LINEN",
    "PACK DATE": "2026-10-07"
  }
];

export const SAMPLE_GARMENT_ITEMS = [
  {
    BARCODE: "5580024151643",
    MAKTX: "H5336B 0132",
    "COMPANY NAME": "Oxemberg",
    SHADE: "1",
    SIZE: "32",
    "SGST PER": "0.0",
    "SGST AMT": "0.0",
    MRP: "1399.0",
    PRODUCT: "CASUAL TROUSER",
    "HSN CODE": "62034200",
    Bill_No: "9170041946",
    QUANTITY: "1.0",
    Challan_No: "8020155152",
    Bill_Date: "2026-10-07",
    Bill_To_Party: "BOMBAY HOSIERY",
    MATNR: "5OXTR0R0000H5336B0132",
    SUBBRAND: "Casual Trouser",
    FABTYPE: "PRINT",
    SLEEVES: "N.A.",
    FIT: "BRAWN FIT",
    SEASON: "AW26",
    "DISC(T)": "0.0",
    "DISC EOSS": "0.0",
    KDMAT: "",
    EXMILL: "806.0",
    WHOLESALE: "937.0",
    CUFF: "N.A."
  },
  {
    BARCODE: "5580024151644",
    MAKTX: "H5336B 0134",
    "COMPANY NAME": "Oxemberg",
    SHADE: "1",
    SIZE: "34",
    "SGST PER": "0.0",
    "SGST AMT": "0.0",
    MRP: "1399.0",
    PRODUCT: "CASUAL TROUSER",
    "HSN CODE": "62034200",
    Bill_No: "9170041946",
    QUANTITY: "2.0",
    Challan_No: "8020155152",
    Bill_Date: "2026-10-07",
    Bill_To_Party: "BOMBAY HOSIERY",
    MATNR: "5OXTR0R0000H5336B0134",
    SUBBRAND: "Casual Trouser",
    FABTYPE: "PRINT",
    SLEEVES: "N.A.",
    FIT: "BRAWN FIT",
    SEASON: "AW26",
    "DISC(T)": "0.0",
    "DISC EOSS": "0.0",
    KDMAT: "",
    EXMILL: "806.0",
    WHOLESALE: "937.0",
    CUFF: "N.A."
  },
  {
    BARCODE: "5580024152899",
    MAKTX: "OX-SHIRT-SLIM-40",
    "COMPANY NAME": "Oxemberg",
    SHADE: "NAVY",
    SIZE: "40",
    "SGST PER": "2.5",
    "SGST AMT": "29.75",
    MRP: "1199.0",
    PRODUCT: "FORMAL SHIRT",
    "HSN CODE": "62052000",
    Bill_No: "9170041948",
    QUANTITY: "3.0",
    Challan_No: "8020155155",
    Bill_Date: "2026-10-08",
    Bill_To_Party: "DEMO MOTORS MUMBAI",
    MATNR: "5OXSH1S0000NAVY0040",
    SUBBRAND: "Formal Shirts",
    FABTYPE: "COTTON TWILL",
    SLEEVES: "FULL SLEEVE",
    FIT: "SLIM FIT",
    SEASON: "AW26",
    "DISC(T)": "0.0",
    "DISC EOSS": "0.0",
    KDMAT: "",
    EXMILL: "680.0",
    WHOLESALE: "790.0",
    CUFF: "REGULAR"
  },
  {
    BARCODE: "5580024153102",
    MAKTX: "OX-DENIM-RGD-32",
    "COMPANY NAME": "Oxemberg",
    SHADE: "INDIGO DARK",
    SIZE: "32",
    "SGST PER": "2.5",
    "SGST AMT": "42.25",
    MRP: "1899.0",
    PRODUCT: "DENIM JEANS",
    "HSN CODE": "62034200",
    Bill_No: "9170041950",
    QUANTITY: "2.0",
    Challan_No: "8020155158",
    Bill_Date: "2026-10-08",
    Bill_To_Party: "DEMO MOTORS MUMBAI",
    MATNR: "5OXDN0R0000INDD0032",
    SUBBRAND: "Oxemberg Denim",
    FABTYPE: "STRETCH DENIM",
    SLEEVES: "N.A.",
    FIT: "SLIM TAPERED",
    SEASON: "AW26",
    "DISC(T)": "0.0",
    "DISC EOSS": "0.0",
    KDMAT: "",
    EXMILL: "1050.0",
    WHOLESALE: "1250.0",
    CUFF: "N.A."
  }
];

/**
 * Normalizes both Fabric and Garment lines into a unified shape
 * while preserving 100% of the raw SAP fields for inspector drawer.
 */
function normalizeSapRow(row, type) {
  if (type === 'FABRIC' || row.Section === 'FABRIC') {
    const qtyMtr = parseFloat(row.Qty || 14.0);
    const rate = parseFloat(row['BILL RATE'] || row.EXMILL || row.MRP || 235.0);
    const mrp = parseFloat(row.MRP || 235.0);
    const totalAmt = parseFloat(row.BILL_AMT || (qtyMtr * rate));
    const igstAmt = parseFloat(row['IGST AMT'] || 0.0);
    const cgstAmt = parseFloat(row['CGST AMT'] || 0.0);
    const sgstAmt = parseFloat(row['SGST AMT'] || 0.0);

    return {
      id: `FAB-${row.Itemcode || row.Serial}-${row.batch}`,
      type: 'FABRIC',
      billNo: row.Bill_No,
      billDate: row.Bill_Date,
      partyCode: row.Sold_To_Party,
      partyName: row.CUSTOMER_NAME,
      brand: row.BRAND,
      category: row.CATEGORY,
      division: row.DIVISION || row['sub section'] || 'FABRIC',
      article: row.ARTICLE,
      shade: row.para1,
      sizeOrLength: row.para2 || `${qtyMtr} MTR`,
      barcode: row.Itemcode,
      itemCode: row.Itemcode,
      serialNo: row.Serial,
      batch: row.batch,
      challanNo: row.Chalan,
      uom: row.UOM || 'MTR',
      qty: qtyMtr,
      rate,
      wholesaleRate: parseFloat(row.WHOLE_SALE || rate),
      mrp,
      totalAmount: totalAmt,
      hsnCode: row['HSN CODE'] || '52103110',
      taxRate: parseFloat(row['IGST RATE'] || (parseFloat(row['CGST RATE'] || 0) + parseFloat(row['SGST RATE'] || 0)) || 5.0),
      taxAmount: igstAmt > 0 ? igstAmt : (cgstAmt + sgstAmt),
      fibre: row['TYPE OF FIBRE'] || '100% LYOCELL',
      transporter: row.TRNSPRTR_NAME || '',
      lrNo: row.LR_NO || '',
      lrDate: row.LR_DATE || row.Bill_Date,
      plant: row['BUSINESS PLACE'] || 'PLANT 1000',
      status: 'IN_TRANSIT_SAP',
      rawSapData: row
    };
  }

  // GARMENT normalization
  const qtyPcs = parseFloat(row.QUANTITY || 1.0);
  const exMill = parseFloat(row.EXMILL || 806.0);
  const mrp = parseFloat(row.MRP || 1399.0);
  const wholesale = parseFloat(row.WHOLESALE || 937.0);

  return {
    id: `GAR-${row.BARCODE}-${row.MATNR}`,
    type: 'GARMENT',
    billNo: row.Bill_No,
    billDate: row.Bill_Date,
    partyCode: row.Bill_To_Party,
    partyName: row.Bill_To_Party,
    brand: row['COMPANY NAME'] || 'Oxemberg',
    category: row.PRODUCT || 'Ready-Made Garment',
    division: row.SUBBRAND || 'Oxemberg Apparel',
    article: row.MAKTX,
    shade: row.SHADE,
    sizeOrLength: row.SIZE,
    barcode: row.BARCODE,
    itemCode: row.MATNR,
    serialNo: row.MATNR,
    batch: row.SEASON || `LOT-${new Date().getFullYear()}`,
    challanNo: row.Challan_No,
    uom: 'PCS',
    qty: qtyPcs,
    rate: exMill,
    wholesaleRate: wholesale,
    mrp,
    totalAmount: Math.round(qtyPcs * exMill * 100) / 100,
    hsnCode: row['HSN CODE'] || '62034200',
    taxRate: 5.0,
    taxAmount: Math.round(qtyPcs * exMill * 0.05 * 100) / 100,
    fibre: row.FABTYPE || 'COTTON',
    fit: row.FIT || 'REGULAR',
    sleeves: row.SLEEVES || 'N.A.',
    season: row.SEASON || 'AW26',
    transporter: 'Siyaram Central Fleet',
    lrNo: `LR-${row.Challan_No}`,
    lrDate: row.Bill_Date,
    plant: 'APPAREL COMPLEX',
    status: 'IN_TRANSIT_SAP',
    rawSapData: row
  };
}

/**
 * Fetch Data from SAP S/4HANA (Live or Production-Grade Simulation)
 */
export async function fetchSapInventoryData({ search = '', division = '', brand = '' } = {}) {
  const isUrlConfigured = Boolean(runtimeSapConfig.endpointUrl && runtimeSapConfig.endpointUrl.trim().startsWith('http'));
  let source = isUrlConfigured ? 'LIVE_SAP_S4HANA' : 'PRODUCTION_SIMULATION';
  let rawFabric = SAMPLE_FABRIC_ITEMS;
  let rawGarments = SAMPLE_GARMENT_ITEMS;
  let liveFetchError = null;

  if (isUrlConfigured) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), runtimeSapConfig.timeoutMs);

      const headers = {
        'Accept': 'application/json',
        'User-Agent': 'Siyaram-DMS-Client/1.0'
      };
      if (runtimeSapConfig.apiKey) {
        headers['Authorization'] = runtimeSapConfig.apiKey.startsWith('Bearer ')
          ? runtimeSapConfig.apiKey
          : `Bearer ${runtimeSapConfig.apiKey}`;
      }

      const sapResponse = await fetch(runtimeSapConfig.endpointUrl, {
        method: 'GET',
        headers,
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (sapResponse.ok) {
        const payload = await sapResponse.json();
        // SAP might return direct array or { d: { results: [...] } } or { items: [...] }
        const parsedList = Array.isArray(payload)
          ? payload
          : (payload.d?.results || payload.items || payload.data || []);

        // Filter or divide items into Fabric and Garment
        const fetchedFabrics = parsedList.filter((item) => item.Section === 'FABRIC' || item.UOM === 'MTR');
        const fetchedGarments = parsedList.filter((item) => item.BARCODE || item.MATNR || item.Section === 'GARMENT');

        if (fetchedFabrics.length > 0) rawFabric = fetchedFabrics;
        if (fetchedGarments.length > 0) rawGarments = fetchedGarments;
        source = 'LIVE_SAP_S4HANA';
      } else {
        liveFetchError = `SAP Endpoint responded with HTTP status ${sapResponse.status} ${sapResponse.statusText}. Using fallback simulation.`;
        source = 'PRODUCTION_SIMULATION (SAP_UNAVAILABLE)';
      }
    } catch (err) {
      liveFetchError = `Failed to contact SAP endpoint: ${err.message}. Falling back to production simulation dataset.`;
      source = 'PRODUCTION_SIMULATION (ERROR_FALLBACK)';
    }
  }

  // Normalize all rows
  const normalizedFabric = rawFabric.map((r) => normalizeSapRow(r, 'FABRIC'));
  const normalizedGarment = rawGarments.map((r) => normalizeSapRow(r, 'GARMENT'));
  let combined = [...normalizedFabric, ...normalizedGarment];

  // Apply division filter
  if (division && division.toUpperCase() !== 'ALL') {
    combined = combined.filter((i) => i.type.toUpperCase() === division.toUpperCase());
  }

  // Apply brand filter
  if (brand) {
    combined = combined.filter((i) => (i.brand || '').toLowerCase().includes(brand.toLowerCase()));
  }

  // Apply search query
  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    combined = combined.filter((i) =>
      (i.article || '').toLowerCase().includes(q) ||
      (i.barcode || '').toLowerCase().includes(q) ||
      (i.billNo || '').toLowerCase().includes(q) ||
      (i.brand || '').toLowerCase().includes(q) ||
      (i.partyName || '').toLowerCase().includes(q) ||
      (i.shade || '').toLowerCase().includes(q)
    );
  }

  // Summary Metrics
  const totalMtrs = normalizedFabric.reduce((acc, i) => acc + (i.qty || 0), 0);
  const totalGarmentPcs = normalizedGarment.reduce((acc, i) => acc + (i.qty || 0), 0);
  const totalValue = combined.reduce((acc, i) => acc + (i.totalAmount || 0), 0);

  return {
    success: true,
    source,
    isLiveSap: source === 'LIVE_SAP_S4HANA',
    endpointUrl: runtimeSapConfig.endpointUrl,
    liveFetchError,
    stats: {
      totalItemsCount: combined.length,
      fabricPiecesCount: normalizedFabric.length,
      fabricMetersTotal: Math.round(totalMtrs * 100) / 100,
      garmentPiecesCount: totalGarmentPcs,
      totalInvoicedValue: Math.round(totalValue * 100) / 100
    },
    items: combined,
    fabricsCount: normalizedFabric.length,
    garmentsCount: normalizedGarment.length
  };
}

/**
 * Return current runtime configuration status
 */
export function getSapConfigStatus() {
  return {
    endpointUrl: runtimeSapConfig.endpointUrl || '',
    isConfigured: Boolean(runtimeSapConfig.endpointUrl && runtimeSapConfig.endpointUrl.trim().startsWith('http')),
    hasApiKey: Boolean(runtimeSapConfig.apiKey),
    timeoutMs: runtimeSapConfig.timeoutMs,
    lastUpdated: runtimeSapConfig.lastUpdated
  };
}

/**
 * Update runtime configuration (allows user to paste SAP URL without restarting backend)
 */
export async function updateSapConfig({ endpointUrl, apiKey, timeoutMs }) {
  if (endpointUrl !== undefined) {
    runtimeSapConfig.endpointUrl = String(endpointUrl || '').trim();
  }
  if (apiKey !== undefined) {
    runtimeSapConfig.apiKey = String(apiKey || '').trim();
  }
  if (timeoutMs !== undefined && !isNaN(timeoutMs)) {
    runtimeSapConfig.timeoutMs = Math.max(1000, Number(timeoutMs));
  }
  runtimeSapConfig.lastUpdated = new Date().toISOString();

  // Validate connectivity if a URL was provided
  let probeStatus = 'NOT_PROBED';
  if (runtimeSapConfig.endpointUrl && runtimeSapConfig.endpointUrl.startsWith('http')) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      const res = await fetch(runtimeSapConfig.endpointUrl, {
        method: 'HEAD',
        signal: controller.signal
      }).catch(() => null);
      clearTimeout(timeoutId);
      probeStatus = res ? `REACHABLE (${res.status})` : 'URL_SAVED_NO_HEAD_RESPONSE';
    } catch {
      probeStatus = 'UNREACHABLE_TIMEOUT';
    }
  }

  return {
    success: true,
    message: 'SAP S/4HANA Endpoint configuration updated successfully.',
    config: getSapConfigStatus(),
    probeStatus
  };
}

/**
 * Inward a specific SAP Invoice Item directly into a DMS In-Transit ASN!
 * Creates or updates the SKU, establishes the ASN, and registers the line item.
 */
export async function inwardSapItemToDmsAsn({ item, dealerId, user }) {
  if (!item || !item.billNo) {
    const err = new Error('Invalid SAP Item: missing Bill_No.');
    err.status = 400;
    throw err;
  }

  // Resolve Dealer
  let targetDealerId = dealerId || user?.dealerId;
  if (!targetDealerId) {
    const dealer = await prisma.dealer.findFirst({ where: { isActive: true }, orderBy: { code: 'asc' } });
    if (!dealer) {
      const err = new Error('No active dealership found in DMS to receive this SAP dispatch.');
      err.status = 404;
      throw err;
    }
    targetDealerId = dealer.id;
  }

  const barcode = item.barcode || item.Itemcode || item.BARCODE;
  const article = item.article || item.ARTICLE || item.MAKTX || 'Siyaram Article';
  const brand = item.brand || item.BRAND || item['COMPANY NAME'] || 'Siyaram';
  const category = item.category || item.CATEGORY || item.PRODUCT || 'Apparel & Fabrics';
  const uom = item.uom || item.UOM || (item.type === 'FABRIC' ? 'MTR' : 'PCS');
  const size = item.sizeOrLength || item.SIZE || item.para2 || 'Standard';
  const colour = item.shade || item.para1 || item.SHADE || 'Standard';
  const mrp = parseFloat(item.mrp || item.MRP || 500);
  const landingPrice = parseFloat(item.rate || item['BILL RATE'] || item.EXMILL || (mrp * 0.6));
  const hsnCode = item.hsnCode || item['HSN CODE'] || '62034200';
  const invoicedQty = Math.max(1, Math.round(parseFloat(item.qty || item.Qty || item.QUANTITY || 1)));
  const batch = item.batch || item.Serial || `B-${new Date().getFullYear()}`;

  // 1. Ensure SKU exists in master
  let sku = await prisma.sku.findFirst({
    where: {
      OR: [
        { barcode },
        { code: barcode },
        { code: item.itemCode || barcode }
      ]
    }
  });

  if (!sku) {
    sku = await prisma.sku.create({
      data: {
        code: barcode.slice(0, 32),
        name: `${article} ${size ? `(${size})` : ''}`,
        barcode,
        brand,
        category,
        article,
        size,
        colour,
        uom,
        mrp,
        landingPrice,
        hsnCode,
        isActive: true
      }
    });
  }

  // 2. Check if ASN with this billNo exists or create one
  let asn = await prisma.asn.findFirst({
    where: { invoiceNo: item.billNo }
  });

  if (!asn) {
    asn = await prisma.asn.create({
      data: {
        invoiceNo: item.billNo,
        invoiceDate: item.billDate ? new Date(item.billDate) : new Date(),
        dealerId: targetDealerId,
        status: 'IN_TRANSIT',
        notes: `SAP S/4HANA Feed | Plant: ${item.plant || 'Central'} | LR: ${item.lrNo || 'N/A'} | Transporter: ${item.transporter || 'Direct'}`,
        lines: {
          create: [
            {
              skuId: sku.id,
              invoicedQty,
              batch,
              landingPrice,
              taxRate: item.taxRate || 5.0,
              taxAmount: item.taxAmount || (invoicedQty * landingPrice * 0.05)
            }
          ]
        }
      },
      include: {
        lines: { include: { sku: true } },
        dealer: { select: { id: true, code: true, name: true } }
      }
    });
  } else {
    // Add line to existing ASN if not already present
    const existingLine = await prisma.asnLine.findFirst({
      where: { asnId: asn.id, skuId: sku.id, batch }
    });

    if (!existingLine) {
      await prisma.asnLine.create({
        data: {
          asnId: asn.id,
          skuId: sku.id,
          invoicedQty,
          batch,
          landingPrice,
          taxRate: item.taxRate || 5.0,
          taxAmount: item.taxAmount || (invoicedQty * landingPrice * 0.05)
        }
      });
    }
  }

  return {
    success: true,
    message: `SAP Bill ${item.billNo} successfully synchronized to DMS In-Transit ASN.`,
    asnId: asn.id,
    invoiceNo: asn.invoiceNo,
    skuCode: sku.code,
    barcode: sku.barcode,
    invoicedQty
  };
}

