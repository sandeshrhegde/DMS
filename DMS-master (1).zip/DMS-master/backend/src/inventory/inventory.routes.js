import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, requireBrandAdmin, resolveRequestDealerId } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  confirmGrnTransaction,
  executeStockTransferTransaction,
  executePurchaseReturnTransaction,
  createStockAudit,
  approveStockAuditTransaction,
  initializeOpeningStockTransaction,
  calculateInventoryAgeingAndReorders
} from '../services/inventory-ledger.service.js';
import {
  fetchSapInventoryData,
  getSapConfigStatus,
  updateSapConfig,
  inwardSapItemToDmsAsn
} from './sap-inventory.service.js';

export const inventoryRouter = Router();

/**
 * Middleware ensuring user is authenticated and attaching dealer context.
 */
async function ensureAuthenticated(req, res, next) {
  try {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const resolvedDealerId = await resolveRequestDealerId(req, user);
    req.effectiveDealerId = resolvedDealerId;
    if (!user.dealerId && resolvedDealerId) {
      user.dealerId = resolvedDealerId;
    }

    req.currentUser = user;
    next();
  } catch (err) {
    next(err);
  }
}

inventoryRouter.use(ensureAuthenticated);

// ==========================================
// 1. WAREHOUSES (Dealer-scoped)
// ==========================================

/**
 * GET /api/inventory/warehouses
 */
inventoryRouter.get('/warehouses', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const targetDealerId = isBrand ? req.query.dealerId : req.currentUser.dealerId;

    const where = { isActive: true };
    if (targetDealerId) {
      where.dealerId = targetDealerId;
    }

    const warehouses = await prisma.warehouse.findMany({
      where,
      orderBy: [{ isDefault: 'desc' }, { name: 'asc' }]
    });

    res.json({ warehouses });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/warehouses
 */
inventoryRouter.post('/warehouses', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { code, name, address, isDefault = false, dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer ID is required to create a warehouse.' });
    }

    if (!code || !name) {
      return res.status(400).json({ error: 'Warehouse code and name are required.' });
    }

    // If setting as default, clear other default warehouses for this dealer
    if (isDefault) {
      await prisma.warehouse.updateMany({
        where: { dealerId, isDefault: true },
        data: { isDefault: false }
      });
    }

    const warehouse = await prisma.warehouse.create({
      data: {
        dealerId,
        code: code.trim().toUpperCase(),
        name: name.trim(),
        address: address ? address.trim() : null,
        isDefault: Boolean(isDefault),
        isActive: true
      }
    });

    res.status(201).json(warehouse);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 2. PRIMARY DISPATCH & ASNs (Simulated SAP)
// ==========================================

/**
 * POST /api/inventory/asns
 * BRAND_ADMIN screen to simulate primary dispatch invoice from Brand to Dealer.
 */
inventoryRouter.post('/asns', requireBrandAdmin, async (req, res, next) => {
  try {
    const { invoiceNo, invoiceDate, dealerId, notes, lines = [] } = req.body;

    if (!invoiceNo || !invoiceNo.trim()) {
      return res.status(400).json({ error: 'Primary invoice number is required.' });
    }
    if (!dealerId) {
      return res.status(400).json({ error: 'Destination dealerId is required.' });
    }
    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'At least one invoice line item is required.' });
    }

    // Verify dealer exists
    const dealer = await prisma.dealer.findUnique({ where: { id: dealerId } });
    if (!dealer) {
      return res.status(404).json({ error: 'Dealer not found.' });
    }

    // Verify all SKUs exist
    const skuIds = lines.map((l) => l.skuId).filter(Boolean);
    const existingSkus = skuIds.length > 0 ? await prisma.sku.findMany({ where: { id: { in: skuIds } } }) : [];
    const skuMap = new Map();
    existingSkus.forEach((s) => skuMap.set(s.id, s));

    const validatedLines = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const sku = skuMap.get(line.skuId);
      if (!sku) {
        return res.status(400).json({ error: `Line ${i + 1}: SKU ${line.skuId} not found.` });
      }

      const qty = parseInt(line.invoicedQty || line.qty, 10);
      if (isNaN(qty) || qty <= 0) {
        return res.status(400).json({ error: `Line ${i + 1}: invoicedQty must be a positive integer.` });
      }

      const landingPrice = line.landingPrice !== undefined
        ? parseFloat(line.landingPrice)
        : (sku.landingPrice || (sku.mrp ? sku.mrp * 0.6 : 100));

      validatedLines.push({
        skuId: sku.id,
        invoicedQty: qty,
        batch: (line.batch || `B-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`).trim(),
        landingPrice
      });
    }

    // Create ASN with lines in database
    const createdAsn = await prisma.asn.create({
      data: {
        invoiceNo: invoiceNo.trim().toUpperCase(),
        invoiceDate: invoiceDate ? new Date(invoiceDate) : new Date(),
        dealerId,
        status: 'IN_TRANSIT',
        notes: notes ? notes.trim() : null,
        lines: {
          create: validatedLines
        }
      },
      include: {
        lines: { include: { sku: true } },
        dealer: { select: { id: true, code: true, name: true, stateCode: true } }
      }
    });

    res.status(201).json(createdAsn);
  } catch (error) {
    next(error);
  }
});


/**
 * GET /api/inventory/asns
 * List ASNs (scoped to dealer for dealer roles, or all for brand).
 */
inventoryRouter.get('/asns', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { status, dealerId, search } = req.query;

    const where = {};
    if (!isBrand) {
      where.dealerId = req.currentUser.dealerId;
    } else if (dealerId) {
      where.dealerId = dealerId;
    }

    if (status) {
      where.status = status;
    }
    if (search) {
      where.invoiceNo = { contains: search.trim(), mode: 'insensitive' };
    }

    const asns = await prisma.asn.findMany({
      where,
      include: {
        dealer: { select: { id: true, code: true, name: true, stateCode: true } },
        receivedWarehouse: { select: { id: true, code: true, name: true } },
        _count: { select: { lines: true, claims: true } }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ asns });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/asns/in-transit
 * Dealer endpoint for in-transit shipments awaiting GRN receipt.
 */
inventoryRouter.get('/asns/in-transit', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const dealerId = isBrand ? req.query.dealerId : req.currentUser.dealerId;

    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required.' });
    }

    const inTransitAsns = await prisma.asn.findMany({
      where: {
        dealerId,
        status: 'IN_TRANSIT'
      },
      include: {
        lines: { include: { sku: true } },
        dealer: { select: { id: true, code: true, name: true } }
      },
      orderBy: [{ invoiceDate: 'desc' }]
    });

    res.json({ inTransitAsns });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/asns/:id
 * ASN details with full line items, warehouse, and claims.
 */
inventoryRouter.get('/asns/:id', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const asn = await prisma.asn.findUnique({
      where: { id: req.params.id },
      include: {
        dealer: { select: { id: true, code: true, name: true, stateCode: true } },
        receivedWarehouse: true,
        lines: {
          include: {
            sku: {
              select: {
                id: true,
                code: true,
                name: true,
                barcode: true,
                article: true,
                size: true,
                colour: true,
                mrp: true,
                landingPrice: true,
                category: true,
                brand: true,
                uom: true
              }
            }
          }
        },
        claims: {
          include: {
            sku: { select: { id: true, code: true, name: true } }
          }
        }
      }
    });

    if (!asn) {
      return res.status(404).json({ error: 'ASN not found.' });
    }

    if (!isBrand && asn.dealerId !== req.currentUser.dealerId) {
      return res.status(403).json({ error: 'Access denied. You can only view your own dealership ASNs.' });
    }

    res.json(asn);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 3. GRN CONFIRMATION (Dealer)
// ==========================================

/**
 * POST /api/inventory/asns/:id/grn
 * Confirm Goods Receipt Note (GRN) with variance capture and atomic ledger posting.
 */
inventoryRouter.post('/asns/:id/grn', async (req, res, next) => {
  try {
    const { warehouseId, lines = [] } = req.body;

    if (!warehouseId) {
      return res.status(400).json({ error: 'Destination warehouseId is required to confirm GRN.' });
    }

    const result = await confirmGrnTransaction({
      asnId: req.params.id,
      warehouseId,
      receivedLines: lines,
      user: req.currentUser
    });

    res.json(result);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 4. TRANSIT CLAIMS (Short, Excess, Damaged)
// ==========================================

/**
 * GET /api/inventory/claims
 * List transit claims (Brand sees all, dealers see their own).
 */
inventoryRouter.get('/claims', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { status, claimType, dealerId } = req.query;

    const where = {};
    if (!isBrand) {
      where.dealerId = req.currentUser.dealerId;
    } else if (dealerId) {
      where.dealerId = dealerId;
    }

    if (status) {
      where.status = status;
    }
    if (claimType) {
      where.claimType = claimType;
    }

    const claims = await prisma.transitClaim.findMany({
      where,
      include: {
        dealer: { select: { id: true, code: true, name: true } },
        asn: { select: { id: true, invoiceNo: true, invoiceDate: true, grnNumber: true } },
        sku: { select: { id: true, code: true, name: true, mrp: true } }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ claims });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/claims/:id/approve
 * Brand Admin approves a claim.
 */
inventoryRouter.post('/claims/:id/approve', requireBrandAdmin, async (req, res, next) => {
  try {
    const { notes } = req.body;
    const claim = await prisma.transitClaim.findUnique({ where: { id: req.params.id } });
    if (!claim) {
      return res.status(404).json({ error: 'Claim not found.' });
    }

    const updated = await prisma.transitClaim.update({
      where: { id: req.params.id },
      data: {
        status: 'APPROVED',
        resolutionNotes: notes ? notes.trim() : 'Claim approved by Brand Administrator',
        reviewedByEmail: req.currentUser.email,
        reviewedAt: new Date()
      }
    });

    res.json({ message: 'Claim approved successfully.', claim: updated });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/claims/:id/reject
 * Brand Admin rejects a claim.
 */
inventoryRouter.post('/claims/:id/reject', requireBrandAdmin, async (req, res, next) => {
  try {
    const { notes } = req.body;
    const claim = await prisma.transitClaim.findUnique({ where: { id: req.params.id } });
    if (!claim) {
      return res.status(404).json({ error: 'Claim not found.' });
    }

    const updated = await prisma.transitClaim.update({
      where: { id: req.params.id },
      data: {
        status: 'REJECTED',
        resolutionNotes: notes ? notes.trim() : 'Claim rejected by Brand Administrator',
        reviewedByEmail: req.currentUser.email,
        reviewedAt: new Date()
      }
    });

    res.json({ message: 'Claim rejected.', claim: updated });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 5. STOCK ON HAND & LOW-STOCK ALERTS
// ==========================================

/**
 * GET /api/inventory/stock-on-hand
 * Filter by SKU, warehouse, state, and lowStock flag.
 */
inventoryRouter.get('/stock-on-hand', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { skuId, warehouseId, stockState, lowStockOnly, dealerId: queryDealerId } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;

    const where = {};
    if (dealerId) where.dealerId = dealerId;
    if (skuId) where.skuId = skuId;
    if (warehouseId) where.warehouseId = warehouseId;
    if (stockState) where.stockState = stockState;

    const stockItems = await prisma.stockOnHand.findMany({
      where,
      include: {
        warehouse: { select: { id: true, code: true, name: true } },
        sku: {
          select: {
            id: true,
            code: true,
            name: true,
            category: true,
            brand: true,
            uom: true,
            mrp: true,
            landingPrice: true,
            barcode: true,
            article: true,
            size: true,
            colour: true
          }
        },
        dealer: { select: { id: true, code: true, name: true } }
      },
      orderBy: [{ sku: { code: 'asc' } }, { batch: 'asc' }]
    });

    // Fetch min stock thresholds for this dealer
    const configs = await prisma.dealerSkuConfig.findMany({
      where: dealerId ? { dealerId } : {}
    });
    const minStockMap = new Map();
    configs.forEach((c) => minStockMap.set(`${c.dealerId}_${c.skuId}`, c.minStock));

    // Aggregate available stock per SKU to evaluate low-stock alert
    const skuAvailableMap = new Map();
    stockItems.forEach((item) => {
      if (item.stockState === 'AVAILABLE') {
        const key = `${item.dealerId}_${item.skuId}`;
        skuAvailableMap.set(key, (skuAvailableMap.get(key) || 0) + item.qty);
      }
    });

    const enrichedItems = stockItems.map((item) => {
      const configKey = `${item.dealerId}_${item.skuId}`;
      const minStock = minStockMap.get(configKey) ?? 10;
      const totalAvailable = skuAvailableMap.get(configKey) || 0;
      const isLowStock = totalAvailable <= minStock;

      return {
        ...item,
        minStock,
        totalAvailableForSku: totalAvailable,
        isLowStock
      };
    });

    const filteredItems = lowStockOnly === 'true'
      ? enrichedItems.filter((i) => i.isLowStock)
      : enrichedItems;

    res.json({
      stockOnHand: filteredItems,
      totalItems: filteredItems.length
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/min-stock
 * Set minStock per SKU per dealer for low-stock alerts.
 */
inventoryRouter.post('/min-stock', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { skuId, minStock = 10, dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId || !skuId) {
      return res.status(400).json({ error: 'dealerId and skuId are required.' });
    }

    const val = Math.max(0, parseInt(minStock, 10));
    const config = await prisma.dealerSkuConfig.upsert({
      where: {
        dealerId_skuId: { dealerId, skuId }
      },
      update: { minStock: val },
      create: { dealerId, skuId, minStock: val }
    });

    res.json(config);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 6. STOCK LEDGER (Append-only Audit Log)
// ==========================================

/**
 * GET /api/inventory/stock-ledger
 * Returns append-only ledger entries for a SKU / warehouse / batch.
 */
inventoryRouter.get('/stock-ledger', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { skuId, warehouseId, batch, stockState, dealerId: queryDealerId, limit = 100, page = 1 } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;

    const where = {};
    if (dealerId) where.dealerId = dealerId;
    if (skuId) where.skuId = skuId;
    if (warehouseId) where.warehouseId = warehouseId;
    if (batch) where.batch = batch;
    if (stockState) where.stockState = stockState;

    const take = Math.min(200, Math.max(1, parseInt(limit, 10) || 100));
    const skip = (Math.max(1, parseInt(page, 10) || 1) - 1) * take;

    const [entries, totalCount] = await Promise.all([
      prisma.stockLedger.findMany({
        where,
        include: {
          warehouse: { select: { id: true, code: true, name: true } },
          sku: { select: { id: true, code: true, name: true, uom: true } },
          dealer: { select: { id: true, code: true, name: true } }
        },
        orderBy: [{ createdAt: 'desc' }],
        take,
        skip
      }),
      prisma.stockLedger.count({ where })
    ]);

    // Also calculate total sum of qtyChange for verification
    const aggregate = await prisma.stockLedger.aggregate({
      where,
      _sum: { qtyChange: true }
    });

    res.json({
      entries,
      totalCount,
      sumQtyChange: aggregate._sum.qtyChange || 0,
      page: parseInt(page, 10) || 1,
      limit: take
    });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 7. MULTI-WAREHOUSE TRANSFERS
// ==========================================

/**
 * POST /api/inventory/transfers
 * Double-entry inter-warehouse stock transfer.
 */
inventoryRouter.post('/transfers', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { sourceWarehouseId, targetWarehouseId, lines = [], notes, dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required for stock transfer.' });
    }

    if (!sourceWarehouseId || !targetWarehouseId) {
      return res.status(400).json({ error: 'sourceWarehouseId and targetWarehouseId are required.' });
    }

    if (sourceWarehouseId === targetWarehouseId) {
      return res.status(400).json({ error: 'Source and target warehouses must be different.' });
    }

    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'At least one item line is required for transfer.' });
    }

    const result = await executeStockTransferTransaction({
      dealerId,
      sourceWarehouseId,
      targetWarehouseId,
      lines,
      notes,
      user: req.currentUser
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/transfers
 * List stock transfers.
 */
inventoryRouter.get('/transfers', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { dealerId: queryDealerId, transferNo, sourceWarehouseId, targetWarehouseId } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;

    const where = {};
    if (dealerId) where.dealerId = dealerId;
    if (transferNo) where.transferNo = { contains: transferNo.trim(), mode: 'insensitive' };
    if (sourceWarehouseId) where.sourceWarehouseId = sourceWarehouseId;
    if (targetWarehouseId) where.targetWarehouseId = targetWarehouseId;

    const transfers = await prisma.stockTransfer.findMany({
      where,
      include: {
        sourceWarehouse: { select: { id: true, code: true, name: true } },
        targetWarehouse: { select: { id: true, code: true, name: true } },
        lines: {
          include: {
            sku: {
              select: {
                id: true,
                code: true,
                name: true,
                category: true,
                size: true,
                colour: true,
                uom: true
              }
            }
          }
        }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ transfers });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 8. PURCHASE RETURNS TO BRAND
// ==========================================

/**
 * POST /api/inventory/purchase-returns
 * Initiate purchase return to brand (generates ERP return order).
 */
inventoryRouter.post('/purchase-returns', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { warehouseId, reason, lines = [], notes, dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required for purchase return.' });
    }

    if (!warehouseId || !reason) {
      return res.status(400).json({ error: 'warehouseId and reason are required.' });
    }

    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'At least one return line item is required.' });
    }

    const result = await executePurchaseReturnTransaction({
      dealerId,
      warehouseId,
      reason,
      lines,
      notes,
      user: req.currentUser
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/purchase-returns
 * List purchase returns to brand.
 */
inventoryRouter.get('/purchase-returns', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { dealerId: queryDealerId, status, returnNo } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;

    const where = {};
    if (dealerId) where.dealerId = dealerId;
    if (status) where.status = status;
    if (returnNo) where.returnNo = { contains: returnNo.trim(), mode: 'insensitive' };

    const purchaseReturns = await prisma.purchaseReturn.findMany({
      where,
      include: {
        warehouse: { select: { id: true, code: true, name: true } },
        lines: {
          include: {
            sku: {
              select: {
                id: true,
                code: true,
                name: true,
                category: true,
                size: true,
                colour: true,
                uom: true
              }
            }
          }
        }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ purchaseReturns });
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 9. PERIODIC PHYSICAL STOCK AUDITS
// ==========================================

/**
 * POST /api/inventory/audits
 * Register barcode-based physical stock audit count with variance calculation.
 */
inventoryRouter.post('/audits', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { warehouseId, lines = [], notes, dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required for physical stock count.' });
    }

    if (!warehouseId) {
      return res.status(400).json({ error: 'warehouseId is required.' });
    }

    if (!Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'At least one SKU line must be counted.' });
    }

    const result = await createStockAudit({
      dealerId,
      warehouseId,
      lines,
      notes,
      user: req.currentUser
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/audits
 * List physical stock audits.
 */
inventoryRouter.get('/audits', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { dealerId: queryDealerId, status, auditNo } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;

    const where = {};
    if (dealerId) where.dealerId = dealerId;
    if (status) where.status = status;
    if (auditNo) where.auditNo = { contains: auditNo.trim(), mode: 'insensitive' };

    const audits = await prisma.stockAudit.findMany({
      where,
      include: {
        warehouse: { select: { id: true, code: true, name: true } },
        lines: {
          include: {
            sku: {
              select: {
                id: true,
                code: true,
                name: true,
                category: true,
                size: true,
                colour: true,
                uom: true
              }
            }
          }
        }
      },
      orderBy: [{ createdAt: 'desc' }]
    });

    res.json({ audits });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/audits/:id/approve
 * Dealer Owner approval for stock audit adjustment.
 */
inventoryRouter.post('/audits/:id/approve', async (req, res, next) => {
  try {
    // Only DEALER_OWNER or BRAND_ADMIN can approve physical stock audit variances
    const isAuthorized = [DASHBOARD_ROLES.DEALER_OWNER, DASHBOARD_ROLES.BRAND_ADMIN].includes(req.currentUser.role);
    if (!isAuthorized) {
      return res.status(403).json({ error: 'Only Dealer Owners or Brand Administrators can approve stock count adjustments.' });
    }

    const result = await approveStockAuditTransaction({
      auditId: req.params.id,
      decision: 'APPROVE',
      user: req.currentUser
    });

    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/audits/:id/reject
 * Reject stock audit.
 */
inventoryRouter.post('/audits/:id/reject', async (req, res, next) => {
  try {
    const isAuthorized = [DASHBOARD_ROLES.DEALER_OWNER, DASHBOARD_ROLES.BRAND_ADMIN].includes(req.currentUser.role);
    if (!isAuthorized) {
      return res.status(403).json({ error: 'Only Dealer Owners or Brand Administrators can reject stock count adjustments.' });
    }

    const { reason } = req.body;
    const result = await approveStockAuditTransaction({
      auditId: req.params.id,
      decision: 'REJECT',
      rejectionReason: reason,
      user: req.currentUser
    });

    res.json(result);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 10. INVENTORY ANALYTICS & REORDERS
// ==========================================

/**
 * GET /api/inventory/analytics
 * Ageing breakdown (0-30, 31-60, 61-90, 90+ days), slow/non-moving flags, min stock alerts & reorder recommendations.
 */
inventoryRouter.get('/analytics', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { dealerId: queryDealerId, warehouseId } = req.query;

    const dealerId = isBrand ? (queryDealerId || null) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required for inventory analytics.' });
    }

    const analytics = await calculateInventoryAgeingAndReorders({
      dealerId,
      warehouseId: warehouseId || undefined
    });

    res.json(analytics);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 11. GO-LIVE OPENING STOCK
// ==========================================

/**
 * POST /api/inventory/opening-stock
 * Initial go-live stock intake before regular ERP ASNs begin.
 */
inventoryRouter.post('/opening-stock', async (req, res, next) => {
  try {
    const isAuthorized = [DASHBOARD_ROLES.DEALER_OWNER, DASHBOARD_ROLES.BRAND_ADMIN].includes(req.currentUser.role);
    if (!isAuthorized) {
      return res.status(403).json({ error: 'Only Dealer Owners or Brand Administrators can initialize opening stock.' });
    }

    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const { warehouseId, lines = [], dealerId: explicitDealerId } = req.body;

    const dealerId = isBrand ? (explicitDealerId || req.currentUser.dealerId) : req.currentUser.dealerId;
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context required.' });
    }

    if (!warehouseId || !Array.isArray(lines) || lines.length === 0) {
      return res.status(400).json({ error: 'warehouseId and lines are required.' });
    }

    const result = await initializeOpeningStockTransaction({
      dealerId,
      warehouseId,
      lines,
      user: req.currentUser
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

// ==========================================
// 10. SAP S/4HANA NEW INVENTORY (Fabric & Garment Feed)
// ==========================================

/**
 * GET /api/inventory/sap-inventory
 * Fetches Fabric and Garment inventory feeds from SAP S/4HANA
 * (Calls configured live SAP endpoint URL if provided, otherwise serves production-fidelity simulation dataset)
 */
inventoryRouter.get('/sap-inventory', async (req, res, next) => {
  try {
    const { search, division, brand } = req.query;
    const result = await fetchSapInventoryData({
      search,
      division,
      brand,
      dealerId: req.effectiveDealerId || req.currentUser.dealerId
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/inventory/sap-inventory/config
 * Retrieves SAP endpoint URL and connectivity status
 */
inventoryRouter.get('/sap-inventory/config', async (req, res, next) => {
  try {
    const config = getSapConfigStatus();
    res.json(config);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/sap-inventory/config
 * Dynamic update of SAP S/4HANA Endpoint URL (e.g. when SAP team delivers live URL)
 */
inventoryRouter.post('/sap-inventory/config', async (req, res, next) => {
  try {
    const { endpointUrl, apiKey, timeoutMs } = req.body;
    const result = await updateSapConfig({ endpointUrl, apiKey, timeoutMs });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/inventory/sap-inventory/inward-to-asn
 * Converts a selected Fabric or Garment row into an In-Transit ASN in DMS
 */
inventoryRouter.post('/sap-inventory/inward-to-asn', async (req, res, next) => {
  try {
    const { item, dealerId } = req.body;
    const targetDealerId = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN
      ? (dealerId || req.effectiveDealerId)
      : req.currentUser.dealerId;

    const result = await inwardSapItemToDmsAsn({
      item,
      dealerId: targetDealerId,
      user: req.currentUser
    });
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

