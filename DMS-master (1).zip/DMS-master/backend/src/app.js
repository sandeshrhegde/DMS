import cors from 'cors';
import cookieParser from 'cookie-parser';
import express from 'express';
import { env } from './config/env.js';
import { errorHandler, notFound } from './middleware/error.middleware.js';
import { apiRouter } from './routes/index.js';
import { dashboardRouter } from './dashboard/dashboard.routes.js';
import { pricingRouter } from './pricing/pricing.routes.js';
import { orderRouter } from './orders/order.routes.js';
import { invoiceRouter } from './billing/invoice.routes.js';
import { noteRouter } from './billing/note.routes.js';

export const app = express();

app.disable('x-powered-by');
app.use(cors({ origin: env.corsOrigins, credentials: true }));
app.use(cookieParser());
app.use(express.json({ limit: '1mb' }));
app.use('/dashboard', dashboardRouter);
app.use('/pricing', pricingRouter);
app.use('/orders', orderRouter);
app.use('/billing', invoiceRouter);
app.use('/invoices', invoiceRouter);
app.use('/notes', noteRouter);
app.use('/api', apiRouter);
app.use(notFound);
app.use(errorHandler);
