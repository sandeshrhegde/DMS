import { Router } from 'express';
import { dashboardRouter } from '../dashboard/dashboard.routes.js';
import { authRouter } from './auth.routes.js';
import { healthRouter } from './health.routes.js';
import { geoRouter } from '../masters/geo.routes.js';
import { hsnRouter } from '../masters/hsn.routes.js';
import { skuRouter } from '../masters/sku.routes.js';
import { dealerRouter } from '../masters/dealer.routes.js';
import { retailerRouter } from '../retailers/retailer.routes.js';
import { pricingRouter } from '../pricing/pricing.routes.js';
import { inventoryRouter } from '../inventory/inventory.routes.js';
import { orderRouter } from '../orders/order.routes.js';
import { invoiceRouter } from '../billing/invoice.routes.js';
import { noteRouter } from '../billing/note.routes.js';

export const apiRouter = Router();

apiRouter.use('/health', healthRouter);
apiRouter.use('/auth', authRouter);
apiRouter.use('/dashboard', dashboardRouter);

// Master Data routes
apiRouter.use('/geography', geoRouter);
apiRouter.use('/geo', geoRouter);
apiRouter.use('/hsn', hsnRouter);
apiRouter.use('/skus', skuRouter);
apiRouter.use('/dealers', dealerRouter);

// Retailer Proposal & Approval Workflow routes
apiRouter.use('/retailers', retailerRouter);

// Pricing & Resolver routes
apiRouter.use('/pricing', pricingRouter);

// Inventory, GRN & Append-only Stock Ledger routes
apiRouter.use('/inventory', inventoryRouter);

// Secondary Orders & Stock Reservation routes
apiRouter.use('/orders', orderRouter);

// Secondary Tax Invoicing & Billing routes
apiRouter.use('/billing', invoiceRouter);
apiRouter.use('/invoices', invoiceRouter);

// Retailer Returns & Credit/Debit Notes routes
apiRouter.use('/notes', noteRouter);
