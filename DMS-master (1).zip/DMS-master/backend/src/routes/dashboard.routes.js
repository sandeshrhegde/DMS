import { Router } from 'express';
import { getDashboard, listMockTenants } from '../controllers/dashboard.controller.js';

export const dashboardRouter = Router();
dashboardRouter.get('/dashboard', getDashboard);
dashboardRouter.get('/mock/tenants', listMockTenants);
