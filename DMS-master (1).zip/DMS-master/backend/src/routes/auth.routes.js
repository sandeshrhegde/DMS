import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '../config/database.js';
import { createAccessToken, createRefreshToken, refreshCookieOptions, safeUser, verifyRefreshToken } from '../auth/token.service.js';
import { jwtAuthGuard } from '../middleware/jwt-auth.middleware.js';
export const authRouter=Router();
async function issue(user,res){const refreshToken=createRefreshToken(user);await prisma.user.update({where:{id:user.id},data:{refreshTokenHash:await bcrypt.hash(refreshToken,12)}});res.cookie('refresh_token',refreshToken,refreshCookieOptions).json({accessToken:createAccessToken(user),user:safeUser(user)});}
authRouter.post('/login',async(req,res,next)=>{try{const user=await prisma.user.findUnique({where:{email:req.body.email}});if(!user||!user.isActive||!await bcrypt.compare(req.body.password??'',user.passwordHash))return res.status(401).json({error:'Invalid email or password.'});await issue(user,res)}catch(e){next(e)}});
authRouter.post('/refresh',async(req,res,next)=>{try{const token=req.cookies.refresh_token;const {sub}=verifyRefreshToken(token);const user=await prisma.user.findUnique({where:{id:sub}});if(!user||!user.refreshTokenHash||!await bcrypt.compare(token,user.refreshTokenHash))return res.status(401).json({error:'Invalid refresh token.'});await issue(user,res)}catch(e){next(e)}});
authRouter.post('/logout',(req,res)=>res.clearCookie('refresh_token',{path:'/api/auth'}).status(204).end());
authRouter.get('/me',jwtAuthGuard,(req,res)=>res.json({user:req.user}));
