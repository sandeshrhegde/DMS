import jwt from 'jsonwebtoken';
const secret = (name) => { if (!process.env[name]) throw new Error(`Missing ${name}; set it before using authentication.`); return process.env[name]; };
export const safeUser = (user) => ({ id: user.id, name: user.name, email: user.email, role: user.role, dealerId: user.dealerId });
export const createAccessToken = (user) => jwt.sign(safeUser(user), secret('JWT_ACCESS_SECRET'), { expiresIn: '15m' });
export const createRefreshToken = (user) => jwt.sign({ sub: user.id, type: 'refresh' }, secret('JWT_REFRESH_SECRET'), { expiresIn: '7d' });
export const verifyAccessToken = (token) => jwt.verify(token, secret('JWT_ACCESS_SECRET'));
export function verifyRefreshToken(token) { const payload = jwt.verify(token, secret('JWT_REFRESH_SECRET')); if (payload.type !== 'refresh') throw new Error('Invalid refresh token.'); return payload; }
export const refreshCookieOptions = { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/api/auth', maxAge: 604800000 };
