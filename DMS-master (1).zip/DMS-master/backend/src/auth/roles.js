export const Roles = Object.freeze({ BRAND_ADMIN: 'BRAND_ADMIN', DEALER_OWNER: 'DEALER_OWNER', DEALER_OPERATOR: 'DEALER_OPERATOR', SALESMAN: 'SALESMAN' });

// Express equivalent of a @Roles decorator: attach it directly to a route.
export const roles = (...allowedRoles) => (req, res, next) => {
  if (!req.user || !allowedRoles.includes(req.user.role)) return res.status(403).json({ error: 'You do not have permission for this action.' });
  return next();
};
