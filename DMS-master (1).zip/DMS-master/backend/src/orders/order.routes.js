import { Router } from 'express';
import { prisma } from '../config/database.js';
import { getAuthUser, resolveRequestDealerId } from '../middleware/auth.middleware.js';
import { DASHBOARD_ROLES } from '@dms/shared';
import {
  calculateOrderPricing,
  createDraftOrder,
  updateDraftOrder,
  submitOrder,
  approveOrder,
  cancelOrder,
  getAvailableStockBySku,
  resolveOrderWarehouse
} from '../services/order.service.js';

export const orderRouter = Router();

/**
 * Middleware ensuring user is authenticated and attaching dealer context.
 */
async function ensureAuthenticated(req, res, next) {
  try {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: 'Authentication required.' });
    }

    const resolvedDealerId = await resolveRequestDealerId(req, user);
    req.effectiveDealerId = resolvedDealerId;
    if (!user.dealerId && resolvedDealerId) {
      user.dealerId = resolvedDealerId;
    }

    req.currentUser = user;
    next();
  } catch (err) {
    next(err);
  }
}

orderRouter.use(ensureAuthenticated);

/**
 * Helper to get the effective dealerId for the request.
 */
function getTargetDealerId(req) {
  return (
    req.query.dealerId ||
    req.body?.dealerId ||
    req.get('x-dealer-id') ||
    req.get('x-tenant-id') ||
    req.effectiveDealerId ||
    req.currentUser?.dealerId
  );
}

/**
 * POST /api/orders/calculate
 * Live server-side pricing and available-stock calculation preview.
 */
orderRouter.post('/calculate', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, warehouseId, items } = req.body;
    if (!retailerId) {
      return res.status(400).json({ error: 'retailerId is required for price calculation.' });
    }

    const warehouse = await resolveOrderWarehouse(dealerId, warehouseId);

    const calculation = await calculateOrderPricing({
      dealerId,
      retailerId,
      warehouseId: warehouse?.id,
      items: items || [],
      date: new Date()
    });

    res.json({
      success: true,
      warehouseId: warehouse?.id,
      warehouseName: warehouse?.name,
      ...calculation
    });
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code,
        skuId: err.skuId
      });
    }
    next(err);
  }
});

/**
 * GET /api/orders/stock-check
 * Live available stock check for specified SKU IDs.
 */
orderRouter.get('/stock-check', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { warehouseId, skuIds } = req.query;
    const skuIdList = Array.isArray(skuIds)
      ? skuIds
      : (typeof skuIds === 'string' ? skuIds.split(',').filter(Boolean) : []);

    const warehouse = await resolveOrderWarehouse(dealerId, warehouseId);
    const { totals } = await getAvailableStockBySku({
      dealerId,
      warehouseId: warehouse?.id,
      skuIds: skuIdList
    });

    res.json({
      warehouseId: warehouse?.id,
      warehouseName: warehouse?.name,
      availableStock: totals
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/orders
 * List secondary orders with status, retailer, date, and search filters.
 */
orderRouter.get('/', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const explicitDealerId = req.query.dealerId || req.get('x-dealer-id') || req.get('x-tenant-id');
    const targetDealerId = isBrand ? explicitDealerId : (req.effectiveDealerId || req.currentUser.dealerId);

    const {
      status,
      retailerId,
      dateFrom,
      dateTo,
      search,
      page = 1,
      limit = 25
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const take = Math.min(100, Math.max(1, parseInt(limit, 10) || 25));
    const skip = (pageNum - 1) * take;

    const where = {};

    if (!isBrand) {
      if (targetDealerId) where.dealerId = targetDealerId;
    } else if (targetDealerId) {
      where.dealerId = targetDealerId;
    }

    if (status) {
      where.status = status;
    }

    if (retailerId) {
      where.retailerId = retailerId;
    }

    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) {
        const toDate = new Date(dateTo);
        toDate.setHours(23, 59, 59, 999);
        where.createdAt.lte = toDate;
      }
    }

    if (search && String(search).trim()) {
      const q = String(search).trim();
      where.OR = [
        { orderNo: { contains: q, mode: 'insensitive' } },
        { retailer: { legalName: { contains: q, mode: 'insensitive' } } },
        { retailer: { tradeName: { contains: q, mode: 'insensitive' } } }
      ];
    }

    const [orders, totalCount] = await Promise.all([
      prisma.order.findMany({
        where,
        include: {
          retailer: {
            select: {
              id: true,
              legalName: true,
              tradeName: true,
              creditLimit: true,
              retailerClass: true,
              channelType: true
            }
          },
          warehouse: {
            select: { id: true, code: true, name: true }
          },
          dealer: {
            select: { id: true, name: true, code: true }
          },
          _count: {
            select: { lines: true }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take
      }),
      prisma.order.count({ where })
    ]);

    res.json({
      orders: orders.map((o) => ({
        ...o,
        itemCount: o._count.lines
      })),
      totalCount,
      page: pageNum,
      limit: take,
      totalPages: Math.ceil(totalCount / take)
    });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/orders/:id
 * Retrieve order details with lines, pricing, reservation status, and audit timestamps.
 */
orderRouter.get('/:id', async (req, res, next) => {
  try {
    const isBrand = req.currentUser.role === DASHBOARD_ROLES.BRAND_ADMIN;
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: {
        retailer: true,
        warehouse: true,
        dealer: {
          select: { id: true, name: true, code: true, stateCode: true }
        },
        lines: {
          include: {
            sku: true
          },
          orderBy: { createdAt: 'asc' }
        }
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }

    if (!isBrand && order.dealerId !== req.currentUser.dealerId) {
      return res.status(403).json({ error: 'Access denied to order from another dealership.' });
    }

    // Fetch current available stock for the order SKUs for live display
    const { totals: currentAvailableStock } = await getAvailableStockBySku({
      dealerId: order.dealerId,
      warehouseId: order.warehouseId,
      skuIds: order.lines.map((l) => l.skuId)
    });

    const enrichedLines = order.lines.map((line) => ({
      ...line,
      currentAvailableStock: currentAvailableStock[line.skuId] || 0
    }));

    res.json({
      ...order,
      lines: enrichedLines
    });
  } catch (err) {
    next(err);
  }
});

/**
 * POST /api/orders
 * Create a new DRAFT secondary order.
 */
orderRouter.post('/', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required to create an order.' });
    }

    const { retailerId, warehouseId, channel, notes, items } = req.body;
    if (!retailerId) {
      return res.status(400).json({ error: 'retailerId is required.' });
    }

    const order = await createDraftOrder({
      dealerId,
      retailerId,
      warehouseId,
      channel,
      notes,
      items: items || [],
      user: req.currentUser
    });

    res.status(201).json(order);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code,
        skuId: err.skuId
      });
    }
    next(err);
  }
});

/**
 * PUT /api/orders/:id
 * Update an existing DRAFT secondary order.
 */
orderRouter.put('/:id', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const { retailerId, warehouseId, notes, items } = req.body;

    const order = await updateDraftOrder({
      orderId: req.params.id,
      dealerId,
      retailerId,
      warehouseId,
      notes,
      items,
      user: req.currentUser
    });

    res.json(order);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code,
        skuId: err.skuId
      });
    }
    next(err);
  }
});

/**
 * POST /api/orders/:id/submit
 * Submit order: evaluates credit limit, sets APPROVED (with stock reservation) or PENDING_APPROVAL.
 */
orderRouter.post('/:id/submit', async (req, res, next) => {
  try {
    const dealerId = getTargetDealerId(req);
    if (!dealerId) {
      return res.status(400).json({ error: 'Dealer context is required.' });
    }

    const result = await submitOrder({
      orderId: req.params.id,
      dealerId,
      user: req.currentUser
    });

    res.json(result);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code,
        skuId: err.skuId
      });
    }
    next(err);
  }
});

/**
 * POST /api/orders/:id/approve
 * Manually approve a credit-blocked order (DEALER_OWNER or BRAND_ADMIN only).
 */
orderRouter.post('/:id/approve', async (req, res, next) => {
  try {
    const result = await approveOrder({
      orderId: req.params.id,
      user: req.currentUser
    });

    res.json(result);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code
      });
    }
    next(err);
  }
});

/**
 * POST /api/orders/:id/cancel
 * Cancel order: releases reserved inventory back to AVAILABLE if previously approved.
 */
orderRouter.post('/:id/cancel', async (req, res, next) => {
  try {
    const { reason } = req.body;
    const result = await cancelOrder({
      orderId: req.params.id,
      reason,
      user: req.currentUser
    });

    res.json(result);
  } catch (err) {
    if (err.status) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code
      });
    }
    next(err);
  }
});

