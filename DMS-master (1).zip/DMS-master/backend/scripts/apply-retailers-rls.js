import { prisma, initializeDatabase, disconnectDatabase } from '../src/config/database.js';

async function main() {
  await initializeDatabase();
  try {
    await prisma.$executeRawUnsafe('ALTER TABLE retailers ENABLE ROW LEVEL SECURITY');
    await prisma.$executeRawUnsafe(
      `DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM pg_policies WHERE tablename = 'retailers' AND policyname = 'retailers_tenant_policy'
        ) THEN
          CREATE POLICY retailers_tenant_policy ON retailers
          USING (current_setting('app.is_brand', true) = 'true' OR dealer_id::text = current_setting('app.dealer_id', true));
        END IF;
      END $$;`
    );
    console.log('Retailers RLS policy ensured.');
  } catch (err) {
    console.error('RLS policy error:', err);
  } finally {
    await disconnectDatabase();
  }
}

main();

