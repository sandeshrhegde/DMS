import fs from 'fs';
import path from 'path';

const samplesDir = path.resolve('samples');
if (!fs.existsSync(samplesDir)) {
  fs.mkdirSync(samplesDir, { recursive: true });
}

// 1. Generate 110 sample SKUs
const categories = [
  { cat: 'Braking', hsn: '87083000', prefix: 'BRK', items: ['Front Brake Pad', 'Rear Brake Shoe', 'Disc Rotor', 'Brake Caliper Kit', 'Brake Master Cylinder', 'Brake Hose Pipe'] },
  { cat: 'Lubricants', hsn: '27101981', prefix: 'OIL', items: ['Engine Oil 5W-30', 'Engine Oil 10W-40', 'Gear Oil 80W-90', 'Brake Fluid DOT4', 'Chassis Grease MP3', 'Transmission Fluid ATF'] },
  { cat: 'Filters', hsn: '84213100', prefix: 'FLT', items: ['Air Filter Element', 'Oil Filter Spin-On', 'Cabin AC Filter', 'Fuel Filter Inline', 'Hydraulic Filter Cartridge'] },
  { cat: 'Ignition', hsn: '85111000', prefix: 'IGN', items: ['Spark Plug Standard', 'Spark Plug Platinum', 'Spark Plug Iridium', 'Ignition Coil Pack', 'High Tension Cable Set'] },
  { cat: 'Electrical', hsn: '85071000', prefix: 'ELC', items: ['12V 35Ah Battery', '12V 45Ah Battery', '12V 65Ah Battery', 'Alternator 12V 90A', 'Starter Motor 1.2kW', 'Dual Tone Electric Horn', 'Automotive Relay 30A'] },
  { cat: 'Lighting', hsn: '87082900', prefix: 'LGT', items: ['Headlamp Assembly LH', 'Headlamp Assembly RH', 'Tail Lamp Assembly LH', 'Tail Lamp Assembly RH', 'Fog Lamp Projector Kit', 'Halogen Bulb H4 12V'] },
  { cat: 'Cooling', hsn: '87082900', prefix: 'COL', items: ['Radiator Aluminum Core', 'Engine Coolant 1L', 'Water Pump Assembly', 'Thermostat Valve 82C', 'Radiator Pressure Cap', 'Cooling Fan Motor 12V'] },
  { cat: 'Suspension', hsn: '87082900', prefix: 'SUS', items: ['Front Gas Shock Absorber', 'Rear Strut Assembly', 'Lower Control Arm LH', 'Lower Control Arm RH', 'Tie Rod End Outer', 'Stabilizer Link Rod', 'Ball Joint Suspension'] },
  { cat: 'Transmission', hsn: '87089300', prefix: 'TRN', items: ['Clutch Disc 190mm', 'Clutch Pressure Plate', 'Clutch Release Bearing', 'Flywheel Dual Mass Assembly', 'Clutch Slave Cylinder'] }
];

const brands = ['AutoPro Genuine', 'LubriMax', 'IgniteTech', 'PowerVolt', 'PrecisionDrive'];
const sizes = ['Standard', 'Universal', 'Oversize +0.25', '1L Can', '5L Jar', 'Set of 2', 'Set of 4', 'Pack of 10'];
const colours = ['Black', 'Metallic Gray', 'Silver', 'White', 'Amber', 'Red', 'Blue', 'Natural'];
const uoms = ['PCS', 'SET', 'BOX', 'CAN', 'LTR'];

const skuRows = ['code,name,brand,category,article,size,colour,uom,mrp,hsnCode,barcode,isActive'];
let count = 0;

for (let i = 0; i < categories.length && count < 110; i++) {
  const c = categories[i];
  for (let j = 0; j < c.items.length && count < 110; j++) {
    const item = c.items[j];
    for (let variant = 1; variant <= 2 && count < 110; variant++) {
      count++;
      const numStr = String(count).padStart(3, '0');
      const code = `${c.prefix}-${numStr}`;
      const name = `${item} ${variant === 1 ? 'Premium' : 'Standard'}`;
      const brand = brands[count % brands.length];
      const category = c.cat;
      const article = `ART-${c.prefix}-${numStr}`;
      const size = sizes[count % sizes.length];
      const colour = colours[count % colours.length];
      const uom = uoms[count % uoms.length];
      const mrp = (250 + ((count * 67) % 5500)).toFixed(2);
      const hsnCode = c.hsn;
      const barcode = `89012345${String(1000 + count).slice(-5)}`;
      const isActive = 'true';
      skuRows.push([code, name, brand, category, article, size, colour, uom, mrp, hsnCode, barcode, isActive].map(v => `"${v}"`).join(','));
    }
  }
}

fs.writeFileSync(path.join(samplesDir, 'sample_skus.csv'), skuRows.join('\n'), 'utf8');
console.log(`Generated sample_skus.csv with ${skuRows.length - 1} SKU rows`);

// 2. Generate sample dealers
const dealerRows = [
  'code,name,gstin,stateCode,contactName,contactEmail,contactPhone,address,pincode,creditDays,maxHeaderDiscountPct,eInvoiceEnabled,geoNodeName,isActive',
  '"DLR-MUM-001","City Auto Wheels Mumbai","27AABCU9603R1ZM","27","Anil Sharma","anil@cityauto.local","+91 98201 11223","Plot 12, Link Road, Andheri West, Mumbai","400053",30,5.0,true,"Andheri Auto Cluster",true',
  '"DLR-DEL-002","Prime Wheels Delhi","07AABCP1234D1Z2","07","Vikram Singh","vikram@primewheels.local","+91 98110 22334","B-45, Okhla Industrial Area Phase 1, New Delhi","110020",45,8.0,true,"North Zone",true',
  '"DLR-PUN-003","North Star Mobility Pune","27AABCX5432E1Z8","27","Sunil Joshi","sunil@northstar.local","+91 98500 33445","Plot 8, Hinjewadi Phase 2, Pune","411057",30,6.0,false,"Maharashtra",true',
  '"DLR-BLR-004","Metro Wheels Bangalore","29AABCY8765F1Z4","29","Kiran Kumar","kiran@metrowheels.local","+91 98450 44556","7th Main, Peenya Industrial Area, Bangalore","560058",60,10.0,true,"West Zone",true',
  '"DLR-HYD-005","Apex Automotive Hyderabad","36AABCZ1122G1Z9","36","Suresh Reddy","suresh@apexauto.local","+91 98490 55667","Balanagar Cross Roads, Hyderabad","500037",30,5.0,false,"West Zone",true'
];

fs.writeFileSync(path.join(samplesDir, 'sample_dealers.csv'), dealerRows.join('\n'), 'utf8');
console.log(`Generated sample_dealers.csv with ${dealerRows.length - 1} Dealer rows`);

