import { prisma, initializeDatabase, disconnectDatabase } from '../src/config/database.js';

async function applyStockLedgerImmutability() {
  await initializeDatabase();
  console.log('Enforcing append-only immutability on stock_ledger table...');

  await prisma.$executeRawUnsafe(`
    CREATE OR REPLACE FUNCTION prevent_stock_ledger_mutation()
    RETURNS TRIGGER AS $$
    BEGIN
      RAISE EXCEPTION 'StockLedger is strictly append-only. UPDATE and DELETE operations are forbidden.';
    END;
    $$ LANGUAGE plpgsql;
  `);

  await prisma.$executeRawUnsafe(`
    DROP TRIGGER IF EXISTS trg_prevent_stock_ledger_mutation ON stock_ledger;
  `);

  await prisma.$executeRawUnsafe(`
    CREATE TRIGGER trg_prevent_stock_ledger_mutation
    BEFORE UPDATE OR DELETE ON stock_ledger
    FOR EACH ROW EXECUTE FUNCTION prevent_stock_ledger_mutation();
  `);

  console.log('Immutability trigger active on stock_ledger.');
  await disconnectDatabase();
}

applyStockLedgerImmutability().catch((e) => {
  console.error('Failed to apply trigger:', e);
  process.exit(1);
});

