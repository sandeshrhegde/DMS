import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateInvoiceTaxes, INVOICE_ERROR_CODES } from '@dms/shared';

test('Secondary Tax Invoice & GST Pure Engine Unit Tests', async (t) => {
  await t.test('1. Intra-State Tax Split: 50% CGST + 50% SGST, 0 IGST', () => {
    // Both dealer and retailer in Maharashtra (state code 27)
    const result = calculateInvoiceTaxes({
      lines: [
        { skuId: 'sku-1', qty: 10, unitPrice: 1000.0, gstRate: 18.0 } // Gross: 10,000, 18% GST
      ],
      dealerStateCode: '27',
      retailerStateCode: '27'
    });

    assert.equal(result.isIntraState, true);
    assert.equal(result.grossAmount, 10000.0);
    assert.equal(result.taxableTotal, 10000.0);
    assert.equal(result.cgstTotal, 900.0); // 9%
    assert.equal(result.sgstTotal, 900.0); // 9%
    assert.equal(result.igstTotal, 0.0);
    assert.equal(result.taxTotal, 1800.0);
    assert.equal(result.netTotal, 11800.0);
    assert.equal(result.rounding, 0.0);

    const l1 = result.lines[0];
    assert.equal(l1.cgstAmount, 900.0);
    assert.equal(l1.sgstAmount, 900.0);
    assert.equal(l1.igstAmount, 0.0);
    assert.equal(l1.lineTotal, 11800.0);
  });

  await t.test('2. Inter-State Tax Split: 0 CGST + 0 SGST, 100% IGST', () => {
    // Dealer in MH (27), retailer in Karnataka (29)
    const result = calculateInvoiceTaxes({
      lines: [
        { skuId: 'sku-1', qty: 5, unitPrice: 2000.0, gstRate: 28.0 } // Gross: 10,000, 28% GST
      ],
      dealerStateCode: '27',
      retailerStateCode: '29'
    });

    assert.equal(result.isIntraState, false);
    assert.equal(result.grossAmount, 10000.0);
    assert.equal(result.taxableTotal, 10000.0);
    assert.equal(result.cgstTotal, 0.0);
    assert.equal(result.sgstTotal, 0.0);
    assert.equal(result.igstTotal, 2800.0); // 28%
    assert.equal(result.taxTotal, 2800.0);
    assert.equal(result.netTotal, 12800.0);
    assert.equal(result.rounding, 0.0);

    const l1 = result.lines[0];
    assert.equal(l1.cgstAmount, 0.0);
    assert.equal(l1.sgstAmount, 0.0);
    assert.equal(l1.igstAmount, 2800.0);
  });

  await t.test('3. Header Discount Pro-rating: discount is deducted BEFORE calculating tax', () => {
    // Line 1: 10 * 1000 = 10,000 (18% GST)
    // Line 2: 5 * 2000 = 10,000 (18% GST)
    // Total Gross = 20,000. Header Discount = 5% (₹1,000)
    // Pro-rated discount: ₹500 on Line 1, ₹500 on Line 2
    // Line 1 Taxable: 9,500. GST 18% = 1,710 (CGST 855, SGST 855)
    // Line 2 Taxable: 9,500. GST 18% = 1,710 (CGST 855, SGST 855)
    // Total Taxable = 19,000. Total Tax = 3,420. Net Total = 22,420
    const result = calculateInvoiceTaxes({
      lines: [
        { skuId: 'sku-1', qty: 10, unitPrice: 1000.0, gstRate: 18.0 },
        { skuId: 'sku-2', qty: 5, unitPrice: 2000.0, gstRate: 18.0 }
      ],
      dealerStateCode: '27',
      retailerStateCode: '27',
      headerDiscountPct: 5.0,
      maxHeaderDiscountPct: 10.0,
      headerDiscountReason: 'Festive promotion special concession'
    });

    assert.equal(result.grossAmount, 20000.0);
    assert.equal(result.headerDiscountAmount, 1000.0);
    assert.equal(result.taxableTotal, 19000.0);
    assert.equal(result.cgstTotal, 1710.0);
    assert.equal(result.sgstTotal, 1710.0);
    assert.equal(result.taxTotal, 3420.0);
    assert.equal(result.netTotal, 22420.0);

    assert.equal(result.lines[0].discountShare, 500.0);
    assert.equal(result.lines[0].taxableValue, 9500.0);
    assert.equal(result.lines[1].discountShare, 500.0);
    assert.equal(result.lines[1].taxableValue, 9500.0);
  });

  await t.test('4. Header Discount Cap Enforcement: blocks discounts exceeding maxHeaderDiscountPct', () => {
    assert.throws(
      () => {
        calculateInvoiceTaxes({
          lines: [{ skuId: 'sku-1', qty: 1, unitPrice: 1000.0, gstRate: 18.0 }],
          dealerStateCode: '27',
          retailerStateCode: '27',
          headerDiscountPct: 12.0, // Exceeds 10%
          maxHeaderDiscountPct: 10.0
        });
      },
      (err) => {
        assert.equal(err.code, INVOICE_ERROR_CODES.HEADER_DISCOUNT_EXCEEDED);
        assert.match(err.message, /exceeds dealer maximum allowed limit/i);
        return true;
      }
    );
  });

  await t.test('5. Header Discount Reason Requirement: mandatory for discounts above 3%', () => {
    // 4% discount without reason -> throws error
    assert.throws(
      () => {
        calculateInvoiceTaxes({
          lines: [{ skuId: 'sku-1', qty: 1, unitPrice: 1000.0, gstRate: 18.0 }],
          dealerStateCode: '27',
          retailerStateCode: '27',
          headerDiscountPct: 4.0,
          maxHeaderDiscountPct: 10.0,
          headerDiscountReason: '' // Empty reason!
        });
      },
      (err) => {
        assert.equal(err.code, INVOICE_ERROR_CODES.HEADER_DISCOUNT_REASON_REQUIRED);
        assert.match(err.message, /justification reason is mandatory/i);
        return true;
      }
    );

    // 2% discount without reason -> allowed!
    const okResult = calculateInvoiceTaxes({
      lines: [{ skuId: 'sku-1', qty: 1, unitPrice: 1000.0, gstRate: 18.0 }],
      dealerStateCode: '27',
      retailerStateCode: '27',
      headerDiscountPct: 2.0,
      maxHeaderDiscountPct: 10.0,
      headerDiscountReason: ''
    });
    assert.equal(okResult.headerDiscountAmount, 20.0);
  });

  await t.test('6. Standard Rounding to Nearest Integer Rupee and Rounding Fraction', () => {
    // Line: 1 * 133.33 with 18% GST
    // Gross: 133.33. Tax (18%): 23.9994 -> rounded to 24.00 (CGST 12.00, SGST 12.00)
    // Unrounded: 157.33
    // Net: 157
    // Rounding fraction: -0.33
    const result = calculateInvoiceTaxes({
      lines: [{ skuId: 'sku-1', qty: 1, unitPrice: 133.33, gstRate: 18.0 }],
      dealerStateCode: '27',
      retailerStateCode: '27'
    });

    assert.equal(result.taxableTotal, 133.33);
    assert.equal(result.taxTotal, 24.0);
    assert.equal(result.unroundedTotal, 157.33);
    assert.equal(result.netTotal, 157);
    assert.equal(result.rounding, -0.33);
    assert.equal(
      Math.round((result.taxableTotal + result.taxTotal + result.rounding) * 100) / 100,
      result.netTotal
    );
  });
});

