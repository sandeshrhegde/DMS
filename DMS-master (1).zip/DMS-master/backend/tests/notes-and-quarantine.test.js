import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';
import {
  NOTE_TYPES,
  NOTE_REASON_CODES,
  NOTE_STATUSES,
  NOTE_ERROR_CODES
} from '@dms/shared';

test('Retailer Returns, Financial Notes, Quarantine & Approval Workflow Suite', async (t) => {
  let server;
  let baseUrl;

  let testDealer1;
  let testDealer2;
  let testWarehouse1;
  let testWarehouse2;
  let testRetailerMH;
  let testRetailerKA;
  let testSku1;
  let testSku2;

  const runId = Date.now();
  const ownerEmail = `owner_${runId}@demo.local`;
  const operatorEmail = `operator_${runId}@demo.local`;

  t.before(async () => {
    await initializeDatabase();

    // 1. Create Dealer 1 (MH, threshold 50,000)
    testDealer1 = await prisma.dealer.create({
      data: {
        code: `DLR-N1-${String(runId).slice(-4)}`,
        name: `Return Motors 1 ${runId}`,
        stateCode: '27', // Maharashtra
        noteApprovalThreshold: 50000.0,
        maxHeaderDiscountPct: 10.0,
        isActive: true
      }
    });

    // 2. Create Dealer 2 (cross-dealer isolation check)
    testDealer2 = await prisma.dealer.create({
      data: {
        code: `DLR-N2-${String(runId).slice(-4)}`,
        name: `Return Motors 2 ${runId}`,
        stateCode: '27',
        noteApprovalThreshold: 50000.0,
        maxHeaderDiscountPct: 10.0,
        isActive: true
      }
    });

    // 3. Create Warehouses
    testWarehouse1 = await prisma.warehouse.create({
      data: {
        dealerId: testDealer1.id,
        code: 'WH-MAIN',
        name: 'Main Return WH',
        isDefault: true,
        isActive: true
      }
    });

    testWarehouse2 = await prisma.warehouse.create({
      data: {
        dealerId: testDealer2.id,
        code: 'WH-MAIN2',
        name: 'Dealer 2 WH',
        isDefault: true,
        isActive: true
      }
    });

    // 4. Create SKUs
    testSku1 = await prisma.sku.create({
      data: {
        code: `SKU-RET1-${runId}`,
        name: 'Heavy Duty Clutch Kit',
        barcode: `89012345${String(runId).slice(-5)}1`,
        brand: 'Valeo',
        category: 'Clutch',
        mrp: 5000.0,
        landingPrice: 3000.0,
        hsnCode: '87089300',
        isActive: true
      }
    });

    testSku2 = await prisma.sku.create({
      data: {
        code: `SKU-RET2-${runId}`,
        name: 'Brake Disc Rotors',
        barcode: `89012345${String(runId).slice(-5)}2`,
        brand: 'Brembo',
        category: 'Brakes',
        mrp: 3000.0,
        landingPrice: 1800.0,
        hsnCode: '87083000',
        isActive: true
      }
    });

    // 5. Create Retailers (Intra-state MH and Inter-state KA)
    testRetailerMH = await prisma.retailer.create({
      data: {
        dealerId: testDealer1.id,
        legalName: `Intra Spares MH ${runId}`,
        tradeName: 'Intra Spares',
        gstin: '27AABCU9603R1Z1',
        mobile: '9876543310',
        billingAddress: 'Andheri, Mumbai',
        shippingAddress: 'Andheri, Mumbai',
        stateCode: '27', // MH (Intra-state)
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 500000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    testRetailerKA = await prisma.retailer.create({
      data: {
        dealerId: testDealer1.id,
        legalName: `Inter Motors KA ${runId}`,
        tradeName: 'Inter Motors',
        gstin: '29AABCU9603R1Z2',
        mobile: '9876543311',
        billingAddress: 'Whitefield, Bangalore',
        shippingAddress: 'Whitefield, Bangalore',
        stateCode: '29', // KA (Inter-state)
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 500000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    // Start HTTP server on dynamic port
    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://127.0.0.1:${port}`;
        resolve();
      });
    });
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  // Helper to create a direct ISSUED invoice for testing returns
  async function createTestIssuedInvoice({ retailer, sku, qty, unitPrice, gstRate, isIntraState }) {
    const gross = qty * unitPrice;
    const taxable = gross;
    let cgst = 0;
    let sgst = 0;
    let igst = 0;

    if (isIntraState) {
      cgst = Math.round((taxable * (gstRate / 2) / 100) * 100) / 100;
      sgst = Math.round((taxable * (gstRate / 2) / 100) * 100) / 100;
    } else {
      igst = Math.round((taxable * gstRate / 100) * 100) / 100;
    }

    const taxTotal = Math.round((cgst + sgst + igst) * 100) / 100;
    const net = Math.round(taxable + taxTotal);
    const rounding = Math.round((net - (taxable + taxTotal)) * 100) / 100;

    const invSeq = Math.floor(Math.random() * 9000) + 1000;
    const invoiceNo = `INV-2026-27-${invSeq}`;

    const invoice = await prisma.invoice.create({
      data: {
        dealerId: testDealer1.id,
        retailerId: retailer.id,
        invoiceNo,
        financialYear: '2026-27',
        invoiceDate: new Date(),
        orderIds: [],
        warehouseId: testWarehouse1.id,
        status: 'ISSUED',
        grossAmount: gross,
        headerDiscountAmount: 0.0,
        taxableTotal: taxable,
        cgstTotal: cgst,
        sgstTotal: sgst,
        igstTotal: igst,
        taxTotal,
        rounding,
        netTotal: net,
        lines: {
          create: [
            {
              skuId: sku.id,
              qty,
              unitPrice,
              gstRate,
              hsnCode: sku.hsnCode,
              grossAmount: gross,
              discountShare: 0.0,
              taxableValue: taxable,
              cgstAmount: cgst,
              sgstAmount: sgst,
              igstAmount: igst,
              lineTax: taxTotal,
              lineTotal: net
            }
          ]
        }
      },
      include: {
        lines: { include: { sku: true } }
      }
    });

    // Create corresponding debit ledger entry for the invoice
    await prisma.ledgerEntry.create({
      data: {
        dealerId: testDealer1.id,
        retailerId: retailer.id,
        type: 'INVOICE',
        debit: net,
        credit: 0.0,
        refType: 'INVOICE',
        refId: invoice.id,
        notes: `Test invoice ${invoiceNo}`
      }
    });

    return invoice;
  }

  // -------------------------------------------------------------
  // TEST 1: Over-return is Blocked
  // -------------------------------------------------------------
  await t.test('1. Over-return blocked: return qty cannot exceed billed minus already returned', async () => {
    const inv = await createTestIssuedInvoice({
      retailer: testRetailerMH,
      sku: testSku1,
      qty: 10,
      unitPrice: 2000.0,
      gstRate: 18.0,
      isIntraState: true
    });
    const lineId = inv.lines[0].id;

    // a) Attempt to return 15 units (exceeds billed 10)
    const overRes = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_DAMAGED,
        lines: [{ invoiceLineId: lineId, qty: 15 }]
      })
    });

    assert.equal(overRes.status, 400);
    const overData = await overRes.json();
    assert.match(overData.error, /exceeds maximum returnable quantity/i);

    // b) Return 6 units (valid, leaves 4)
    const validRes = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_DAMAGED,
        lines: [{ invoiceLineId: lineId, qty: 6 }]
      })
    });
    assert.equal(validRes.status, 201);
    const validData = await validRes.json();
    assert.equal(validData.note.status, NOTE_STATUSES.APPROVED);

    // c) Attempt to return 5 units (now only 4 are remaining)
    const secondOverRes = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_DAMAGED,
        lines: [{ invoiceLineId: lineId, qty: 5 }]
      })
    });
    assert.equal(secondOverRes.status, 400);
    const secondOverData = await secondOverRes.json();
    assert.match(secondOverData.error, /exceeds maximum returnable quantity of 4/i);
  });

  // -------------------------------------------------------------
  // TEST 2: Exact Tax Reversal (Intra-state CGST + SGST)
  // -------------------------------------------------------------
  await t.test('2. Exact tax reversal: Intra-state reverses CGST and SGST proportionally', async () => {
    const inv = await createTestIssuedInvoice({
      retailer: testRetailerMH,
      sku: testSku1,
      qty: 10,
      unitPrice: 1000.0, // 10 * 1000 = 10,000 + 18% (900 CGST + 900 SGST) = 11,800
      gstRate: 18.0,
      isIntraState: true
    });
    const lineId = inv.lines[0].id;

    // Return 3 units: gross = 3000, cgst = 270, sgst = 270, igst = 0, total = 3540
    const res = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_WRONG_ITEM,
        lines: [{ invoiceLineId: lineId, qty: 3 }]
      })
    });

    assert.equal(res.status, 201);
    const { note } = await res.json();
    assert.equal(note.grossAmount, 3000.0);
    assert.equal(note.taxableAmount, 3000.0);
    assert.equal(note.cgstAmount, 270.0);
    assert.equal(note.sgstAmount, 270.0);
    assert.equal(note.igstAmount, 0.0);
    assert.equal(note.totalAmount, 3540.0);
    assert.match(note.noteNo, /^CN-\d{2}-\d{2}-\d{4}$/);
  });

  // -------------------------------------------------------------
  // TEST 3: Exact Tax Reversal (Inter-state IGST)
  // -------------------------------------------------------------
  await t.test('3. Exact tax reversal: Inter-state reverses IGST only', async () => {
    const inv = await createTestIssuedInvoice({
      retailer: testRetailerKA,
      sku: testSku2,
      qty: 5,
      unitPrice: 2000.0, // 5 * 2000 = 10,000 + 28% IGST = 2,800 -> 12,800
      gstRate: 28.0,
      isIntraState: false
    });
    const lineId = inv.lines[0].id;

    // Return 2 units: gross = 4000, igst = 1120, cgst = 0, sgst = 0, total = 5120
    const res = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerKA.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_DAMAGED,
        lines: [{ invoiceLineId: lineId, qty: 2 }]
      })
    });

    assert.equal(res.status, 201);
    const { note } = await res.json();
    assert.equal(note.grossAmount, 4000.0);
    assert.equal(note.taxableAmount, 4000.0);
    assert.equal(note.cgstAmount, 0.0);
    assert.equal(note.sgstAmount, 0.0);
    assert.equal(note.igstAmount, 1120.0);
    assert.equal(note.totalAmount, 5120.0);
  });

  // -------------------------------------------------------------
  // TEST 4: Quarantine Inspection Moves Stock Correctly
  // -------------------------------------------------------------
  await t.test('4. Quarantine inspection moves quarantined stock to AVAILABLE and DAMAGED', async () => {
    const inv = await createTestIssuedInvoice({
      retailer: testRetailerMH,
      sku: testSku1,
      qty: 6,
      unitPrice: 1000.0,
      gstRate: 18.0,
      isIntraState: true
    });
    const lineId = inv.lines[0].id;

    // Return 4 units (Auto-approved because 4 * 1180 = 4720 <= 50,000)
    const createRes = await fetch(`${baseUrl}/api/notes/sales-return`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        invoiceId: inv.id,
        reasonCode: NOTE_REASON_CODES.RETURN_DAMAGED,
        lines: [{ invoiceLineId: lineId, qty: 4, batch: 'B-QUAR-TEST' }]
      })
    });

    assert.equal(createRes.status, 201);
    const { note } = await createRes.json();
    assert.equal(note.status, NOTE_STATUSES.APPROVED);

    const noteLineId = note.lines[0].id;

    // Check stock in QUARANTINE on hand
    const quOnHand = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer1.id,
          warehouseId: testWarehouse1.id,
          skuId: testSku1.id,
          batch: 'B-QUAR-TEST',
          stockState: 'QUARANTINE'
        }
      }
    });
    assert.ok(quOnHand && quOnHand.qty >= 4);

    // Mismatched inspection split (good 3 + damaged 2 = 5 != 4) -> should fail
    const mismatchRes = await fetch(`${baseUrl}/api/notes/quarantine/inspect`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id
      },
      body: JSON.stringify({
        noteId: note.id,
        noteLineId,
        warehouseId: testWarehouse1.id,
        goodQty: 3,
        damagedQty: 2
      })
    });
    assert.equal(mismatchRes.status, 400);

    // Valid inspection: 3 good, 1 damaged
    const inspectRes = await fetch(`${baseUrl}/api/notes/quarantine/inspect`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        noteId: note.id,
        noteLineId,
        warehouseId: testWarehouse1.id,
        goodQty: 3,
        damagedQty: 1,
        notes: 'Passed QC 3 units, 1 cracked casing'
      })
    });
    assert.equal(inspectRes.status, 200);

    // Verify StockOnHand AVAILABLE increased by 3, DAMAGED increased by 1
    const availStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer1.id,
          warehouseId: testWarehouse1.id,
          skuId: testSku1.id,
          batch: 'B-QUAR-TEST',
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.ok(availStock && availStock.qty >= 3);

    const damagedStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer1.id,
          warehouseId: testWarehouse1.id,
          skuId: testSku1.id,
          batch: 'B-QUAR-TEST',
          stockState: 'DAMAGED'
        }
      }
    });
    assert.ok(damagedStock && damagedStock.qty >= 1);
  });

  // -------------------------------------------------------------
  // TEST 5: Approval Threshold Workflow
  // -------------------------------------------------------------
  await t.test('5. Approval threshold: Notes > threshold require DEALER_OWNER approval', async () => {
    // Financial Credit Note with amount 75,000 > threshold (50,000)
    const createRes = await fetch(`${baseUrl}/api/notes/financial`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        type: NOTE_TYPES.CREDIT_FINANCIAL,
        reasonCode: NOTE_REASON_CODES.SCHEME_BENEFIT,
        amount: 75000.0,
        isTaxable: false,
        notes: 'Annual scheme rebate'
      })
    });

    assert.equal(createRes.status, 201);
    const { note } = await createRes.json();
    assert.equal(note.status, NOTE_STATUSES.PENDING_APPROVAL);
    assert.equal(note.requiresApproval, true);

    // Operator cannot approve (403 forbidden)
    const opApproveRes = await fetch(`${baseUrl}/api/notes/${note.id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      }
    });
    assert.equal(opApproveRes.status, 403);

    // Owner approves successfully
    const ownerApproveRes = await fetch(`${baseUrl}/api/notes/${note.id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer1.id,
        'x-user-email': ownerEmail
      }
    });
    assert.equal(ownerApproveRes.status, 200);
    const approvedData = await ownerApproveRes.json();
    assert.equal(approvedData.note.status, NOTE_STATUSES.APPROVED);
    assert.equal(approvedData.note.approvedByEmail, ownerEmail);

    // Ledger Entry should now exist for the credit note
    const ledgerEntry = await prisma.ledgerEntry.findFirst({
      where: {
        dealerId: testDealer1.id,
        retailerId: testRetailerMH.id,
        refType: 'CREDIT_NOTE',
        refId: note.id
      }
    });
    assert.ok(ledgerEntry);
    assert.equal(ledgerEntry.credit, 75000.0);
  });

  // -------------------------------------------------------------
  // TEST 6: Ledger Balance After Note + Allocation
  // -------------------------------------------------------------
  await t.test('6. Ledger balance: Note credits balance, and allocation settles open invoices', async () => {
    // 1. Create open invoice for 10,000
    const inv = await createTestIssuedInvoice({
      retailer: testRetailerMH,
      sku: testSku1,
      qty: 10,
      unitPrice: 847.46, // 8474.60 + 18% = 10,000
      gstRate: 18.0,
      isIntraState: true
    });

    // 2. Create financial credit note for 4,000 (auto-approved <= 50,000)
    const noteRes = await fetch(`${baseUrl}/api/notes/financial`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        type: NOTE_TYPES.CREDIT_FINANCIAL,
        reasonCode: NOTE_REASON_CODES.RATE_DIFFERENCE,
        amount: 4000.0,
        isTaxable: false
      })
    });
    assert.equal(noteRes.status, 201);
    const { note } = await noteRes.json();
    assert.equal(note.status, NOTE_STATUSES.APPROVED);
    assert.equal(note.balanceAmount, 4000.0);

    // 3. Allocate note against open invoice
    const allocRes = await fetch(`${baseUrl}/api/notes/${note.id}/allocate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        autoAllocateFifo: false,
        allocations: [{ invoiceId: inv.id, amount: 4000.0 }]
      })
    });
    assert.equal(allocRes.status, 200);
    const allocData = await allocRes.json();
    assert.equal(allocData.note.allocatedAmount, 4000.0);
    assert.equal(allocData.note.balanceAmount, 0.0);

    // Verify invoice paidAmount updated
    const updatedInv = await prisma.invoice.findUnique({ where: { id: inv.id } });
    assert.equal(updatedInv.paidAmount, 4000.0);
    assert.equal(updatedInv.paymentStatus, 'PARTIALLY_PAID');
  });

  // -------------------------------------------------------------
  // TEST 7: Cheque Bounce Creates Formal Gapless DEBIT Note
  // -------------------------------------------------------------
  await t.test('7. Cheque bounce integration: Replaces bare entry with formal DEBIT Note', async () => {
    // Record cheque collection of 5,000
    const colRes = await fetch(`${baseUrl}/api/billing/collections`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer1.id,
        'x-user-email': operatorEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        mode: 'CHEQUE',
        amount: 5000.0,
        reference: `CHQ-BOUNCE-${runId}`,
        autoAllocateFifo: true
      })
    });
    assert.equal(colRes.status, 201);
    const colData = await colRes.json();
    const collectionId = colData.collection?.id || colData.id;

    // Bounce the cheque with 750 bounce charge
    const bounceRes = await fetch(`${baseUrl}/api/billing/collections/${collectionId}/bounce`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer1.id,
        'x-user-email': ownerEmail
      },
      body: JSON.stringify({
        reason: 'Insufficient funds on clearing',
        bounceCharge: 750.0
      })
    });
    assert.equal(bounceRes.status, 200);

    // Verify formal DEBIT note was created
    const debitNote = await prisma.note.findFirst({
      where: {
        dealerId: testDealer1.id,
        retailerId: testRetailerMH.id,
        type: NOTE_TYPES.DEBIT,
        reasonCode: NOTE_REASON_CODES.CHEQUE_BOUNCE_CHARGE
      },
      orderBy: { createdAt: 'desc' }
    });

    assert.ok(debitNote);
    assert.match(debitNote.noteNo, /^DN-\d{2}-\d{2}-\d{4}$/);
    assert.equal(debitNote.totalAmount, 750.0);
    assert.equal(debitNote.status, NOTE_STATUSES.APPROVED);

    // Verify LedgerEntry references this debit note
    const chargeEntry = await prisma.ledgerEntry.findFirst({
      where: {
        dealerId: testDealer1.id,
        retailerId: testRetailerMH.id,
        type: 'DEBIT_NOTE',
        refType: 'DEBIT_NOTE',
        refId: debitNote.id
      }
    });
    assert.ok(chargeEntry);
    assert.equal(chargeEntry.debit, 750.0);
  });

  // -------------------------------------------------------------
  // TEST 8: Permission & Multi-tenant Isolation Checks
  // -------------------------------------------------------------
  await t.test('8. Multi-tenant isolation: Dealer 2 cannot access Dealer 1 notes', async () => {
    // Create note for Dealer 1
    const d1Note = await prisma.note.create({
      data: {
        dealerId: testDealer1.id,
        retailerId: testRetailerMH.id,
        noteNo: `CN-2026-27-9999`,
        financialYear: '2026-27',
        type: NOTE_TYPES.CREDIT_FINANCIAL,
        reasonCode: NOTE_REASON_CODES.OTHER,
        status: NOTE_STATUSES.PENDING_APPROVAL,
        totalAmount: 10000.0
      }
    });

    // Dealer 2 tries to fetch Dealer 1 note
    const crossGetRes = await fetch(`${baseUrl}/api/notes/${d1Note.id}`, {
      headers: {
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer2.id
      }
    });
    assert.equal(crossGetRes.status, 404);

    // Dealer 2 tries to approve Dealer 1 note
    const crossApproveRes = await fetch(`${baseUrl}/api/notes/${d1Note.id}/approve`, {
      method: 'POST',
      headers: {
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer2.id
      }
    });
    assert.equal(crossApproveRes.status, 403);
  });
});
