import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';
import {
  allocatePaymentFifo,
  validateManualAllocations,
  calculateAgeingBuckets,
  PAYMENT_MODES,
  COLLECTION_STATUSES,
  INVOICE_PAYMENT_STATUSES
} from '@dms/shared';
import {
  createCollectionTransaction,
  bounceChequeTransaction,
  getRetailerLedgerData,
  getDealerOutstandingOverview
} from '../src/services/collection.service.js';
import {
  getRetailerOutstanding,
  checkRetailerOverdueInvoices,
  createDraftOrder,
  submitOrder
} from '../src/services/order.service.js';

test('Collections, Allocations, Cheque Bounce & Ledger Outstanding Suite', async (t) => {
  let server;
  let baseUrl;

  let testDealer;
  let testWarehouse;
  let testRetailer;
  let testSku;

  const runId = Date.now();
  const ownerEmail = `owner_${runId}@demo.local`;

  t.before(async () => {
    await initializeDatabase();

    // 1. Create Dealer with creditDays = 30 and bounceCharge = 500
    testDealer = await prisma.dealer.create({
      data: {
        code: `DLR${String(runId).slice(-4)}`,
        name: `Collections Test Motors ${runId}`,
        stateCode: '27',
        creditDays: 30,
        bounceCharge: 500.0,
        isActive: true
      }
    });

    // 2. Create Warehouse
    testWarehouse = await prisma.warehouse.create({
      data: {
        dealerId: testDealer.id,
        code: 'MAIN',
        name: 'Main Warehouse',
        isDefault: true,
        isActive: true
      }
    });

    // 3. Create Retailer
    testRetailer = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Test Retailer Enterprises ${runId}`,
        tradeName: 'Test Enterprises',
        mobile: '9876543210',
        billingAddress: '123 Market Road, Mumbai',
        shippingAddress: '123 Market Road, Mumbai',
        stateCode: '27',
        retailerClass: 'A',
        creditLimit: 10000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    // 4. Create SKU
    testSku = await prisma.sku.create({
      data: {
        code: `SKU-COL-${runId}`,
        name: 'High Performance Engine Oil',
        brand: 'TestBrand',
        category: 'Lubricants',
        mrp: 1000.0,
        hsnCode: '27101981',
        barcode: `BAR-${runId}`,
        isActive: true
      }
    });

    // 5. Create Approved Price Rule
    const pl = await prisma.priceList.create({
      data: {
        name: `PriceList-${runId}`,
        status: 'APPROVED',
        validFrom: new Date('2020-01-01')
      }
    });

    await prisma.priceRule.create({
      data: {
        priceListId: pl.id,
        skuId: testSku.id,
        targetType: 'NATIONAL',
        method: 'FIXED',
        value: 1000.0
      }
    });

    // Start HTTP test server
    server = app.listen(0);
    const port = server.address().port;
    baseUrl = `http://127.0.0.1:${port}`;
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  await t.test('1. Pure Logic: FIFO allocation, manual validation & ageing buckets', async () => {
    // A. FIFO Allocation
    const openInvoices = [
      { id: 'inv-1', invoiceNo: 'INV001', netTotal: 1000.0, paidAmount: 0.0, invoiceDate: new Date('2026-09-01') },
      { id: 'inv-2', invoiceNo: 'INV002', netTotal: 2000.0, paidAmount: 0.0, invoiceDate: new Date('2026-09-10') }
    ];

    const fifoResult = allocatePaymentFifo(1500.0, openInvoices);
    assert.equal(fifoResult.allocatedAmount, 1500.0);
    assert.equal(fifoResult.advanceAmount, 0.0);
    assert.equal(fifoResult.allocations.length, 2);
    assert.equal(fifoResult.allocations[0].invoiceId, 'inv-1');
    assert.equal(fifoResult.allocations[0].amount, 1000.0);
    assert.equal(fifoResult.allocations[1].invoiceId, 'inv-2');
    assert.equal(fifoResult.allocations[1].amount, 500.0);

    // B. Manual Allocation & Over-allocation guardrails
    assert.throws(() => {
      validateManualAllocations(1500.0, [{ invoiceId: 'inv-1', amount: 1200.0 }], openInvoices);
    }, /Over-allocation error.*exceeds invoice.*open balance/);

    assert.throws(() => {
      validateManualAllocations(1000.0, [
        { invoiceId: 'inv-1', amount: 600.0 },
        { invoiceId: 'inv-2', amount: 600.0 }
      ], openInvoices);
    }, /Over-allocation error.*exceeds payment amount/);

    const validManual = validateManualAllocations(1200.0, [
      { invoiceId: 'inv-1', amount: 800.0 },
      { invoiceId: 'inv-2', amount: 200.0 }
    ], openInvoices);
    assert.equal(validManual.allocatedAmount, 1000.0);
    assert.equal(validManual.advanceAmount, 200.0);

    // C. Ageing Buckets Pure Test
    const asOf = new Date('2026-10-08');
    const agedInvoices = [
      { id: '1', invoiceDate: new Date('2026-10-01'), netTotal: 100, paidAmount: 0 }, // 7 days old -> 0-30
      { id: '2', invoiceDate: new Date('2026-08-25'), netTotal: 200, paidAmount: 0 }, // 44 days old -> 31-60 (overdue for 30d credit)
      { id: '3', invoiceDate: new Date('2026-07-20'), netTotal: 300, paidAmount: 0 }, // 80 days old -> 61-90 (overdue)
      { id: '4', invoiceDate: new Date('2026-06-01'), netTotal: 400, paidAmount: 0 }  // 129 days old -> 90+ (overdue)
    ];

    const ageing = calculateAgeingBuckets(agedInvoices, 30, asOf);
    assert.equal(ageing.buckets['0_30'], 100.0);
    assert.equal(ageing.buckets['31_60'], 200.0);
    assert.equal(ageing.buckets['61_90'], 300.0);
    assert.equal(ageing.buckets['90_plus'], 400.0);
    assert.equal(ageing.totalOutstanding, 1000.0);
    assert.equal(ageing.totalOverdue, 900.0); // 200 + 300 + 400
    assert.equal(ageing.hasOverdue, true);
  });

  await t.test('2. FIFO payment collection reduces open invoices and updates ledger', async () => {
    // Setup: Create 2 invoices in DB for testRetailer
    const inv1 = await prisma.invoice.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        invoiceNo: `INV/${runId}/001`,
        financialYear: '26-27',
        grossAmount: 1000.0,
        taxableTotal: 1000.0,
        taxTotal: 0.0,
        netTotal: 1000.0,
        orderIds: [],
        status: 'ISSUED',
        paidAmount: 0.0,
        paymentStatus: 'UNPAID'
      }
    });

    // Create corresponding debit ledger entry for inv1
    await prisma.ledgerEntry.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        type: 'INVOICE',
        debit: 1000.0,
        credit: 0.0,
        refType: 'INVOICE',
        refId: inv1.id,
        date: new Date()
      }
    });

    const inv2 = await prisma.invoice.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        invoiceNo: `INV/${runId}/002`,
        financialYear: '26-27',
        grossAmount: 2000.0,
        taxableTotal: 2000.0,
        taxTotal: 0.0,
        netTotal: 2000.0,
        orderIds: [],
        status: 'ISSUED',
        paidAmount: 0.0,
        paymentStatus: 'UNPAID'
      }
    });

    // Create corresponding debit ledger entry for inv2
    await prisma.ledgerEntry.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        type: 'INVOICE',
        debit: 2000.0,
        credit: 0.0,
        refType: 'INVOICE',
        refId: inv2.id,
        date: new Date()
      }
    });

    // Check outstanding before payment
    const outstandingBefore = await getRetailerOutstanding(testRetailer.id);
    assert.equal(outstandingBefore, 3000.0);

    // Record Collection of ₹1,500 via FIFO via HTTP POST
    const res = await fetch(`${baseUrl}/api/billing/collections`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-email': ownerEmail,
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        mode: 'NEFT',
        amount: 1500.0,
        reference: 'UTR123456789',
        collectedBy: 'Branch Manager',
        autoAllocateFifo: true
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.equal(body.amount, 1500.0);
    assert.equal(body.allocatedAmount, 1500.0);
    assert.equal(body.advanceAmount, 0.0);
    assert.equal(body.allocations.length, 2);

    // Verify Inv 1 is PAID and Inv 2 is PARTIALLY_PAID
    const checkInv1 = await prisma.invoice.findUnique({ where: { id: inv1.id } });
    assert.equal(checkInv1.paidAmount, 1000.0);
    assert.equal(checkInv1.paymentStatus, 'PAID');

    const checkInv2 = await prisma.invoice.findUnique({ where: { id: inv2.id } });
    assert.equal(checkInv2.paidAmount, 500.0);
    assert.equal(checkInv2.paymentStatus, 'PARTIALLY_PAID');

    // Verify real ledger outstanding drops to ₹1,500
    const outstandingAfter = await getRetailerOutstanding(testRetailer.id);
    assert.equal(outstandingAfter, 1500.0);
  });

  await t.test('3. Advance payment creates on-account credit and negative outstanding', async () => {
    // Current outstanding is ₹1,500 on Inv 2.
    // Record payment of ₹2,500 (covers ₹1,500 open balance + ₹1,000 advance)
    const res = await fetch(`${baseUrl}/api/billing/collections`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-email': ownerEmail,
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        mode: 'UPI',
        amount: 2500.0,
        reference: 'UPI-987654321',
        collectedBy: 'Cashier'
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.equal(body.allocatedAmount, 1500.0);
    assert.equal(body.advanceAmount, 1000.0);

    // Outstanding balance is now -1000.0 (credit advance)
    const ledgerData = await getRetailerLedgerData({
      dealerId: testDealer.id,
      retailerId: testRetailer.id
    });

    assert.equal(ledgerData.summary.currentOutstanding, -1000.0);
    assert.equal(ledgerData.summary.onAccountAdvance, 1000.0);
    assert.equal(ledgerData.summary.netDue, 0.0);
  });

  await t.test('4. Cheque bounce reverses allocations, restores invoices and charges bounce penalty', async () => {
    // 1. Create a fresh invoice of ₹2,000
    const invBounce = await prisma.invoice.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        invoiceNo: `INV/${runId}/BOUNCE`,
        financialYear: '26-27',
        grossAmount: 2000.0,
        taxableTotal: 2000.0,
        taxTotal: 0.0,
        netTotal: 2000.0,
        orderIds: [],
        status: 'ISSUED',
        paidAmount: 0.0,
        paymentStatus: 'UNPAID'
      }
    });

    await prisma.ledgerEntry.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        type: 'INVOICE',
        debit: 2000.0,
        credit: 0.0,
        refType: 'INVOICE',
        refId: invBounce.id,
        date: new Date()
      }
    });

    // 2. Record Cheque Collection of ₹2,000 allocated to invBounce
    const collection = await createCollectionTransaction({
      dealerId: testDealer.id,
      retailerId: testRetailer.id,
      mode: 'CHEQUE',
      amount: 2000.0,
      reference: 'CHQ-888999',
      bankName: 'State Bank of India',
      collectedBy: 'Sales Officer',
      allocations: [{ invoiceId: invBounce.id, amount: 2000.0 }],
      autoAllocateFifo: false,
      user: { email: ownerEmail }
    });

    assert.equal(collection.status, 'RECORDED');

    // Verify invoice is paid
    const invPaid = await prisma.invoice.findUnique({ where: { id: invBounce.id } });
    assert.equal(invPaid.paidAmount, 2000.0);
    assert.equal(invPaid.paymentStatus, 'PAID');

    // 3. Mark Cheque as Bounced via HTTP POST
    const bounceRes = await fetch(`${baseUrl}/api/billing/collections/${collection.id}/bounce`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-email': ownerEmail,
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        reason: 'Signature mismatch on cheque',
        bounceCharge: 500.0
      })
    });

    assert.equal(bounceRes.status, 200);
    const bouncedCollection = await bounceRes.json();
    assert.equal(bouncedCollection.status, 'BOUNCED');
    assert.equal(bouncedCollection.bounceCharge, 500.0);

    // 4. Verify Invoice is reopened
    const invReopened = await prisma.invoice.findUnique({ where: { id: invBounce.id } });
    assert.equal(invReopened.paidAmount, 0.0);
    assert.equal(invReopened.paymentStatus, 'UNPAID');

    // 5. Verify Ledger Entries created:
    // One debit note for collection reversal (₹2,000)
    // One debit note for bounce charge (₹500)
    const bounceEntries = await prisma.ledgerEntry.findMany({
      where: {
        dealerId: testDealer.id,
        retailerId: testRetailer.id,
        OR: [
          { refId: collection.id },
          { refType: 'DEBIT_NOTE' }
        ]
      }
    });

    assert.equal(bounceEntries.length, 3); // 1 credit COLLECTION, 1 debit CHEQUE_BOUNCE, 1 debit DEBIT_NOTE
    const reversal = bounceEntries.find((e) => e.refType === 'CHEQUE_BOUNCE');
    assert.ok(reversal);
    assert.equal(reversal.debit, 2000.0);

    const penalty = bounceEntries.find((e) => e.refType === 'DEBIT_NOTE' || e.refType === 'BOUNCE_CHARGE');
    assert.ok(penalty);
    assert.equal(penalty.debit, 500.0);
  });

  await t.test('5. Outstanding overview and printable receipt endpoints', async () => {
    // A. Outstanding list
    const res = await fetch(`${baseUrl}/api/billing/outstanding`, {
      headers: {
        'x-user-email': ownerEmail,
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      }
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.ok(body.summary);
    assert.ok(Array.isArray(body.retailers));
    assert.ok(body.retailers.length >= 1);

    const foundRetailer = body.retailers.find((r) => r.id === testRetailer.id);
    assert.ok(foundRetailer);
    assert.ok(foundRetailer.currentOutstanding !== undefined);

    // B. Printable Receipt Data
    const collections = await prisma.collection.findMany({
      where: { dealerId: testDealer.id }
    });
    assert.ok(collections.length > 0);

    const receiptRes = await fetch(`${baseUrl}/api/billing/collections/${collections[0].id}/receipt`, {
      headers: {
        'x-user-email': ownerEmail,
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      }
    });

    assert.equal(receiptRes.status, 200);
    const receiptData = await receiptRes.json();
    assert.ok(receiptData.receiptNo);
    assert.ok(receiptData.amountInWords);
    assert.ok(receiptData.dealer);
    assert.ok(receiptData.retailer);
  });

  await t.test('6. Order credit check uses real ledger outstanding and blocks on overdue invoices', async () => {
    // Create Retailer dedicated for credit check test
    const creditRetailer = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Credit Limit Test Retailer ${runId}`,
        tradeName: 'Credit Limit Test',
        mobile: '9123456789',
        billingAddress: '456 Commercial Street, Mumbai',
        shippingAddress: '456 Commercial Street, Mumbai',
        stateCode: '27',
        creditLimit: 3000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    // 1. Initial outstanding is 0. Retailer can place order of 2 units (₹2,000) <= ₹3,000 creditLimit
    const order1 = await createDraftOrder({
      dealerId: testDealer.id,
      retailerId: creditRetailer.id,
      warehouseId: testWarehouse.id,
      items: [{ skuId: testSku.id, orderedQty: 2 }],
      user: { email: ownerEmail }
    });

    assert.equal(order1.totalAmount, 2000.0);
    assert.equal(order1.currentOutstanding, 0.0);
    assert.equal(order1.creditLimitExceeded, false);

    // 2. Simulate invoice issued for ₹2,500 on ledger
    await prisma.ledgerEntry.create({
      data: {
        dealerId: testDealer.id,
        retailerId: creditRetailer.id,
        type: 'INVOICE',
        debit: 2500.0,
        credit: 0.0,
        refType: 'INVOICE',
        refId: 'simulated-inv',
        date: new Date()
      }
    });

    // Real outstanding is now ₹2,500
    const currentBal = await getRetailerOutstanding(creditRetailer.id);
    assert.equal(currentBal, 2500.0);

    // Now submitting order1 (₹2,000) creates total exposure ₹2,500 + ₹2,000 = ₹4,500 > ₹3,000 creditLimit
    // Should move to PENDING_APPROVAL
    const submitResult = await submitOrder({
      orderId: order1.id,
      dealerId: testDealer.id,
      user: { email: ownerEmail }
    });

    assert.equal(submitResult.autoApproved, false);
    assert.equal(submitResult.order.status, 'PENDING_APPROVAL');
    assert.equal(submitResult.order.creditLimitExceeded, true);

    // 3. Test Overdue Invoices: Create an overdue invoice (45 days old)
    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - 45);

    const overdueInv = await prisma.invoice.create({
      data: {
        dealerId: testDealer.id,
        retailerId: creditRetailer.id,
        invoiceNo: `INV/${runId}/OVERDUE`,
        financialYear: '26-27',
        invoiceDate: pastDate,
        grossAmount: 1500.0,
        taxableTotal: 1500.0,
        taxTotal: 0.0,
        netTotal: 1500.0,
        orderIds: [],
        status: 'ISSUED',
        paidAmount: 0.0,
        paymentStatus: 'UNPAID'
      }
    });

    const overdueCheck = await checkRetailerOverdueInvoices(creditRetailer.id);
    assert.equal(overdueCheck.hasOverdue, true);
    assert.equal(overdueCheck.totalOverdueAmount, 1500.0);

    // Attempting to create new order draft is blocked!
    await assert.rejects(
      async () => {
        await createDraftOrder({
          dealerId: testDealer.id,
          retailerId: creditRetailer.id,
          warehouseId: testWarehouse.id,
          items: [{ skuId: testSku.id, orderedQty: 1 }],
          user: { email: ownerEmail }
        });
      },
      (err) => {
        assert.equal(err.code, 'RETAILER_OVERDUE_BLOCKED');
        return true;
      }
    );

    // 4. Pay the overdue invoice
    await createCollectionTransaction({
      dealerId: testDealer.id,
      retailerId: creditRetailer.id,
      mode: 'CASH',
      amount: 1500.0,
      collectedBy: 'Cashier',
      allocations: [{ invoiceId: overdueInv.id, amount: 1500.0 }],
      autoAllocateFifo: false,
      user: { email: ownerEmail }
    });

    // Overdue check is now clear!
    const overdueCheckCleared = await checkRetailerOverdueInvoices(creditRetailer.id);
    assert.equal(overdueCheckCleared.hasOverdue, false);

    // Creating draft order is now permitted!
    const unblockedOrder = await createDraftOrder({
      dealerId: testDealer.id,
      retailerId: creditRetailer.id,
      warehouseId: testWarehouse.id,
      items: [{ skuId: testSku.id, orderedQty: 1 }],
      user: { email: ownerEmail }
    });
    assert.ok(unblockedOrder.id);
  });
});
