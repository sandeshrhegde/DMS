import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';

test('Secondary Tax Invoicing, Stock Ledger Consumption & Reversals Suite', async (t) => {
  let server;
  let baseUrl;

  let testDealer;
  let testWarehouse;
  let testRetailerMH;
  let testRetailerKA;
  let testSku1;
  let testSku2;
  let testPriceList;
  let testPriceRule1;
  let testPriceRule2;

  const runId = Date.now();
  const dealerOwnerEmail = `owner_${runId}@demo.local`;

  t.before(async () => {
    await initializeDatabase();

    // 1. Create or fetch test dealer with maxHeaderDiscountPct = 10%
    testDealer = await prisma.dealer.create({
      data: {
        code: `DLR${String(runId).slice(-4)}`,
        name: `Invoicing Test Motors ${runId}`,
        stateCode: '27', // Maharashtra
        maxHeaderDiscountPct: 10.0,
        isActive: true
      }
    });

    // 2. Create test warehouse
    testWarehouse = await prisma.warehouse.create({
      data: {
        dealerId: testDealer.id,
        code: 'MAIN',
        name: 'Main Warehouse',
        isDefault: true,
        isActive: true
      }
    });

    // 3. Create HSN master for test
    await prisma.hsn.upsert({
      where: { code: '87082900' },
      update: { gstRate: 18.0 },
      create: {
        code: '87082900',
        description: 'Brake pads and friction materials',
        gstRate: 18.0
      }
    });

    await prisma.hsn.upsert({
      where: { code: '27101981' },
      update: { gstRate: 28.0 },
      create: {
        code: '27101981',
        description: 'Automotive lubricants',
        gstRate: 28.0
      }
    });

    // 4. Create test SKUs
    testSku1 = await prisma.sku.create({
      data: {
        code: `SKU-INV1-${runId}`,
        name: 'Ceramic Brake Disc',
        brand: 'Brembo',
        category: 'Brakes',
        mrp: 3000.0,
        landingPrice: 1800.0,
        hsnCode: '87082900',
        barcode: `EAN-INV1-${runId}`,
        isActive: true
      }
    });

    testSku2 = await prisma.sku.create({
      data: {
        code: `SKU-INV2-${runId}`,
        name: 'Synthetic Transmission Fluid',
        brand: 'Castrol',
        category: 'Lubricants',
        mrp: 1200.0,
        landingPrice: 700.0,
        hsnCode: '27101981',
        barcode: `EAN-INV2-${runId}`,
        isActive: true
      }
    });

    // 5. Create Approved Price List and Rules
    testPriceList = await prisma.priceList.create({
      data: {
        name: `Invoice Test Price List ${runId}`,
        version: 1,
        status: 'APPROVED',
        validFrom: new Date(Date.now() - 86400000),
        validTo: new Date(Date.now() + 30 * 86400000),
        createdByEmail: 'admin1@brand.local',
        approvedByEmail: 'admin2@brand.local'
      }
    });

    testPriceRule1 = await prisma.priceRule.create({
      data: {
        priceListId: testPriceList.id,
        skuId: testSku1.id,
        targetType: 'NATIONAL',
        targetId: null,
        method: 'FIXED',
        value: 2400.0,
        validFrom: new Date(Date.now() - 86400000)
      }
    });

    testPriceRule2 = await prisma.priceRule.create({
      data: {
        priceListId: testPriceList.id,
        skuId: testSku2.id,
        targetType: 'NATIONAL',
        targetId: null,
        method: 'FIXED',
        value: 950.0,
        validFrom: new Date(Date.now() - 86400000)
      }
    });

    // 6. Create Test Retailers (Intra-state MH & Inter-state KA)
    testRetailerMH = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Apex Spares Intra ${runId}`,
        tradeName: 'Apex Spares',
        gstin: '27AABCU9603R1ZM',
        mobile: '9876543220',
        billingAddress: 'Bandra, Mumbai',
        shippingAddress: 'Bandra, Mumbai',
        stateCode: '27', // Intra-state
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 500000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    testRetailerKA = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Bangalore Motors Inter ${runId}`,
        tradeName: 'Bangalore Motors',
        gstin: '29AABCU9603R1ZN',
        mobile: '9876543221',
        billingAddress: 'Indiranagar, Bangalore',
        shippingAddress: 'Indiranagar, Bangalore',
        stateCode: '29', // Inter-state
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 500000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    // 7. Seed stock in warehouse (AVAILABLE: 100 units each)
    for (const sku of [testSku1, testSku2]) {
      await prisma.stockOnHand.upsert({
        where: {
          dealerId_warehouseId_skuId_batch_stockState: {
            dealerId: testDealer.id,
            warehouseId: testWarehouse.id,
            skuId: sku.id,
            batch: `B-INV-${runId}`,
            stockState: 'AVAILABLE'
          }
        },
        update: { qty: 100 },
        create: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: sku.id,
          batch: `B-INV-${runId}`,
          stockState: 'AVAILABLE',
          qty: 100
        }
      });
    }

    server = app.listen(0);
    await new Promise((resolve) => server.once('listening', resolve));
    const { port } = server.address();
    baseUrl = `http://127.0.0.1:${port}`;
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  // -------------------------------------------------------------
  // TEST 1: Create Approved Order and Check Billing Preview
  // -------------------------------------------------------------
  let testOrder1;
  await t.test('1. Create Approved Order with reserved stock and preview billing calculation', async () => {
    // a) Create Draft Order
    const createRes = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        warehouseId: testWarehouse.id,
        items: [
          { skuId: testSku1.id, orderedQty: 10 }, // 10 * 2400 = 24,000
          { skuId: testSku2.id, orderedQty: 20 }  // 20 * 950 = 19,000 -> Gross 43,000
        ]
      })
    });

    assert.equal(createRes.status, 201);
    const orderData = await createRes.json();

    // b) Submit Order -> Auto-approves and reserves 10 and 20 units
    const submitRes = await fetch(`${baseUrl}/api/orders/${orderData.id}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      }
    });
    assert.equal(submitRes.status, 200);
    const submitData = await submitRes.json();
    assert.equal(submitData.order.status, 'APPROVED');
    const resLine1 = submitData.order.lines.find((l) => l.skuId === testSku1.id);
    const resLine2 = submitData.order.lines.find((l) => l.skuId === testSku2.id);
    assert.equal(resLine1.reservedQty, 10);
    assert.equal(resLine2.reservedQty, 20);

    testOrder1 = submitData.order;

    // c) Call Preview Calculation Endpoint
    const calcRes = await fetch(`${baseUrl}/api/billing/calculate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        orderIds: [testOrder1.id],
        headerDiscountPct: 2.0 // 2% header discount
      })
    });

    assert.equal(calcRes.status, 200);
    const preview = await calcRes.json();
    assert.equal(preview.grossAmount, 43000.0);
    assert.equal(preview.headerDiscountAmount, 860.0); // 2% of 43,000
    assert.equal(preview.taxableTotal, 42140.0); // 43,000 - 860
    assert.equal(preview.isIntraState, true);
    assert.ok(preview.cgstTotal > 0);
    assert.ok(preview.sgstTotal > 0);
    assert.equal(preview.igstTotal, 0);
  });

  // -------------------------------------------------------------
  // TEST 2: Partial Billing (Reducing Qty) & Gapless Sequence Numbering
  // -------------------------------------------------------------
  let partialInvoiceId;
  let firstInvoiceNo;
  await t.test('2. Partial billing: reduces billed quantity, updates order status to PARTIALLY_BILLED, generates gapless sequence', async () => {
    const line1 = testOrder1.lines.find((l) => l.skuId === testSku1.id);
    const line2 = testOrder1.lines.find((l) => l.skuId === testSku2.id);

    // Bill only 6 of 10 for SKU1 and 10 of 20 for SKU2
    const invoiceRes = await fetch(`${baseUrl}/api/billing/invoices`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': dealerOwnerEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        orderIds: [testOrder1.id],
        billedItems: [
          { orderLineId: line1.id, qty: 6 },
          { orderLineId: line2.id, qty: 10 }
        ],
        headerDiscountPct: 0.0
      })
    });

    assert.equal(invoiceRes.status, 201);
    const invoice = await invoiceRes.json();
    partialInvoiceId = invoice.id;
    firstInvoiceNo = invoice.invoiceNo;

    // Verify Gapless Invoice Number Format: DLR.../26-27/000001
    assert.match(invoice.invoiceNo, new RegExp(`^${testDealer.code}/\\d{2}-\\d{2}/000001$`));
    assert.equal(invoice.status, 'ISSUED');

    // Verify Order Line quantities:
    // line1: ordered: 10, billed: 6, reserved: 4
    // line2: ordered: 20, billed: 10, reserved: 10
    const refreshedOrder = await prisma.order.findUnique({
      where: { id: testOrder1.id },
      include: { lines: true }
    });
    assert.equal(refreshedOrder.status, 'PARTIALLY_BILLED');
    const refLine1 = refreshedOrder.lines.find((l) => l.id === line1.id);
    const refLine2 = refreshedOrder.lines.find((l) => l.id === line2.id);
    assert.equal(refLine1.billedQty, 6);
    assert.equal(refLine1.reservedQty, 4);
    assert.equal(refLine2.billedQty, 10);
    assert.equal(refLine2.reservedQty, 10);

    // Verify StockOnHand:
    // RESERVED decremented by 6 for SKU1 and 10 for SKU2.
    // AVAILABLE untouched!
    const stockSku1 = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: testSku1.id,
          batch: `B-INV-${runId}`,
          stockState: 'RESERVED'
        }
      }
    });
    assert.equal(stockSku1.qty, 4); // 10 - 6 = 4

    // Verify Retailer Ledger: debit entry created for netTotal
    const debitEntry = await prisma.ledgerEntry.findFirst({
      where: {
        dealerId: testDealer.id,
        retailerId: testRetailerMH.id,
        refId: invoice.id,
        type: 'INVOICE'
      }
    });
    assert.ok(debitEntry);
    assert.equal(debitEntry.debit, invoice.netTotal);
    assert.equal(debitEntry.credit, 0.0);
  });

  // -------------------------------------------------------------
  // TEST 3: Subsequent Billing of Remaining Qty Updates Order to FULLY_BILLED
  // -------------------------------------------------------------
  await t.test('3. Subsequent billing of remaining quantity transitions order to FULLY_BILLED and increments sequence', async () => {
    const refreshedOrder = await prisma.order.findUnique({
      where: { id: testOrder1.id },
      include: { lines: true }
    });

    const line1 = refreshedOrder.lines.find((l) => l.skuId === testSku1.id);
    const line2 = refreshedOrder.lines.find((l) => l.skuId === testSku2.id);

    // Bill remaining 4 and 10 units
    const invoiceRes = await fetch(`${baseUrl}/api/billing/invoices`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': dealerOwnerEmail
      },
      body: JSON.stringify({
        retailerId: testRetailerMH.id,
        orderIds: [testOrder1.id],
        billedItems: [
          { orderLineId: line1.id, qty: 4 },
          { orderLineId: line2.id, qty: 10 }
        ]
      })
    });

    assert.equal(invoiceRes.status, 201);
    const invoice2 = await invoiceRes.json();

    // Verify sequence incremented to 000002!
    assert.match(invoice2.invoiceNo, new RegExp(`^${testDealer.code}/\\d{2}-\\d{2}/000002$`));

    // Order status should now be FULLY_BILLED
    const fullyBilledOrder = await prisma.order.findUnique({
      where: { id: testOrder1.id }
    });
    assert.equal(fullyBilledOrder.status, 'FULLY_BILLED');
  });

  // -------------------------------------------------------------
  // TEST 4: Same-Day Cancellation Reverses Stock, Ledger, and Order
  // -------------------------------------------------------------
  await t.test('4. Same-day cancellation reverses stock, ledger, and order quantities in one transaction', async () => {
    const cancelRes = await fetch(`${baseUrl}/api/billing/invoices/${partialInvoiceId}/cancel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': dealerOwnerEmail
      },
      body: JSON.stringify({
        reason: 'Customer cancelled delivery due to sudden shop closure'
      })
    });

    assert.equal(cancelRes.status, 200);
    const cancelResult = await cancelRes.json();
    assert.equal(cancelResult.invoice.status, 'CANCELLED');
    assert.equal(cancelResult.invoice.cancelledReason, 'Customer cancelled delivery due to sudden shop closure');

    // 1. Verify StockOnHand has restored the RESERVED quantity
    const restoredStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: testSku1.id,
          batch: `B-INV-${runId}`,
          stockState: 'RESERVED'
        }
      }
    });
    assert.equal(restoredStock.qty, 6); // Restored back +6!

    // 2. Verify Retailer Ledger has recorded CREDIT_NOTE reversal entry
    const creditEntry = await prisma.ledgerEntry.findFirst({
      where: {
        dealerId: testDealer.id,
        retailerId: testRetailerMH.id,
        refId: partialInvoiceId,
        type: 'CREDIT_NOTE'
      }
    });
    assert.ok(creditEntry);
    assert.equal(creditEntry.credit, cancelResult.invoice.netTotal);
    assert.equal(creditEntry.debit, 0.0);
  });

  // -------------------------------------------------------------
  // TEST 5: Inter-State Billing (100% IGST)
  // -------------------------------------------------------------
  await t.test('5. Inter-state billing applies 100% IGST and zero CGST/SGST', async () => {
    // Create and approve order for KA retailer
    const order = await prisma.order.create({
      data: {
        dealerId: testDealer.id,
        retailerId: testRetailerKA.id,
        warehouseId: testWarehouse.id,
        orderNo: `ORD-KA-${runId}`,
        financialYear: '2627',
        status: 'APPROVED',
        totalAmount: 24000.0,
        lines: {
          create: [
            {
              skuId: testSku1.id,
              orderedQty: 10,
              reservedQty: 10,
              unitPrice: 2400.0,
              lineValue: 24000.0
            }
          ]
        }
      },
      include: { lines: true }
    });

    // Seed reserved stock for KA order
    await prisma.stockOnHand.upsert({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: testSku1.id,
          batch: `B-KA-${runId}`,
          stockState: 'RESERVED'
        }
      },
      update: { qty: 10 },
      create: {
        dealerId: testDealer.id,
        warehouseId: testWarehouse.id,
        skuId: testSku1.id,
        batch: `B-KA-${runId}`,
        stockState: 'RESERVED',
        qty: 10
      }
    });

    const invRes = await fetch(`${baseUrl}/api/billing/invoices`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: testRetailerKA.id,
        orderIds: [order.id]
      })
    });

    assert.equal(invRes.status, 201);
    const invoice = await invRes.json();
    assert.equal(invoice.cgstTotal, 0.0);
    assert.equal(invoice.sgstTotal, 0.0);
    assert.ok(invoice.igstTotal > 0);
    assert.equal(invoice.igstTotal, invoice.taxTotal);
  });
});

