import test from 'node:test';
import assert from 'node:assert/strict';
import {
  resolvePrice,
  calculatePriceFromRule,
  validateGuardrails,
  matchesTarget,
  isRuleDateValid,
  PRECEDENCE_LEVELS
} from '../src/services/pricing-resolver.service.js';

test('Secondary Price Resolver & Guardrails Pure Unit Test Suite', async (t) => {
  const sampleSku = {
    id: 'sku-001',
    code: 'BRK-PAD-001',
    name: 'Ceramic Front Brake Pads (Set)',
    mrp: 1850.0,
    landingPrice: 1100.0
  };

  const sampleRetailer = {
    id: 'ret-001',
    legalName: 'Apex Auto Spares',
    retailerClass: 'A',
    channelType: 'MBO',
    stateCode: '27',
    clusterId: 'geo-cluster-001',
    cityId: 'geo-city-001',
    regionId: 'geo-region-001',
    stateId: 'geo-state-001',
    zoneId: 'geo-zone-001'
  };

  const basePriceList = {
    id: 'pl-001',
    name: 'National Standard Q4',
    version: 1,
    status: 'APPROVED',
    validFrom: new Date('2026-01-01T00:00:00Z'),
    validTo: new Date('2026-12-31T23:59:59Z')
  };

  await t.test('1. Precedence: Precedence order is strictly enforced at every level', async () => {
    // Construct rules at every single level from National down to Retailer
    const nationalRule = {
      id: 'rule-national',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      targetId: null,
      method: 'FIXED',
      value: 1500.0
    };

    const zoneRule = {
      id: 'rule-zone',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'ZONE',
      targetId: sampleRetailer.zoneId,
      method: 'FIXED',
      value: 1520.0
    };

    const stateRule = {
      id: 'rule-state',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'STATE',
      targetId: sampleRetailer.stateId,
      method: 'FIXED',
      value: 1540.0
    };

    const regionRule = {
      id: 'rule-region',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'REGION',
      targetId: sampleRetailer.regionId,
      method: 'FIXED',
      value: 1560.0
    };

    const cityRule = {
      id: 'rule-city',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'CITY',
      targetId: sampleRetailer.cityId,
      method: 'FIXED',
      value: 1580.0
    };

    const clusterRule = {
      id: 'rule-cluster',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'CLUSTER',
      targetId: sampleRetailer.clusterId,
      method: 'FIXED',
      value: 1600.0
    };

    const classRule = {
      id: 'rule-class',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'RETAILER_CLASS',
      targetId: sampleRetailer.retailerClass, // 'A'
      method: 'FIXED',
      value: 1620.0
    };

    const retailerRule = {
      id: 'rule-retailer',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'RETAILER',
      targetId: sampleRetailer.id,
      method: 'FIXED',
      value: 1650.0
    };

    const targetDate = new Date('2026-06-15T10:00:00Z');

    // Test a) National alone resolves to National
    const resNat = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule]
    });
    assert.equal(resNat.level, 'NATIONAL');
    assert.equal(resNat.ruleId, 'rule-national');
    assert.equal(resNat.price, 1500.0);

    // Test b) Zone beats National
    const resZone = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule]
    });
    assert.equal(resZone.level, 'ZONE');
    assert.equal(resZone.ruleId, 'rule-zone');
    assert.equal(resZone.price, 1520.0);

    // Test c) State beats Zone & National
    const resState = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule]
    });
    assert.equal(resState.level, 'STATE');
    assert.equal(resState.ruleId, 'rule-state');
    assert.equal(resState.price, 1540.0);

    // Test d) Region beats State
    const resRegion = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule, regionRule]
    });
    assert.equal(resRegion.level, 'REGION');
    assert.equal(resRegion.ruleId, 'rule-region');
    assert.equal(resRegion.price, 1560.0);

    // Test e) City beats Region
    const resCity = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule, regionRule, cityRule]
    });
    assert.equal(resCity.level, 'CITY');
    assert.equal(resCity.ruleId, 'rule-city');
    assert.equal(resCity.price, 1580.0);

    // Test f) Cluster beats City
    const resCluster = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule, regionRule, cityRule, clusterRule]
    });
    assert.equal(resCluster.level, 'CLUSTER');
    assert.equal(resCluster.ruleId, 'rule-cluster');
    assert.equal(resCluster.price, 1600.0);

    // Test g) Retailer Class beats Cluster
    const resClass = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule, regionRule, cityRule, clusterRule, classRule]
    });
    assert.equal(resClass.level, 'RETAILER_CLASS');
    assert.equal(resClass.ruleId, 'rule-class');
    assert.equal(resClass.price, 1620.0);

    // Test h) Retailer beats Retailer Class (and all other levels)
    const resRetailer = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: targetDate,
      rules: [nationalRule, zoneRule, stateRule, regionRule, cityRule, clusterRule, classRule, retailerRule]
    });
    assert.equal(resRetailer.level, 'RETAILER');
    assert.equal(resRetailer.ruleId, 'rule-retailer');
    assert.equal(resRetailer.price, 1650.0);
  });

  await t.test('2. Date validity: Rules only match within valid date windows', async () => {
    const expiredRule = {
      id: 'rule-expired',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      targetId: null,
      method: 'FIXED',
      value: 1400.0,
      validFrom: new Date('2025-01-01T00:00:00Z'),
      validTo: new Date('2025-12-31T23:59:59Z') // expired in 2025
    };

    const futureRule = {
      id: 'rule-future',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      targetId: null,
      method: 'FIXED',
      value: 1700.0,
      validFrom: new Date('2027-01-01T00:00:00Z'), // starts 2027
      validTo: new Date('2027-12-31T23:59:59Z')
    };

    const activeRule = {
      id: 'rule-active',
      priceListId: 'pl-001',
      priceList: basePriceList,
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      targetId: null,
      method: 'FIXED',
      value: 1550.0,
      validFrom: new Date('2026-01-01T00:00:00Z'),
      validTo: new Date('2026-12-31T23:59:59Z')
    };

    const queryDate = new Date('2026-05-10T00:00:00Z');

    const res = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: queryDate,
      rules: [expiredRule, futureRule, activeRule]
    });

    assert.equal(res.ruleId, 'rule-active');
    assert.equal(res.price, 1550.0);

    // If only expired rule is present, returns NO_PRICE
    const resExpiredOnly = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: queryDate,
      rules: [expiredRule]
    });
    assert.equal(resExpiredOnly.error, 'NO_PRICE');
  });

  await t.test('3. Pricing methods: Calculates prices correctly for FIXED, PERCENT_OFF_MRP, and MARKUP_ON_LANDING', async () => {
    // Sku MRP = 1850, landingPrice = 1100

    // a) FIXED method
    const fixedRule = {
      id: 'rf',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'FIXED',
      value: 1450.0,
      priceList: basePriceList
    };
    const resFixed = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: [fixedRule]
    });
    assert.equal(resFixed.price, 1450.0);

    // b) PERCENT_OFF_MRP method: 15% off MRP (1850 - 277.5 = 1572.5)
    const pctOffRule = {
      id: 'rp',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'PERCENT_OFF_MRP',
      value: 15.0, // 15% discount off MRP
      priceList: basePriceList
    };
    const resPct = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: [pctOffRule]
    });
    assert.equal(resPct.price, 1572.5);

    // c) MARKUP_ON_LANDING method: 25% markup on landing price (1100 * 1.25 = 1375.0)
    const markupRule = {
      id: 'rm',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'MARKUP_ON_LANDING',
      value: 25.0, // 25% markup on landing
      priceList: basePriceList
    };
    const resMarkup = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      landingPrice: 1100.0,
      rules: [markupRule]
    });
    assert.equal(resMarkup.price, 1375.0);
  });

  await t.test('4. Guardrail validation: Enforces price <= MRP and price >= landing price + minMarginPct', async () => {
    // Sku MRP = 1850, landingPrice = 1100, minMarginPct = 10%
    // minAllowedPrice = 1100 * 1.10 = 1210.0
    // maxAllowedPrice = 1850.0

    // a) Breach: Price exceeds MRP
    const breachOverMrp = validateGuardrails({
      method: 'FIXED',
      value: 1950.0, // exceeds 1850 MRP
      sku: sampleSku,
      landingPrice: 1100.0,
      minMarginPct: 10
    });
    assert.equal(breachOverMrp.valid, false);
    assert.equal(breachOverMrp.code, 'GUARDRAIL_EXCEEDS_MRP');
    assert.match(breachOverMrp.error, /exceeds SKU MRP/);

    // b) Breach: PERCENT_OFF_MRP with negative discount (would exceed MRP)
    const breachPctOver = validateGuardrails({
      method: 'PERCENT_OFF_MRP',
      value: -5.0, // -5% discount = 105% of MRP
      sku: sampleSku,
      landingPrice: 1100.0,
      minMarginPct: 10
    });
    assert.equal(breachPctOver.valid, false);
    assert.equal(breachPctOver.code, 'GUARDRAIL_EXCEEDS_MRP');

    // c) Breach: Price falls below landing price + minMarginPct
    const breachBelowMargin = validateGuardrails({
      method: 'FIXED',
      value: 1150.0, // below 1210 minimum required
      sku: sampleSku,
      landingPrice: 1100.0,
      minMarginPct: 10
    });
    assert.equal(breachBelowMargin.valid, false);
    assert.equal(breachBelowMargin.code, 'GUARDRAIL_BELOW_MIN_MARGIN');
    assert.match(breachBelowMargin.error, /minimum margin/);

    // d) Breach: MARKUP_ON_LANDING below minMarginPct
    const breachMarkupBelow = validateGuardrails({
      method: 'MARKUP_ON_LANDING',
      value: 5.0, // 5% markup is below configured 10% min margin
      sku: sampleSku,
      landingPrice: 1100.0,
      minMarginPct: 10
    });
    assert.equal(breachMarkupBelow.valid, false);
    assert.equal(breachMarkupBelow.code, 'GUARDRAIL_BELOW_MIN_MARGIN');

    // e) Valid: Price within [1210.0, 1850.0] passes cleanly
    const passValid = validateGuardrails({
      method: 'FIXED',
      value: 1450.0,
      sku: sampleSku,
      landingPrice: 1100.0,
      minMarginPct: 10
    });
    assert.equal(passValid.valid, true);
    assert.equal(passValid.calculatedPrice, 1450.0);
  });

  await t.test('5. No-rule case: Returns error code NO_PRICE when no rule applies', async () => {
    // Empty rule list
    const resEmpty = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: []
    });
    assert.equal(resEmpty.error, 'NO_PRICE');
    assert.equal(resEmpty.price, null);

    // Rule for another SKU
    const anotherSkuRule = {
      id: 'rule-other',
      skuId: 'sku-999-other',
      targetType: 'NATIONAL',
      method: 'FIXED',
      value: 1450.0,
      priceList: basePriceList
    };
    const resOtherSku = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: [anotherSkuRule]
    });
    assert.equal(resOtherSku.error, 'NO_PRICE');

    // Rule for non-approved price list
    const draftPriceListRule = {
      id: 'rule-draft',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'FIXED',
      value: 1450.0,
      priceList: {
        ...basePriceList,
        status: 'DRAFT'
      }
    };
    const resDraft = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: [draftPriceListRule]
    });
    assert.equal(resDraft.error, 'NO_PRICE');
  });

  await t.test('6. Tie-breaking & Versioning: Higher price list version wins at the same precedence level', async () => {
    const v1Rule = {
      id: 'rule-v1',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'FIXED',
      value: 1400.0,
      priceList: {
        ...basePriceList,
        version: 1
      }
    };

    const v2Rule = {
      id: 'rule-v2',
      skuId: sampleSku.id,
      targetType: 'NATIONAL',
      method: 'FIXED',
      value: 1480.0,
      priceList: {
        ...basePriceList,
        version: 2
      }
    };

    const res = resolvePrice({
      retailer: sampleRetailer,
      sku: sampleSku,
      date: new Date('2026-06-01'),
      rules: [v1Rule, v2Rule]
    });

    assert.equal(res.ruleId, 'rule-v2');
    assert.equal(res.price, 1480.0);
  });
});

