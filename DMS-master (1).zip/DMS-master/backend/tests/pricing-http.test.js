import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';

test('Pricing HTTP API & Maker-Checker Integration Suite', async (t) => {
  let server;
  let baseUrl;

  let testSku;
  let testRetailer;
  let clusterNode;

  const admin1Email = 'brand@dms.local';
  const admin2Email = 'brand2@dms.local';

  t.before(async () => {
    await initializeDatabase();

    // Fetch or create a test cluster node
    clusterNode = await prisma.geoNode.findFirst({ where: { type: 'CLUSTER' } });

    // Fetch or create a test SKU with MRP 1850 and landingPrice 1100
    testSku = await prisma.sku.findUnique({ where: { code: 'BRK-PAD-001' } });
    if (!testSku) {
      testSku = await prisma.sku.create({
        data: {
          code: 'BRK-PAD-001',
          name: 'Ceramic Front Brake Pads (Set)',
          brand: 'AutoPro',
          category: 'Braking',
          barcode: '8901234500018',
          mrp: 1850.0,
          landingPrice: 1100.0,
          isActive: true
        }
      });
    }

    // Ensure sample retailer exists
    const dealer = await prisma.dealer.findFirst({ where: { isActive: true } });
    testRetailer = await prisma.retailer.findFirst({
      where: { dealerId: dealer.id }
    });
    if (!testRetailer) {
      testRetailer = await prisma.retailer.create({
        data: {
          dealerId: dealer.id,
          legalName: 'Apex Motor Works',
          mobile: '9820098200',
          billingAddress: '42 Link Road, Mumbai',
          shippingAddress: '42 Link Road, Mumbai',
          stateCode: '27',
          geoNodeId: clusterNode?.id || null,
          retailerClass: 'A',
          channelType: 'MBO',
          status: 'APPROVED'
        }
      });
    }

    server = app.listen(0);
    await new Promise((resolve) => server.once('listening', resolve));
    const { port } = server.address();
    baseUrl = `http://127.0.0.1:${port}`;
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  let createdPriceListId;

  await t.test('1. Creator creates draft PriceList', async () => {
    const res = await fetch(`${baseUrl}/api/pricing/lists`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        name: 'Maharashtra Summer Price List 2026',
        version: 1,
        validFrom: '2026-01-01T00:00:00Z',
        validTo: '2026-12-31T23:59:59Z'
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.equal(body.name, 'Maharashtra Summer Price List 2026');
    assert.equal(body.status, 'DRAFT');
    assert.equal(body.createdByEmail, admin1Email);
    createdPriceListId = body.id;
  });

  await t.test('2. Guardrail validation at save time', async () => {
    // Sku MRP = 1850, landingPrice = 1100, minMargin = 10%
    // minPrice = 1100 * 1.10 = 1210.0, maxPrice = 1850.0

    // a) Price > MRP breach
    const resOver = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/rules`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        skuId: testSku.id,
        targetType: 'NATIONAL',
        method: 'FIXED',
        value: 1999.0 // exceeds 1850
      })
    });
    assert.equal(resOver.status, 400);
    const bodyOver = await resOver.json();
    assert.equal(bodyOver.code, 'GUARDRAIL_EXCEEDS_MRP');

    // b) Price < landing price + minMarginPct breach
    const resUnder = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/rules`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        skuId: testSku.id,
        targetType: 'NATIONAL',
        method: 'FIXED',
        value: 1150.0 // below 1210 minimum
      })
    });
    assert.equal(resUnder.status, 400);
    const bodyUnder = await resUnder.json();
    assert.equal(bodyUnder.code, 'GUARDRAIL_BELOW_MIN_MARGIN');

    // c) Valid rule (1550 INR) passes and saves
    const resValid = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/rules`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        skuId: testSku.id,
        targetType: 'NATIONAL',
        method: 'FIXED',
        value: 1550.0
      })
    });
    assert.equal(resValid.status, 201);
    const bodyValid = await resValid.json();
    assert.equal(bodyValid.rule.value, 1550.0);
  });

  await t.test('3. Maker-checker: Creator cannot approve their own price list', async () => {
    // a) Creator submits for approval
    const resSubmit = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/submit`, {
      method: 'POST',
      headers: {
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      }
    });
    assert.equal(resSubmit.status, 200);
    const bodySubmit = await resSubmit.json();
    assert.equal(bodySubmit.status, 'PENDING_APPROVAL');

    // b) Creator attempts to approve -> Rejected with 403 MAKER_CHECKER_VIOLATION
    const resSelfApprove = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/approve`, {
      method: 'POST',
      headers: {
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email // SAME as creator!
      }
    });
    assert.equal(resSelfApprove.status, 403);
    const bodySelf = await resSelfApprove.json();
    assert.equal(bodySelf.code, 'MAKER_CHECKER_VIOLATION');
    assert.match(bodySelf.error, /Maker–checker violation/);

    // c) Different admin (admin2) approves -> Succeeded!
    const resCheckerApprove = await fetch(`${baseUrl}/api/pricing/lists/${createdPriceListId}/approve`, {
      method: 'POST',
      headers: {
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin2Email // DIFFERENT admin!
      }
    });
    assert.equal(resCheckerApprove.status, 200);
    const bodyApproved = await resCheckerApprove.json();
    assert.equal(bodyApproved.priceList.status, 'APPROVED');
    assert.equal(bodyApproved.priceList.approvedByEmail, admin2Email);
  });

  await t.test('4. POST /pricing/resolve endpoint resolves secondary price preview', async () => {
    // Both /pricing/resolve and /api/pricing/resolve work
    const res = await fetch(`${baseUrl}/pricing/resolve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        retailerId: testRetailer.id,
        skuId: testSku.id,
        date: '2026-06-01T00:00:00Z'
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.status, 'RESOLVED');
    assert.equal(body.price, 1550.0);
    assert.equal(body.level, 'NATIONAL');
    assert.equal(body.guardrailCheck.valid, true);
  });

  await t.test('5. POST /pricing/resolve returns NO_PRICE when no rule matches', async () => {
    // Query for date in 2030 (outside validTo)
    const res = await fetch(`${baseUrl}/pricing/resolve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': admin1Email
      },
      body: JSON.stringify({
        retailerId: testRetailer.id,
        skuId: testSku.id,
        date: '2030-01-01T00:00:00Z'
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.status, 'NO_PRICE');
    assert.equal(body.error, 'NO_PRICE');
  });
});

