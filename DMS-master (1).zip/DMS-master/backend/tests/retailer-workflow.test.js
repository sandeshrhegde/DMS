import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';
import { createAccessToken } from '../src/auth/token.service.js';
import {
  validateGstin,
  validateMobile,
  calculateGstinChecksumChar
} from '../src/services/retailer-validation.service.js';

test('Retailer Proposal, Approval & RLS Workflow Suite', async (t) => {
  let server;
  let baseUrl;

  let dealer1;
  let dealer2;
  let clusterNode;

  let brandToken;
  let dealer1Token;
  let dealer2Token;

  const runId = Date.now();

  t.before(async () => {
    await initializeDatabase();

    // Ensure two test dealers
    dealer1 = await prisma.dealer.upsert({
      where: { code: 'DLR-TEST-001' },
      update: {},
      create: {
        code: 'DLR-TEST-001',
        name: 'Alpha Motors Mumbai',
        stateCode: '27',
        isActive: true
      }
    });

    dealer2 = await prisma.dealer.upsert({
      where: { code: 'DLR-TEST-002' },
      update: {},
      create: {
        code: 'DLR-TEST-002',
        name: 'Beta Motors Delhi',
        stateCode: '07',
        isActive: true
      }
    });

    // Ensure cluster node
    clusterNode = await prisma.geoNode.findFirst({
      where: { type: 'CLUSTER' }
    });

    brandToken = createAccessToken({
      id: 'test-brand-user',
      role: 'BRAND_ADMIN',
      email: 'brand@dms.local'
    });

    dealer1Token = createAccessToken({
      id: 'test-dealer-1-user',
      role: 'DEALER_OWNER',
      dealerId: dealer1.id,
      email: 'owner@alpha.local'
    });

    dealer2Token = createAccessToken({
      id: 'test-dealer-2-user',
      role: 'DEALER_OPERATOR',
      dealerId: dealer2.id,
      email: 'operator@beta.local'
    });

    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://localhost:${port}/api`;
        resolve();
      });
    });
  });

  t.after(async () => {
    await prisma.retailer.deleteMany({
      where: { legalName: { contains: 'Test' } }
    });
    await new Promise((resolve) => server.close(resolve));
  });

  // 1. Validation & Checksum
  await t.test('Validation: checks GSTIN regex, Luhn mod-36 checksum, and mobile format', async () => {
    // A. Valid GSTIN with correct checksum
    const prefix1 = '27AABCT3518Q1Z';
    const check1 = calculateGstinChecksumChar(prefix1);
    const validGstin = `${prefix1}${check1}`;
    const validRes = validateGstin(validGstin);
    assert.equal(validRes.valid, true);

    // B. Invalid checksum digit
    const wrongChar = check1 === '0' ? '1' : '0';
    const badChecksumGstin = `${prefix1}${wrongChar}`;
    const badCheckRes = validateGstin(badChecksumGstin);
    assert.equal(badCheckRes.valid, false);
    assert.match(badCheckRes.error, /checksum mismatch/i);

    // C. Invalid mobile format
    assert.equal(validateMobile('12345').valid, false);
    assert.equal(validateMobile('9820012345').valid, true);
    assert.equal(validateMobile('+91 98200 12345').valid, true);
  });

  // 2. Propose Retailer & Duplicate Check
  let retailer1Id;
  const testGstin = `27AABCU9603R1Z${calculateGstinChecksumChar('27AABCU9603R1Z')}`;
  const testMobile = `98200${String(runId).slice(-5)}`;

  await t.test('Dealer 1 proposes retailer with status PROPOSED (orders blocked)', async () => {
    const res = await fetch(`${baseUrl}/retailers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealer1Token}`
      },
      body: JSON.stringify({
        legalName: `Test Retailer Alpha ${runId}`,
        tradeName: 'Alpha Auto Spares',
        gstin: testGstin,
        mobile: testMobile,
        billingAddress: 'Shop 10, Main Market, Mumbai',
        shippingAddress: 'Shop 10, Main Market, Mumbai',
        stateCode: '27',
        geoNodeId: clusterNode?.id,
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 250000,
        creditDays: 30
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.equal(body.status, 'PROPOSED');
    assert.equal(body.canOrder, false, 'Proposed retailer must NOT be eligible for orders');
    assert.equal(body.dealerId, dealer1.id);
    retailer1Id = body.id;

    // Check order check endpoint
    const canOrderRes = await fetch(`${baseUrl}/retailers/${retailer1Id}/can-order`, {
      headers: { Authorization: `Bearer ${dealer1Token}` }
    });
    const orderCheck = await canOrderRes.json();
    assert.equal(orderCheck.canOrder, false);
  });

  // 3. Cross-Dealer Duplicate Warning
  await t.test('Dealer 2 proposes retailer with same GSTIN/Mobile; duplicate flagged as warning', async () => {
    const res = await fetch(`${baseUrl}/retailers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealer2Token}`
      },
      body: JSON.stringify({
        legalName: `Test Retailer Beta Duplicate ${runId}`,
        gstin: testGstin, // Same GSTIN as retailer 1!
        mobile: testMobile, // Same Mobile as retailer 1!
        billingAddress: 'Shop 5, Chandni Chowk, Delhi',
        shippingAddress: 'Shop 5, Chandni Chowk, Delhi',
        stateCode: '07'
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.ok(Array.isArray(body.duplicateWarnings));
    assert.ok(body.duplicateWarnings.length >= 1, 'Must return duplicate warning for approver');
    const gstinWarning = body.duplicateWarnings.find((w) => w.field === 'gstin');
    assert.ok(gstinWarning);
    assert.equal(gstinWarning.matchedRetailerId, retailer1Id);
    assert.equal(gstinWarning.dealerCode, dealer1.code);
  });

  // 4. Brand Approval Workflow
  await t.test('Brand Admin approves Retailer 1; becomes APPROVED and order-eligible', async () => {
    const approveRes = await fetch(`${baseUrl}/retailers/${retailer1Id}/approve`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${brandToken}` }
    });

    assert.equal(approveRes.status, 200);
    const approved = await approveRes.json();
    assert.equal(approved.status, 'APPROVED');
    assert.equal(approved.canOrder, true);

    // Verify order eligibility
    const orderCheckRes = await fetch(`${baseUrl}/retailers/${retailer1Id}/can-order`, {
      headers: { Authorization: `Bearer ${dealer1Token}` }
    });
    const orderCheck = await orderCheckRes.json();
    assert.equal(orderCheck.canOrder, true);
  });

  // 5. Change Request on Approved Retailer
  await t.test('Dealer changes creditLimit on APPROVED retailer; creates pending re-approval request', async () => {
    // Current approved creditLimit is 250000. Dealer tries to change to 500000.
    const editRes = await fetch(`${baseUrl}/retailers/${retailer1Id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealer1Token}`
      },
      body: JSON.stringify({
        creditLimit: 500000,
        tradeName: 'Alpha Super Spares Updated'
      })
    });

    assert.equal(editRes.status, 200);
    const body = await editRes.json();
    assert.equal(body.creditLimit, 250000, 'Live approved creditLimit MUST remain old value until approved');
    assert.equal(body.tradeName, 'Alpha Super Spares Updated', 'Non-sensitive field updates immediately');
    assert.equal(body.hasPendingChanges, true);
    assert.equal(body.pendingChanges.creditLimit, 500000);

    // Brand checks pending approvals queue
    const queueRes = await fetch(`${baseUrl}/retailers/pending-approvals`, {
      headers: { Authorization: `Bearer ${brandToken}` }
    });
    assert.equal(queueRes.status, 200);
    const queue = await queueRes.json();
    const itemInQueue = queue.pendingChangesRetailers.find((r) => r.id === retailer1Id);
    assert.ok(itemInQueue, 'Retailer with pending change request must appear in Brand queue');
    assert.equal(itemInQueue.pendingChangeRequest.changes.creditLimit, 500000);

    // Brand approves change request
    const changeId = itemInQueue.pendingChangeRequest.id;
    const approveChangeRes = await fetch(`${baseUrl}/retailers/${retailer1Id}/changes/${changeId}/approve`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${brandToken}` }
    });
    assert.equal(approveChangeRes.status, 200);

    // Verify live retailer has now updated
    const liveRes = await fetch(`${baseUrl}/retailers/${retailer1Id}`, {
      headers: { Authorization: `Bearer ${dealer1Token}` }
    });
    const liveRetailer = await liveRes.json();
    assert.equal(liveRetailer.creditLimit, 500000, 'Credit limit is updated once approved');
    assert.equal(liveRetailer.hasPendingChanges, false);
  });

  // 6. Dealer Tenant Isolation (RLS Scoping)
  await t.test('Dealer tenant isolation: Dealer 2 cannot see or edit Dealer 1 retailer', async () => {
    // A. Dealer 2 lists retailers -> retailer1 (Dealer 1) must NOT be present
    const listRes = await fetch(`${baseUrl}/retailers`, {
      headers: { Authorization: `Bearer ${dealer2Token}` }
    });
    assert.equal(listRes.status, 200);
    const { retailers } = await listRes.json();
    assert.equal(retailers.some((r) => r.id === retailer1Id), false, 'Dealer 2 must not see Dealer 1 retailer in list');

    // B. Dealer 2 directly GETs retailer 1 by ID -> 403 Forbidden
    const getRes = await fetch(`${baseUrl}/retailers/${retailer1Id}`, {
      headers: { Authorization: `Bearer ${dealer2Token}` }
    });
    assert.equal(getRes.status, 403);

    // C. Dealer 2 attempts to edit retailer 1 -> 403 Forbidden
    const editRes = await fetch(`${baseUrl}/retailers/${retailer1Id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealer2Token}`
      },
      body: JSON.stringify({ legalName: 'Hijacked Retailer' })
    });
    assert.equal(editRes.status, 403);
  });

  // 7. Audit Trail
  await t.test('Audit trail: stores complete timeline of who/when/what changed', async () => {
    const auditRes = await fetch(`${baseUrl}/retailers/${retailer1Id}/audit`, {
      headers: { Authorization: `Bearer ${brandToken}` }
    });
    assert.equal(auditRes.status, 200);
    const { logs } = await auditRes.json();
    assert.ok(Array.isArray(logs));
    assert.ok(logs.length >= 3);

    const actions = logs.map((l) => l.action);
    assert.ok(actions.includes('PROPOSED'));
    assert.ok(actions.includes('APPROVED'));
    assert.ok(actions.includes('CHANGE_PROPOSED'));
    assert.ok(actions.includes('CHANGE_APPROVED'));
  });
});

