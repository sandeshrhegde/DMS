import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';

test('Secondary Orders & Stock Reservation Workflow Suite', async (t) => {
  let server;
  let baseUrl;

  let testDealer;
  let testWarehouse;
  let approvedRetailer;
  let proposedRetailer;
  let lowCreditRetailer;

  let billablePricedSku;
  let billableUnpricedSku;
  let nonBillableSku;

  let approvedPriceList;
  let priceRule;

  const runId = Date.now();
  const brandEmail = 'brand@dms.local';
  const dealerOwnerEmail = 'owner@demo.local';
  const salesmanEmail = 'sales@demo.local';

  t.before(async () => {
    await initializeDatabase();

    // 1. Get or create test dealer
    testDealer = await prisma.dealer.findFirst({ where: { isActive: true } });
    if (!testDealer) {
      testDealer = await prisma.dealer.create({
        data: {
          code: `DLR-ORD-${runId}`,
          name: 'Order Test Dealership',
          stateCode: '27',
          isActive: true
        }
      });
    }

    // 2. Ensure test warehouse exists
    testWarehouse = await prisma.warehouse.findFirst({
      where: { dealerId: testDealer.id, isDefault: true }
    });
    if (!testWarehouse) {
      testWarehouse = await prisma.warehouse.create({
        data: {
          dealerId: testDealer.id,
          code: `WH-ORD-${runId}`,
          name: 'Order Test Warehouse',
          isDefault: true,
          isActive: true
        }
      });
    }

    // 3. Create test SKUs
    // a) Billable SKU with approved price
    billablePricedSku = await prisma.sku.create({
      data: {
        code: `SKU-PRICED-${runId}`,
        name: 'High Performance Ceramic Brake Pad',
        brand: 'Brembo',
        category: 'Brakes',
        mrp: 2000.0,
        landingPrice: 1200.0,
        hsnCode: '87082900',
        barcode: `EAN-PRICED-${runId}`,
        isActive: true
      }
    });

    // b) Billable SKU without any approved price
    billableUnpricedSku = await prisma.sku.create({
      data: {
        code: `SKU-UNPRICED-${runId}`,
        name: 'Synthetic Engine Oil 5W-40',
        brand: 'Mobil',
        category: 'Lubricants',
        mrp: 1500.0,
        landingPrice: 900.0,
        hsnCode: '27101981',
        barcode: `EAN-UNPRICED-${runId}`,
        isActive: true
      }
    });

    // c) Non-billable SKU (missing MRP / HSN)
    nonBillableSku = await prisma.sku.create({
      data: {
        code: `SKU-NONBILL-${runId}`,
        name: 'Prototype Air Filter Draft',
        brand: 'K&N',
        category: 'Filters',
        mrp: null, // missing MRP makes it unbillable!
        landingPrice: 500.0,
        hsnCode: null,
        barcode: `EAN-NONBILL-${runId}`,
        isActive: true
      }
    });

    // 4. Create Approved Price List and Price Rule for billablePricedSku
    approvedPriceList = await prisma.priceList.create({
      data: {
        name: `National Secondary Price List ${runId}`,
        version: 1,
        status: 'APPROVED',
        validFrom: new Date(Date.now() - 86400000), // yesterday
        validTo: new Date(Date.now() + 30 * 86400000), // +30 days
        createdByEmail: 'admin1@brand.local',
        approvedByEmail: 'admin2@brand.local',
        approvedAt: new Date()
      }
    });

    priceRule = await prisma.priceRule.create({
      data: {
        priceListId: approvedPriceList.id,
        skuId: billablePricedSku.id,
        targetType: 'NATIONAL',
        targetId: null,
        method: 'FIXED',
        value: 1600.0, // Fixed secondary price
        validFrom: new Date(Date.now() - 86400000)
      }
    });

    // 5. Create Test Retailers
    // a) Approved retailer with high credit limit (₹100,000)
    approvedRetailer = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Metro Auto Spares ${runId}`,
        tradeName: 'Metro Spares',
        gstin: '27AABCU9603R1ZM',
        mobile: '9876543210',
        billingAddress: '123 MG Road, Mumbai',
        shippingAddress: '123 MG Road, Mumbai',
        stateCode: '27',
        retailerClass: 'A',
        channelType: 'MBO',
        creditLimit: 100000.0,
        creditDays: 30,
        status: 'APPROVED'
      }
    });

    // b) Proposed retailer (not yet approved)
    proposedRetailer = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Apex Retail Draft ${runId}`,
        tradeName: 'Apex Retail',
        gstin: '27AABCU9603R2ZN',
        mobile: '9876543211',
        billingAddress: '456 Link Road, Mumbai',
        shippingAddress: '456 Link Road, Mumbai',
        stateCode: '27',
        retailerClass: 'B',
        channelType: 'MBO',
        creditLimit: 50000.0,
        creditDays: 15,
        status: 'PROPOSED'
      }
    });

    // c) Approved retailer with low credit limit (₹2,000) to trigger credit block
    lowCreditRetailer = await prisma.retailer.create({
      data: {
        dealerId: testDealer.id,
        legalName: `Speedy Spares Tight Credit ${runId}`,
        tradeName: 'Speedy Spares',
        gstin: '27AABCU9603R3ZO',
        mobile: '9876543212',
        billingAddress: '789 SV Road, Mumbai',
        shippingAddress: '789 SV Road, Mumbai',
        stateCode: '27',
        retailerClass: 'C',
        channelType: 'MBO',
        creditLimit: 2000.0,
        creditDays: 7,
        status: 'APPROVED'
      }
    });

    // 6. Seed Initial Stock in Warehouse for billablePricedSku (20 units AVAILABLE in batch B1)
    await prisma.stockLedger.create({
      data: {
        dealerId: testDealer.id,
        warehouseId: testWarehouse.id,
        skuId: billablePricedSku.id,
        batch: `BATCH-ORD-${runId}`,
        stockState: 'AVAILABLE',
        qtyChange: 20,
        sourceType: 'TEST_SEED',
        sourceId: `SEED-${runId}`,
        createdByEmail: 'seed@test.local'
      }
    });

    await prisma.stockOnHand.upsert({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'AVAILABLE'
        }
      },
      update: { qty: 20 },
      create: {
        dealerId: testDealer.id,
        warehouseId: testWarehouse.id,
        skuId: billablePricedSku.id,
        batch: `BATCH-ORD-${runId}`,
        stockState: 'AVAILABLE',
        qty: 20
      }
    });

    // Start server
    server = app.listen(0);
    await new Promise((resolve) => server.once('listening', resolve));
    const { port } = server.address();
    baseUrl = `http://127.0.0.1:${port}`;
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  // -------------------------------------------------------------
  // TEST 1: Pricing preview & validation checks
  // -------------------------------------------------------------
  await t.test('1. Pricing preview endpoint resolves unit price and available stock', async () => {
    const res = await fetch(`${baseUrl}/api/orders/calculate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: approvedRetailer.id,
        warehouseId: testWarehouse.id,
        items: [
          { skuId: billablePricedSku.id, orderedQty: 5 }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.success, true);
    assert.equal(body.lines.length, 1);
    assert.equal(body.lines[0].unitPrice, 1600.0);
    assert.equal(body.lines[0].lineValue, 8000.0);
    assert.equal(body.lines[0].pricingLevel, 'NATIONAL');
    assert.equal(body.lines[0].availableStock, 20);
    assert.equal(body.totalAmount, 8000.0);
    assert.equal(body.creditLimitExceeded, false);
  });

  // -------------------------------------------------------------
  // TEST 2: Block orders for non-approved retailer
  // -------------------------------------------------------------
  await t.test('2. Blocks order creation for non-approved retailer (PROPOSED status)', async () => {
    const res = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: proposedRetailer.id,
        items: [{ skuId: billablePricedSku.id, orderedQty: 2 }]
      })
    });

    assert.equal(res.status, 400);
    const body = await res.json();
    assert.equal(body.code, 'RETAILER_NOT_APPROVED');
    assert.match(body.error, /Only APPROVED retailers can place secondary orders/i);
  });

  // -------------------------------------------------------------
  // TEST 3: Block SKU without approved price
  // -------------------------------------------------------------
  await t.test('3. Blocks line if SKU has no approved price rule (NO_PRICE)', async () => {
    const res = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: approvedRetailer.id,
        items: [{ skuId: billableUnpricedSku.id, orderedQty: 1 }]
      })
    });

    assert.equal(res.status, 400);
    const body = await res.json();
    assert.equal(body.code, 'NO_PRICE');
    assert.match(body.error, /No approved price rule found/i);
  });

  // -------------------------------------------------------------
  // TEST 4: Block non-billable SKU (missing MRP or HSN)
  // -------------------------------------------------------------
  await t.test('4. Blocks line if SKU is non-billable (missing MRP/HSN)', async () => {
    const res = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: approvedRetailer.id,
        items: [{ skuId: nonBillableSku.id, orderedQty: 1 }]
      })
    });

    assert.equal(res.status, 400);
    const body = await res.json();
    assert.equal(body.code, 'NON_BILLABLE_SKU');
    assert.match(body.error, /not billable/i);
  });

  // -------------------------------------------------------------
  // TEST 5: Create draft order, update draft, and submit with auto-approval
  // -------------------------------------------------------------
  let autoApprovedOrderId;
  await t.test('5. Create draft order and submit: auto-approves and reserves stock when credit check passes', async () => {
    // a) Create Draft Order
    const createRes = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: approvedRetailer.id,
        warehouseId: testWarehouse.id,
        notes: 'Urgent stock for festival weekend',
        items: [{ skuId: billablePricedSku.id, orderedQty: 6 }]
      })
    });

    assert.equal(createRes.status, 201);
    const createdOrder = await createRes.json();
    assert.equal(createdOrder.status, 'DRAFT');
    assert.match(createdOrder.orderNo, /^ORD-\d{4}-\d{4}$/);
    assert.equal(createdOrder.totalAmount, 9600.0); // 6 * 1600
    assert.equal(createdOrder.lines[0].orderedQty, 6);
    assert.equal(createdOrder.lines[0].reservedQty, 0);

    autoApprovedOrderId = createdOrder.id;

    // b) Submit Order
    const submitRes = await fetch(`${baseUrl}/api/orders/${autoApprovedOrderId}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': salesmanEmail
      }
    });

    assert.equal(submitRes.status, 200);
    const submitBody = await submitRes.json();
    assert.equal(submitBody.autoApproved, true);
    assert.equal(submitBody.order.status, 'APPROVED');

    // Check line reservation: all 6 units should be reserved, 0 shortfall
    const approvedLine = submitBody.order.lines[0];
    assert.equal(approvedLine.reservedQty, 6);
    assert.equal(approvedLine.shortfallQty, 0);

    // c) Verify StockOnHand summary: AVAILABLE decreased by 6 (20 -> 14), RESERVED increased to 6
    const availableStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(availableStock.qty, 14);

    const reservedStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'RESERVED'
        }
      }
    });
    assert.equal(reservedStock.qty, 6);

    // d) Verify append-only StockLedger records
    const ledgerEntries = await prisma.stockLedger.findMany({
      where: {
        dealerId: testDealer.id,
        sourceType: 'ORDER_RESERVE',
        sourceId: submitBody.order.orderNo
      }
    });
    assert.equal(ledgerEntries.length, 2);
    const deductAvailable = ledgerEntries.find((e) => e.stockState === 'AVAILABLE');
    const addReserved = ledgerEntries.find((e) => e.stockState === 'RESERVED');
    assert.equal(deductAvailable.qtyChange, -6);
    assert.equal(addReserved.qtyChange, 6);
  });

  // -------------------------------------------------------------
  // TEST 6: Credit check breach sets PENDING_APPROVAL and Dealer Owner approves
  // -------------------------------------------------------------
  let creditBlockedOrderId;
  await t.test('6. Credit limit breach: moves to PENDING_APPROVAL, then Dealer Owner approves and reserves stock', async () => {
    // lowCreditRetailer has limit of ₹2,000.
    // Order of 2 units @ ₹1600 = ₹3,200 (> ₹2,000 limit)
    const createRes = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: lowCreditRetailer.id,
        warehouseId: testWarehouse.id,
        items: [{ skuId: billablePricedSku.id, orderedQty: 2 }]
      })
    });

    assert.equal(createRes.status, 201);
    const draft = await createRes.json();
    creditBlockedOrderId = draft.id;

    // Submit order -> should breach credit limit
    const submitRes = await fetch(`${baseUrl}/api/orders/${creditBlockedOrderId}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      }
    });

    assert.equal(submitRes.status, 200);
    const submitResult = await submitRes.json();
    assert.equal(submitResult.autoApproved, false);
    assert.equal(submitResult.order.status, 'PENDING_APPROVAL');
    assert.equal(submitResult.order.creditLimitExceeded, true);
    // In PENDING_APPROVAL, stock is NOT yet reserved
    assert.equal(submitResult.order.lines[0].reservedQty, 0);

    // Operator or salesman cannot approve (must be DEALER_OWNER or BRAND_ADMIN)
    const unauthorizedApproveRes = await fetch(`${baseUrl}/api/orders/${creditBlockedOrderId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': 'operator@test.local'
      }
    });
    assert.equal(unauthorizedApproveRes.status, 403);

    // Now Dealer Owner approves the credit-blocked order
    const approveRes = await fetch(`${baseUrl}/api/orders/${creditBlockedOrderId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id,
        'x-user-email': dealerOwnerEmail
      }
    });

    assert.equal(approveRes.status, 200);
    const approveResult = await approveRes.json();
    assert.equal(approveResult.order.status, 'APPROVED');
    assert.equal(approveResult.order.approvedByEmail, dealerOwnerEmail);
    assert.equal(approveResult.order.lines[0].reservedQty, 2);

    // Available stock decreased from 14 to 12
    const availableStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(availableStock.qty, 12);
  });

  // -------------------------------------------------------------
  // TEST 7: Shortfall (back-order) when stock is insufficient
  // -------------------------------------------------------------
  let shortfallOrderId;
  await t.test('7. Partial reservation and shortfall (back-order) when stock is insufficient', async () => {
    // Current available stock is 12 units.
    // Order 20 units -> Should reserve 12, shortfall 8!
    const createRes = await fetch(`${baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      },
      body: JSON.stringify({
        retailerId: approvedRetailer.id,
        warehouseId: testWarehouse.id,
        items: [{ skuId: billablePricedSku.id, orderedQty: 20 }]
      })
    });

    assert.equal(createRes.status, 201);
    const draft = await createRes.json();
    shortfallOrderId = draft.id;

    const submitRes = await fetch(`${baseUrl}/api/orders/${shortfallOrderId}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id
      }
    });

    assert.equal(submitRes.status, 200);
    const submitResult = await submitRes.json();
    assert.equal(submitResult.order.status, 'APPROVED');

    const line = submitResult.order.lines[0];
    assert.equal(line.orderedQty, 20);
    assert.equal(line.reservedQty, 12); // All remaining 12 available stock reserved
    assert.equal(line.shortfallQty, 8);  // Shortfall back-order of 8 units!

    // Available stock is now 0
    const availableStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(availableStock.qty, 0);
  });

  // -------------------------------------------------------------
  // TEST 8: Order cancellation releases reserved stock back to AVAILABLE
  // -------------------------------------------------------------
  await t.test('8. Order cancellation releases reserved stock back to AVAILABLE on ledger', async () => {
    // Cancel the shortfall order (which had 12 reserved units)
    const cancelRes = await fetch(`${baseUrl}/api/orders/${shortfallOrderId}/cancel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OPERATOR',
        'x-dealer-id': testDealer.id,
        'x-user-email': salesmanEmail
      },
      body: JSON.stringify({
        reason: 'Customer requested cancellation due to stock shortage'
      })
    });

    assert.equal(cancelRes.status, 200);
    const cancelBody = await cancelRes.json();
    assert.equal(cancelBody.order.status, 'CANCELLED');
    assert.equal(cancelBody.releasedStock, true);
    assert.equal(cancelBody.order.cancelledReason, 'Customer requested cancellation due to stock shortage');

    // Available stock should be restored back to 12
    const availableStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: testWarehouse.id,
          skuId: billablePricedSku.id,
          batch: `BATCH-ORD-${runId}`,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(availableStock.qty, 12);

    // Ledger should record ORDER_CANCEL_RELEASE entries
    const releaseLedgers = await prisma.stockLedger.findMany({
      where: {
        dealerId: testDealer.id,
        sourceType: 'ORDER_CANCEL_RELEASE',
        sourceId: cancelBody.order.orderNo
      }
    });
    assert.equal(releaseLedgers.length, 2);
    const releaseReserved = releaseLedgers.find((e) => e.stockState === 'RESERVED');
    const restoreAvailable = releaseLedgers.find((e) => e.stockState === 'AVAILABLE');
    assert.equal(releaseReserved.qtyChange, -12);
    assert.equal(restoreAvailable.qtyChange, 12);
  });

  // -------------------------------------------------------------
  // TEST 9: List orders and details endpoint
  // -------------------------------------------------------------
  await t.test('9. Order list and detail endpoints return expected status, filters, and items', async () => {
    const listRes = await fetch(`${baseUrl}/api/orders?dealerId=${testDealer.id}`, {
      headers: {
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': brandEmail
      }
    });

    assert.equal(listRes.status, 200);
    const listBody = await listRes.json();
    assert.ok(listBody.orders.length >= 3);
    assert.ok(listBody.totalCount >= 3);

    const detailRes = await fetch(`${baseUrl}/api/orders/${autoApprovedOrderId}`, {
      headers: {
        'x-user-role': 'DEALER_OWNER',
        'x-dealer-id': testDealer.id
      }
    });

    assert.equal(detailRes.status, 200);
    const detail = await detailRes.json();
    assert.equal(detail.id, autoApprovedOrderId);
    assert.equal(detail.retailer.id, approvedRetailer.id);
    assert.equal(detail.lines.length, 1);
    assert.equal(detail.lines[0].sku.id, billablePricedSku.id);
  });
});

