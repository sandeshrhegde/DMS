import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import path from 'path';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';
import { createAccessToken } from '../src/auth/token.service.js';
import { computeIsBillable } from '../src/masters/sku.routes.js';

test('Master Data Management API Suite', async (t) => {
  let server;
  let baseUrl;

  const brandToken = createAccessToken({
    id: 'test-brand-user',
    role: 'BRAND_ADMIN',
    email: 'brand@dms.local'
  });

  const dealerToken = createAccessToken({
    id: 'test-dealer-user',
    role: 'DEALER_OWNER',
    dealerId: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1',
    email: 'owner@demo.local'
  });

  const runId = Date.now();

  async function cleanTestData() {
    await prisma.sku.deleteMany({
      where: {
        OR: [
          { code: { startsWith: 'TEST-' } },
          { code: { in: ['GOOD-01', 'BAD-02', 'ATOMIC-01', 'ATOMIC-02'] } },
          { barcode: { startsWith: '89099' } }
        ]
      }
    });
    await prisma.geoNode.deleteMany({
      where: { name: { contains: 'Test' } }
    });
  }

  t.before(async () => {
    await initializeDatabase();
    await cleanTestData();

    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://localhost:${port}/api`;
        resolve();
      });
    });
  });

  t.after(async () => {
    await cleanTestData();
    await new Promise((resolve) => server.close(resolve));
  });

  // 1. Geography Hierarchy & Validation
  await t.test('Geography hierarchy: validates strict next-level hierarchy and builds tree', async () => {
    // A. Root node must be ZONE
    const badRootRes = await fetch(`${baseUrl}/geography`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({ name: `Invalid State Root ${runId}`, type: 'STATE' })
    });
    assert.equal(badRootRes.status, 400);
    const badRootBody = await badRootRes.json();
    assert.match(badRootBody.error, /Root geography node must be of type 'ZONE'/i);

    // B. Create valid ZONE
    const zoneRes = await fetch(`${baseUrl}/geography`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({ name: `South Zone Test ${runId}`, type: 'ZONE' })
    });
    assert.equal(zoneRes.status, 201);
    const zone = await zoneRes.json();
    assert.equal(zone.type, 'ZONE');
    assert.equal(zone.path, `/South Zone Test ${runId}`);

    // C. Child of ZONE must be STATE (try CITY -> should fail)
    const badChildRes = await fetch(`${baseUrl}/geography`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        name: `Bengaluru City ${runId}`,
        type: 'CITY',
        parentId: zone.id
      })
    });
    assert.equal(badChildRes.status, 400);
    const badChildBody = await badChildRes.json();
    assert.match(badChildBody.error, /Child of 'ZONE' must be 'STATE'/i);

    // D. Create valid STATE under ZONE
    const stateRes = await fetch(`${baseUrl}/geography`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        name: `Karnataka Test ${runId}`,
        type: 'STATE',
        parentId: zone.id
      })
    });
    assert.equal(stateRes.status, 201);
    const state = await stateRes.json();
    assert.equal(state.path, `/South Zone Test ${runId}/Karnataka Test ${runId}`);

    // E. Tree endpoint returns nested structure
    const treeRes = await fetch(`${baseUrl}/geography/tree`, {
      headers: { Authorization: `Bearer ${brandToken}` }
    });
    assert.equal(treeRes.status, 200);
    const { tree } = await treeRes.json();
    assert.ok(Array.isArray(tree));
    const foundZone = tree.find((n) => n.id === zone.id);
    assert.ok(foundZone);
    assert.ok(foundZone.children.some((c) => c.id === state.id));
  });

  // 2. HSN Master
  await t.test('HSN Master: validates 6 or 8 digits and prevents invalid codes', async () => {
    const invalidRes = await fetch(`${baseUrl}/hsn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({ code: '12345', description: 'Invalid HSN', gstRate: 18 })
    });
    assert.equal(invalidRes.status, 400);

    const validRes = await fetch(`${baseUrl}/hsn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        code: '87089900',
        description: 'Other parts of motor vehicles test',
        gstRate: 28
      })
    });
    assert.ok([201, 409].includes(validRes.status));
  });

  // 3. SKU Master and isBillable computed field
  await t.test('SKU Master: computes isBillable and blocks non-billable states', async () => {
    assert.equal(computeIsBillable({ isActive: true, hsnCode: '87083000', mrp: 500 }), true);
    assert.equal(computeIsBillable({ isActive: false, hsnCode: '87083000', mrp: 500 }), false);
    assert.equal(computeIsBillable({ isActive: true, hsnCode: null, mrp: 500 }), false);
    assert.equal(computeIsBillable({ isActive: true, hsnCode: '87083000', mrp: null }), false);
    assert.equal(computeIsBillable({ isActive: true, hsnCode: '87083000', mrp: 0 }), false);

    const nonBillableRes = await fetch(`${baseUrl}/skus`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        code: `TEST-NO-MRP-${runId}`,
        name: 'Unpriced Prototype Part',
        brand: 'TestBrand',
        category: 'Prototypes',
        barcode: `89099${String(runId).slice(-7)}1`,
        hsnCode: '87083000'
      })
    });
    assert.equal(nonBillableRes.status, 201);
    const nonBillableSku = await nonBillableRes.json();
    assert.equal(nonBillableSku.isBillable, false);

    const billableRes = await fetch(`${baseUrl}/skus`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        code: `TEST-BILLABLE-${runId}`,
        name: 'Commercial Brake Pad Set',
        brand: 'AutoPro Genuine',
        category: 'Braking',
        barcode: `89099${String(runId).slice(-7)}2`,
        hsnCode: '87083000',
        mrp: 1450.0,
        isActive: true
      })
    });
    assert.equal(billableRes.status, 201);
    const billableSku = await billableRes.json();
    assert.equal(billableSku.isBillable, true);
  });

  // 4. CSV Bulk Import with 100+ SKUs and error reporting
  await t.test('CSV import: imports 100+ SKUs, tests all-or-nothing rollback and skip-bad-rows', async () => {
    const sampleSkuCsv = fs.readFileSync(path.resolve('samples', 'sample_skus.csv'), 'utf8');

    const importRes = await fetch(`${baseUrl}/skus/import-csv`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        csvText: sampleSkuCsv,
        mode: 'skip-bad-rows'
      })
    });
    assert.equal(importRes.status, 200);
    const importReport = await importRes.json();
    assert.ok(importReport.totalRows >= 100);
    assert.ok(importReport.createdCount + importReport.updatedCount >= 100);

    const atomicBadCsv = `code,name,brand,category,article,size,colour,uom,mrp,hsnCode,barcode,isActive
"ATOMIC-01","Atomic Valid Item","Brand","Cat","","","","PCS",100,"87082900","890990000001",true
"ATOMIC-02","","Brand","Cat","","","","PCS",-50,"invalid_hsn","",true`;

    const atomicFailRes = await fetch(`${baseUrl}/skus/import-csv`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        csvText: atomicBadCsv,
        mode: 'all-or-nothing'
      })
    });
    assert.equal(atomicFailRes.status, 422);
    const atomicReport = await atomicFailRes.json();
    assert.equal(atomicReport.success, false);
    assert.equal(atomicReport.createdCount, 0);
    assert.equal(atomicReport.rejectedCount, 1);

    const checkAtomic = await prisma.sku.findUnique({ where: { code: 'ATOMIC-01' } });
    assert.equal(checkAtomic, null, 'Must rollback on all-or-nothing failure');

    const skipBadRes = await fetch(`${baseUrl}/skus/import-csv`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        csvText: atomicBadCsv,
        mode: 'skip-bad-rows'
      })
    });
    assert.equal(skipBadRes.status, 200);
    const skipReport = await skipBadRes.json();
    assert.equal(skipReport.createdCount, 1);
    assert.equal(skipReport.rejectedCount, 1);
  });

  // 5. Extended Dealer Master & CSV Import
  await t.test('Dealer Master: extended fields and CSV import report', async () => {
    const sampleDealerCsv = fs.readFileSync(path.resolve('samples', 'sample_dealers.csv'), 'utf8');

    const importRes = await fetch(`${baseUrl}/dealers/import-csv`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${brandToken}`
      },
      body: JSON.stringify({
        csvText: sampleDealerCsv,
        mode: 'skip-bad-rows'
      })
    });
    assert.equal(importRes.status, 200);
    const report = await importRes.json();
    assert.ok(report.totalRows >= 5);

    const dealer = await prisma.dealer.findUnique({ where: { code: 'DLR-MUM-001' } });
    assert.ok(dealer);
    assert.equal(dealer.creditDays, 30);
    assert.equal(dealer.eInvoiceEnabled, true);
    assert.equal(dealer.contactName, 'Anil Sharma');
  });

  // 6. Role Authorization: Dealers get read-only access to SKUs and geography, writes blocked
  await t.test('Role Authorization: dealers can read SKUs and Geography, but writes are 403 Forbidden', async () => {
    const readSkusRes = await fetch(`${baseUrl}/skus`, {
      headers: { Authorization: `Bearer ${dealerToken}` }
    });
    assert.equal(readSkusRes.status, 200);
    const skuList = await readSkusRes.json();
    assert.ok(Array.isArray(skuList.items));
    assert.ok(skuList.items.length > 0);

    const readGeoRes = await fetch(`${baseUrl}/geography/tree`, {
      headers: { Authorization: `Bearer ${dealerToken}` }
    });
    assert.equal(readGeoRes.status, 200);

    const writeSkuRes = await fetch(`${baseUrl}/skus`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealerToken}`
      },
      body: JSON.stringify({
        code: 'DEALER-HACK',
        name: 'Unauthorized Part',
        barcode: '890000000000'
      })
    });
    assert.equal(writeSkuRes.status, 403);
    const writeErr = await writeSkuRes.json();
    assert.match(writeErr.error, /Brand Admin role required/i);

    const writeGeoRes = await fetch(`${baseUrl}/geography`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${dealerToken}`
      },
      body: JSON.stringify({ name: 'Unauthorized Zone', type: 'ZONE' })
    });
    assert.equal(writeGeoRes.status, 403);

    const dealerAccessRes = await fetch(`${baseUrl}/dealers`, {
      headers: { Authorization: `Bearer ${dealerToken}` }
    });
    assert.equal(dealerAccessRes.status, 403);
  });
});

