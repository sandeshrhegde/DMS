import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import { prisma, initializeDatabase } from '../src/config/database.js';

test('Inventory, GRN & Append-Only Stock Ledger Suite', async (t) => {
  let server;
  let baseUrl;

  let testDealer;
  let defaultWarehouse;
  let testSku1;
  let testSku2;

  const brandEmail = 'brand@dms.local';
  const dealerEmail = 'owner@demo.local';
  const runId = Date.now();

  t.before(async () => {
    await initializeDatabase();

    // 1. Get or create test dealer
    testDealer = await prisma.dealer.findFirst({ where: { isActive: true } });
    assert.ok(testDealer, 'A test dealer must exist');

    // 2. Ensure default warehouse exists
    defaultWarehouse = await prisma.warehouse.findFirst({
      where: { dealerId: testDealer.id, isDefault: true }
    });
    if (!defaultWarehouse) {
      defaultWarehouse = await prisma.warehouse.create({
        data: {
          dealerId: testDealer.id,
          code: 'MAIN',
          name: 'Main Dealership Warehouse',
          isDefault: true,
          isActive: true
        }
      });
    }

    // 3. Ensure SKUs
    testSku1 = await prisma.sku.findUnique({ where: { code: 'BRK-PAD-001' } });
    testSku2 = await prisma.sku.findUnique({ where: { code: 'OIL-SYN-5W30' } });

    server = app.listen(0);
    await new Promise((resolve) => server.once('listening', resolve));
    const { port } = server.address();
    baseUrl = `http://127.0.0.1:${port}`;
  });

  t.after(async () => {
    if (server) {
      await new Promise((resolve) => server.close(resolve));
    }
  });

  await t.test('1. Brand creates simulated primary dispatch ASN', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/asns`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': brandEmail
      },
      body: JSON.stringify({
        invoiceNo: `SAP-INV-${runId}-001`,
        invoiceDate: '2026-10-01T00:00:00Z',
        dealerId: testDealer.id,
        notes: 'Monthly replenishment shipment from Bhiwandi Mother Hub',
        lines: [
          { skuId: testSku1.id, invoicedQty: 50, batch: `B-${runId}-BRK-01`, landingPrice: 1100.0 },
          { skuId: testSku2.id, invoicedQty: 40, batch: `B-${runId}-OIL-01`, landingPrice: 420.0 }
        ]
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.equal(body.status, 'IN_TRANSIT');
    assert.equal(body.invoiceNo, `SAP-INV-${runId}-001`);
    assert.equal(body.lines.length, 2);
  });

  const fullBatch = `B-FULL-${runId}`;
  await t.test('2. GRN Full Receipt without variance: posts accepted qty to AVAILABLE, status RECEIVED', async () => {
    const asn = await prisma.asn.create({
      data: {
        invoiceNo: `SAP-INV-FULL-${runId}`,
        invoiceDate: new Date(),
        dealerId: testDealer.id,
        status: 'IN_TRANSIT',
        lines: {
          create: [
            { skuId: testSku1.id, invoicedQty: 50, batch: fullBatch, landingPrice: 1100.0 }
          ]
        }
      },
      include: { lines: true }
    });

    const asnLine = asn.lines[0];

    const res = await fetch(`${baseUrl}/api/inventory/asns/${asn.id}/grn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        lines: [
          {
            asnLineId: asnLine.id,
            receivedGoodQty: 50,
            shortQty: 0,
            excessQty: 0,
            damagedQty: 0
          }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.asn.status, 'RECEIVED');
    assert.ok(body.asn.grnNumber.startsWith('GRN-'));

    // Check ledger: +50 AVAILABLE
    const ledgerEntry = await prisma.stockLedger.findFirst({
      where: {
        dealerId: testDealer.id,
        skuId: testSku1.id,
        batch: fullBatch,
        sourceType: 'GRN_RECEIPT'
      }
    });
    assert.ok(ledgerEntry);
    assert.equal(ledgerEntry.qtyChange, 50);
    assert.equal(ledgerEntry.stockState, 'AVAILABLE');

    // Check StockOnHand: 50 AVAILABLE
    const onHand = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku1.id,
          batch: fullBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.ok(onHand);
    assert.equal(onHand.qty, 50);

    // No claims created
    const claims = await prisma.transitClaim.findMany({ where: { asnId: asn.id } });
    assert.equal(claims.length, 0);
  });

  const shortBatch = `B-SHORT-${runId}`;
  await t.test('3. GRN with SHORT variance: posts only accepted good qty, creates OPEN TransitClaim, short qty NOT in stock', async () => {
    const asn = await prisma.asn.create({
      data: {
        invoiceNo: `SAP-INV-SHORT-${runId}`,
        invoiceDate: new Date(),
        dealerId: testDealer.id,
        status: 'IN_TRANSIT',
        lines: {
          create: [
            { skuId: testSku1.id, invoicedQty: 40, batch: shortBatch, landingPrice: 1100.0 }
          ]
        }
      },
      include: { lines: true }
    });

    const asnLine = asn.lines[0];

    const res = await fetch(`${baseUrl}/api/inventory/asns/${asn.id}/grn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        lines: [
          {
            asnLineId: asnLine.id,
            receivedGoodQty: 35,
            shortQty: 5,
            excessQty: 0,
            damagedQty: 0,
            varianceReason: 'Carton seal was broken, 5 units missing'
          }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.asn.status, 'RECEIVED_WITH_VARIANCE');

    // Check StockLedger: ONLY +35 posted to AVAILABLE. 0 short posted.
    const ledgerEntries = await prisma.stockLedger.findMany({
      where: {
        dealerId: testDealer.id,
        batch: shortBatch
      }
    });
    assert.equal(ledgerEntries.length, 1);
    assert.equal(ledgerEntries[0].qtyChange, 35);
    assert.equal(ledgerEntries[0].stockState, 'AVAILABLE');

    // Check StockOnHand has 35
    const onHand = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku1.id,
          batch: shortBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(onHand.qty, 35);

    // TransitClaim for SHORT is created with status OPEN
    const claim = await prisma.transitClaim.findFirst({
      where: { asnId: asn.id, claimType: 'SHORT' }
    });
    assert.ok(claim);
    assert.equal(claim.qty, 5);
    assert.equal(claim.status, 'OPEN');
    assert.match(claim.reason, /Carton seal was broken/);
  });

  const excessBatch = `B-EXCESS-${runId}`;
  await t.test('4. GRN with EXCESS variance: posts accepted good qty up to invoiced, excess NOT in stock, creates TransitClaim', async () => {
    const asn = await prisma.asn.create({
      data: {
        invoiceNo: `SAP-INV-EXCESS-${runId}`,
        invoiceDate: new Date(),
        dealerId: testDealer.id,
        status: 'IN_TRANSIT',
        lines: {
          create: [
            { skuId: testSku2.id, invoicedQty: 30, batch: excessBatch, landingPrice: 420.0 }
          ]
        }
      },
      include: { lines: true }
    });

    const asnLine = asn.lines[0];

    const res = await fetch(`${baseUrl}/api/inventory/asns/${asn.id}/grn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        lines: [
          {
            asnLineId: asnLine.id,
            receivedGoodQty: 30,
            shortQty: 0,
            excessQty: 8,
            damagedQty: 0,
            varianceReason: 'Extra box of 8 cans included in container'
          }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.asn.status, 'RECEIVED_WITH_VARIANCE');

    // Only invoiced qty (30) posted to AVAILABLE
    const onHand = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku2.id,
          batch: excessBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(onHand.qty, 30);

    // TransitClaim for EXCESS
    const claim = await prisma.transitClaim.findFirst({
      where: { asnId: asn.id, claimType: 'EXCESS' }
    });
    assert.ok(claim);
    assert.equal(claim.qty, 8);
    assert.equal(claim.status, 'OPEN');
  });

  const damagedBatch = `B-DAMAGED-${runId}`;
  await t.test('5. GRN with DAMAGED goods: posts good qty to AVAILABLE and damaged qty to DAMAGED, creates DAMAGED claim', async () => {
    const asn = await prisma.asn.create({
      data: {
        invoiceNo: `SAP-INV-DAMAGED-${runId}`,
        invoiceDate: new Date(),
        dealerId: testDealer.id,
        status: 'IN_TRANSIT',
        lines: {
          create: [
            { skuId: testSku1.id, invoicedQty: 25, batch: damagedBatch, landingPrice: 1100.0 }
          ]
        }
      },
      include: { lines: true }
    });

    const asnLine = asn.lines[0];

    const res = await fetch(`${baseUrl}/api/inventory/asns/${asn.id}/grn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        lines: [
          {
            asnLineId: asnLine.id,
            receivedGoodQty: 20,
            shortQty: 0,
            excessQty: 0,
            damagedQty: 5,
            varianceReason: 'Water seepage inside outer packaging damaged 5 units'
          }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.asn.status, 'RECEIVED_WITH_VARIANCE');

    // AVAILABLE stock on hand is 20
    const onHandAvail = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku1.id,
          batch: damagedBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(onHandAvail.qty, 20);

    // DAMAGED stock on hand is 5
    const onHandDamaged = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku1.id,
          batch: damagedBatch,
          stockState: 'DAMAGED'
        }
      }
    });
    assert.equal(onHandDamaged.qty, 5);

    // DAMAGED claim created
    const claim = await prisma.transitClaim.findFirst({
      where: { asnId: asn.id, claimType: 'DAMAGED' }
    });
    assert.ok(claim);
    assert.equal(claim.qty, 5);
  });

  await t.test('6. Idempotency: Repeating GRN confirm does nothing and returns current state', async () => {
    // Find an already received ASN
    const existingAsn = await prisma.asn.findFirst({
      where: { status: 'RECEIVED_WITH_VARIANCE' },
      include: { lines: true }
    });

    const ledgerCountBefore = await prisma.stockLedger.count({
      where: { dealerId: testDealer.id }
    });
    const claimsCountBefore = await prisma.transitClaim.count({
      where: { dealerId: testDealer.id }
    });

    const res = await fetch(`${baseUrl}/api/inventory/asns/${existingAsn.id}/grn`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        lines: [
          { asnLineId: existingAsn.lines[0].id, receivedGoodQty: 10 }
        ]
      })
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.idempotent, true);

    const ledgerCountAfter = await prisma.stockLedger.count({
      where: { dealerId: testDealer.id }
    });
    const claimsCountAfter = await prisma.transitClaim.count({
      where: { dealerId: testDealer.id }
    });

    // Zero additional ledger rows or claims created on duplicate confirm!
    assert.equal(ledgerCountAfter, ledgerCountBefore);
    assert.equal(claimsCountAfter, claimsCountBefore);
  });

  await t.test('7. Ledger Integrity: StockLedger sum strictly equals StockOnHand', async () => {
    const ledgerSumAvail = await prisma.stockLedger.aggregate({
      where: {
        dealerId: testDealer.id,
        skuId: testSku1.id,
        batch: damagedBatch,
        stockState: 'AVAILABLE'
      },
      _sum: { qtyChange: true }
    });

    const onHandAvail = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: defaultWarehouse.id,
          skuId: testSku1.id,
          batch: damagedBatch,
          stockState: 'AVAILABLE'
        }
      }
    });

    assert.equal(ledgerSumAvail._sum.qtyChange, onHandAvail.qty);
  });

  await t.test('8. Database Immutability Trigger: UPDATE or DELETE on stock_ledger is forbidden', async () => {
    const entry = await prisma.stockLedger.findFirst({
      where: { dealerId: testDealer.id }
    });
    assert.ok(entry);

    // Attempt UPDATE on stock_ledger
    await assert.rejects(
      async () => {
        await prisma.$executeRawUnsafe(`
          UPDATE stock_ledger SET qty_change = 9999 WHERE id = '${entry.id}'::uuid;
        `);
      },
      /StockLedger is strictly append-only/
    );

    // Attempt DELETE on stock_ledger
    await assert.rejects(
      async () => {
        await prisma.$executeRawUnsafe(`
          DELETE FROM stock_ledger WHERE id = '${entry.id}'::uuid;
        `);
      },
      /StockLedger is strictly append-only/
    );
  });

  await t.test('9. Brand Admin approves and rejects transit claims', async () => {
    const claim = await prisma.transitClaim.findFirst({
      where: { status: 'OPEN' }
    });
    assert.ok(claim);

    // Approve claim
    const resApprove = await fetch(`${baseUrl}/api/inventory/claims/${claim.id}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'BRAND_ADMIN',
        'x-user-email': brandEmail
      },
      body: JSON.stringify({ notes: 'Verified shortage with logistics carrier' })
    });
    assert.equal(resApprove.status, 200);
    const bodyApprove = await resApprove.json();
    assert.equal(bodyApprove.claim.status, 'APPROVED');
  });

  await t.test('10. Low stock alert threshold: flags items when available <= minStock', async () => {
    // Set a very high minStock threshold so isLowStock is guaranteed true
    await prisma.dealerSkuConfig.upsert({
      where: {
        dealerId_skuId: { dealerId: testDealer.id, skuId: testSku1.id }
      },
      update: { minStock: 99999 },
      create: { dealerId: testDealer.id, skuId: testSku1.id, minStock: 99999 }
    });

    const res = await fetch(`${baseUrl}/api/inventory/stock-on-hand?dealerId=${testDealer.id}`, {
      headers: {
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      }
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    const sku1Items = body.stockOnHand.filter((i) => i.skuId === testSku1.id);
    assert.ok(sku1Items.length > 0);
    assert.equal(sku1Items[0].isLowStock, true);
    assert.equal(sku1Items[0].minStock, 99999);
  });

  let secondWarehouse;
  await t.test('11. Multi-warehouse transfer: double-entry posting to ledger and balance update', async () => {
    secondWarehouse = await prisma.warehouse.findFirst({
      where: { dealerId: testDealer.id, code: 'SHOWROOM' }
    });
    if (!secondWarehouse) {
      secondWarehouse = await prisma.warehouse.create({
        data: {
          dealerId: testDealer.id,
          code: 'SHOWROOM',
          name: 'Retail Showroom Store',
          isDefault: false,
          isActive: true
        }
      });
    }

    const transferQty = 15;
    const res = await fetch(`${baseUrl}/api/inventory/transfers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        sourceWarehouseId: defaultWarehouse.id,
        targetWarehouseId: secondWarehouse.id,
        notes: 'Transfer to showroom',
        lines: [
          { skuId: testSku1.id, batch: fullBatch, qty: transferQty }
        ]
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.ok(body.transfer.transferNo.startsWith('TRF-'));

    // Verify StockLedger has OUT (-15) and IN (+15)
    const ledgerOut = await prisma.stockLedger.findFirst({
      where: {
        dealerId: testDealer.id,
        warehouseId: defaultWarehouse.id,
        skuId: testSku1.id,
        sourceType: 'STOCK_TRANSFER_OUT',
        sourceId: body.transfer.transferNo
      }
    });
    assert.ok(ledgerOut);
    assert.equal(ledgerOut.qtyChange, -transferQty);

    const ledgerIn = await prisma.stockLedger.findFirst({
      where: {
        dealerId: testDealer.id,
        warehouseId: secondWarehouse.id,
        skuId: testSku1.id,
        sourceType: 'STOCK_TRANSFER_IN',
        sourceId: body.transfer.transferNo
      }
    });
    assert.ok(ledgerIn);
    assert.equal(ledgerIn.qtyChange, transferQty);

    // Verify target warehouse stock on hand
    const targetStock = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: secondWarehouse.id,
          skuId: testSku1.id,
          batch: fullBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.ok(targetStock);
    assert.equal(targetStock.qty, transferQty);
  });

  await t.test('12. Multi-warehouse transfer: blocks when insufficient stock in source', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/transfers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        sourceWarehouseId: defaultWarehouse.id,
        targetWarehouseId: secondWarehouse.id,
        lines: [
          { skuId: testSku1.id, batch: fullBatch, qty: 999999 }
        ]
      })
    });

    assert.equal(res.status, 400);
    const body = await res.json();
    assert.match(body.error, /Insufficient available stock/);
  });

  await t.test('13. Purchase return to brand: generates ERP return order and deducts stock', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/purchase-returns`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: defaultWarehouse.id,
        reason: 'DAMAGED_IN_TRANSIT',
        lines: [
          { skuId: testSku1.id, batch: damagedBatch, qty: 5, fromStockState: 'DAMAGED' }
        ]
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.ok(body.purchaseReturn.returnNo.startsWith('PR-'));
    assert.ok(body.purchaseReturn.erpReturnOrderNo.startsWith('ERP-RO-'));

    // Check ledger has RETURNED_TO_BRAND entry
    const returnLedger = await prisma.stockLedger.findFirst({
      where: {
        dealerId: testDealer.id,
        skuId: testSku1.id,
        sourceType: 'PURCHASE_RETURN',
        stockState: 'RETURNED_TO_BRAND',
        sourceId: body.purchaseReturn.returnNo
      }
    });
    assert.ok(returnLedger);
    assert.equal(returnLedger.qtyChange, 5);
  });

  let auditId;
  await t.test('14. Physical stock audit: records book vs counted variance with PENDING_APPROVAL', async () => {
    // Current stock of testSku1 in target warehouse is 15. We count 12 (variance -3)
    const res = await fetch(`${baseUrl}/api/inventory/audits`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_STAFF',
        'x-user-email': 'staff@demo.local',
        'x-tenant-id': testDealer.id
      },
      body: JSON.stringify({
        warehouseId: secondWarehouse.id,
        lines: [
          { skuId: testSku1.id, batch: fullBatch, countedQty: 12, reasonCode: 'COUNTING_VARIANCE' }
        ]
      })
    });

    assert.equal(res.status, 201);
    const body = await res.json();
    assert.ok(body.audit.auditNo.startsWith('AUD-'));
    assert.equal(body.audit.status, 'PENDING_APPROVAL');
    assert.equal(body.audit.lines[0].bookQty, 15);
    assert.equal(body.audit.lines[0].countedQty, 12);
    assert.equal(body.audit.lines[0].varianceQty, -3);
    auditId = body.audit.id;
  });

  await t.test('15. Physical stock audit approval: non-owner role is forbidden', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/audits/${auditId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_STAFF',
        'x-user-email': 'staff@demo.local',
        'x-tenant-id': testDealer.id
      }
    });

    assert.equal(res.status, 403);
  });

  await t.test('16. Physical stock audit approval: Dealer Owner approves and posts adjustment to ledger', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/audits/${auditId}/approve`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      }
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.audit.status, 'APPROVED');

    // Verify StockLedger has PHYSICAL_AUDIT_ADJUSTMENT (-3)
    const auditLedger = await prisma.stockLedger.findFirst({
      where: {
        dealerId: testDealer.id,
        warehouseId: secondWarehouse.id,
        skuId: testSku1.id,
        sourceType: 'PHYSICAL_AUDIT_ADJUSTMENT'
      }
    });
    assert.ok(auditLedger);
    assert.equal(auditLedger.qtyChange, -3);

    // Verify StockOnHand is now exactly 12
    const updatedOnHand = await prisma.stockOnHand.findUnique({
      where: {
        dealerId_warehouseId_skuId_batch_stockState: {
          dealerId: testDealer.id,
          warehouseId: secondWarehouse.id,
          skuId: testSku1.id,
          batch: fullBatch,
          stockState: 'AVAILABLE'
        }
      }
    });
    assert.equal(updatedOnHand.qty, 12);
  });

  await t.test('17. Inventory ageing & reorder suggestions: calculates ageing buckets and primary reorders', async () => {
    const res = await fetch(`${baseUrl}/api/inventory/analytics?dealerId=${testDealer.id}`, {
      headers: {
        'x-user-role': 'DEALER_OWNER',
        'x-user-email': dealerEmail,
        'x-tenant-id': testDealer.id
      }
    });

    assert.equal(res.status, 200);
    const body = await res.json();
    assert.ok(body.ageingBuckets);
    assert.ok('0_30' in body.ageingBuckets);
    assert.ok('31_60' in body.ageingBuckets);
    assert.ok('61_90' in body.ageingBuckets);
    assert.ok('90_plus' in body.ageingBuckets);
    assert.ok(Array.isArray(body.reorderSuggestions));
  });
});

