import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/app.js';
import {
  DashboardModule,
  DashboardDataSource,
  MockDashboardDataSource,
  setDashboardDataSource
} from '../src/dashboard/dashboard.module.js';
import { createAccessToken } from '../src/auth/token.service.js';

test('DashboardDataSource interface and Mock implementation', async (t) => {
  await t.test('base DashboardDataSource methods throw not implemented', async () => {
    const baseSource = new DashboardDataSource();
    await assert.rejects(async () => baseSource.getBrandDashboard(), /not implemented/);
    await assert.rejects(async () => baseSource.getDealerDashboard(), /not implemented/);
  });

  await t.test('MockDashboardDataSource returns valid brand metrics', async () => {
    const mockSource = new MockDashboardDataSource();
    const data = await mockSource.getBrandDashboard();

    assert.ok(data.totalSecondarySales);
    assert.equal(typeof data.totalSecondarySales.today, 'number');
    assert.equal(typeof data.totalSecondarySales.monthToDate, 'number');
    assert.equal(typeof data.totalSecondarySales.vsLastMonthPercent, 'number');

    assert.equal(typeof data.activeDealersCount, 'number');
    assert.equal(typeof data.pendingRetailerApprovalsCount, 'number');

    assert.ok(Array.isArray(data.salesByDealer));
    assert.equal(data.salesByDealer.length, 10, 'Must return top 10 dealers');

    assert.ok(Array.isArray(data.dealersWithLowStock));
    assert.ok(data.dealersWithLowStock.length > 0);

    assert.ok(Array.isArray(data.salesTrend));
    assert.equal(data.salesTrend.length, 30, 'Must return 30 days trend');
    assert.ok(data.salesTrend[0].date);
    assert.equal(typeof data.salesTrend[0].value, 'number');
  });

  await t.test('MockDashboardDataSource returns valid dealer metrics', async () => {
    const mockSource = new MockDashboardDataSource();
    const data = await mockSource.getDealerDashboard();

    assert.equal(typeof data.todaysSales, 'number');
    assert.equal(typeof data.monthToDateSales, 'number');
    assert.equal(typeof data.collectionsToday, 'number');
    assert.equal(typeof data.pendingOrdersCount, 'number');
    assert.equal(typeof data.outstandingTotal, 'number');

    assert.ok(Array.isArray(data.stockAlerts));
    assert.equal(data.stockAlerts.length, 10, 'Must return top 10 stock alerts');
    assert.ok(data.stockAlerts[0].sku);
    assert.ok(data.stockAlerts[0].name);
    assert.ok(data.stockAlerts[0].available <= data.stockAlerts[0].minimum);

    assert.ok(Array.isArray(data.salesTrend));
    assert.equal(data.salesTrend.length, 30, 'Must return 30 days trend');
  });

  await t.test('swapping data source via provider works cleanly', async () => {
    class CustomProvider extends DashboardDataSource {
      async getBrandDashboard() {
        return { custom: true, totalSecondarySales: { today: 999, monthToDate: 888, vsLastMonthPercent: 5 } };
      }
      async getDealerDashboard() {
        return { custom: true, todaysSales: 111 };
      }
    }

    const original = DashboardModule.provider;
    try {
      DashboardModule.setProvider(new CustomProvider());
      const brandData = await DashboardModule.provider.getBrandDashboard();
      assert.equal(brandData.custom, true);
      assert.equal(brandData.totalSecondarySales.today, 999);
    } finally {
      DashboardModule.setProvider(original);
    }
  });
});

test('HTTP Dashboard API endpoints and role authorization', async (t) => {
  let server;
  let baseUrl;

  t.before(async () => {
    await new Promise((resolve) => {
      server = app.listen(0, () => {
        const port = server.address().port;
        baseUrl = `http://localhost:${port}`;
        resolve();
      });
    });
  });

  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
  });

  await t.test('GET /dashboard/brand without credentials returns 401 Unauthorized', async () => {
    const res = await fetch(`${baseUrl}/dashboard/brand`);
    assert.equal(res.status, 401);
  });

  await t.test('GET /dashboard/brand as DEALER_OWNER returns 403 Forbidden', async () => {
    const res = await fetch(`${baseUrl}/dashboard/brand`, {
      headers: { 'x-demo-role': 'DEALER_OWNER' }
    });
    assert.equal(res.status, 403);
    const body = await res.json();
    assert.match(body.error, /Brand Admin role required/i);
  });

  await t.test('GET /dashboard/brand as BRAND_ADMIN returns 200 with full metrics', async () => {
    const res = await fetch(`${baseUrl}/dashboard/brand`, {
      headers: { 'x-demo-role': 'BRAND_ADMIN' }
    });
    assert.equal(res.status, 200);
    const body = await res.json();

    assert.equal(typeof body.totalSecondarySales.today, 'number');
    assert.equal(typeof body.totalSecondarySales.monthToDate, 'number');
    assert.equal(typeof body.totalSecondarySales.vsLastMonthPercent, 'number');
    assert.equal(typeof body.activeDealersCount, 'number');
    assert.equal(typeof body.pendingRetailerApprovalsCount, 'number');
    assert.equal(body.salesByDealer.length, 10);
    assert.ok(body.dealersWithLowStock.length > 0);
    assert.equal(body.salesTrend.length, 30);
    assert.ok(Array.isArray(body.kpis));
  });

  await t.test('GET /api/dashboard/brand also works identically under /api prefix', async () => {
    const res = await fetch(`${baseUrl}/api/dashboard/brand`, {
      headers: { 'x-demo-role': 'BRAND_ADMIN' }
    });
    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.salesByDealer.length, 10);
  });

  await t.test('GET /dashboard/dealer without credentials returns 401 Unauthorized', async () => {
    const res = await fetch(`${baseUrl}/dashboard/dealer`);
    assert.equal(res.status, 401);
  });

  await t.test('GET /dashboard/dealer as BRAND_ADMIN returns 403 Forbidden', async () => {
    const res = await fetch(`${baseUrl}/dashboard/dealer`, {
      headers: { 'x-demo-role': 'BRAND_ADMIN' }
    });
    assert.equal(res.status, 403);
    const body = await res.json();
    assert.match(body.error, /Dealer role required/i);
  });

  await t.test('GET /dashboard/dealer as DEALER_OWNER returns 200 with dealer metrics', async () => {
    const res = await fetch(`${baseUrl}/dashboard/dealer`, {
      headers: { 'x-demo-role': 'DEALER_OWNER' }
    });
    assert.equal(res.status, 200);
    const body = await res.json();

    assert.equal(typeof body.todaysSales, 'number');
    assert.equal(typeof body.monthToDateSales, 'number');
    assert.equal(typeof body.collectionsToday, 'number');
    assert.equal(typeof body.pendingOrdersCount, 'number');
    assert.equal(typeof body.outstandingTotal, 'number');
    assert.equal(body.stockAlerts.length, 10);
    assert.equal(body.salesTrend.length, 30);
  });

  await t.test('GET /dashboard/dealer with valid JWT token works', async () => {
    const token = createAccessToken({
      id: 'test-user-1',
      role: 'DEALER_OPERATOR',
      dealerId: 'dlr-001'
    });

    const res = await fetch(`${baseUrl}/dashboard/dealer`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    assert.equal(res.status, 200);
    const body = await res.json();
    assert.equal(body.stockAlerts.length, 10);
  });
});

