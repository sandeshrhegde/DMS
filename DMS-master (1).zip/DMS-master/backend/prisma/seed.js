import bcrypt from 'bcryptjs';
import { prisma, initializeDatabase, disconnectDatabase } from '../src/config/database.js';

async function seed() {
  await initializeDatabase();
  console.log('Seeding master data into PostgreSQL...');

  const passwordHash = await bcrypt.hash('Demo@123', 10);

  // 1. Geography Hierarchy
  // Level sequence: ZONE -> STATE -> REGION -> CITY -> CLUSTER
  const northZone = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000001',
      name: 'North Zone',
      type: 'ZONE',
      path: '/North Zone'
    }
  });

  const westZone = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000002' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000002',
      name: 'West Zone',
      type: 'ZONE',
      path: '/West Zone'
    }
  });

  const maharashtra = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000003' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000003',
      name: 'Maharashtra',
      type: 'STATE',
      parentId: westZone.id,
      path: '/West Zone/Maharashtra'
    }
  });

  const mumbaiRegion = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000004' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000004',
      name: 'Mumbai MMR Region',
      type: 'REGION',
      parentId: maharashtra.id,
      path: '/West Zone/Maharashtra/Mumbai MMR Region'
    }
  });

  const mumbaiCity = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000005' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000005',
      name: 'Mumbai City',
      type: 'CITY',
      parentId: mumbaiRegion.id,
      path: '/West Zone/Maharashtra/Mumbai MMR Region/Mumbai City'
    }
  });

  const andheriCluster = await prisma.geoNode.upsert({
    where: { id: '00000000-0000-0000-0000-000000000006' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000006',
      name: 'Andheri Auto Cluster',
      type: 'CLUSTER',
      parentId: mumbaiCity.id,
      path: '/West Zone/Maharashtra/Mumbai MMR Region/Mumbai City/Andheri Auto Cluster'
    }
  });

  // 2. Demo Dealer
  const demoDealer = await prisma.dealer.upsert({
    where: { code: 'DEMO-001' },
    update: {
      geoNodeId: andheriCluster.id
    },
    create: {
      id: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1',
      code: 'DEMO-001',
      name: 'Demo Motors Mumbai',
      gstin: '27AABCT3518Q1ZV',
      stateCode: '27',
      contactName: 'Ramesh Patel',
      contactEmail: 'contact@demomotors.local',
      contactPhone: '+91 98200 12345',
      address: 'Plot 42, MIDC Industrial Area, Andheri East, Mumbai',
      pincode: '400093',
      creditDays: 30,
      maxHeaderDiscountPct: 7.5,
      eInvoiceEnabled: true,
      geoNodeId: andheriCluster.id,
      isActive: true
    }
  });

  // 2b. Default Warehouse for Dealership
  await prisma.warehouse.upsert({
    where: {
      dealerId_code: {
        dealerId: demoDealer.id,
        code: 'MAIN'
      }
    },
    update: {},
    create: {
      dealerId: demoDealer.id,
      code: 'MAIN',
      name: 'Main Dealership Warehouse',
      address: 'Plot 42, MIDC, Andheri East, Mumbai',
      isDefault: true,
      isActive: true
    }
  });

  // 2c. Second Warehouse for Dealership (Multi-Warehouse support)
  await prisma.warehouse.upsert({
    where: {
      dealerId_code: {
        dealerId: demoDealer.id,
        code: 'SHOWROOM'
      }
    },
    update: {},
    create: {
      dealerId: demoDealer.id,
      code: 'SHOWROOM',
      name: 'Andheri Retail Store & Showroom',
      address: 'Shop 12-14, Linking Road, Andheri West, Mumbai',
      isDefault: false,
      isActive: true
    }
  });

  // 3. Demo Users
  await prisma.user.upsert({
    where: { email: 'brand@dms.local' },
    update: { passwordHash },
    create: {
      name: 'Brand Administrator',
      email: 'brand@dms.local',
      passwordHash,
      role: 'BRAND_ADMIN',
      dealerId: null,
      isActive: true
    }
  });

  await prisma.user.upsert({
    where: { email: 'brand2@dms.local' },
    update: { passwordHash },
    create: {
      name: 'Brand Approver Checker',
      email: 'brand2@dms.local',
      passwordHash,
      role: 'BRAND_ADMIN',
      dealerId: null,
      isActive: true
    }
  });

  await prisma.user.upsert({
    where: { email: 'owner@demo.local' },
    update: { passwordHash, dealerId: demoDealer.id },
    create: {
      name: 'Demo Motors Owner',
      email: 'owner@demo.local',
      passwordHash,
      role: 'DEALER_OWNER',
      dealerId: demoDealer.id,
      isActive: true
    }
  });

  await prisma.user.upsert({
    where: { email: 'operator@demo.local' },
    update: { passwordHash, dealerId: demoDealer.id },
    create: {
      name: 'Demo Motors Operator',
      email: 'operator@demo.local',
      passwordHash,
      role: 'DEALER_OPERATOR',
      dealerId: demoDealer.id,
      isActive: true
    }
  });

  await prisma.user.upsert({
    where: { email: 'salesman@demo.local' },
    update: { passwordHash, dealerId: demoDealer.id },
    create: {
      name: 'Demo Motors Salesman',
      email: 'salesman@demo.local',
      passwordHash,
      role: 'SALESMAN',
      dealerId: demoDealer.id,
      isActive: true
    }
  });

  // 4. HSN Masters
  const hsnItems = [
    { code: '87082900', description: 'Parts and accessories of bodies for motor vehicles', gstRate: 28 },
    { code: '27101981', description: 'Engine oil and lubricating oils', gstRate: 18 },
    { code: '84212300', description: 'Oil or petrol filters for internal combustion engines', gstRate: 18 },
    { code: '84213100', description: 'Intake air filters for internal combustion engines', gstRate: 18 },
    { code: '85111000', description: 'Sparking plugs for internal combustion engines', gstRate: 18 },
    { code: '85071000', description: 'Lead-acid accumulators/batteries for starting piston engines', gstRate: 28 },
    { code: '87083000', description: 'Brakes and servo-brakes and parts thereof', gstRate: 28 },
    { code: '87089300', description: 'Clutches and parts thereof', gstRate: 28 }
  ];

  for (const hsn of hsnItems) {
    await prisma.hsn.upsert({
      where: { code: hsn.code },
      update: hsn,
      create: hsn
    });
  }

  // 5. Seed Initial SKUs
  const sampleSkus = [
    {
      code: 'BRK-PAD-001',
      name: 'Ceramic Front Brake Pads (Set)',
      brand: 'AutoPro Genuine',
      category: 'Braking',
      article: 'BRK-CER-204',
      size: 'Standard',
      colour: 'Metallic Gray',
      uom: 'SET',
      mrp: 1850.0,
      landingPrice: 1100.0,
      hsnCode: '87083000',
      barcode: '8901234500018',
      isActive: true
    },
    {
      code: 'OIL-SYN-5W30',
      name: 'Synthetic Engine Oil 5W-30 (1L Can)',
      brand: 'LubriMax',
      category: 'Lubricants',
      article: 'SYN-5W30-1L',
      size: '1L',
      colour: 'Amber',
      uom: 'CAN',
      mrp: 720.0,
      landingPrice: 420.0,
      hsnCode: '27101981',
      barcode: '8901234500025',
      isActive: true
    },
    {
      code: 'FLT-AIR-113',
      name: 'High Flow Air Filter Element',
      brand: 'AutoPro Genuine',
      category: 'Filters',
      article: 'FLT-ELM-113',
      size: 'Universal',
      colour: 'White/Orange',
      uom: 'PCS',
      mrp: 450.0,
      landingPrice: 260.0,
      hsnCode: '84213100',
      barcode: '8901234500032',
      isActive: true
    },
    {
      code: 'SPK-PLG-401',
      name: 'Laser Iridium Spark Plug (Pack of 4)',
      brand: 'IgniteTech',
      category: 'Ignition',
      article: 'IRID-SPK-4',
      size: '14mm',
      colour: 'Silver',
      uom: 'BOX',
      mrp: 1200.0,
      landingPrice: 700.0,
      hsnCode: '85111000',
      barcode: '8901234500049',
      isActive: true
    },
    {
      code: 'BAT-45AH-12V',
      name: '12V 45Ah Maintenance Free Battery',
      brand: 'PowerVolt',
      category: 'Electrical',
      article: 'BAT-MF-45',
      size: '45Ah',
      colour: 'Black/Red',
      uom: 'PCS',
      mrp: 4800.0,
      landingPrice: 2900.0,
      hsnCode: '85071000',
      barcode: '8901234500056',
      isActive: true
    }
  ];

  for (const sku of sampleSkus) {
    await prisma.sku.upsert({
      where: { code: sku.code },
      update: sku,
      create: sku
    });
  }

  // 6. Global System Settings (Guardrails)
  await prisma.systemSetting.upsert({
    where: { key: 'minMarginPct' },
    update: { value: '10' },
    create: {
      key: 'minMarginPct',
      value: '10',
      description: 'Configured global minimum margin % over landing price'
    }
  });

  console.log('Seeding complete!');
  await disconnectDatabase();
}

seed().catch(async (e) => {
  console.error('Seeding error:', e);
  await disconnectDatabase();
  process.exit(1);
});

