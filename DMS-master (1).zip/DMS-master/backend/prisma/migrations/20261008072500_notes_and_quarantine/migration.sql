-- Migration: 20261008072500_notes_and_quarantine

-- Add QUARANTINE to StockState enum
ALTER TYPE "StockState" ADD VALUE IF NOT EXISTS 'QUARANTINE';

-- Create Note enums if not exist
DO $$ BEGIN
  CREATE TYPE "NoteType" AS ENUM ('CREDIT_SALES_RETURN', 'CREDIT_FINANCIAL', 'DEBIT');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "NoteReasonCode" AS ENUM (
    'RETURN_DAMAGED',
    'RETURN_WRONG_ITEM',
    'RATE_DIFFERENCE',
    'SCHEME_BENEFIT',
    'CHEQUE_BOUNCE_CHARGE',
    'OTHER'
  );
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "NoteStatus" AS ENUM ('DRAFT', 'PENDING_APPROVAL', 'APPROVED', 'CANCELLED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Dealer threshold
ALTER TABLE "dealers" ADD COLUMN IF NOT EXISTS "note_approval_threshold" DOUBLE PRECISION NOT NULL DEFAULT 50000.0;

-- Notes table
CREATE TABLE IF NOT EXISTS "notes" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "retailer_id" UUID NOT NULL,
  "note_no" TEXT NOT NULL,
  "financial_year" TEXT NOT NULL,
  "type" "NoteType" NOT NULL,
  "reason_code" "NoteReasonCode" NOT NULL,
  "status" "NoteStatus" NOT NULL DEFAULT 'DRAFT',
  "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "ref_invoice_id" UUID,
  "is_taxable" BOOLEAN NOT NULL DEFAULT false,
  "gross_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "discount_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "taxable_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "gst_rate" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "cgst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "sgst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "igst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "tax_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "rounding" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "total_amount" DOUBLE PRECISION NOT NULL,
  "allocated_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "balance_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "requires_approval" BOOLEAN NOT NULL DEFAULT false,
  "approved_by_email" TEXT,
  "approved_at" TIMESTAMP(3),
  "rejection_reason" TEXT,
  "cancelled_by_email" TEXT,
  "cancelled_at" TIMESTAMP(3),
  "cancelled_reason" TEXT,
  "created_by_email" TEXT,
  "notes" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "notes_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "notes_dealer_id_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE,
  CONSTRAINT "notes_retailer_id_fkey" FOREIGN KEY ("retailer_id") REFERENCES "retailers"("id") ON DELETE CASCADE,
  CONSTRAINT "notes_ref_invoice_id_fkey" FOREIGN KEY ("ref_invoice_id") REFERENCES "invoices"("id") ON DELETE SET NULL,
  CONSTRAINT "notes_dealer_id_note_no_key" UNIQUE ("dealer_id", "note_no")
);

-- Note lines table
CREATE TABLE IF NOT EXISTS "note_lines" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "note_id" UUID NOT NULL,
  "invoice_line_id" UUID,
  "sku_id" UUID NOT NULL,
  "batch" TEXT NOT NULL DEFAULT 'DEFAULT',
  "qty" INTEGER NOT NULL,
  "unit_price" DOUBLE PRECISION NOT NULL,
  "hsn_code" TEXT,
  "gst_rate" DOUBLE PRECISION NOT NULL,
  "gross_amount" DOUBLE PRECISION NOT NULL,
  "discount_share" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "taxable_value" DOUBLE PRECISION NOT NULL,
  "cgst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "sgst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "igst_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  "line_tax" DOUBLE PRECISION NOT NULL,
  "line_total" DOUBLE PRECISION NOT NULL,
  "quarantined_qty" INTEGER NOT NULL DEFAULT 0,
  "inspected_good_qty" INTEGER NOT NULL DEFAULT 0,
  "inspected_damaged_qty" INTEGER NOT NULL DEFAULT 0,
  "is_inspected" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "note_lines_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "note_lines_note_id_fkey" FOREIGN KEY ("note_id") REFERENCES "notes"("id") ON DELETE CASCADE,
  CONSTRAINT "note_lines_invoice_line_id_fkey" FOREIGN KEY ("invoice_line_id") REFERENCES "invoice_lines"("id") ON DELETE SET NULL,
  CONSTRAINT "note_lines_sku_id_fkey" FOREIGN KEY ("sku_id") REFERENCES "skus"("id") ON DELETE CASCADE
);

-- Note allocations table
CREATE TABLE IF NOT EXISTS "note_allocations" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "note_id" UUID NOT NULL,
  "invoice_id" UUID NOT NULL,
  "amount" DOUBLE PRECISION NOT NULL,
  "is_reversed" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "note_allocations_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "note_allocations_note_id_fkey" FOREIGN KEY ("note_id") REFERENCES "notes"("id") ON DELETE CASCADE,
  CONSTRAINT "note_allocations_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON DELETE CASCADE
);

-- Quarantine inspections table
CREATE TABLE IF NOT EXISTS "quarantine_inspections" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "note_id" UUID NOT NULL,
  "note_line_id" UUID,
  "warehouse_id" UUID NOT NULL,
  "sku_id" UUID NOT NULL,
  "batch" TEXT NOT NULL,
  "good_qty" INTEGER NOT NULL,
  "damaged_qty" INTEGER NOT NULL,
  "inspected_by_email" TEXT,
  "notes" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "quarantine_inspections_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "quarantine_inspections_dealer_id_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE,
  CONSTRAINT "quarantine_inspections_note_id_fkey" FOREIGN KEY ("note_id") REFERENCES "notes"("id") ON DELETE CASCADE,
  CONSTRAINT "quarantine_inspections_warehouse_id_fkey" FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE
);

-- Dealer note sequence counters
CREATE TABLE IF NOT EXISTS "dealer_credit_note_sequences" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "financial_year" TEXT NOT NULL,
  "current_value" INTEGER NOT NULL DEFAULT 0,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "dealer_credit_note_sequences_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "dealer_credit_note_sequences_dealer_id_financial_year_key" UNIQUE ("dealer_id", "financial_year"),
  CONSTRAINT "dealer_credit_note_sequences_dealer_id_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "dealer_debit_note_sequences" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "financial_year" TEXT NOT NULL,
  "current_value" INTEGER NOT NULL DEFAULT 0,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "dealer_debit_note_sequences_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "dealer_debit_note_sequences_dealer_id_financial_year_key" UNIQUE ("dealer_id", "financial_year"),
  CONSTRAINT "dealer_debit_note_sequences_dealer_id_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE
);

-- Enable RLS on notes, note_lines, note_allocations, quarantine_inspections
ALTER TABLE "notes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notes_tenant_policy" ON "notes"
  USING (current_setting('app.is_brand', true) = 'true' OR "dealer_id"::text = current_setting('app.dealer_id', true));

ALTER TABLE "quarantine_inspections" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "quarantine_inspections_tenant_policy" ON "quarantine_inspections"
  USING (current_setting('app.is_brand', true) = 'true' OR "dealer_id"::text = current_setting('app.dealer_id', true));

