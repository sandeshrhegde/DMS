-- Migration: 20261008123000_inventory_transfers_audit_returns

-- 1. Enum value for StockState: RETURNED_TO_BRAND
ALTER TYPE "StockState" ADD VALUE IF NOT EXISTS 'RETURNED_TO_BRAND';

-- 2. Enums for Stock Transfers, Purchase Returns, and Stock Audits
DO $$ BEGIN
  CREATE TYPE "StockTransferStatus" AS ENUM ('DRAFT', 'COMPLETED', 'CANCELLED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "PurchaseReturnStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'ERP_ACCEPTED', 'CANCELLED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "StockAuditStatus" AS ENUM ('IN_PROGRESS', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- 3. Extend ASN and ASN Lines for ERP tax and acknowledgement tracking
ALTER TABLE "asns" ADD COLUMN IF NOT EXISTS "erp_acknowledged_at" TIMESTAMP(3);
ALTER TABLE "asns" ADD COLUMN IF NOT EXISTS "total_tax" DOUBLE PRECISION NOT NULL DEFAULT 0.0;
ALTER TABLE "asns" ADD COLUMN IF NOT EXISTS "net_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0;

ALTER TABLE "asn_lines" ADD COLUMN IF NOT EXISTS "tax_rate" DOUBLE PRECISION NOT NULL DEFAULT 18.0;
ALTER TABLE "asn_lines" ADD COLUMN IF NOT EXISTS "tax_amount" DOUBLE PRECISION NOT NULL DEFAULT 0.0;

-- 4. Extend StockOnHand and StockLedger for inward date / ageing
ALTER TABLE "stock_on_hand" ADD COLUMN IF NOT EXISTS "inward_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "stock_ledger" ADD COLUMN IF NOT EXISTS "inward_date" TIMESTAMP(3);

-- 5. Multi-Warehouse Stock Transfers
CREATE TABLE IF NOT EXISTS "stock_transfers" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "transfer_no" TEXT NOT NULL,
  "source_warehouse_id" UUID NOT NULL,
  "target_warehouse_id" UUID NOT NULL,
  "status" "StockTransferStatus" NOT NULL DEFAULT 'DRAFT',
  "notes" TEXT,
  "transferred_by_email" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "stock_transfers_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_transfers_dealer_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE,
  CONSTRAINT "stock_transfers_source_wh_fkey" FOREIGN KEY ("source_warehouse_id") REFERENCES "warehouses"("id") ON DELETE RESTRICT,
  CONSTRAINT "stock_transfers_target_wh_fkey" FOREIGN KEY ("target_warehouse_id") REFERENCES "warehouses"("id") ON DELETE RESTRICT
);

CREATE UNIQUE INDEX IF NOT EXISTS "stock_transfers_dealer_id_transfer_no_key" ON "stock_transfers"("dealer_id", "transfer_no");
CREATE INDEX IF NOT EXISTS "stock_transfers_dealer_id_idx" ON "stock_transfers"("dealer_id");
CREATE INDEX IF NOT EXISTS "stock_transfers_source_warehouse_id_idx" ON "stock_transfers"("source_warehouse_id");
CREATE INDEX IF NOT EXISTS "stock_transfers_target_warehouse_id_idx" ON "stock_transfers"("target_warehouse_id");

CREATE TABLE IF NOT EXISTS "stock_transfer_lines" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "transfer_id" UUID NOT NULL,
  "sku_id" UUID NOT NULL,
  "batch" TEXT NOT NULL DEFAULT 'DEFAULT',
  "qty" INTEGER NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "stock_transfer_lines_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_transfer_lines_transfer_fkey" FOREIGN KEY ("transfer_id") REFERENCES "stock_transfers"("id") ON DELETE CASCADE,
  CONSTRAINT "stock_transfer_lines_sku_fkey" FOREIGN KEY ("sku_id") REFERENCES "skus"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "stock_transfer_lines_transfer_id_idx" ON "stock_transfer_lines"("transfer_id");
CREATE INDEX IF NOT EXISTS "stock_transfer_lines_sku_id_idx" ON "stock_transfer_lines"("sku_id");

-- 6. Purchase Return to Brand (DMS Request -> ERP Return Order)
CREATE TABLE IF NOT EXISTS "purchase_returns" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "warehouse_id" UUID NOT NULL,
  "return_no" TEXT NOT NULL,
  "status" "PurchaseReturnStatus" NOT NULL DEFAULT 'DRAFT',
  "reason" TEXT NOT NULL,
  "erp_return_order_no" TEXT,
  "notes" TEXT,
  "created_by_email" TEXT,
  "submitted_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "purchase_returns_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "purchase_returns_dealer_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE,
  CONSTRAINT "purchase_returns_warehouse_fkey" FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "purchase_returns_dealer_id_return_no_key" ON "purchase_returns"("dealer_id", "return_no");
CREATE INDEX IF NOT EXISTS "purchase_returns_dealer_id_idx" ON "purchase_returns"("dealer_id");
CREATE INDEX IF NOT EXISTS "purchase_returns_warehouse_id_idx" ON "purchase_returns"("warehouse_id");

CREATE TABLE IF NOT EXISTS "purchase_return_lines" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "return_id" UUID NOT NULL,
  "sku_id" UUID NOT NULL,
  "batch" TEXT NOT NULL DEFAULT 'DEFAULT',
  "qty" INTEGER NOT NULL,
  "from_stock_state" "StockState" NOT NULL DEFAULT 'DAMAGED',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "purchase_return_lines_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "purchase_return_lines_return_fkey" FOREIGN KEY ("return_id") REFERENCES "purchase_returns"("id") ON DELETE CASCADE,
  CONSTRAINT "purchase_return_lines_sku_fkey" FOREIGN KEY ("sku_id") REFERENCES "skus"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "purchase_return_lines_return_id_idx" ON "purchase_return_lines"("return_id");
CREATE INDEX IF NOT EXISTS "purchase_return_lines_sku_id_idx" ON "purchase_return_lines"("sku_id");

-- 7. Periodic Physical Stock Count & Approval-Based Adjustment
CREATE TABLE IF NOT EXISTS "stock_audits" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "dealer_id" UUID NOT NULL,
  "warehouse_id" UUID NOT NULL,
  "audit_no" TEXT NOT NULL,
  "status" "StockAuditStatus" NOT NULL DEFAULT 'IN_PROGRESS',
  "audit_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "notes" TEXT,
  "conducted_by_email" TEXT,
  "approved_by_email" TEXT,
  "approved_at" TIMESTAMP(3),
  "rejection_reason" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "stock_audits_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_audits_dealer_fkey" FOREIGN KEY ("dealer_id") REFERENCES "dealers"("id") ON DELETE CASCADE,
  CONSTRAINT "stock_audits_warehouse_fkey" FOREIGN KEY ("warehouse_id") REFERENCES "warehouses"("id") ON DELETE CASCADE
);

CREATE UNIQUE INDEX IF NOT EXISTS "stock_audits_dealer_id_audit_no_key" ON "stock_audits"("dealer_id", "audit_no");
CREATE INDEX IF NOT EXISTS "stock_audits_dealer_id_idx" ON "stock_audits"("dealer_id");
CREATE INDEX IF NOT EXISTS "stock_audits_warehouse_id_idx" ON "stock_audits"("warehouse_id");

CREATE TABLE IF NOT EXISTS "stock_audit_lines" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "audit_id" UUID NOT NULL,
  "sku_id" UUID NOT NULL,
  "batch" TEXT NOT NULL DEFAULT 'DEFAULT',
  "book_qty" INTEGER NOT NULL,
  "counted_qty" INTEGER NOT NULL,
  "variance_qty" INTEGER NOT NULL,
  "reason_code" TEXT,
  "notes" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "stock_audit_lines_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "stock_audit_lines_audit_fkey" FOREIGN KEY ("audit_id") REFERENCES "stock_audits"("id") ON DELETE CASCADE,
  CONSTRAINT "stock_audit_lines_sku_fkey" FOREIGN KEY ("sku_id") REFERENCES "skus"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS "stock_audit_lines_audit_id_idx" ON "stock_audit_lines"("audit_id");
CREATE INDEX IF NOT EXISTS "stock_audit_lines_sku_id_idx" ON "stock_audit_lines"("sku_id");

