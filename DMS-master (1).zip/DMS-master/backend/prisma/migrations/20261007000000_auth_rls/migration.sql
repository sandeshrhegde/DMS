CREATE TYPE "Role" AS ENUM ('BRAND_ADMIN','DEALER_OWNER','DEALER_OPERATOR','SALESMAN');
CREATE TABLE dealers (id uuid PRIMARY KEY, code text UNIQUE NOT NULL, name text NOT NULL, gstin text UNIQUE, "stateCode" text NOT NULL, is_active boolean NOT NULL DEFAULT true);
CREATE TABLE users (id uuid PRIMARY KEY, name text NOT NULL, email text UNIQUE NOT NULL, password_hash text NOT NULL, role "Role" NOT NULL, dealer_id uuid REFERENCES dealers(id), is_active boolean NOT NULL DEFAULT true, refresh_token_hash text, CHECK ((role = 'BRAND_ADMIN' AND dealer_id IS NULL) OR (role <> 'BRAND_ADMIN' AND dealer_id IS NOT NULL)));
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY users_tenant_policy ON users USING (current_setting('app.is_brand', true) = 'true' OR dealer_id::text = current_setting('app.dealer_id', true));
