import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
    headers['x-user-role'] = user.role;
  }
  if (user?.email) {
    headers['x-demo-email'] = user.email;
    headers['x-user-email'] = user.email;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  if (user?.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
    headers['x-dealer-id'] = user.dealerId;
  }
  return headers;
}

export async function fetchPendingOrders(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/billing/pending-orders${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function previewInvoice(user, data) {
  return apiFetch('/billing/calculate', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function createInvoice(user, data) {
  return apiFetch('/billing/invoices', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchInvoices(user, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/billing/invoices${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchInvoiceById(user, id) {
  return apiFetch(`/billing/invoices/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function cancelInvoice(user, id, reason) {
  return apiFetch(`/billing/invoices/${id}/cancel`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function fetchRetailerLedger(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/billing/retailer-ledger${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchRetailerLedgerData(user, retailerId, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/billing/retailers/${retailerId}/ledger${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchRetailerOpenInvoices(user, retailerId, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/billing/retailers/${retailerId}/open-invoices${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchCollections(user, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/billing/collections${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchCollectionById(user, id) {
  return apiFetch(`/billing/collections/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function recordCollection(user, data) {
  return apiFetch('/billing/collections', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function bounceCheque(user, id, data) {
  return apiFetch(`/billing/collections/${id}/bounce`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchCollectionReceipt(user, id) {
  return apiFetch(`/billing/collections/${id}/receipt`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchDealerOutstandingOverview(user, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/billing/outstanding${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}
