import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  return headers;
}

// ==================== GEOGRAPHY API ====================

export async function fetchGeoTree(user) {
  return apiFetch('/geography/tree', {
    headers: getAuthHeaders(user)
  });
}

export async function fetchGeoNodes(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/geography${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createGeoNode(user, data) {
  return apiFetch('/geography', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateGeoNode(user, id, data) {
  return apiFetch(`/geography/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function deleteGeoNode(user, id) {
  return apiFetch(`/geography/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders(user)
  });
}

// ==================== HSN API ====================

export async function fetchHsnList(user, search = '') {
  const query = search ? `?search=${encodeURIComponent(search)}` : '';
  return apiFetch(`/hsn${query}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createHsn(user, data) {
  return apiFetch('/hsn', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateHsn(user, id, data) {
  return apiFetch(`/hsn/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function deleteHsn(user, id) {
  return apiFetch(`/hsn/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders(user)
  });
}

// ==================== SKU API ====================

export async function fetchSkus(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  const res = await apiFetch(`/skus${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
  const list = res.skus || res.items || [];
  return {
    ...res,
    skus: list,
    items: list
  };
}

export async function createSku(user, data) {
  return apiFetch('/skus', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateSku(user, id, data) {
  return apiFetch(`/skus/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function deleteSku(user, id) {
  return apiFetch(`/skus/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders(user)
  });
}

export async function importSkusCsv(user, { csvText, mode }) {
  return apiFetch('/skus/import-csv', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ csvText, mode })
  });
}

export async function fetchSampleSkusCsv(user) {
  const res = await fetch('http://localhost:4000/api/skus/sample-csv', {
    headers: getAuthHeaders(user)
  });
  return res.text();
}

// ==================== DEALERS API ====================

export async function fetchDealers(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/dealers${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createDealer(user, data) {
  return apiFetch('/dealers', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateDealer(user, id, data) {
  return apiFetch(`/dealers/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function deleteDealer(user, id) {
  return apiFetch(`/dealers/${id}`, {
    method: 'DELETE',
    headers: getAuthHeaders(user)
  });
}

export async function importDealersCsv(user, { csvText, mode }) {
  return apiFetch('/dealers/import-csv', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ csvText, mode })
  });
}

export async function fetchSampleDealersCsv(user) {
  const res = await fetch('http://localhost:4000/api/dealers/sample-csv', {
    headers: getAuthHeaders(user)
  });
  return res.text();
}

