import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
    headers['x-user-role'] = user.role;
  }
  if (user?.email) {
    headers['x-demo-email'] = user.email;
    headers['x-user-email'] = user.email;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  return headers;
}

export async function fetchPriceLists(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/pricing/lists${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchPriceListById(user, id) {
  return apiFetch(`/pricing/lists/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createPriceList(user, data) {
  return apiFetch('/pricing/lists', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updatePriceList(user, id, data) {
  return apiFetch(`/pricing/lists/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function submitPriceList(user, id) {
  return apiFetch(`/pricing/lists/${id}/submit`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function approvePriceList(user, id) {
  return apiFetch(`/pricing/lists/${id}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function rejectPriceList(user, id, reason) {
  return apiFetch(`/pricing/lists/${id}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function deactivatePriceList(user, id) {
  return apiFetch(`/pricing/lists/${id}/deactivate`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function addPriceRule(user, priceListId, ruleData) {
  return apiFetch(`/pricing/lists/${priceListId}/rules`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(ruleData)
  });
}

export async function deletePriceRule(user, priceListId, ruleId) {
  return apiFetch(`/pricing/lists/${priceListId}/rules/${ruleId}`, {
    method: 'DELETE',
    headers: getAuthHeaders(user)
  });
}

export async function importPriceRulesCsv(user, priceListId, data) {
  return apiFetch(`/pricing/lists/${priceListId}/rules/csv-import`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchPricingSettings(user) {
  return apiFetch('/pricing/settings', {
    headers: getAuthHeaders(user)
  });
}

export async function updatePricingSettings(user, data) {
  return apiFetch('/pricing/settings', {
    method: 'PATCH',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function resolvePricePreview(user, data) {
  return apiFetch('/pricing/resolve', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

