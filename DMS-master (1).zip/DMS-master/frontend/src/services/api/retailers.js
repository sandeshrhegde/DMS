import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  if (user?.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
  }
  return headers;
}

export async function fetchRetailers(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/retailers${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchPendingApprovals(user) {
  return apiFetch('/retailers/pending-approvals', {
    headers: getAuthHeaders(user)
  });
}

export async function fetchRetailerById(user, id) {
  return apiFetch(`/retailers/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function proposeRetailer(user, data) {
  return apiFetch('/retailers', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateRetailer(user, id, data) {
  return apiFetch(`/retailers/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function approveRetailer(user, id) {
  return apiFetch(`/retailers/${id}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function rejectRetailer(user, id, reason) {
  return apiFetch(`/retailers/${id}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function approveRetailerChange(user, id, changeId) {
  return apiFetch(`/retailers/${id}/changes/${changeId}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function rejectRetailerChange(user, id, changeId, reason) {
  return apiFetch(`/retailers/${id}/changes/${changeId}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function checkCanOrder(user, id) {
  return apiFetch(`/retailers/${id}/can-order`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchRetailerAudit(user, id) {
  return apiFetch(`/retailers/${id}/audit`, {
    headers: getAuthHeaders(user)
  });
}

export async function validateGstinOnline(user, gstin) {
  return apiFetch(`/retailers/validate-gstin?gstin=${encodeURIComponent(gstin)}`, {
    headers: getAuthHeaders(user)
  });
}

