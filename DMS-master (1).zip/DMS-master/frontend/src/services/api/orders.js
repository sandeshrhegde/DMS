import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
    headers['x-user-role'] = user.role;
  }
  if (user?.email) {
    headers['x-demo-email'] = user.email;
    headers['x-user-email'] = user.email;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  if (user?.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
    headers['x-dealer-id'] = user.dealerId;
  }
  return headers;
}

export async function fetchOrders(user, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/orders${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchOrderById(user, id) {
  return apiFetch(`/orders/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function previewOrderCalculation(user, data) {
  return apiFetch('/orders/calculate', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function checkAvailableStock(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/orders/stock-check${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createDraftOrder(user, data) {
  return apiFetch('/orders', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function updateDraftOrder(user, id, data) {
  return apiFetch(`/orders/${id}`, {
    method: 'PUT',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function submitOrder(user, id) {
  return apiFetch(`/orders/${id}/submit`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function approveOrder(user, id) {
  return apiFetch(`/orders/${id}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function cancelOrder(user, id, reason) {
  return apiFetch(`/orders/${id}/cancel`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

