import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
    headers['x-user-role'] = user.role;
  }
  if (user?.email) {
    headers['x-demo-email'] = user.email;
    headers['x-user-email'] = user.email;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  if (user?.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
  }
  return headers;
}

export async function fetchWarehouses(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/warehouses${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createWarehouse(user, data) {
  return apiFetch('/inventory/warehouses', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchAsns(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/asns${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchInTransitAsns(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/asns/in-transit${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchAsnById(user, id) {
  return apiFetch(`/inventory/asns/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createPrimaryDispatchAsn(user, data) {
  return apiFetch('/inventory/asns', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function confirmGrn(user, asnId, data) {
  return apiFetch(`/inventory/asns/${asnId}/grn`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchClaims(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/claims${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function approveClaim(user, claimId, notes = '') {
  return apiFetch(`/inventory/claims/${claimId}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ notes })
  });
}

export async function rejectClaim(user, claimId, notes = '') {
  return apiFetch(`/inventory/claims/${claimId}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ notes })
  });
}

export async function fetchStockOnHand(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/stock-on-hand${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchStockLedger(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/stock-ledger${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function updateMinStockThreshold(user, data) {
  return apiFetch('/inventory/min-stock', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchTransfers(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/transfers${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createTransfer(user, data) {
  return apiFetch('/inventory/transfers', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchPurchaseReturns(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/purchase-returns${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createPurchaseReturn(user, data) {
  return apiFetch('/inventory/purchase-returns', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchStockAudits(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/audits${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createStockAudit(user, data) {
  return apiFetch('/inventory/audits', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function approveStockAudit(user, auditId) {
  return apiFetch(`/inventory/audits/${auditId}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function rejectStockAudit(user, auditId, reason = '') {
  return apiFetch(`/inventory/audits/${auditId}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function fetchInventoryAnalytics(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/analytics${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createOpeningStock(user, data) {
  return apiFetch('/inventory/opening-stock', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

// ==================== SAP S/4HANA NEW INVENTORY API ====================

export async function fetchSapInventory(user, params = {}) {
  const query = new URLSearchParams(params).toString();
  return apiFetch(`/inventory/sap-inventory${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchSapConfig(user) {
  return apiFetch('/inventory/sap-inventory/config', {
    headers: getAuthHeaders(user)
  });
}

export async function updateSapConfig(user, data) {
  return apiFetch('/inventory/sap-inventory/config', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function inwardSapItem(user, data) {
  return apiFetch('/inventory/sap-inventory/inward-to-asn', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}


