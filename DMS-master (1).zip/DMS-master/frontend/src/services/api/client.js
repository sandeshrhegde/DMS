const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:4000/api';

/**
 * Custom Error class for structured API errors with status code and payload details.
 */
export class ApiError extends Error {
  constructor(message, { status = 500, statusText = 'Error', data = null, path = '', url = '' } = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.statusText = statusText;
    this.data = data;
    this.path = path;
    this.url = url;
    this.isNetworkError = status === 0;
  }
}

/**
 * Global API error listeners for telemetry, toasts, or monitoring.
 */
const apiErrorListeners = new Set();

export function onApiError(listener) {
  apiErrorListeners.add(listener);
  return () => apiErrorListeners.delete(listener);
}

function notifyApiError(error) {
  for (const listener of apiErrorListeners) {
    try {
      listener(error);
    } catch (e) {
      console.error('[DMS apiFetch listener error]:', e);
    }
  }
}

/**
 * Universal safe API fetch wrapper with global exception handling.
 */
export async function apiFetch(path, options = {}) {
  const url = `${API_BASE_URL}${path}`;
  let response;

  try {
    response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });
  } catch (networkErr) {
    const isOffline = typeof navigator !== 'undefined' && !navigator.onLine;
    const msg = isOffline
      ? 'You appear to be offline. Please check your internet connection.'
      : `Cannot connect to DMS server at ${API_BASE_URL}. Please ensure the backend is running and reachable.`;

    const apiErr = new ApiError(msg, {
      status: 0,
      statusText: 'Network Error',
      data: null,
      path,
      url
    });

    notifyApiError(apiErr);
    throw apiErr;
  }

  if (!response.ok) {
    let errorData = null;
    let errorMessage = null;

    try {
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        errorData = await response.json();
        errorMessage =
          errorData?.error ||
          errorData?.message ||
          (Array.isArray(errorData?.errors) ? errorData.errors.join('; ') : null);
      } else {
        const text = await response.text();
        if (text && text.length < 250) {
          errorMessage = text;
        }
      }
    } catch {
      // Body reading or parsing failed, fallback below
    }

    if (!errorMessage) {
      if (response.status === 401) {
        errorMessage = 'Your session has expired or authentication is required. Please sign in again.';
      } else if (response.status === 403) {
        errorMessage = 'You do not have permission to perform this action.';
      } else if (response.status === 404) {
        errorMessage = `The requested resource was not found (${path}).`;
      } else if (response.status === 409) {
        errorMessage = 'A conflict occurred with existing data.';
      } else if (response.status >= 500) {
        errorMessage = `Internal server error (${response.status}). Please try again shortly.`;
      } else {
        errorMessage = `Request failed with HTTP status ${response.status} (${response.statusText || 'Error'}).`;
      }
    }

    const apiErr = new ApiError(errorMessage, {
      status: response.status,
      statusText: response.statusText,
      data: errorData,
      path,
      url
    });

    notifyApiError(apiErr);
    throw apiErr;
  }

  // Handle 204 No Content
  if (response.status === 204) {
    return null;
  }

  try {
    return await response.json();
  } catch {
    return null;
  }
}

/**
 * Extracts a human-readable message from any unknown error object.
 */
export function getErrorMessage(error, fallback = 'An unexpected error occurred.') {
  if (!error) return fallback;
  if (typeof error === 'string') return error;
  if (error instanceof ApiError) return error.message;
  if (error instanceof Error) return error.message;
  if (typeof error === 'object' && error.message) return String(error.message);
  return fallback;
}
