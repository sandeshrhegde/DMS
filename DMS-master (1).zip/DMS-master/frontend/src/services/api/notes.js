import { apiFetch } from './client.js';

function getAuthHeaders(user) {
  const headers = {};
  if (user?.role) {
    headers['x-demo-role'] = user.role;
    headers['x-user-role'] = user.role;
  }
  if (user?.email) {
    headers['x-demo-email'] = user.email;
    headers['x-user-email'] = user.email;
  }
  if (user?.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }
  if (user?.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
    headers['x-dealer-id'] = user.dealerId;
  }
  return headers;
}

export async function fetchNotes(user, params = {}) {
  const cleanParams = Object.fromEntries(
    Object.entries(params).filter(([_, v]) => v !== undefined && v !== null && v !== '')
  );
  const query = new URLSearchParams(cleanParams).toString();
  return apiFetch(`/notes${query ? `?${query}` : ''}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchNoteById(user, id) {
  return apiFetch(`/notes/${id}`, {
    headers: getAuthHeaders(user)
  });
}

export async function fetchReturnableInvoice(user, invoiceId) {
  return apiFetch(`/notes/returnable-invoice/${invoiceId}`, {
    headers: getAuthHeaders(user)
  });
}

export async function createSalesReturn(user, data) {
  return apiFetch('/notes/sales-return', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function createFinancialNote(user, data) {
  return apiFetch('/notes/financial', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchPendingApprovals(user) {
  return apiFetch('/notes/approvals/pending', {
    headers: getAuthHeaders(user)
  });
}

export async function approveNote(user, id) {
  return apiFetch(`/notes/${id}/approve`, {
    method: 'POST',
    headers: getAuthHeaders(user)
  });
}

export async function rejectNote(user, id, reason) {
  return apiFetch(`/notes/${id}/reject`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify({ reason })
  });
}

export async function allocateCreditNote(user, id, data) {
  return apiFetch(`/notes/${id}/allocate`, {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchPendingQuarantine(user) {
  return apiFetch('/notes/quarantine/pending', {
    headers: getAuthHeaders(user)
  });
}

export async function inspectQuarantine(user, data) {
  return apiFetch('/notes/quarantine/inspect', {
    method: 'POST',
    headers: getAuthHeaders(user),
    body: JSON.stringify(data)
  });
}

export async function fetchNotePrintData(user, id) {
  return apiFetch(`/notes/${id}/print`, {
    headers: getAuthHeaders(user)
  });
}

