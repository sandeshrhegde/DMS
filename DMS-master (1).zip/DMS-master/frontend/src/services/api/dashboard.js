import { apiFetch } from './client.js';
import { BRAND_DASHBOARD_PATH, DEALER_DASHBOARD_PATH, isBrandRole } from '@dms/shared';

/**
 * Fetches dashboard data based on current user role.
 * Works seamlessly with both mock and real backend implementations.
 */
export async function fetchDashboard(user) {
  const path = isBrandRole(user.role) ? BRAND_DASHBOARD_PATH : DEALER_DASHBOARD_PATH;

  const headers = {
    'x-demo-role': user.role
  };

  if (user.token) {
    headers.Authorization = `Bearer ${user.token}`;
  }

  if (user.dealerId) {
    headers['x-tenant-id'] = user.dealerId;
  }

  return apiFetch(path, { headers });
}

