import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchSapInventory,
  fetchSapConfig,
  updateSapConfig,
  inwardSapItem
} from '../services/api/inventory.js';

export default function NewInventoryPage({ user }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState({
    items: [],
    stats: {},
    source: 'PRODUCTION_SIMULATION',
    isLiveSap: false,
    endpointUrl: '',
    liveFetchError: null
  });

  // Selected Division: 'FABRIC' or 'GARMENT'
  const [division, setDivision] = useState('FABRIC');
  const [brandFilter, setBrandFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals state
  const [selectedItemForInspect, setSelectedItemForInspect] = useState(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [configForm, setConfigForm] = useState({
    endpointUrl: '',
    apiKey: '',
    timeoutMs: 10000
  });
  const [configStatus, setConfigStatus] = useState(null);
  const [configSaving, setConfigSaving] = useState(false);
  const [inwardingId, setInwardingId] = useState(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState(null);

  // Load SAP Inventory Data
  const loadInventory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchSapInventory(user, {
        division,
        brand: brandFilter,
        search: searchTerm
      });
      setData(res);
    } catch (err) {
      setError(err.message || 'Failed to load SAP S/4HANA inventory feed.');
    } finally {
      setLoading(false);
    }
  }, [user, division, brandFilter, searchTerm]);

  // Load SAP Configuration Status
  const loadConfig = useCallback(async () => {
    try {
      const cfg = await fetchSapConfig(user);
      setConfigStatus(cfg);
      setConfigForm({
        endpointUrl: cfg.endpointUrl || '',
        apiKey: '',
        timeoutMs: cfg.timeoutMs || 10000
      });
    } catch {
      // Ignore background config lookup failure
    }
  }, [user]);

  useEffect(() => {
    loadInventory();
  }, [loadInventory]);

  useEffect(() => {
    loadConfig();
  }, [loadConfig]);

  // Handle Save Endpoint Config
  const handleSaveConfig = async (e) => {
    e.preventDefault();
    setConfigSaving(true);
    try {
      const res = await updateSapConfig(user, configForm);
      alert(res.message || 'SAP S/4HANA configuration updated successfully!');
      setShowConfigModal(false);
      loadConfig();
      loadInventory();
    } catch (err) {
      alert('Failed to save SAP configuration: ' + err.message);
    } finally {
      setConfigSaving(false);
    }
  };

  // Handle Inward to DMS ASN
  const handleInwardItem = async (item) => {
    if (!confirm(`Do you want to inward SAP Invoice #${item.billNo} (${item.article}) into DMS In-Transit ASN?`)) {
      return;
    }
    setInwardingId(item.id);
    setActionSuccessMsg(null);
    try {
      const res = await inwardSapItem(user, { item });
      setActionSuccessMsg(`✅ Success! Invoice ${item.billNo} (${item.article}) is now In-Transit ASN in DMS (ASN ID: ${res.asnId.slice(0, 8)}...).`);
    } catch (err) {
      alert('Failed to inward SAP item: ' + err.message);
    } finally {
      setInwardingId(null);
    }
  };

  // Filter items specifically for the selected division
  const items = (data.items || []).filter((item) => item.type === division);

  // Compute metrics specifically for the active division
  const isFabric = division === 'FABRIC';
  const totalMtrs = isFabric ? items.reduce((sum, i) => sum + (i.qty || 0), 0) : 0;
  const totalPcs = !isFabric ? items.reduce((sum, i) => sum + (i.qty || 0), 0) : 0;
  const totalValue = items.reduce((sum, i) => sum + (i.totalAmount || 0), 0);

  return (
    <div className="master-page" style={{ padding: '24px 32px', maxWidth: '1600px', margin: '0 auto' }}>
      
      {/* 1. Page Header */}
      <div className="page-header-row" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <h2 style={{ margin: 0, fontFamily: 'Playfair Display, serif', fontSize: '1.75rem', fontWeight: 700, color: '#1E293B' }}>
              SAP S/4HANA Primary Inward Feed
            </h2>
            <span
              style={{
                fontSize: '0.75rem',
                fontWeight: 700,
                padding: '4px 10px',
                borderRadius: '20px',
                background: data.isLiveSap ? '#10B981' : '#C5A059',
                color: '#FFFFFF',
                letterSpacing: '0.5px'
              }}
            >
              {data.isLiveSap ? '● LIVE SAP S/4HANA' : '⚡ PRODUCTION SIMULATION'}
            </span>
          </div>
          <p className="page-desc" style={{ margin: '4px 0 0', color: '#64748B', fontSize: '0.9rem' }}>
            Direct Primary Inward Feed from SAP S/4HANA (Fabric Lumps &amp; Ready-Made Garments).
          </p>
        </div>

        <div className="header-actions" style={{ display: 'flex', gap: '10px' }}>
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={loadInventory}
            disabled={loading}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            🔄 {loading ? 'Fetching...' : 'Refresh Feed'}
          </button>
          <button
            type="button"
            className="btn btn-outline btn-sm"
            style={{ borderColor: '#C5A059', color: '#855E0E', fontWeight: 600 }}
            onClick={() => setShowConfigModal(true)}
          >
            ⚙️ Configure SAP Endpoint URL
          </button>
        </div>
      </div>

      {/* 2. Success Alert */}
      {actionSuccessMsg && (
        <div
          className="alert alert-success"
          style={{
            background: '#ECFDF5',
            color: '#065F46',
            border: '1px solid #A7F3D0',
            padding: '12px 18px',
            borderRadius: '8px',
            marginBottom: '16px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}
        >
          <span>{actionSuccessMsg}</span>
          <button className="close-btn" style={{ color: '#065F46' }} onClick={() => setActionSuccessMsg(null)}>✕</button>
        </div>
      )}

      {/* 3. Division Selection & Filter Controls Card */}
      <div
        className="card"
        style={{
          background: '#FFFFFF',
          border: '1px solid #E2E8F0',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '20px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
        }}
      >
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'flex-end', justifyContent: 'space-between' }}>
          
          {/* Main Dropdown to select Fabric or Garment */}
          <div style={{ flex: '1 1 320px', maxWidth: '440px' }}>
            <label style={{ display: 'block', fontSize: '0.85rem', fontWeight: 700, color: '#1E293B', marginBottom: '6px' }}>
              Select Product Division *
            </label>
            <select
              value={division}
              onChange={(e) => setDivision(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 14px',
                borderRadius: '8px',
                border: '2px solid #C5A059',
                fontSize: '0.95rem',
                fontWeight: 600,
                background: '#FFFDF9',
                color: '#1E293B',
                cursor: 'pointer',
                outline: 'none',
                boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
              }}
            >
              <option value="FABRIC">🧵 Fabric Division (Cadini / Shirting / Suiting - MTR)</option>
              <option value="GARMENT">👔 Garment Division (Oxemberg / Ready-Made - PCS)</option>
            </select>
          </div>

          {/* Secondary Filters: Brand & Search */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'flex-end' }}>
            <div style={{ minWidth: '180px' }}>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#64748B', marginBottom: '4px' }}>
                Filter Brand
              </label>
              <select
                value={brandFilter}
                onChange={(e) => setBrandFilter(e.target.value)}
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: '6px',
                  border: '1px solid #CBD5E1',
                  fontSize: '0.88rem',
                  background: '#FFFFFF'
                }}
              >
                <option value="">All Brands</option>
                {isFabric ? (
                  <>
                    <option value="CADINI">CADINI</option>
                    <option value="SIYARAM">SIYARAM</option>
                    <option value="J.HAMPSTEAD">J.HAMPSTEAD</option>
                  </>
                ) : (
                  <>
                    <option value="Oxemberg">Oxemberg</option>
                  </>
                )}
              </select>
            </div>

            <div style={{ minWidth: '280px' }}>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: '#64748B', marginBottom: '4px' }}>
                Search SAP Lines
              </label>
              <input
                type="text"
                placeholder={isFabric ? 'Search Article, Shade, Barcode, Bill No...' : 'Search Article, EAN Barcode, Size, Bill No...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{
                  width: '100%',
                  padding: '9px 12px',
                  borderRadius: '6px',
                  border: '1px solid #CBD5E1',
                  fontSize: '0.88rem'
                }}
              />
            </div>
          </div>

        </div>
      </div>

      {/* 4. Styled Division-Specific KPI Cards */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '16px',
          marginBottom: '24px'
        }}
      >
        {isFabric ? (
          <>
            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #C5A059',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                🧵 Fabric Cut Pieces / Lumps
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#1E293B', marginTop: '6px' }}>
                {items.length} Pieces
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Cadini &amp; Siyaram Fabrics
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #C5A059',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                📏 Total Fabric Length
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#855E0E', marginTop: '6px' }}>
                {totalMtrs.toFixed(2)} MTR
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Shirting &amp; Suiting Bolts
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #10B981',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                💰 Total Invoiced Value (₹)
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#10B981', marginTop: '6px' }}>
                ₹{totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Primary SAP Dispatch Total
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #2563EB',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                🏭 Production Plants
              </div>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#1E293B', marginTop: '8px' }}>
                Tarapur &amp; Silvassa
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Siyaram Silk Mills Ltd.
              </div>
            </div>
          </>
        ) : (
          <>
            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #2563EB',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                👔 Total Ready-Made Units
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#2563EB', marginTop: '6px' }}>
                {totalPcs} PCS
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Oxemberg Apparel Dispatches
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #2563EB',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                🏷️ Product Range
              </div>
              <div style={{ fontSize: '1.15rem', fontWeight: 700, color: '#1E293B', marginTop: '8px' }}>
                Casual Trouser, Shirts, Denim
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Season: AW26
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #10B981',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                💰 Total Invoiced Value (₹)
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: 800, color: '#10B981', marginTop: '6px' }}>
                ₹{totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Garment Primary Invoice Total
              </div>
            </div>

            <div
              style={{
                background: '#FFFFFF',
                border: '1px solid #E2E8F0',
                borderTop: '4px solid #E21E25',
                borderRadius: '12px',
                padding: '18px 20px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.02)'
              }}
            >
              <div style={{ fontSize: '0.8rem', fontWeight: 600, color: '#64748B', textTransform: 'uppercase' }}>
                🏢 Dispatch Origin
              </div>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#1E293B', marginTop: '8px' }}>
                Apparel Complex
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94A3B8', marginTop: '4px' }}>
                Central Logistics Hub
              </div>
            </div>
          </>
        )}
      </div>

      {/* 5. Division Data Table (Shows ONLY Fabric columns when Fabric selected, ONLY Garment columns when Garment selected) */}
      <div
        className="card"
        style={{
          background: '#FFFFFF',
          border: '1px solid #E2E8F0',
          borderRadius: '12px',
          padding: 0,
          overflow: 'hidden',
          boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
        }}
      >
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #E2E8F0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h4 style={{ margin: 0, color: '#1E293B', fontSize: '1.05rem', fontWeight: 700 }}>
            {isFabric ? '🧵 SAP S/4HANA Fabric Lines' : '👔 SAP S/4HANA Garment Lines'} ({items.length})
          </h4>
          <span style={{ fontSize: '0.85rem', color: '#64748B' }}>
            Showing {items.length} records for <strong>{isFabric ? 'Fabric Division' : 'Garment Division'}</strong>
          </span>
        </div>

        {loading ? (
          <div style={{ padding: '50px', textAlign: 'center', color: '#64748B' }}>
            ⏳ Fetching SAP S/4HANA {isFabric ? 'Fabric' : 'Garment'} feeds...
          </div>
        ) : error ? (
          <div style={{ padding: '30px', textAlign: 'center', color: '#E21E25' }}>
            ❌ {error}
          </div>
        ) : items.length === 0 ? (
          <div style={{ padding: '50px', textAlign: 'center', color: '#64748B' }}>
            No SAP dispatch records found for {isFabric ? 'Fabric' : 'Garment'} division.
          </div>
        ) : isFabric ? (
          /* ==========================================================
             FABRIC TABLE: Specific Fabric Columns
             ========================================================== */
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Bill No &amp; Date</th>
                  <th>Customer (Sold-To)</th>
                  <th>Brand &amp; Division</th>
                  <th>Article &amp; Pattern</th>
                  <th>Shade (para1)</th>
                  <th>Cut Length (para2)</th>
                  <th>Piece Itemcode / Barcode</th>
                  <th>Batch</th>
                  <th>Fibre Composition</th>
                  <th>Bill Rate (₹)</th>
                  <th>MRP (₹)</th>
                  <th>Tax</th>
                  <th>Total (₹)</th>
                  <th>Transporter / LR</th>
                  <th style={{ textAlign: 'center' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.billNo}</strong>
                      <div style={{ fontSize: '0.75rem', color: '#64748B' }}>{item.billDate}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{item.partyName}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748B' }}>Code: {item.partyCode}</div>
                    </td>
                    <td>
                      <strong style={{ color: '#C5A059' }}>{item.brand}</strong>
                      <div style={{ fontSize: '0.75rem', color: '#64748B' }}>{item.division}</div>
                    </td>
                    <td>
                      <strong>{item.article}</strong>
                      {item.rawSapData?.pattern && (
                        <div style={{ fontSize: '0.75rem', color: '#64748B' }}>Pattern: {item.rawSapData.pattern}</div>
                      )}
                    </td>
                    <td>
                      <span className="status-pill" style={{ background: '#FEF3C7', color: '#92400E', fontWeight: 700 }}>
                        {item.shade}
                      </span>
                    </td>
                    <td>
                      <strong style={{ color: '#1E293B', fontSize: '0.95rem' }}>
                        {item.sizeOrLength}
                      </strong>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontWeight: 600, fontSize: '0.85rem' }}>
                        {item.barcode}
                      </span>
                      {item.serialNo && item.serialNo !== item.barcode && (
                        <div style={{ fontSize: '0.72rem', color: '#64748B' }}>Serial: {item.serialNo}</div>
                      )}
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>{item.batch}</span>
                    </td>
                    <td>
                      <span className="status-pill" style={{ background: '#ECFDF5', color: '#065F46', fontSize: '0.75rem' }}>
                        {item.fibre}
                      </span>
                    </td>
                    <td>₹{item.rate?.toFixed(2)}</td>
                    <td>₹{item.mrp?.toFixed(2)}</td>
                    <td>
                      <div style={{ fontSize: '0.8rem', color: '#64748B' }}>
                        {item.taxRate}% (₹{item.taxAmount?.toFixed(2)})
                      </div>
                    </td>
                    <td>
                      <strong>₹{item.totalAmount?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
                    </td>
                    <td>
                      <div style={{ fontSize: '0.8rem' }}>{item.transporter || 'Direct'}</div>
                      {item.lrNo && (
                        <div style={{ fontSize: '0.75rem', color: '#64748B' }}>LR: {item.lrNo}</div>
                      )}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                        <button
                          type="button"
                          className="btn btn-outline btn-xs"
                          onClick={() => setSelectedItemForInspect(item)}
                          title="Inspect all 50+ SAP S/4HANA fields"
                        >
                          🔍 Inspect
                        </button>
                        <button
                          type="button"
                          className="btn btn-primary btn-xs"
                          onClick={() => handleInwardItem(item)}
                          disabled={inwardingId === item.id}
                          title="Inward this invoice into DMS In-Transit ASN"
                        >
                          {inwardingId === item.id ? 'Inwarding...' : '📥 Inward ASN'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          /* ==========================================================
             GARMENT TABLE: Specific Ready-Made Garment Columns
             ========================================================== */
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Bill No &amp; Date</th>
                  <th>Customer (Bill-To)</th>
                  <th>Brand</th>
                  <th>Product</th>
                  <th>Article (MAKTX)</th>
                  <th>EAN Barcode</th>
                  <th>Material Code (MATNR)</th>
                  <th>Shade</th>
                  <th>Size</th>
                  <th>Fit</th>
                  <th>Fabric Type</th>
                  <th>Qty</th>
                  <th>Ex-Mill (₹)</th>
                  <th>Wholesale (₹)</th>
                  <th>MRP (₹)</th>
                  <th>Challan No</th>
                  <th style={{ textAlign: 'center' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <strong>{item.billNo}</strong>
                      <div style={{ fontSize: '0.75rem', color: '#64748B' }}>{item.billDate}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{item.partyName}</div>
                    </td>
                    <td>
                      <strong style={{ color: '#2563EB' }}>{item.brand}</strong>
                    </td>
                    <td>
                      <span className="status-pill" style={{ background: '#DBEAFE', color: '#1E40AF', fontWeight: 600 }}>
                        {item.category}
                      </span>
                    </td>
                    <td>
                      <strong>{item.article}</strong>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: '0.85rem' }}>
                        {item.barcode}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '0.8rem', color: '#4B5563' }}>
                        {item.itemCode}
                      </span>
                    </td>
                    <td>
                      <span className="status-pill" style={{ background: '#F3F4F6', color: '#374151', fontWeight: 600 }}>
                        {item.shade}
                      </span>
                    </td>
                    <td>
                      <strong style={{ fontSize: '1rem', color: '#1E293B' }}>{item.sizeOrLength}</strong>
                    </td>
                    <td>
                      <span className="status-pill" style={{ background: '#EFF6FF', color: '#1D4ED8', fontSize: '0.75rem' }}>
                        {item.fit}
                      </span>
                    </td>
                    <td>{item.fibre}</td>
                    <td>
                      <strong style={{ fontSize: '1rem', color: '#2563EB' }}>{item.qty} PCS</strong>
                    </td>
                    <td>₹{item.rate?.toFixed(2)}</td>
                    <td>₹{item.wholesaleRate?.toFixed(2)}</td>
                    <td>₹{item.mrp?.toFixed(2)}</td>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{item.challanNo}</span>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                        <button
                          type="button"
                          className="btn btn-outline btn-xs"
                          onClick={() => setSelectedItemForInspect(item)}
                          title="Inspect all 50+ SAP S/4HANA fields"
                        >
                          🔍 Inspect
                        </button>
                        <button
                          type="button"
                          className="btn btn-primary btn-xs"
                          onClick={() => handleInwardItem(item)}
                          disabled={inwardingId === item.id}
                          title="Inward this invoice into DMS In-Transit ASN"
                        >
                          {inwardingId === item.id ? 'Inwarding...' : '📥 Inward ASN'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 6. Modal: Inspect Raw SAP S/4HANA Fields (Fiori Inspector) */}
      {selectedItemForInspect && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '900px', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header" style={{ flexShrink: 0 }}>
              <div>
                <h3 style={{ margin: 0, fontFamily: 'Playfair Display, serif' }}>
                  🔍 SAP S/4HANA Line Inspector: {selectedItemForInspect.article}
                </h3>
                <span style={{ fontSize: '0.85rem', color: '#64748B' }}>
                  Bill No: <strong>{selectedItemForInspect.billNo}</strong> | Division: <strong>{selectedItemForInspect.type}</strong>
                </span>
              </div>
              <button className="close-btn" onClick={() => setSelectedItemForInspect(null)}>✕</button>
            </div>

            <div className="modal-body" style={{ overflowY: 'auto', flexGrow: 1, padding: '20px' }}>
              
              {/* Inspection Sections */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '15px', marginBottom: '20px' }}>
                <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#C5A059', fontWeight: 700 }}>📦 Document &amp; Dispatch</h5>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Bill No:</strong> {selectedItemForInspect.billNo}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Bill Date:</strong> {selectedItemForInspect.billDate}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Challan / PGI:</strong> {selectedItemForInspect.challanNo}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Customer:</strong> {selectedItemForInspect.partyName} ({selectedItemForInspect.partyCode})</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Plant / Place:</strong> {selectedItemForInspect.plant}</div>
                </div>

                <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#2563EB', fontWeight: 700 }}>🏷️ Material &amp; Specification</h5>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Brand:</strong> {selectedItemForInspect.brand}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Article:</strong> {selectedItemForInspect.article}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Barcode:</strong> {selectedItemForInspect.barcode}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Shade:</strong> {selectedItemForInspect.shade}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Size / Length:</strong> {selectedItemForInspect.sizeOrLength}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Batch / Lot:</strong> {selectedItemForInspect.batch}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Fibre:</strong> {selectedItemForInspect.fibre}</div>
                </div>

                <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#E21E25', fontWeight: 700 }}>💰 Commercials &amp; GST</h5>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Quantity:</strong> {selectedItemForInspect.qty} {selectedItemForInspect.uom}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Bill Rate / Ex-Mill:</strong> ₹{selectedItemForInspect.rate}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Wholesale Rate:</strong> ₹{selectedItemForInspect.wholesaleRate}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>MRP:</strong> ₹{selectedItemForInspect.mrp}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>HSN Code:</strong> {selectedItemForInspect.hsnCode}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>GST Rate:</strong> {selectedItemForInspect.taxRate}%</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Tax Amount:</strong> ₹{selectedItemForInspect.taxAmount}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Line Total:</strong> ₹{selectedItemForInspect.totalAmount}</div>
                </div>

                <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '8px', border: '1px solid #E2E8F0' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#10B981', fontWeight: 700 }}>🚚 Logistics &amp; Transport</h5>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>Transporter:</strong> {selectedItemForInspect.transporter}</div>
                  <div style={{ fontSize: '0.85rem', marginBottom: '4px' }}><strong>LR Number:</strong> {selectedItemForInspect.lrNo}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>LR Date:</strong> {selectedItemForInspect.lrDate}</div>
                </div>
              </div>

              {/* Raw SAP S/4HANA JSON payload */}
              <div style={{ marginTop: '15px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <strong style={{ fontSize: '0.9rem', color: '#1E293B' }}>
                    Complete Raw SAP JSON Payload (50+ Fields):
                  </strong>
                  <button
                    type="button"
                    className="btn btn-outline btn-xs"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(selectedItemForInspect.rawSapData, null, 2));
                      alert('Copied raw SAP JSON to clipboard!');
                    }}
                  >
                    📋 Copy JSON
                  </button>
                </div>
                <pre
                  style={{
                    background: '#0F172A',
                    color: '#F8FAFC',
                    padding: '14px',
                    borderRadius: '8px',
                    fontSize: '0.78rem',
                    overflowX: 'auto',
                    maxHeight: '220px',
                    fontFamily: 'monospace'
                  }}
                >
                  {JSON.stringify(selectedItemForInspect.rawSapData, null, 2)}
                </pre>
              </div>
            </div>

            <div className="modal-footer" style={{ flexShrink: 0, justifyContent: 'space-between' }}>
              <button type="button" className="btn btn-secondary" onClick={() => setSelectedItemForInspect(null)}>
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  const itm = selectedItemForInspect;
                  setSelectedItemForInspect(null);
                  handleInwardItem(itm);
                }}
              >
                📥 Inward to DMS In-Transit ASN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. Modal: SAP S/4HANA Endpoint Settings */}
      {showConfigModal && (
        <div className="modal-backdrop">
          <div className="modal-card" style={{ maxWidth: '650px' }}>
            <div className="modal-header">
              <h3>⚙️ Configure SAP S/4HANA Endpoint URL</h3>
              <button className="close-btn" onClick={() => setShowConfigModal(false)}>✕</button>
            </div>
            <form onSubmit={handleSaveConfig}>
              <div className="modal-body form-grid">
                <div className="grid-span-full">
                  <p style={{ margin: '0 0 12px', fontSize: '0.88rem', color: '#4B5563' }}>
                    Enter the live SAP S/4HANA OData / REST service URL provided by your SAP team.
                    When empty, DMS automatically runs in <strong>Production-Fidelity Simulation Mode</strong> using real Siyaram's Fabric and Garment schemas.
                  </p>
                </div>

                <div className="form-field grid-span-full">
                  <label>SAP S/4HANA Service Endpoint URL</label>
                  <input
                    type="url"
                    placeholder="https://sap-api.siyaram.com/sap/opu/odata/sap/API_BILLING_DOCUMENT_SRV/A_BillingDocument"
                    value={configForm.endpointUrl}
                    onChange={(e) => setConfigForm({ ...configForm, endpointUrl: e.target.value })}
                  />
                  <small style={{ color: '#6B7280' }}>
                    Leave blank to use the built-in production simulation feeds.
                  </small>
                </div>

                <div className="form-field grid-span-full">
                  <label>SAP API Key / Bearer Token (Optional)</label>
                  <input
                    type="password"
                    placeholder="e.g. Bearer eyJhbGciOi..."
                    value={configForm.apiKey}
                    onChange={(e) => setConfigForm({ ...configForm, apiKey: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Request Timeout (Milliseconds)</label>
                  <input
                    type="number"
                    min="1000"
                    step="1000"
                    value={configForm.timeoutMs}
                    onChange={(e) => setConfigForm({ ...configForm, timeoutMs: Number(e.target.value) })}
                  />
                </div>

                {configStatus && (
                  <div className="grid-span-full" style={{ background: '#F8FAFC', padding: '12px 16px', borderRadius: '6px', border: '1px solid #E2E8F0' }}>
                    <div style={{ fontSize: '0.85rem' }}>
                      Status: <strong>{configStatus.isConfigured ? '🟢 Custom SAP Endpoint Configured' : '🟡 Using Production Simulation'}</strong>
                    </div>
                    {configStatus.lastUpdated && (
                      <div style={{ fontSize: '0.78rem', color: '#64748B', marginTop: '2px' }}>
                        Last Configured: {new Date(configStatus.lastUpdated).toLocaleString()}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowConfigModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={configSaving}>
                  {configSaving ? 'Saving & Probing...' : 'Save & Connect SAP URL'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

export { NewInventoryPage };

