import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchRetailers,
  fetchPendingApprovals,
  proposeRetailer,
  updateRetailer,
  approveRetailer,
  rejectRetailer,
  approveRetailerChange,
  rejectRetailerChange,
  fetchRetailerAudit
} from '../services/api/retailers.js';
import { fetchGeoNodes } from '../services/api/masters.js';
import { isBrandRole } from '@dms/shared';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

export function RetailersPage({ user }) {
  const isBrand = isBrandRole(user.role);

  // Brand view tabs: 'pending' | 'directory'
  const [activeTab, setActiveTab] = useState(isBrand ? 'pending' : 'directory');

  // Data states
  const [retailers, setRetailers] = useState([]);
  const [total, setTotal] = useState(0);
  const [pendingData, setPendingData] = useState({ proposedRetailers: [], pendingChangesRetailers: [] });
  const [geoNodes, setGeoNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters & Search
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Modals
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingRetailer, setEditingRetailer] = useState(null);
  const [formData, setFormData] = useState({
    legalName: '',
    tradeName: '',
    gstin: '',
    isUnregistered: false,
    pan: '',
    mobile: '',
    billingAddress: '',
    shippingAddress: '',
    stateCode: '27',
    geoNodeId: '',
    retailerClass: 'C',
    channelType: 'MBO',
    creditLimit: 100000,
    creditDays: 30
  });
  const [formError, setFormError] = useState(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [duplicateWarnings, setDuplicateWarnings] = useState([]);

  // Reject Prompt Modal
  const [rejectingItem, setRejectingItem] = useState(null); // { type: 'retailer' | 'change', retailerId, changeId }
  const [rejectReason, setRejectReason] = useState('');
  const [rejectSubmitting, setRejectSubmitting] = useState(false);

  // Audit Modal
  const [auditRetailer, setAuditRetailer] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [auditLoading, setAuditLoading] = useState(false);

  // Load GeoNodes once for dropdown
  useEffect(() => {
    fetchGeoNodes(user).then((res) => {
      if (res?.nodes) setGeoNodes(res.nodes);
    }).catch(() => {});
  }, [user]);

  // Load Main Retailers List
  const loadRetailers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      if (isBrand && activeTab === 'pending') {
        const pending = await fetchPendingApprovals(user);
        setPendingData(pending);
      } else {
        const data = await fetchRetailers(user, { search, status: statusFilter });
        setRetailers(data.retailers || []);
        setTotal(data.total || 0);
      }
    } catch (err) {
      setError(err.message || 'Failed to load retailers.');
    } finally {
      setLoading(false);
    }
  }, [user, isBrand, activeTab, search, statusFilter]);

  useEffect(() => {
    loadRetailers();
  }, [loadRetailers]);

  // Form Handlers
  const handleOpenCreate = () => {
    setEditingRetailer(null);
    setDuplicateWarnings([]);
    setFormData({
      legalName: '',
      tradeName: '',
      gstin: '',
      isUnregistered: false,
      pan: '',
      mobile: '',
      billingAddress: '',
      shippingAddress: '',
      stateCode: '27',
      geoNodeId: geoNodes.find((n) => n.type === 'CLUSTER')?.id || '',
      retailerClass: 'C',
      channelType: 'MBO',
      creditLimit: 100000,
      creditDays: 30
    });
    setFormError(null);
    setShowFormModal(true);
  };

  const handleOpenEdit = (ret) => {
    setEditingRetailer(ret);
    setDuplicateWarnings([]);
    setFormData({
      legalName: ret.legalName,
      tradeName: ret.tradeName || '',
      gstin: ret.gstin || '',
      isUnregistered: ret.isUnregistered || false,
      pan: ret.pan || '',
      mobile: ret.mobile,
      billingAddress: ret.billingAddress,
      shippingAddress: ret.shippingAddress,
      stateCode: ret.stateCode,
      geoNodeId: ret.geoNodeId || '',
      retailerClass: ret.retailerClass,
      channelType: ret.channelType,
      creditLimit: ret.creditLimit,
      creditDays: ret.creditDays
    });
    setFormError(null);
    setShowFormModal(true);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setFormSubmitting(true);
    setFormError(null);
    setDuplicateWarnings([]);

    try {
      if (editingRetailer) {
        const res = await updateRetailer(user, editingRetailer.id, formData);
        if (res.duplicateWarnings && res.duplicateWarnings.length > 0) {
          setDuplicateWarnings(res.duplicateWarnings);
        }
      } else {
        const res = await proposeRetailer(user, formData);
        if (res.duplicateWarnings && res.duplicateWarnings.length > 0) {
          setDuplicateWarnings(res.duplicateWarnings);
        }
      }
      setShowFormModal(false);
      loadRetailers();
    } catch (err) {
      setFormError(err.message || 'Failed to save retailer.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Approval Handlers (Brand Admin)
  const handleApproveRetailer = async (id) => {
    try {
      await approveRetailer(user, id);
      loadRetailers();
    } catch (err) {
      alert(err.message || 'Failed to approve retailer.');
    }
  };

  const handleOpenRejectRetailer = (id) => {
    setRejectingItem({ type: 'retailer', retailerId: id });
    setRejectReason('');
  };

  const handleApproveChange = async (retailerId, changeId) => {
    try {
      await approveRetailerChange(user, retailerId, changeId);
      loadRetailers();
    } catch (err) {
      alert(err.message || 'Failed to approve change request.');
    }
  };

  const handleOpenRejectChange = (retailerId, changeId) => {
    setRejectingItem({ type: 'change', retailerId, changeId });
    setRejectReason('');
  };

  const handleConfirmReject = async (e) => {
    e.preventDefault();
    if (!rejectReason.trim()) {
      return alert('Please enter a rejection reason.');
    }

    setRejectSubmitting(true);
    try {
      if (rejectingItem.type === 'retailer') {
        await rejectRetailer(user, rejectingItem.retailerId, rejectReason);
      } else if (rejectingItem.type === 'change') {
        await rejectRetailerChange(user, rejectingItem.retailerId, rejectingItem.changeId, rejectReason);
      }
      setRejectingItem(null);
      loadRetailers();
    } catch (err) {
      alert(err.message || 'Rejection failed.');
    } finally {
      setRejectSubmitting(false);
    }
  };

  // Audit Logs Modal
  const handleOpenAudit = async (ret) => {
    setAuditRetailer(ret);
    setAuditLoading(true);
    try {
      const res = await fetchRetailerAudit(user, ret.id);
      setAuditLogs(res.logs || []);
    } catch (err) {
      alert(err.message || 'Failed to load audit history.');
    } finally {
      setAuditLoading(false);
    }
  };

  return (
    <div className="master-page retailers-page">
      <div className="page-header-row">
        <div>
          <h2>Retailer Partners & Approval Workflow</h2>
          <p className="page-desc">
            {isBrand
              ? 'Review dealer retailer proposals, manage approval queues, inspect cross-dealer duplicates, and approve territory/credit change requests.'
              : 'Propose retail partners, track brand approval status, and manage commercial credit limits.'}
          </p>
        </div>

        <div className="header-actions">
          {!isBrand && (
            <button className="btn btn-primary" onClick={handleOpenCreate}>
              + Propose New Retailer
            </button>
          )}
          <button className="btn btn-secondary" onClick={loadRetailers}>
            ↻ Refresh
          </button>
        </div>
      </div>

      {/* Brand Admin Tab Bar */}
      {isBrand && (
        <div className="brand-tabs-bar">
          <button
            className={`tab-btn ${activeTab === 'pending' ? 'active' : ''}`}
            onClick={() => setActiveTab('pending')}
          >
            📋 Pending Approvals Queue
            {(pendingData.totalPending || 0) > 0 && (
              <span className="tab-badge-alert">{pendingData.totalPending}</span>
            )}
          </button>
          <button
            className={`tab-btn ${activeTab === 'directory' ? 'active' : ''}`}
            onClick={() => setActiveTab('directory')}
          >
            🏢 All Network Retailers
          </button>
        </div>
      )}

      {/* Search Bar for Directory View */}
      {(!isBrand || activeTab === 'directory') && (
        <div className="search-filter-bar">
          <input
            type="text"
            className="search-input"
            placeholder="Search by legal name, trade name, GSTIN, PAN, or mobile…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{ padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
          >
            <option value="">All Statuses</option>
            <option value="PROPOSED">PROPOSED (Pending Approval)</option>
            <option value="APPROVED">APPROVED (Order Eligible)</option>
            <option value="REJECTED">REJECTED</option>
          </select>

          {(search || statusFilter) && (
            <button
              className="btn btn-outline btn-sm"
              onClick={() => {
                setSearch('');
                setStatusFilter('');
              }}
            >
              Clear
            </button>
          )}
        </div>
      )}

      {/* BRAND ADMIN: PENDING APPROVALS QUEUE */}
      {isBrand && activeTab === 'pending' ? (
        <div className="approval-queue-container">
          {loading ? (
            <div className="loading-card">
              <div className="spinner" />
              <p>Loading approval queue…</p>
            </div>
          ) : pendingData.totalPending === 0 ? (
            <div className="empty-card">
              <div className="empty-icon">✅</div>
              <h3>Approval Queue Is Clear!</h3>
              <p>There are no retailer proposals or change requests currently pending Brand review.</p>
            </div>
          ) : (
            <div className="approval-sections">
              {/* Section 1: New Proposals */}
              {pendingData.proposedRetailers.length > 0 && (
                <div className="queue-section">
                  <div className="section-header">
                    <h3>New Retailer Proposals ({pendingData.proposedRetailers.length})</h3>
                    <small>Review credit limits and KYC credentials proposed by dealers</small>
                  </div>

                  <div className="queue-grid">
                    {pendingData.proposedRetailers.map((ret) => (
                      <article key={ret.id} className="approval-card">
                        <div className="card-top">
                          <div>
                            <span className="status-pill status-low">PROPOSED</span>
                            <h4 className="retailer-name">{ret.legalName}</h4>
                            {ret.tradeName && <small className="trade-sub">Trade: {ret.tradeName}</small>}
                          </div>
                          <span className="dealer-attribution">
                            By: <strong>{ret.dealer?.name}</strong> ({ret.dealer?.code})
                          </span>
                        </div>

                        {/* Inline Duplicate Warnings Banner */}
                        {ret.duplicateWarnings && ret.duplicateWarnings.length > 0 && (
                          <div className="duplicate-alert-box">
                            <div className="dup-icon">⚠️</div>
                            <div>
                              <strong>Duplicate Flagged ({ret.duplicateWarnings.length} Match):</strong>
                              <ul className="dup-list">
                                {ret.duplicateWarnings.map((w, wIdx) => (
                                  <li key={wIdx}>
                                    <strong>{w.field.toUpperCase()}</strong>: {w.value} matches retailer{' '}
                                    <em>"{w.matchedRetailerName}"</em> under dealer{' '}
                                    <strong>{w.dealerName}</strong> ({w.status})
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        )}

                        <div className="details-grid">
                          <div>
                            <span className="prop-label">GSTIN:</span>
                            {ret.isUnregistered ? (
                              <span className="unreg-pill">Unregistered</span>
                            ) : (
                              <code>{ret.gstin}</code>
                            )}
                          </div>
                          <div>
                            <span className="prop-label">PAN:</span>
                            <code>{ret.pan || '—'}</code>
                          </div>
                          <div>
                            <span className="prop-label">Mobile:</span>
                            <span>{ret.mobile}</span>
                          </div>
                          <div>
                            <span className="prop-label">Territory:</span>
                            <span>{ret.geoNode?.name || 'Unassigned'} ({ret.geoNode?.type || '—'})</span>
                          </div>
                          <div>
                            <span className="prop-label">Class / Channel:</span>
                            <span>Class {ret.retailerClass} • {ret.channelType}</span>
                          </div>
                          <div>
                            <span className="prop-label">Proposed Credit:</span>
                            <strong>{inrFormat.format(ret.creditLimit)}</strong> ({ret.creditDays} days)
                          </div>
                        </div>

                        <div className="address-snippet">
                          <small><strong>Billing:</strong> {ret.billingAddress}</small>
                        </div>

                        <div className="card-actions-bar">
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={() => handleOpenAudit(ret)}
                          >
                            📜 Audit
                          </button>
                          <div className="btn-group">
                            <button
                              className="btn btn-danger-outline btn-sm"
                              onClick={() => handleOpenRejectRetailer(ret.id)}
                            >
                              ✕ Reject
                            </button>
                            <button
                              className="btn btn-primary btn-sm"
                              onClick={() => handleApproveRetailer(ret.id)}
                            >
                              ✓ Approve Retailer
                            </button>
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                </div>
              )}

              {/* Section 2: Pending Change Requests on Approved Retailers */}
              {pendingData.pendingChangesRetailers.length > 0 && (
                <div className="queue-section">
                  <div className="section-header">
                    <h3>
                      Pending Change Requests on Approved Retailers (
                      {pendingData.pendingChangesRetailers.length})
                    </h3>
                    <small>
                      Changes to GSTIN, Credit Limit, or Geography requiring re-approval
                    </small>
                  </div>

                  <div className="queue-grid">
                    {pendingData.pendingChangesRetailers.map((ret) => {
                      const req = ret.pendingChangeRequest;
                      const changes = req?.changes || {};

                      return (
                        <article key={ret.id} className="approval-card change-req-card">
                          <div className="card-top">
                            <div>
                              <span className="status-pill status-billable">CURRENT: APPROVED</span>
                              <h4 className="retailer-name">{ret.legalName}</h4>
                              <small className="trade-sub">Dealer: {ret.dealer?.name}</small>
                            </div>
                            <span className="change-indicator-pill">Re-Approval Required</span>
                          </div>

                          <div className="comparison-table-wrapper">
                            <h5>Requested Changes vs Current Live Values:</h5>
                            <table className="comparison-table">
                              <thead>
                                <tr>
                                  <th>Attribute</th>
                                  <th>Current Live Approved Value</th>
                                  <th>Requested New Value</th>
                                </tr>
                              </thead>
                              <tbody>
                                {changes.creditLimit !== undefined && (
                                  <tr>
                                    <td><strong>Credit Limit</strong></td>
                                    <td>{inrFormat.format(ret.creditLimit)}</td>
                                    <td>
                                      <strong className="changed-val">
                                        {inrFormat.format(changes.creditLimit)}
                                      </strong>
                                    </td>
                                  </tr>
                                )}

                                {changes.gstin !== undefined && (
                                  <tr>
                                    <td><strong>GSTIN</strong></td>
                                    <td>{ret.gstin || 'Unregistered'}</td>
                                    <td>
                                      <strong className="changed-val">
                                        {changes.gstin || 'Unregistered'}
                                      </strong>
                                    </td>
                                  </tr>
                                )}

                                {changes.geoNodeId !== undefined && (
                                  <tr>
                                    <td><strong>Territory / Cluster</strong></td>
                                    <td>{ret.geoNode?.name || 'Unassigned'}</td>
                                    <td>
                                      <strong className="changed-val">
                                        {req?.geoNodeDetails?.name || changes.geoNodeId}
                                      </strong>
                                    </td>
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>

                          <div className="card-actions-bar">
                            <button
                              className="btn btn-secondary btn-sm"
                              onClick={() => handleOpenAudit(ret)}
                            >
                              📜 Audit
                            </button>
                            <div className="btn-group">
                              <button
                                className="btn btn-danger-outline btn-sm"
                                onClick={() => handleOpenRejectChange(ret.id, req.id)}
                              >
                                ✕ Reject Changes
                              </button>
                              <button
                                className="btn btn-primary btn-sm"
                                onClick={() => handleApproveChange(ret.id, req.id)}
                              >
                                ✓ Approve & Apply Changes
                              </button>
                            </div>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        /* ALL RETAILERS DIRECTORY VIEW (For Dealers & Brand Directory Tab) */
        <div className="table-card">
          <div className="table-meta-bar">
            <span>
              Showing {retailers.length} of <strong>{total}</strong> retailer{total === 1 ? '' : 's'}
            </span>
          </div>

          {loading ? (
            <div className="loading-card">
              <div className="spinner" />
              <p>Loading retailers…</p>
            </div>
          ) : retailers.length === 0 ? (
            <div className="empty-card">
              <div className="empty-icon">🏪</div>
              <h3>No Retailers Found</h3>
              <p>Propose a new retailer partner to get started.</p>
              {!isBrand && (
                <button className="btn btn-primary" onClick={handleOpenCreate}>
                  + Propose First Retailer
                </button>
              )}
            </div>
          ) : (
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Retailer Legal Name</th>
                    {isBrand && <th>Dealership</th>}
                    <th>Status</th>
                    <th>Order Eligibility</th>
                    <th>GSTIN / PAN</th>
                    <th>Mobile</th>
                    <th>Territory Cluster</th>
                    <th>Credit Limit & Terms</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {retailers.map((ret) => {
                    const isApproved = ret.status === 'APPROVED';
                    const isProposed = ret.status === 'PROPOSED';
                    const isRejected = ret.status === 'REJECTED';

                    return (
                      <tr key={ret.id}>
                        <td>
                          <strong>{ret.legalName}</strong>
                          {ret.tradeName && <small className="trade-sub">Trade: {ret.tradeName}</small>}
                          {ret.hasPendingChanges && (
                            <span className="badge-pending-change">Re-approval Pending</span>
                          )}
                        </td>

                        {isBrand && (
                          <td>
                            <strong>{ret.dealer?.name}</strong>
                            <br />
                            <small>{ret.dealer?.code}</small>
                          </td>
                        )}

                        <td>
                          <span
                            className={`status-pill ${
                              isApproved
                                ? 'status-billable'
                                : isProposed
                                ? 'status-low'
                                : 'status-critical'
                            }`}
                          >
                            {ret.status}
                          </span>
                          {isRejected && ret.rejectionReason && (
                            <small className="rejection-reason-hint">
                              Reason: {ret.rejectionReason}
                            </small>
                          )}
                        </td>

                        <td>
                          <span
                            className={`status-pill ${
                              ret.canOrder ? 'status-billable' : 'status-blocked'
                            }`}
                          >
                            {ret.canOrder ? '✓ Order Eligible' : '⛔ Orders Blocked'}
                          </span>
                        </td>

                        <td>
                          {ret.isUnregistered ? (
                            <span className="unreg-pill">Unregistered</span>
                          ) : (
                            <code>{ret.gstin}</code>
                          )}
                          <br />
                          <small>PAN: {ret.pan || '—'}</small>
                        </td>

                        <td>{ret.mobile}</td>

                        <td>
                          {ret.geoNode ? (
                            <span>
                              <strong>{ret.geoNode.name}</strong>
                              <br />
                              <small>{ret.geoNode.type}</small>
                            </span>
                          ) : (
                            <span className="text-muted">Unassigned</span>
                          )}
                        </td>

                        <td>
                          <strong>{inrFormat.format(ret.creditLimit)}</strong>
                          <br />
                          <small>{ret.creditDays} days • Class {ret.retailerClass}</small>
                        </td>

                        <td>
                          <div className="table-action-group">
                            {(!isBrand || ret.status !== 'APPROVED') && (
                              <button
                                className="btn btn-secondary btn-xs"
                                onClick={() => handleOpenEdit(ret)}
                              >
                                Edit
                              </button>
                            )}
                            <button
                              className="btn btn-outline btn-xs"
                              onClick={() => handleOpenAudit(ret)}
                            >
                              Audit
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* PROPOSE / EDIT RETAILER MODAL */}
      {showFormModal && (
        <div className="modal-backdrop" onClick={() => setShowFormModal(false)}>
          <div className="modal-card modal-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h3>{editingRetailer ? `Edit Retailer: ${editingRetailer.legalName}` : 'Propose New Retailer Partner'}</h3>
                <small>
                  {editingRetailer?.status === 'APPROVED'
                    ? 'Note: Modifying GSTIN, Credit Limit, or Geography creates a pending change request requiring Brand re-approval.'
                    : 'Submitted retailer proposals enter the Brand Admin review queue before commercial orders can be placed.'}
                </small>
              </div>
              <button className="close-btn" onClick={() => setShowFormModal(false)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="modal-body form-grid">
              <label className="form-field grid-span-full">
                <span>Legal Business Name *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Apex Automobiles Retail Pvt Ltd"
                  value={formData.legalName}
                  onChange={(e) => setFormData({ ...formData, legalName: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Trade / Display Name:</span>
                <input
                  type="text"
                  placeholder="e.g. Apex Auto Spares"
                  value={formData.tradeName}
                  onChange={(e) => setFormData({ ...formData, tradeName: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Mobile Number (10 digits) *:</span>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9820012345"
                  value={formData.mobile}
                  onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                />
              </label>

              <label className="form-checkbox-label grid-span-full">
                <input
                  type="checkbox"
                  checked={formData.isUnregistered}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setFormData({
                      ...formData,
                      isUnregistered: checked,
                      gstin: checked ? '' : formData.gstin
                    });
                  }}
                />
                <span>Unregistered Entity (No GSTIN)</span>
              </label>

              {!formData.isUnregistered && (
                <label className="form-field">
                  <span>GSTIN (15 Alphanumeric with Checksum) *:</span>
                  <input
                    type="text"
                    required={!formData.isUnregistered}
                    placeholder="e.g. 27AABCT3518Q1ZW"
                    value={formData.gstin}
                    onChange={(e) => {
                      const val = e.target.value.toUpperCase();
                      const panExtracted = val.length >= 12 ? val.slice(2, 12) : formData.pan;
                      setFormData({
                        ...formData,
                        gstin: val,
                        pan: panExtracted
                      });
                    }}
                  />
                  <small className="field-hint">Format: 2 state + 10 PAN + entity + Z + check char</small>
                </label>
              )}

              <label className="form-field">
                <span>Permanent Account Number (PAN) *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. AABCT3518Q"
                  value={formData.pan}
                  onChange={(e) => setFormData({ ...formData, pan: e.target.value.toUpperCase() })}
                />
              </label>

              <label className="form-field grid-span-full">
                <span>Billing Address *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shop 12, Commercial Complex, Link Road"
                  value={formData.billingAddress}
                  onChange={(e) => setFormData({ ...formData, billingAddress: e.target.value })}
                />
              </label>

              <label className="form-field grid-span-full">
                <span>Shipping Address *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Warehouse 3, MIDC Industrial Area"
                  value={formData.shippingAddress}
                  onChange={(e) => setFormData({ ...formData, shippingAddress: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>GST State Code *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. 27"
                  value={formData.stateCode}
                  onChange={(e) => setFormData({ ...formData, stateCode: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Territory Cluster (Geo Node):</span>
                <select
                  value={formData.geoNodeId}
                  onChange={(e) => setFormData({ ...formData, geoNodeId: e.target.value })}
                >
                  <option value="">-- Select Geography Cluster --</option>
                  {geoNodes.map((n) => (
                    <option key={n.id} value={n.id}>
                      [{n.type}] {n.name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="form-field">
                <span>Retailer Class:</span>
                <select
                  value={formData.retailerClass}
                  onChange={(e) => setFormData({ ...formData, retailerClass: e.target.value })}
                >
                  <option value="A">Class A (High Volume)</option>
                  <option value="B">Class B (Standard)</option>
                  <option value="C">Class C (Entry)</option>
                </select>
              </label>

              <label className="form-field">
                <span>Channel Type:</span>
                <select
                  value={formData.channelType}
                  onChange={(e) => setFormData({ ...formData, channelType: e.target.value })}
                >
                  <option value="MBO">Multi-Brand Outlet (MBO)</option>
                  <option value="EBO">Exclusive Brand Outlet (EBO)</option>
                  <option value="ETHNIC">Ethnic Retail</option>
                  <option value="FAST_FASHION">Fast Fashion</option>
                  <option value="OTHER">Other Channel</option>
                </select>
              </label>

              <label className="form-field">
                <span>Proposed Credit Limit (₹):</span>
                <input
                  type="number"
                  min="0"
                  step="5000"
                  value={formData.creditLimit}
                  onChange={(e) => setFormData({ ...formData, creditLimit: parseFloat(e.target.value) || 0 })}
                />
              </label>

              <label className="form-field">
                <span>Credit Days:</span>
                <input
                  type="number"
                  min="0"
                  value={formData.creditDays}
                  onChange={(e) => setFormData({ ...formData, creditDays: parseInt(e.target.value, 10) || 0 })}
                />
              </label>

              {formError && <div className="error-alert grid-span-full">{formError}</div>}

              {duplicateWarnings.length > 0 && (
                <div className="duplicate-alert-box grid-span-full">
                  <div className="dup-icon">⚠️</div>
                  <div>
                    <strong>Cross-Dealer Duplicate Warning:</strong>
                    <ul className="dup-list">
                      {duplicateWarnings.map((w, i) => (
                        <li key={i}>{w.message}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              <div className="modal-footer grid-span-full">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowFormModal(false)}
                  disabled={formSubmitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={formSubmitting}>
                  {formSubmitting
                    ? 'Submitting…'
                    : editingRetailer
                    ? 'Save & Submit Changes'
                    : 'Propose Retailer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REJECTION REASON PROMPT MODAL */}
      {rejectingItem && (
        <div className="modal-backdrop" onClick={() => setRejectingItem(null)}>
          <div className="modal-card modal-sm" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>
                {rejectingItem.type === 'retailer' ? 'Reject Retailer Proposal' : 'Reject Change Request'}
              </h3>
              <button className="close-btn" onClick={() => setRejectingItem(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmReject} className="modal-body">
              <label className="form-field">
                <span>Rejection Reason *:</span>
                <textarea
                  required
                  rows={4}
                  placeholder="Explain why this proposal or change request is being rejected (e.g. Invalid billing address, GSTIN registration inactive, or territory overlap)…"
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  style={{
                    padding: '10px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    fontFamily: 'inherit',
                    fontSize: '13px'
                  }}
                  autoFocus
                />
              </label>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setRejectingItem(null)}
                  disabled={rejectSubmitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-danger-outline" disabled={rejectSubmitting}>
                  {rejectSubmitting ? 'Rejecting…' : 'Confirm Rejection'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AUDIT LOG TIMELINE MODAL */}
      {auditRetailer && (
        <div className="modal-backdrop" onClick={() => setAuditRetailer(null)}>
          <div className="modal-card modal-md" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h3>Audit History: {auditRetailer.legalName}</h3>
                <small>Immutable chronological log of proposals, edits, and approval decisions</small>
              </div>
              <button className="close-btn" onClick={() => setAuditRetailer(null)}>
                ✕
              </button>
            </div>

            <div className="modal-body">
              {auditLoading ? (
                <div className="loading-card">
                  <div className="spinner" />
                  <p>Loading audit timeline…</p>
                </div>
              ) : auditLogs.length === 0 ? (
                <p>No audit events recorded yet.</p>
              ) : (
                <div className="audit-timeline">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="timeline-item">
                      <div className="timeline-badge-circle" />
                      <div className="timeline-content">
                        <div className="timeline-head">
                          <span className="timeline-action">{log.action}</span>
                          <span className="timeline-date">
                            {new Date(log.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <div className="timeline-actor">
                          By: <strong>{log.performedByEmail || 'User'}</strong> ({log.performedByRole})
                        </div>
                        {log.details && (
                          <pre className="timeline-json">
                            {JSON.stringify(log.details, null, 2)}
                          </pre>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setAuditRetailer(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

