import React, { useState, useEffect, useMemo } from 'react';
import {
  fetchCollections,
  fetchCollectionReceipt,
  recordCollection,
  bounceCheque,
  fetchRetailerLedgerData,
  fetchRetailerOpenInvoices,
  fetchDealerOutstandingOverview
} from '../services/api/billing.js';
import { fetchRetailers } from '../services/api/retailers.js';
import { fetchDealers } from '../services/api/masters.js';
import {
  allocatePaymentFifo,
  PAYMENT_MODES,
  COLLECTION_STATUSES,
  isBrandRole
} from '@dms/shared';

export function CollectionsPage({ user, initialTab = 'overview', initialRetailerId = null }) {
  const isBrand = isBrandRole(user.role);
  const [dealers, setDealers] = useState([]);
  const [selectedDealerId, setSelectedDealerId] = useState('');

  // Load Dealers if Brand Admin
  useEffect(() => {
    if (isBrand) {
      fetchDealers(user)
        .then((res) => {
          const list = res.dealers || res || [];
          setDealers(list);
          if (list.length > 0 && !selectedDealerId) {
            const demo = list.find((d) => d.code === 'DEMO-001') || list[0];
            setSelectedDealerId(demo.id);
          }
        })
        .catch((err) => console.error('Failed to load dealers for collections:', err));
    }
  }, [isBrand, user]);

  const [activeTab, setActiveTab] = useState(initialTab); // 'overview' | 'collections' | 'record' | 'ledger'
  const [retailers, setRetailers] = useState([]);
  const [loadingRetailers, setLoadingRetailers] = useState(false);

  // Collections state
  const [collections, setCollections] = useState([]);
  const [loadingCollections, setLoadingCollections] = useState(false);
  const [collectionFilter, setCollectionFilter] = useState({ mode: '', status: '', search: '' });

  // Outstanding Overview state
  const [overviewData, setOverviewData] = useState(null);
  const [loadingOverview, setLoadingOverview] = useState(false);
  const [overviewSearch, setOverviewSearch] = useState('');
  const [overviewFilter, setOverviewFilter] = useState(''); // '' | 'overdue' | 'exceeded' | 'has_balance'

  // Selected Retailer for Ledger View
  const [selectedRetailerId, setSelectedRetailerId] = useState(initialRetailerId);
  const [ledgerData, setLedgerData] = useState(null);
  const [loadingLedger, setLoadingLedger] = useState(false);
  const [ledgerSubTab, setLedgerSubTab] = useState('open-items'); // 'open-items' | 'statement'

  // Record Payment Form state
  const [formData, setFormData] = useState({
    retailerId: initialRetailerId || '',
    date: new Date().toISOString().slice(0, 10),
    mode: PAYMENT_MODES.CHEQUE,
    amount: '',
    reference: '',
    chequeDate: new Date().toISOString().slice(0, 10),
    bankName: '',
    collectedBy: user?.name || 'Dealership Cashier',
    notes: '',
    autoAllocateFifo: true
  });
  const [openInvoicesForForm, setOpenInvoicesForForm] = useState([]);
  const [loadingOpenInvoices, setLoadingOpenInvoices] = useState(false);
  const [manualAllocations, setManualAllocations] = useState({}); // { [invoiceId]: amount }
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');

  // Receipt Modal state
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [receiptData, setReceiptData] = useState(null);
  const [loadingReceipt, setLoadingReceipt] = useState(false);

  // Bounce Modal state
  const [bounceModalOpen, setBounceModalOpen] = useState(false);
  const [bouncingCollection, setBouncingCollection] = useState(null);
  const [bounceReason, setBounceReason] = useState('Insufficient funds / signature mismatch');
  const [bounceCharge, setBounceCharge] = useState(500);
  const [submittingBounce, setSubmittingBounce] = useState(false);
  const [bounceError, setBounceError] = useState('');

  // Global message / error banner
  const [globalError, setGlobalError] = useState('');

  // Load retailers list on mount or dealer change
  useEffect(() => {
    async function loadRetailersList() {
      try {
        setLoadingRetailers(true);
        const params = { status: 'APPROVED' };
        if (isBrand && selectedDealerId) {
          params.dealerId = selectedDealerId;
        }
        const res = await fetchRetailers(user, params);
        const list = res.retailers || res || [];
        setRetailers(list);
        if (list.length > 0) {
          setFormData((prev) => ({ ...prev, retailerId: list[0].id }));
          setSelectedRetailerId(list[0].id);
        } else {
          setFormData((prev) => ({ ...prev, retailerId: '' }));
          setSelectedRetailerId('');
        }
      } catch (err) {
        console.error('Failed to load retailers:', err);
      } finally {
        setLoadingRetailers(false);
      }
    }
    loadRetailersList();
  }, [user, isBrand, selectedDealerId]);

  // Load collections when collections tab is active or dealer change
  useEffect(() => {
    if (activeTab === 'collections') {
      loadCollectionsList();
    } else if (activeTab === 'overview') {
      loadOutstandingOverview();
    } else if (activeTab === 'ledger' && selectedRetailerId) {
      loadLedgerStatement(selectedRetailerId);
    }
  }, [activeTab, selectedRetailerId, selectedDealerId]);

  // Load open invoices whenever retailerId in payment form changes or dealer change
  useEffect(() => {
    if (formData.retailerId) {
      loadOpenInvoicesForRetailer(formData.retailerId);
    } else {
      setOpenInvoicesForForm([]);
      setManualAllocations({});
    }
  }, [formData.retailerId, selectedDealerId]);

  async function loadCollectionsList() {
    try {
      setLoadingCollections(true);
      setGlobalError('');
      const params = {};
      if (collectionFilter.mode) params.mode = collectionFilter.mode;
      if (collectionFilter.status) params.status = collectionFilter.status;
      if (isBrand && selectedDealerId) params.dealerId = selectedDealerId;
      const res = await fetchCollections(user, params);
      setCollections(res.collections || []);
    } catch (err) {
      setGlobalError(err.message || 'Failed to load collections list.');
    } finally {
      setLoadingCollections(false);
    }
  }

  async function loadOutstandingOverview() {
    try {
      setLoadingOverview(true);
      setGlobalError('');
      const params = {};
      if (overviewSearch) params.search = overviewSearch;
      if (overviewFilter) params.filter = overviewFilter;
      if (isBrand && selectedDealerId) params.dealerId = selectedDealerId;
      const data = await fetchDealerOutstandingOverview(user, params);
      setOverviewData(data);
    } catch (err) {
      setGlobalError(err.message || 'Failed to load outstanding overview.');
    } finally {
      setLoadingOverview(false);
    }
  }

  async function loadLedgerStatement(retailerId) {
    if (!retailerId) return;
    try {
      setLoadingLedger(true);
      setGlobalError('');
      const params = {};
      if (isBrand && selectedDealerId) params.dealerId = selectedDealerId;
      const data = await fetchRetailerLedgerData(user, retailerId, params);
      setLedgerData(data);
    } catch (err) {
      setGlobalError(err.message || 'Failed to load retailer ledger.');
    } finally {
      setLoadingLedger(false);
    }
  }

  async function loadOpenInvoicesForRetailer(retailerId) {
    try {
      setLoadingOpenInvoices(true);
      const params = {};
      if (isBrand && selectedDealerId) params.dealerId = selectedDealerId;
      const res = await fetchRetailerOpenInvoices(user, retailerId, params);
      const invs = res.openInvoices || [];
      setOpenInvoicesForForm(invs);

      // Pre-fill manual allocations with 0
      const initialManual = {};
      invs.forEach((inv) => {
        initialManual[inv.id] = '';
      });
      setManualAllocations(initialManual);
    } catch (err) {
      console.error('Failed to load open invoices:', err);
    } finally {
      setLoadingOpenInvoices(false);
    }
  }

  // Live calculation of payment allocations
  const paymentBreakdown = useMemo(() => {
    const numericAmount = Math.round(Number(formData.amount || 0) * 100) / 100;
    if (numericAmount <= 0 || openInvoicesForForm.length === 0) {
      return {
        allocations: [],
        allocatedAmount: 0,
        advanceAmount: numericAmount > 0 ? numericAmount : 0,
        isValid: numericAmount > 0
      };
    }

    if (formData.autoAllocateFifo) {
      try {
        const res = allocatePaymentFifo(numericAmount, openInvoicesForForm);
        return {
          ...res,
          isValid: true
        };
      } catch (err) {
        return { allocations: [], allocatedAmount: 0, advanceAmount: 0, isValid: false, error: err.message };
      }
    } else {
      // Manual Allocation
      let totalAllocated = 0;
      const allocations = [];
      let hasOverAllocation = false;

      for (const inv of openInvoicesForForm) {
        const allocAmt = Math.round(Number(manualAllocations[inv.id] || 0) * 100) / 100;
        if (allocAmt > 0) {
          const openBal = inv.openBalance;
          if (allocAmt > openBal + 0.01) {
            hasOverAllocation = true;
          }
          totalAllocated = Math.round((totalAllocated + allocAmt) * 100) / 100;
          allocations.push({
            invoiceId: inv.id,
            invoiceNo: inv.invoiceNo,
            amount: allocAmt,
            openBalanceBefore: openBal,
            openBalanceAfter: Math.max(0, Math.round((openBal - allocAmt) * 100) / 100)
          });
        }
      }

      const advance = Math.max(0, Math.round((numericAmount - totalAllocated) * 100) / 100);
      const isExceeded = totalAllocated > numericAmount + 0.01;

      return {
        allocations,
        allocatedAmount: totalAllocated,
        advanceAmount: advance,
        isValid: !hasOverAllocation && !isExceeded,
        hasOverAllocation,
        isExceeded
      };
    }
  }, [formData.amount, formData.autoAllocateFifo, openInvoicesForForm, manualAllocations]);

  // Handle Recording Payment
  async function handleRecordPayment(e) {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    const numericAmount = Number(formData.amount);
    if (!numericAmount || numericAmount <= 0) {
      return setFormError('Please enter a valid payment amount greater than zero.');
    }
    if (!formData.retailerId) {
      return setFormError('Please select a retailer.');
    }
    if (!formData.autoAllocateFifo && !paymentBreakdown.isValid) {
      return setFormError('Please adjust manual allocations: cannot over-allocate open invoice balances or exceed total payment amount.');
    }

    try {
      setSubmittingPayment(true);
      const payload = {
        retailerId: formData.retailerId,
        date: formData.date,
        mode: formData.mode,
        amount: numericAmount,
        reference: formData.reference,
        chequeDate: formData.mode === PAYMENT_MODES.CHEQUE ? formData.chequeDate : null,
        bankName: formData.mode === PAYMENT_MODES.CHEQUE ? formData.bankName : null,
        collectedBy: formData.collectedBy,
        notes: formData.notes,
        autoAllocateFifo: formData.autoAllocateFifo,
        allocations: formData.autoAllocateFifo
          ? []
          : paymentBreakdown.allocations.map((a) => ({ invoiceId: a.invoiceId, amount: a.amount })),
        ...(isBrand && selectedDealerId ? { dealerId: selectedDealerId } : {})
      };

      const result = await recordCollection(user, payload);
      setFormSuccess(`Payment ${result.collectionNo} recorded successfully! Allocated: ₹${result.allocatedAmount.toFixed(2)}${result.advanceAmount > 0 ? `, Advance: ₹${result.advanceAmount.toFixed(2)}` : ''}`);

      // Refresh open invoices and overview
      loadOpenInvoicesForRetailer(formData.retailerId);

      // Offer receipt view
      handleViewReceipt(result.id);

      // Reset form amount
      setFormData((prev) => ({
        ...prev,
        amount: '',
        reference: '',
        notes: ''
      }));
    } catch (err) {
      setFormError(err.message || 'Failed to record payment collection.');
    } finally {
      setSubmittingPayment(false);
    }
  }

  // Handle Receipt Modal
  async function handleViewReceipt(collectionId) {
    try {
      setLoadingReceipt(true);
      setReceiptModalOpen(true);
      const data = await fetchCollectionReceipt(user, collectionId);
      setReceiptData(data);
    } catch (err) {
      setGlobalError(err.message || 'Failed to fetch receipt data.');
      setReceiptModalOpen(false);
    } finally {
      setLoadingReceipt(false);
    }
  }

  // Open Bounce Modal
  function handleOpenBounceModal(col) {
    setBouncingCollection(col);
    setBounceReason('Insufficient funds / signature mismatch');
    setBounceCharge(col.dealer?.bounceCharge || 500);
    setBounceError('');
    setBounceModalOpen(true);
  }

  // Submit Cheque Bounce
  async function handleSubmitBounce(e) {
    e.preventDefault();
    if (!bouncingCollection) return;
    try {
      setSubmittingBounce(true);
      setBounceError('');
      await bounceCheque(user, bouncingCollection.id, {
        reason: bounceReason,
        bounceCharge: Number(bounceCharge) || 0
      });
      setBounceModalOpen(false);
      loadCollectionsList();
      if (activeTab === 'overview') loadOutstandingOverview();
      if (activeTab === 'ledger' && selectedRetailerId) loadLedgerStatement(selectedRetailerId);
    } catch (err) {
      setBounceError(err.message || 'Failed to process cheque bounce.');
    } finally {
      setSubmittingBounce(false);
    }
  }

  // Switch to Ledger view for a specific retailer
  function handleNavigateToLedger(retailerId) {
    setSelectedRetailerId(retailerId);
    setActiveTab('ledger');
  }

  // Switch to Record Payment for a specific retailer
  function handleNavigateToRecordPayment(retailerId) {
    setFormData((prev) => ({ ...prev, retailerId }));
    setActiveTab('record');
  }

  return (
    <div className="collections-module">
      {/* Tab Navigation Bar */}
      <div className="table-meta-bar" style={{ marginBottom: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div className="brand-tabs-bar" style={{ margin: 0 }}>
          <button
            type="button"
            className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
            onClick={() => setActiveTab('overview')}
          >
            📊 Outstanding Overview
          </button>
          <button
            type="button"
            className={`tab-btn ${activeTab === 'collections' ? 'active' : ''}`}
            onClick={() => setActiveTab('collections')}
          >
            💰 Collections & Receipts
          </button>
          <button
            type="button"
            className={`tab-btn ${activeTab === 'record' ? 'active' : ''}`}
            onClick={() => setActiveTab('record')}
          >
            ➕ Record Payment
          </button>
          <button
            type="button"
            className={`tab-btn ${activeTab === 'ledger' ? 'active' : ''}`}
            onClick={() => setActiveTab('ledger')}
          >
            📜 Retailer Ledger
          </button>
        </div>

        {activeTab === 'ledger' && ledgerData && (
          <button
            type="button"
            className="btn btn-primary btn-sm no-print"
            onClick={() => window.print()}
          >
            🖨️ Print Statement
          </button>
        )}
      </div>

      {/* Brand Dealership Scope Selector */}
      {isBrand && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', background: '#FDFBF7', padding: '10px 16px', borderRadius: '8px', border: '1px solid #E7D7B5', marginBottom: '16px' }}>
          <span style={{ fontSize: '13px', fontWeight: 600, color: '#785A18' }}>🏢 Active Dealership Scope:</span>
          <select
            value={selectedDealerId}
            onChange={(e) => setSelectedDealerId(e.target.value)}
            style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #E7D7B5', background: '#fff', fontSize: '13px', fontWeight: 500 }}
          >
            {dealers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
          <span style={{ fontSize: '12px', color: '#64748b', marginLeft: 'auto' }}>
            Brand HQ inspecting dealership collections, open items &amp; retailer ageing.
          </span>
        </div>
      )}

      {globalError && (
        <div className="error" style={{ marginBottom: '16px' }}>
          <strong>Error:</strong> {globalError}
        </div>
      )}

      {/* =========================================================================
          TAB 1: OUTSTANDING OVERVIEW
          ========================================================================= */}
      {activeTab === 'overview' && (
        <section className="overview-tab">
          {loadingOverview && !overviewData ? (
            <div className="loading-card" style={{ padding: '40px', textAlign: 'center', background: '#fff', borderRadius: '12px' }}>
              <div className="spinner" />
              <p>Calculating live dealer outstanding and ageing across all retailers...</p>
            </div>
          ) : overviewData ? (
            <>
              {/* Summary Metric Cards */}
              <div className="kpi-grid" style={{ marginBottom: '24px' }}>
                <div className="kpi-card">
                  <div className="kpi-meta">
                    <span className="kpi-label">TOTAL DEALER OUTSTANDING</span>
                    <span className="kpi-value" style={{ color: '#0f172a' }}>
                      ₹{overviewData.summary.totalOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                    <span className="kpi-subtext">Across {overviewData.summary.totalRetailers} retailers</span>
                  </div>
                </div>

                <div className="kpi-card">
                  <div className="kpi-meta">
                    <span className="kpi-label">TOTAL OVERDUE AMOUNT</span>
                    <span className="kpi-value" style={{ color: overviewData.summary.totalOverdue > 0 ? '#dc2626' : '#16a34a' }}>
                      ₹{overviewData.summary.totalOverdue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                    <span className="kpi-subtext">
                      {overviewData.summary.overdueRetailers} retailer(s) with overdue invoices
                    </span>
                  </div>
                </div>

                <div className="kpi-card">
                  <div className="kpi-meta">
                    <span className="kpi-label">CREDIT LIMIT EXPOSURE</span>
                    <span className="kpi-value" style={{ color: '#E21E25' }}>
                      ₹{overviewData.summary.totalCreditLimit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                    <span className="kpi-subtext">
                      Overall Utilisation: <b>{overviewData.summary.dealerOverallUtilisationPct}%</b>
                    </span>
                  </div>
                </div>
              </div>

              {/* Filter & Search Bar */}
              <div className="filter-card" style={{ marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
                <div style={{ flex: 1, minWidth: '240px' }}>
                  <input
                    type="text"
                    placeholder="Search retailer name, GSTIN, mobile..."
                    value={overviewSearch}
                    onChange={(e) => setOverviewSearch(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && loadOutstandingOverview()}
                    style={{ margin: 0 }}
                  />
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    type="button"
                    className={`btn btn-sm ${overviewFilter === '' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => { setOverviewFilter(''); }}
                  >
                    All Retailers
                  </button>
                  <button
                    type="button"
                    className={`btn btn-sm ${overviewFilter === 'overdue' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => { setOverviewFilter('overdue'); }}
                  >
                    ⚠️ Overdue Only
                  </button>
                  <button
                    type="button"
                    className={`btn btn-sm ${overviewFilter === 'has_balance' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => { setOverviewFilter('has_balance'); }}
                  >
                    Outstanding &gt; 0
                  </button>
                  <button
                    type="button"
                    className={`btn btn-sm ${overviewFilter === 'exceeded' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => { setOverviewFilter('exceeded'); }}
                  >
                    Limit Exceeded
                  </button>
                  <button
                    type="button"
                    className="btn btn-outline btn-sm"
                    onClick={loadOutstandingOverview}
                  >
                    🔄 Refresh
                  </button>
                </div>
              </div>

              {/* Retailers Outstanding Table */}
              <div className="table-card">
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Retailer</th>
                        <th>Class / Channel</th>
                        <th>Credit Limit</th>
                        <th>Current Outstanding</th>
                        <th>Overdue Amount</th>
                        <th>Oldest Invoice</th>
                        <th>Credit Utilisation</th>
                        <th style={{ textAlign: 'right' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {overviewData.retailers.length === 0 ? (
                        <tr>
                          <td colSpan="8" style={{ textAlign: 'center', padding: '32px', color: '#64748b' }}>
                            No retailers match the specified criteria.
                          </td>
                        </tr>
                      ) : (
                        overviewData.retailers.map((ret) => {
                          const isExceeded = ret.creditUtilisationPct > 100;
                          const barColor = isExceeded ? '#ef4444' : ret.creditUtilisationPct > 75 ? '#f59e0b' : '#10b981';

                          return (
                            <tr key={ret.id}>
                              <td>
                                <b>{ret.legalName}</b>
                                {ret.tradeName && <small style={{ display: 'block', color: '#64748b' }}>{ret.tradeName}</small>}
                                <small style={{ display: 'block', color: '#94a3b8' }}>GSTIN: {ret.gstin || 'Unregistered'}</small>
                              </td>
                              <td>
                                <span className="status-badge" style={{ background: '#f1f5f9', color: '#334155' }}>
                                  Class {ret.retailerClass} • {ret.channelType}
                                </span>
                              </td>
                              <td>
                                ₹{ret.creditLimit.toLocaleString()}
                                <small style={{ display: 'block', color: '#64748b' }}>{ret.creditDays} days</small>
                              </td>
                              <td>
                                <b style={{ color: ret.currentOutstanding > 0 ? '#0f172a' : '#16a34a' }}>
                                  {ret.currentOutstanding < 0 ? (
                                    `Adv: ₹${Math.abs(ret.currentOutstanding).toLocaleString()}`
                                  ) : (
                                    `₹${ret.currentOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}`
                                  )}
                                </b>
                              </td>
                              <td>
                                {ret.hasOverdue ? (
                                  <span style={{ color: '#dc2626', fontWeight: 700 }}>
                                    ₹{ret.overdueAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  </span>
                                ) : (
                                  <span style={{ color: '#16a34a' }}>None</span>
                                )}
                              </td>
                              <td>
                                {ret.openInvoicesCount > 0 ? (
                                  <span>{ret.oldestInvoiceDays} days</span>
                                ) : (
                                  <span style={{ color: '#94a3b8' }}>—</span>
                                )}
                              </td>
                              <td style={{ minWidth: '150px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                  <div style={{ flex: 1, height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                                    <div
                                      style={{
                                        width: `${Math.min(100, ret.creditUtilisationPct)}%`,
                                        height: '100%',
                                        background: barColor,
                                        borderRadius: '4px'
                                      }}
                                    />
                                  </div>
                                  <small style={{ fontWeight: 600, color: barColor }}>{ret.creditUtilisationPct}%</small>
                                </div>
                              </td>
                              <td style={{ textAlign: 'right' }}>
                                <div style={{ display: 'inline-flex', gap: '6px' }}>
                                  <button
                                    type="button"
                                    className="btn btn-outline btn-xs"
                                    onClick={() => handleNavigateToRecordPayment(ret.id)}
                                    title="Record payment for this retailer"
                                  >
                                    💵 Pay
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-primary btn-xs"
                                    onClick={() => handleNavigateToLedger(ret.id)}
                                    title="View detailed ledger and statements"
                                  >
                                    📜 Ledger
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          ) : null}
        </section>
      )}

      {/* =========================================================================
          TAB 2: COLLECTIONS LIST
          ========================================================================= */}
      {activeTab === 'collections' && (
        <section className="collections-tab">
          {/* Filter Bar */}
          <div className="filter-card" style={{ marginBottom: '16px', display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ minWidth: '180px' }}>
              <select
                value={collectionFilter.mode}
                onChange={(e) => setCollectionFilter((prev) => ({ ...prev, mode: e.target.value }))}
                style={{ margin: 0 }}
              >
                <option value="">All Payment Modes</option>
                <option value="CHEQUE">Cheque</option>
                <option value="NEFT">NEFT / RTGS</option>
                <option value="UPI">UPI</option>
                <option value="CASH">Cash</option>
              </select>
            </div>

            <div style={{ minWidth: '180px' }}>
              <select
                value={collectionFilter.status}
                onChange={(e) => setCollectionFilter((prev) => ({ ...prev, status: e.target.value }))}
                style={{ margin: 0 }}
              >
                <option value="">All Statuses</option>
                <option value="RECORDED">Recorded (Valid)</option>
                <option value="BOUNCED">Bounced</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>

            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={loadCollectionsList}
            >
              Filter
            </button>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => { setCollectionFilter({ mode: '', status: '', search: '' }); loadCollectionsList(); }}
            >
              Reset
            </button>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              style={{ marginLeft: 'auto' }}
              onClick={() => setActiveTab('record')}
            >
              ➕ Record New Payment
            </button>
          </div>

          {loadingCollections ? (
            <div className="loading-card" style={{ padding: '40px', textAlign: 'center', background: '#fff', borderRadius: '12px' }}>
              <div className="spinner" />
              <p>Loading collection receipts...</p>
            </div>
          ) : (
            <div className="table-card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Receipt No</th>
                      <th>Date</th>
                      <th>Retailer</th>
                      <th>Mode & Ref</th>
                      <th>Amount</th>
                      <th>Allocated</th>
                      <th>Advance</th>
                      <th>Status</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {collections.length === 0 ? (
                      <tr>
                        <td colSpan="9" style={{ textAlign: 'center', padding: '32px', color: '#64748b' }}>
                          No payment collections recorded yet. Click "Record New Payment" to enter a receipt.
                        </td>
                      </tr>
                    ) : (
                      collections.map((col) => {
                        const isBounced = col.status === COLLECTION_STATUSES.BOUNCED;
                        return (
                          <tr key={col.id} style={{ opacity: isBounced ? 0.75 : 1 }}>
                            <td>
                              <b>{col.collectionNo}</b>
                              <small style={{ display: 'block', color: '#64748b' }}>By {col.collectedBy}</small>
                            </td>
                            <td>{new Date(col.date).toLocaleDateString()}</td>
                            <td>
                              <b>{col.retailer?.legalName}</b>
                              {col.retailer?.tradeName && <small style={{ display: 'block', color: '#64748b' }}>{col.retailer.tradeName}</small>}
                            </td>
                            <td>
                              <span className="status-badge" style={{ background: '#FDFBF7', color: '#785A18', border: '1px solid #E7D7B5' }}>
                                {col.mode}
                              </span>
                              {col.reference && <small style={{ display: 'block', color: '#475569', marginTop: '2px' }}>Ref: {col.reference}</small>}
                              {col.bankName && <small style={{ display: 'block', color: '#94a3b8' }}>{col.bankName}</small>}
                            </td>
                            <td>
                              <b style={{ fontSize: '14px', color: isBounced ? '#dc2626' : '#0f172a' }}>
                                ₹{col.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </b>
                            </td>
                            <td>₹{col.allocatedAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                            <td>
                              {col.advanceAmount > 0 ? (
                                <span style={{ color: '#16a34a', fontWeight: 600 }}>
                                  ₹{col.advanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </span>
                              ) : (
                                '—'
                              )}
                            </td>
                            <td>
                              <span
                                className="status-badge"
                                style={{
                                  background: isBounced ? '#fee2e2' : col.status === 'RECORDED' ? '#dcfce7' : '#f1f5f9',
                                  color: isBounced ? '#991b1b' : col.status === 'RECORDED' ? '#166534' : '#475569'
                                }}
                              >
                                {col.status}
                              </span>
                              {isBounced && (
                                <small style={{ display: 'block', color: '#b91c1c', marginTop: '2px' }}>
                                  {col.bounceReason || 'Bounced'}
                                </small>
                              )}
                            </td>
                            <td style={{ textAlign: 'right' }}>
                              <div style={{ display: 'inline-flex', gap: '6px' }}>
                                <button
                                  type="button"
                                  className="btn btn-outline btn-xs"
                                  onClick={() => handleViewReceipt(col.id)}
                                >
                                  🖨️ Receipt
                                </button>
                                {col.mode === PAYMENT_MODES.CHEQUE && col.status === COLLECTION_STATUSES.RECORDED && (
                                  <button
                                    type="button"
                                    className="btn btn-outline btn-xs"
                                    style={{ borderColor: '#fca5a5', color: '#dc2626' }}
                                    onClick={() => handleOpenBounceModal(col)}
                                    title="Mark cheque as bounced and reverse"
                                  >
                                    ⚠️ Bounce
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </section>
      )}

      {/* =========================================================================
          TAB 3: RECORD PAYMENT FORM
          ========================================================================= */}
      {activeTab === 'record' && (
        <section className="record-payment-tab">
          <div className="card" style={{ maxWidth: '900px', margin: '0 auto', padding: '32px' }}>
            <span className="eyebrow">CASH & BANK COLLECTIONS</span>
            <h2>Record Payment Receipt</h2>
            <p style={{ color: '#64748b', marginBottom: '24px' }}>
              Record incoming payment from retailer, allocate to open invoices via FIFO or manual selection, and post real credit to the ledger.
            </p>

            {formError && (
              <div className="error" style={{ marginBottom: '20px' }}>
                {formError}
              </div>
            )}
            {formSuccess && (
              <div className="notice" style={{ marginBottom: '20px', background: '#f0fdf4', borderColor: '#16a34a', color: '#166534' }}>
                {formSuccess}
              </div>
            )}

            <form onSubmit={handleRecordPayment}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px' }}>
                <label>
                  Retailer *
                  <select
                    value={formData.retailerId}
                    onChange={(e) => setFormData((prev) => ({ ...prev, retailerId: e.target.value }))}
                    required
                    disabled={submittingPayment}
                  >
                    <option value="">Select Retailer</option>
                    {retailers.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.legalName} {r.tradeName ? `(${r.tradeName})` : ''} - Credit: ₹{r.creditLimit}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  Payment Date *
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                    required
                    disabled={submittingPayment}
                  />
                </label>

                <label>
                  Payment Mode *
                  <select
                    value={formData.mode}
                    onChange={(e) => setFormData((prev) => ({ ...prev, mode: e.target.value }))}
                    required
                    disabled={submittingPayment}
                  >
                    <option value={PAYMENT_MODES.CHEQUE}>Cheque</option>
                    <option value={PAYMENT_MODES.NEFT}>NEFT / RTGS</option>
                    <option value={PAYMENT_MODES.UPI}>UPI</option>
                    <option value={PAYMENT_MODES.CASH}>Cash</option>
                  </select>
                </label>

                <label>
                  Payment Amount (₹) *
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    placeholder="e.g. 50000"
                    value={formData.amount}
                    onChange={(e) => setFormData((prev) => ({ ...prev, amount: e.target.value }))}
                    required
                    disabled={submittingPayment}
                    style={{ fontWeight: 700, fontSize: '16px' }}
                  />
                </label>
              </div>

              {/* Mode-specific Fields */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '16px', marginTop: '12px' }}>
                <label>
                  Reference / Cheque No / UTR {formData.mode === PAYMENT_MODES.CHEQUE ? '*' : ''}
                  <input
                    type="text"
                    placeholder={formData.mode === PAYMENT_MODES.CHEQUE ? 'Cheque No (e.g. 123456)' : 'UTR / Txn Ref'}
                    value={formData.reference}
                    onChange={(e) => setFormData((prev) => ({ ...prev, reference: e.target.value }))}
                    required={formData.mode === PAYMENT_MODES.CHEQUE}
                    disabled={submittingPayment}
                  />
                </label>

                {formData.mode === PAYMENT_MODES.CHEQUE && (
                  <>
                    <label>
                      Drawer Bank Name
                      <input
                        type="text"
                        placeholder="e.g. HDFC Bank, SBI"
                        value={formData.bankName}
                        onChange={(e) => setFormData((prev) => ({ ...prev, bankName: e.target.value }))}
                        disabled={submittingPayment}
                      />
                    </label>

                    <label>
                      Cheque Date
                      <input
                        type="date"
                        value={formData.chequeDate}
                        onChange={(e) => setFormData((prev) => ({ ...prev, chequeDate: e.target.value }))}
                        disabled={submittingPayment}
                      />
                    </label>
                  </>
                )}

                <label>
                  Collected By
                  <input
                    type="text"
                    placeholder="Collector / Cashier"
                    value={formData.collectedBy}
                    onChange={(e) => setFormData((prev) => ({ ...prev, collectedBy: e.target.value }))}
                    disabled={submittingPayment}
                  />
                </label>
              </div>

              <label style={{ marginTop: '12px' }}>
                Notes / Remarks
                <input
                  type="text"
                  placeholder="Optional payment notes"
                  value={formData.notes}
                  onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
                  disabled={submittingPayment}
                />
              </label>

              {/* Allocation Strategy & Grid */}
              <div style={{ marginTop: '28px', borderTop: '1px solid #e2e8f0', paddingTop: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <div>
                    <h4 style={{ margin: 0, fontSize: '16px', color: '#0f172a' }}>Invoice Allocation Breakdown</h4>
                    <small style={{ color: '#64748b' }}>
                      {openInvoicesForForm.length} unpaid / partially-paid invoice(s) found for this retailer.
                    </small>
                  </div>

                  <label style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', cursor: 'pointer', margin: 0 }}>
                    <input
                      type="checkbox"
                      checked={formData.autoAllocateFifo}
                      onChange={(e) => setFormData((prev) => ({ ...prev, autoAllocateFifo: e.target.checked }))}
                      style={{ width: 'auto', margin: 0 }}
                    />
                    <span style={{ fontSize: '13px', fontWeight: 600 }}>Auto-allocate FIFO (Oldest first)</span>
                  </label>
                </div>

                {loadingOpenInvoices ? (
                  <p style={{ color: '#64748b' }}>Fetching open invoices...</p>
                ) : openInvoicesForForm.length === 0 ? (
                  <div className="notice" style={{ background: '#f8fafc', borderColor: '#cbd5e1', color: '#475569' }}>
                    Retailer has no open invoices. The entire payment amount of <b>₹{formData.amount || '0'}</b> will be safely credited as an <b>On-Account Advance</b>.
                  </div>
                ) : (
                  <div className="table-responsive" style={{ border: '1px solid #e2e8f0', borderRadius: '8px' }}>
                    <table className="data-table" style={{ fontSize: '12px' }}>
                      <thead>
                        <tr>
                          <th>Invoice No</th>
                          <th>Invoice Date</th>
                          <th>Net Total</th>
                          <th>Paid So Far</th>
                          <th>Open Balance</th>
                          <th>Allocated Amount</th>
                          <th>Balance Remaining</th>
                        </tr>
                      </thead>
                      <tbody>
                        {openInvoicesForForm.map((inv) => {
                          const fifoAlloc = paymentBreakdown.allocations.find((a) => a.invoiceId === inv.id);
                          const allocatedAmt = formData.autoAllocateFifo
                            ? (fifoAlloc?.amount || 0)
                            : (Number(manualAllocations[inv.id]) || 0);
                          const balanceAfter = Math.max(0, Math.round((inv.openBalance - allocatedAmt) * 100) / 100);

                          return (
                            <tr key={inv.id}>
                              <td><b>{inv.invoiceNo}</b></td>
                              <td>{new Date(inv.invoiceDate).toLocaleDateString()}</td>
                              <td>₹{inv.netTotal.toLocaleString()}</td>
                              <td>₹{inv.paidAmount.toLocaleString()}</td>
                              <td><b>₹{inv.openBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}</b></td>
                              <td>
                                {formData.autoAllocateFifo ? (
                                  <span style={{ fontWeight: 700, color: allocatedAmt > 0 ? '#16a34a' : '#64748b' }}>
                                    ₹{allocatedAmt.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  </span>
                                ) : (
                                  <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max={inv.openBalance}
                                    placeholder="0.00"
                                    value={manualAllocations[inv.id] || ''}
                                    onChange={(e) => {
                                      const val = e.target.value;
                                      setManualAllocations((prev) => ({
                                        ...prev,
                                        [inv.id]: val
                                      }));
                                    }}
                                    style={{ width: '120px', padding: '6px 8px', margin: 0, fontSize: '12px' }}
                                  />
                                )}
                              </td>
                              <td style={{ color: balanceAfter === 0 ? '#16a34a' : '#334155' }}>
                                {balanceAfter === 0 ? '✓ Paid in Full' : `₹${balanceAfter.toLocaleString(undefined, { minimumFractionDigits: 2 })}`}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Allocation Summary Box */}
                <div style={{ marginTop: '16px', padding: '14px 18px', background: '#f8fafc', borderRadius: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                  <div>
                    <small style={{ color: '#64748b', display: 'block' }}>Payment Summary</small>
                    <span style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>
                      Payment: ₹{Number(formData.amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div>
                    <small style={{ color: '#64748b', display: 'block' }}>Allocated to Invoices</small>
                    <span style={{ fontSize: '15px', fontWeight: 700, color: '#E21E25' }}>
                      ₹{paymentBreakdown.allocatedAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div>
                    <small style={{ color: '#64748b', display: 'block' }}>On-Account Advance</small>
                    <span style={{ fontSize: '15px', fontWeight: 700, color: '#16a34a' }}>
                      ₹{paymentBreakdown.advanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                style={{ width: '100%', marginTop: '24px', padding: '14px' }}
                disabled={submittingPayment}
              >
                {submittingPayment ? 'Posting Collection to Ledger...' : '✓ Record Payment & Post Credit to Ledger'}
              </button>
            </form>
          </div>
        </section>
      )}

      {/* =========================================================================
          TAB 4: RETAILER LEDGER VIEW
          ========================================================================= */}
      {activeTab === 'ledger' && (
        <section className="retailer-ledger-tab">
          {/* Retailer Selector Bar */}
          <div className="filter-card no-print" style={{ marginBottom: '20px', display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
            <label style={{ margin: 0, minWidth: '320px', flex: 1 }}>
              <span style={{ fontSize: '12px', color: '#64748b', display: 'block', marginBottom: '4px' }}>Select Retailer</span>
              <select
                value={selectedRetailerId || ''}
                onChange={(e) => {
                  setSelectedRetailerId(e.target.value);
                  loadLedgerStatement(e.target.value);
                }}
                style={{ margin: 0 }}
              >
                {retailers.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.legalName} {r.tradeName ? `(${r.tradeName})` : ''} - GSTIN: {r.gstin || 'Unreg'}
                  </option>
                ))}
              </select>
            </label>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={() => selectedRetailerId && loadLedgerStatement(selectedRetailerId)}
              >
                🔄 Refresh
              </button>
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={() => {
                  setFormData((prev) => ({ ...prev, retailerId: selectedRetailerId }));
                  setActiveTab('record');
                }}
              >
                💵 Record Payment
              </button>
            </div>
          </div>

          {loadingLedger ? (
            <div className="loading-card" style={{ padding: '40px', textAlign: 'center', background: '#fff', borderRadius: '12px' }}>
              <div className="spinner" />
              <p>Loading retailer ledger statement...</p>
            </div>
          ) : ledgerData ? (
            <div className="ledger-statement-container">
              {/* Dealership & Retailer Header Box */}
              <div className="card" style={{ padding: '24px', marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '16px' }}>
                  <div>
                    <span className="eyebrow">RETAILER ACCOUNT STATEMENT</span>
                    <h2 style={{ margin: '4px 0 2px' }}>{ledgerData.retailer.legalName}</h2>
                    {ledgerData.retailer.tradeName && <p style={{ margin: '0 0 6px', color: '#64748b' }}>Trade Name: {ledgerData.retailer.tradeName}</p>}
                    <div style={{ fontSize: '13px', color: '#475569' }}>
                      <span><b>GSTIN:</b> {ledgerData.retailer.gstin || 'Unregistered'}</span> • <span><b>Mobile:</b> {ledgerData.retailer.mobile}</span>
                      <br />
                      <span><b>Address:</b> {ledgerData.retailer.billingAddress}</span>
                    </div>
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <span style={{ fontSize: '12px', color: '#64748b', textTransform: 'uppercase' }}>Issued By</span>
                    <h3 style={{ margin: '2px 0 4px', fontSize: '16px' }}>{ledgerData.dealer?.name || 'Dealership'}</h3>
                    <small style={{ color: '#64748b', display: 'block' }}>GSTIN: {ledgerData.dealer?.gstin || 'N/A'}</small>
                    <small style={{ color: '#94a3b8', display: 'block' }}>Statement As of {new Date().toLocaleDateString()}</small>
                  </div>
                </div>

                {/* KPI Summary Strip */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '14px', marginTop: '24px', borderTop: '1px solid #f1f5f9', paddingTop: '20px' }}>
                  <div style={{ background: '#f8fafc', padding: '12px 16px', borderRadius: '8px' }}>
                    <small style={{ color: '#64748b', textTransform: 'uppercase', fontSize: '11px', fontWeight: 600 }}>CURRENT OUTSTANDING</small>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: ledgerData.summary.currentOutstanding > 0 ? '#dc2626' : '#16a34a', marginTop: '4px' }}>
                      {ledgerData.summary.currentOutstanding < 0 ? (
                        `Adv: ₹${Math.abs(ledgerData.summary.currentOutstanding).toLocaleString(undefined, { minimumFractionDigits: 2 })}`
                      ) : (
                        `₹${ledgerData.summary.currentOutstanding.toLocaleString(undefined, { minimumFractionDigits: 2 })}`
                      )}
                    </div>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '12px 16px', borderRadius: '8px' }}>
                    <small style={{ color: '#64748b', textTransform: 'uppercase', fontSize: '11px', fontWeight: 600 }}>CREDIT LIMIT</small>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a', marginTop: '4px' }}>
                      ₹{ledgerData.summary.creditLimit.toLocaleString()}
                    </div>
                    <small style={{ color: '#64748b' }}>{ledgerData.summary.creditDays} credit days</small>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '12px 16px', borderRadius: '8px' }}>
                    <small style={{ color: '#64748b', textTransform: 'uppercase', fontSize: '11px', fontWeight: 600 }}>AVAILABLE CREDIT</small>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: '#E21E25', marginTop: '4px' }}>
                      ₹{ledgerData.summary.availableCredit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </div>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '12px 16px', borderRadius: '8px' }}>
                    <small style={{ color: '#64748b', textTransform: 'uppercase', fontSize: '11px', fontWeight: 600 }}>LIMIT UTILISATION</small>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: ledgerData.summary.creditUtilisationPct > 100 ? '#ef4444' : '#10b981', marginTop: '4px' }}>
                      {ledgerData.summary.creditUtilisationPct}%
                    </div>
                    <div style={{ height: '6px', background: '#e2e8f0', borderRadius: '3px', marginTop: '6px', overflow: 'hidden' }}>
                      <div
                        style={{
                          width: `${Math.min(100, ledgerData.summary.creditUtilisationPct)}%`,
                          height: '100%',
                          background: ledgerData.summary.creditUtilisationPct > 100 ? '#ef4444' : '#10b981'
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Ageing Chips */}
                <div style={{ marginTop: '20px', borderTop: '1px solid #f1f5f9', paddingTop: '16px' }}>
                  <small style={{ fontWeight: 600, color: '#475569', display: 'block', marginBottom: '8px', textTransform: 'uppercase', fontSize: '11px' }}>
                    Invoice Ageing Buckets (Days Since Issuance):
                  </small>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
                    <div style={{ padding: '8px 14px', background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '8px' }}>
                      <small style={{ color: '#065f46', fontWeight: 600, display: 'block' }}>0–30 Days (Current)</small>
                      <b style={{ color: '#047857' }}>₹{ledgerData.ageing.buckets['0_30'].toLocaleString(undefined, { minimumFractionDigits: 2 })}</b>
                    </div>

                    <div style={{ padding: '8px 14px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '8px' }}>
                      <small style={{ color: '#92400e', fontWeight: 600, display: 'block' }}>31–60 Days</small>
                      <b style={{ color: '#b45309' }}>₹{ledgerData.ageing.buckets['31_60'].toLocaleString(undefined, { minimumFractionDigits: 2 })}</b>
                    </div>

                    <div style={{ padding: '8px 14px', background: '#fff7ed', border: '1px solid #fed7aa', borderRadius: '8px' }}>
                      <small style={{ color: '#9a3412', fontWeight: 600, display: 'block' }}>61–90 Days</small>
                      <b style={{ color: '#c2410c' }}>₹{ledgerData.ageing.buckets['61_90'].toLocaleString(undefined, { minimumFractionDigits: 2 })}</b>
                    </div>

                    <div style={{ padding: '8px 14px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px' }}>
                      <small style={{ color: '#991b1b', fontWeight: 600, display: 'block' }}>90+ Days (Critical)</small>
                      <b style={{ color: '#dc2626' }}>₹{ledgerData.ageing.buckets['90_plus'].toLocaleString(undefined, { minimumFractionDigits: 2 })}</b>
                    </div>

                    {ledgerData.ageing.hasOverdue && (
                      <div style={{ padding: '8px 14px', background: '#fee2e2', border: '1px solid #ef4444', borderRadius: '8px', marginLeft: 'auto' }}>
                        <small style={{ color: '#991b1b', fontWeight: 700, display: 'block' }}>⚠️ TOTAL OVERDUE</small>
                        <b style={{ color: '#b91c1c' }}>₹{ledgerData.ageing.totalOverdue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</b>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Subtabs: Open Invoices vs Running Balance Statement */}
              <div className="brand-tabs-bar no-print" style={{ marginBottom: '16px' }}>
                <button
                  type="button"
                  className={`tab-btn ${ledgerSubTab === 'open-items' ? 'active' : ''}`}
                  onClick={() => setLedgerSubTab('open-items')}
                >
                  📋 Open Items ({ledgerData.openInvoices.length})
                </button>
                <button
                  type="button"
                  className={`tab-btn ${ledgerSubTab === 'statement' ? 'active' : ''}`}
                  onClick={() => setLedgerSubTab('statement')}
                >
                  📑 Running Balance Statement ({ledgerData.entries.length})
                </button>
              </div>

              {/* View 1: Open Items (Invoices) */}
              {ledgerSubTab === 'open-items' && (
                <div className="table-card">
                  <div className="table-responsive">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Invoice No</th>
                          <th>Invoice Date</th>
                          <th>Gross Total</th>
                          <th>Paid Amount</th>
                          <th>Open Balance</th>
                          <th>Age (Days)</th>
                          <th>Payment Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ledgerData.openInvoices.length === 0 ? (
                          <tr>
                            <td colSpan="7" style={{ textAlign: 'center', padding: '32px', color: '#16a34a' }}>
                              ✓ All invoices are fully paid! No open items pending.
                            </td>
                          </tr>
                        ) : (
                          ledgerData.openInvoices.map((inv) => {
                            const isOverdue = inv.ageDays > ledgerData.summary.creditDays;
                            return (
                              <tr key={inv.id}>
                                <td><b>{inv.invoiceNo}</b></td>
                                <td>{new Date(inv.invoiceDate).toLocaleDateString()}</td>
                                <td>₹{inv.netTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                                <td>₹{inv.paidAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                                <td>
                                  <b style={{ color: isOverdue ? '#dc2626' : '#0f172a' }}>
                                    ₹{inv.openBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                  </b>
                                </td>
                                <td>
                                  <span style={{ fontWeight: 600, color: isOverdue ? '#dc2626' : '#334155' }}>
                                    {inv.ageDays} days
                                  </span>
                                  {isOverdue && <small style={{ display: 'block', color: '#b91c1c' }}>Overdue!</small>}
                                </td>
                                <td>
                                  <span
                                    className="status-badge"
                                    style={{
                                      background: inv.paymentStatus === 'PAID' ? '#dcfce7' : inv.paymentStatus === 'PARTIALLY_PAID' ? '#fef3c7' : '#fee2e2',
                                      color: inv.paymentStatus === 'PAID' ? '#166534' : inv.paymentStatus === 'PARTIALLY_PAID' ? '#92400e' : '#991b1b'
                                    }}
                                  >
                                    {inv.paymentStatus}
                                  </span>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* View 2: Running Balance Ledger Entries */}
              {ledgerSubTab === 'statement' && (
                <div className="table-card">
                  <div className="table-responsive">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Type</th>
                          <th>Reference</th>
                          <th>Debit (₹)</th>
                          <th>Credit (₹)</th>
                          <th>Running Balance (₹)</th>
                          <th>Description / Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ledgerData.entries.length === 0 ? (
                          <tr>
                            <td colSpan="7" style={{ textAlign: 'center', padding: '32px', color: '#64748b' }}>
                              No transactions recorded on this retailer's ledger yet.
                            </td>
                          </tr>
                        ) : (
                          ledgerData.entries.map((entry) => (
                            <tr key={entry.id}>
                              <td>{new Date(entry.date).toLocaleDateString()}</td>
                              <td>
                                <span
                                  className="status-badge"
                                  style={{
                                    background: entry.type === 'INVOICE' ? '#FDFBF7' : entry.type === 'COLLECTION' ? '#f0fdf4' : '#fff7ed',
                                    color: entry.type === 'INVOICE' ? '#785A18' : entry.type === 'COLLECTION' ? '#15803d' : '#c2410c',
                                    border: entry.type === 'INVOICE' ? '1px solid #E7D7B5' : 'none'
                                  }}
                                >
                                  {entry.type}
                                </span>
                              </td>
                              <td><b>{entry.refType}</b></td>
                              <td style={{ color: entry.debit > 0 ? '#0f172a' : '#94a3b8' }}>
                                {entry.debit > 0 ? `₹${entry.debit.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : '—'}
                              </td>
                              <td style={{ color: entry.credit > 0 ? '#16a34a' : '#94a3b8', fontWeight: entry.credit > 0 ? 600 : 400 }}>
                                {entry.credit > 0 ? `₹${entry.credit.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : '—'}
                              </td>
                              <td>
                                <b style={{ color: entry.runningBalance > 0 ? '#dc2626' : '#16a34a' }}>
                                  ₹{entry.runningBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                </b>
                              </td>
                              <td style={{ fontSize: '12px', color: '#64748b', maxWidth: '300px' }}>
                                {entry.notes || '—'}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ) : null}
        </section>
      )}

      {/* =========================================================================
          MODAL 1: PRINTABLE PAYMENT RECEIPT
          ========================================================================= */}
      {receiptModalOpen && (
        <div className="modal-backdrop" onClick={() => setReceiptModalOpen(false)}>
          <div className="modal-card" style={{ maxWidth: '780px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header no-print">
              <h3>Official Payment Receipt</h3>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  type="button"
                  className="btn btn-primary btn-sm"
                  onClick={() => window.print()}
                >
                  🖨️ Print Receipt
                </button>
                <button
                  type="button"
                  className="btn btn-outline btn-sm"
                  onClick={() => setReceiptModalOpen(false)}
                >
                  ✕ Close
                </button>
              </div>
            </div>

            <div className="modal-body" style={{ padding: '24px' }}>
              {loadingReceipt || !receiptData ? (
                <div style={{ textAlign: 'center', padding: '40px' }}>
                  <div className="spinner" />
                  <p>Generating official receipt sheet...</p>
                </div>
              ) : (
                <div className="a4-invoice-sheet" style={{ border: '1px solid #cbd5e1', padding: '28px', background: '#fff', borderRadius: '8px' }}>
                  {/* Dealership Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0f172a', paddingBottom: '16px' }}>
                    <div>
                      <h2 style={{ margin: '0 0 4px', fontSize: '20px', color: '#0f172a' }}>{receiptData.dealer.name}</h2>
                      <p style={{ margin: 0, fontSize: '12px', color: '#475569' }}>
                        {receiptData.dealer.address}
                        <br />
                        GSTIN: <b>{receiptData.dealer.gstin || 'N/A'}</b>
                      </p>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <span className="eyebrow" style={{ color: '#16a34a' }}>PAYMENT RECEIPT</span>
                      <h3 style={{ margin: '4px 0', fontSize: '18px' }}>{receiptData.receiptNo}</h3>
                      <small style={{ color: '#64748b', display: 'block' }}>Date: {new Date(receiptData.date).toLocaleDateString()}</small>
                    </div>
                  </div>

                  {/* Receipt Body */}
                  <div style={{ margin: '20px 0', padding: '16px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                    <p style={{ margin: '0 0 8px', fontSize: '14px', lineHeight: 1.6 }}>
                      Received with thanks from <b>{receiptData.retailer.legalName}</b>
                      {receiptData.retailer.tradeName && ` (${receiptData.retailer.tradeName})`}
                      <br />
                      GSTIN: <b>{receiptData.retailer.gstin || 'Unregistered'}</b> • Mobile: {receiptData.retailer.mobile}
                    </p>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '12px', borderTop: '1px solid #e2e8f0', paddingTop: '10px' }}>
                      <span style={{ fontSize: '15px' }}>
                        The sum of: <b>{receiptData.amountInWords}</b>
                      </span>
                      <span style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a' }}>
                        ₹{receiptData.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <div style={{ marginTop: '10px', fontSize: '12px', color: '#475569' }}>
                      Payment Mode: <b>{receiptData.mode}</b>
                      {receiptData.reference && ` • Ref/Cheque No: ${receiptData.reference}`}
                      {receiptData.bankName && ` • Bank: ${receiptData.bankName}`}
                    </div>
                  </div>

                  {/* Allocation Table */}
                  {receiptData.allocations.length > 0 && (
                    <div style={{ marginTop: '20px' }}>
                      <h4 style={{ margin: '0 0 8px', fontSize: '13px', textTransform: 'uppercase', color: '#475569' }}>
                        Invoices Settled Under This Receipt:
                      </h4>
                      <table className="data-table" style={{ fontSize: '11px', width: '100%' }}>
                        <thead>
                          <tr>
                            <th>Invoice No</th>
                            <th>Date</th>
                            <th>Invoice Total</th>
                            <th style={{ textAlign: 'right' }}>Amount Applied</th>
                          </tr>
                        </thead>
                        <tbody>
                          {receiptData.allocations.map((a) => (
                            <tr key={a.id}>
                              <td><b>{a.invoiceNo || 'Invoice'}</b></td>
                              <td>{a.invoiceDate ? new Date(a.invoiceDate).toLocaleDateString() : '—'}</td>
                              <td>₹{(a.invoiceTotal || 0).toLocaleString()}</td>
                              <td style={{ textAlign: 'right', fontWeight: 700 }}>
                                ₹{a.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {receiptData.advanceAmount > 0 && (
                    <div style={{ marginTop: '12px', padding: '8px 12px', background: '#ecfdf5', borderRadius: '6px', fontSize: '12px', color: '#065f46' }}>
                      <b>On-Account Advance Balance:</b> ₹{receiptData.advanceAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })} has been credited to the retailer's ledger for future orders.
                    </div>
                  )}

                  {/* Signatures */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: '48px', paddingTop: '16px', borderTop: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>
                      This is a computer generated payment receipt.
                      <br />
                      Cashier: <b>{receiptData.collectedBy}</b>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{ borderTop: '1px dashed #64748b', width: '180px', marginTop: '36px' }} />
                      <small style={{ fontSize: '11px', color: '#475569' }}>Authorized Signatory</small>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: CHEQUE BOUNCE
          ========================================================================= */}
      {bounceModalOpen && bouncingCollection && (
        <div className="modal-backdrop" onClick={() => setBounceModalOpen(false)}>
          <div className="modal-card" style={{ maxWidth: '520px' }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3 style={{ color: '#991b1b' }}>⚠️ Record Cheque Bounce</h3>
              <button
                type="button"
                className="btn btn-outline btn-sm"
                onClick={() => setBounceModalOpen(false)}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitBounce} className="modal-body">
              {bounceError && (
                <div className="error" style={{ marginBottom: '16px' }}>
                  {bounceError}
                </div>
              )}

              <p style={{ color: '#475569', fontSize: '13px', lineHeight: 1.5, margin: '0 0 16px' }}>
                You are marking cheque payment receipt <b>{bouncingCollection.collectionNo}</b> (Amount: <b>₹{bouncingCollection.amount.toLocaleString()}</b>) as BOUNCED.
              </p>

              <div className="notice" style={{ background: '#fef2f2', borderColor: '#fca5a5', color: '#991b1b', marginBottom: '16px', fontSize: '12px' }}>
                <b>Automatic Accounting Actions:</b>
                <ul style={{ margin: '6px 0 0', paddingLeft: '18px' }}>
                  <li>All invoice allocations will be reversed and invoices reopened.</li>
                  <li>Original collection credit entry will be reversed with a debit note.</li>
                  <li>Configured bounce penalty charge will be debited to the retailer's ledger.</li>
                </ul>
              </div>

              <label>
                Bounce Reason *
                <input
                  type="text"
                  value={bounceReason}
                  onChange={(e) => setBounceReason(e.target.value)}
                  placeholder="e.g. Insufficient funds / Drawer signature mismatch"
                  required
                />
              </label>

              <label style={{ marginTop: '12px' }}>
                Cheque Bounce Penalty Charge (₹)
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={bounceCharge}
                  onChange={(e) => setBounceCharge(e.target.value)}
                />
              </label>

              <div className="modal-footer" style={{ marginTop: '24px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => setBounceModalOpen(false)}
                  disabled={submittingBounce}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-danger"
                  style={{ background: '#dc2626', color: '#fff', border: 'none' }}
                  disabled={submittingBounce}
                >
                  {submittingBounce ? 'Processing Reversal...' : 'Confirm Cheque Bounce'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

