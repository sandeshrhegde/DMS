export function HomePage() {
  return <main><h1>Dealer Management System</h1><p>Frontend foundation is ready.</p></main>;
}
