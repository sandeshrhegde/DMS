import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchOrders,
  fetchOrderById,
  previewOrderCalculation,
  createDraftOrder,
  updateDraftOrder,
  submitOrder,
  approveOrder,
  cancelOrder,
  checkAvailableStock
} from '../services/api/orders.js';
import { fetchRetailers } from '../services/api/retailers.js';
import { fetchWarehouses } from '../services/api/inventory.js';
import { fetchSkus, fetchDealers } from '../services/api/masters.js';
import { isBrandRole, ORDER_STATUS } from '@dms/shared';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

export function OrdersPage({ user }) {
  const isBrand = isBrandRole(user.role);
  const isOwner = user.role === 'DEALER_OWNER' || isBrand;

  // Dealers Master (for Brand Admin scope)
  const [dealers, setDealers] = useState([]);
  const [selectedDealerId, setSelectedDealerId] = useState('');

  // Load Dealers if Brand Admin
  useEffect(() => {
    if (isBrand) {
      fetchDealers(user)
        .then((res) => {
          const list = res.dealers || res || [];
          setDealers(list);
          if (list.length > 0 && !selectedDealerId) {
            const demo = list.find((d) => d.code === 'DEMO-001') || list[0];
            setSelectedDealerId(demo.id);
          }
        })
        .catch((err) => console.error('Failed to load dealers for orders:', err));
    }
  }, [isBrand, user]);

  // List states
  const [orders, setOrders] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filter states
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  // Masters cached for dropdowns
  const [retailersList, setRetailersList] = useState([]);
  const [warehousesList, setWarehousesList] = useState([]);
  const [skusList, setSkusList] = useState([]);

  // Detail Modal state
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Create / Edit Wizard state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingOrderId, setEditingOrderId] = useState(null);
  const [formRetailerId, setFormRetailerId] = useState('');
  const [formWarehouseId, setFormWarehouseId] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formLines, setFormLines] = useState([]); // [{ skuId, sku, orderedQty, unitPrice, mrp, availableStock, lineValue, pricingLevel }]
  const [formSummary, setFormSummary] = useState(null); // { totalAmount, creditLimit, currentOutstanding, creditLimitExceeded }
  const [formCalculating, setFormCalculating] = useState(false);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);

  // SKU Search in Wizard
  const [skuSearchQuery, setSkuSearchQuery] = useState('');
  const [selectedSkuToAdd, setSelectedSkuToAdd] = useState(null);
  const [addQty, setAddQty] = useState(1);

  // Cancel Confirmation Modal state
  const [cancellingOrder, setCancellingOrder] = useState(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelSubmitting, setCancelSubmitting] = useState(false);

  // 1. Load Orders List
  const loadOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        status: statusFilter,
        search,
        page,
        limit: 25
      };
      if (isBrand && selectedDealerId) {
        params.dealerId = selectedDealerId;
      }
      const res = await fetchOrders(user, params);
      setOrders(res.orders || []);
      setTotalCount(res.totalCount || 0);
    } catch (err) {
      setError(err.message || 'Failed to load secondary orders.');
    } finally {
      setLoading(false);
    }
  }, [user, isBrand, selectedDealerId, statusFilter, search, page]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  // 2. Load Masters for Create Modal
  const loadMasters = useCallback(async () => {
    try {
      const [retRes, whRes, skuRes] = await Promise.all([
        fetchRetailers(user, { status: 'APPROVED', limit: 100 }),
        fetchWarehouses(user),
        fetchSkus(user, { limit: 100, isBillable: 'true', isActive: 'true' })
      ]);

      setRetailersList(retRes.retailers || []);
      setWarehousesList(whRes.warehouses || []);
      setSkusList(skuRes.skus || []);
    } catch (e) {
      console.error('Error preloading master lists for orders:', e);
    }
  }, [user]);

  useEffect(() => {
    loadMasters();
  }, [loadMasters]);

  // Recalculate order preview when retailer, warehouse, or lines change
  const runLiveCalculation = useCallback(
    async (retailerId, warehouseId, lines) => {
      if (!retailerId || lines.length === 0) {
        setFormSummary(null);
        return;
      }

      setFormCalculating(true);
      setFormError(null);
      try {
        const payload = {
          retailerId,
          warehouseId: warehouseId || undefined,
          items: lines.map((l) => ({ skuId: l.skuId, orderedQty: l.orderedQty }))
        };

        const result = await previewOrderCalculation(user, payload);
        setFormSummary({
          totalAmount: result.totalAmount,
          creditLimit: result.creditLimit,
          currentOutstanding: result.currentOutstanding,
          creditLimitExceeded: result.creditLimitExceeded
        });

        // Update line prices and availability from calculation
        if (result.lines) {
          const resMap = new Map();
          result.lines.forEach((rl) => resMap.set(rl.skuId, rl));

          setFormLines((prev) =>
            prev.map((l) => {
              const enriched = resMap.get(l.skuId);
              if (enriched) {
                return {
                  ...l,
                  unitPrice: enriched.unitPrice,
                  lineValue: enriched.lineValue,
                  pricingLevel: enriched.pricingLevel,
                  availableStock: enriched.availableStock
                };
              }
              return l;
            })
          );
        }
      } catch (err) {
        setFormError(err.message || 'Price calculation failed.');
      } finally {
        setFormCalculating(false);
      }
    },
    [user]
  );

  // Trigger recalculation on lines or retailer change
  useEffect(() => {
    if (showCreateModal && formRetailerId && formLines.length > 0) {
      const timer = setTimeout(() => {
        runLiveCalculation(formRetailerId, formWarehouseId, formLines);
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [formRetailerId, formWarehouseId, formLines, showCreateModal, runLiveCalculation]);

  // Open Create Order Modal
  const handleOpenCreateModal = () => {
    setEditingOrderId(null);
    setFormRetailerId(retailersList[0]?.id || '');
    const defWh = warehousesList.find((w) => w.isDefault) || warehousesList[0];
    setFormWarehouseId(defWh?.id || '');
    setFormNotes('');
    setFormLines([]);
    setFormSummary(null);
    setFormError(null);
    setSkuSearchQuery('');
    setSelectedSkuToAdd(null);
    setAddQty(1);
    setShowCreateModal(true);
  };

  // Add SKU to order lines
  const handleAddSkuLine = () => {
    if (!selectedSkuToAdd) return;
    if (addQty <= 0) return alert('Quantity must be greater than 0');

    // Check if SKU already in lines
    const existingIndex = formLines.findIndex((l) => l.skuId === selectedSkuToAdd.id);
    let updated;
    if (existingIndex >= 0) {
      updated = [...formLines];
      updated[existingIndex].orderedQty += Number(addQty);
    } else {
      updated = [
        ...formLines,
        {
          skuId: selectedSkuToAdd.id,
          sku: selectedSkuToAdd,
          orderedQty: Number(addQty),
          unitPrice: selectedSkuToAdd.mrp || 0,
          mrp: selectedSkuToAdd.mrp || 0,
          lineValue: (selectedSkuToAdd.mrp || 0) * Number(addQty),
          pricingLevel: 'CALCULATING',
          availableStock: 0
        }
      ];
    }

    setFormLines(updated);
    setSelectedSkuToAdd(null);
    setSkuSearchQuery('');
    setAddQty(1);
  };

  // Update line quantity
  const handleUpdateQty = (skuId, newQty) => {
    const qty = parseInt(newQty, 10);
    if (isNaN(qty) || qty <= 0) return;
    setFormLines((prev) =>
      prev.map((l) => (l.skuId === skuId ? { ...l, orderedQty: qty } : l))
    );
  };

  // Remove line
  const handleRemoveLine = (skuId) => {
    setFormLines((prev) => prev.filter((l) => l.skuId !== skuId));
  };

  // Save as Draft or Submit
  const handleSaveOrder = async (isSubmittingImmediately = false) => {
    if (!formRetailerId) return setFormError('Please select a retailer.');
    if (formLines.length === 0) return setFormError('Please add at least one line item.');

    setFormSubmitting(true);
    setFormError(null);

    try {
      const payload = {
        retailerId: formRetailerId,
        warehouseId: formWarehouseId || undefined,
        notes: formNotes,
        items: formLines.map((l) => ({ skuId: l.skuId, orderedQty: l.orderedQty }))
      };

      let order;
      if (editingOrderId) {
        order = await updateDraftOrder(user, editingOrderId, payload);
      } else {
        order = await createDraftOrder(user, payload);
      }

      if (isSubmittingImmediately) {
        const submitRes = await submitOrder(user, order.id);
        alert(submitRes.message || 'Order submitted successfully.');
      } else {
        alert(`Order saved as draft (${order.orderNo}).`);
      }

      setShowCreateModal(false);
      loadOrders();
    } catch (err) {
      setFormError(err.message || 'Failed to save order.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // View Order Details
  const handleViewDetail = async (orderId) => {
    setDetailLoading(true);
    setSelectedOrder(null);
    try {
      const full = await fetchOrderById(user, orderId);
      setSelectedOrder(full);
    } catch (err) {
      alert(err.message || 'Failed to load order details.');
    } finally {
      setDetailLoading(false);
    }
  };

  // Submit Order directly from list or detail
  const handleSubmitFromList = async (orderId) => {
    if (!confirm('Submit this order for credit check and stock reservation?')) return;
    try {
      const res = await submitOrder(user, orderId);
      alert(res.message || 'Order submitted.');
      loadOrders();
      if (selectedOrder && selectedOrder.id === orderId) {
        handleViewDetail(orderId);
      }
    } catch (err) {
      alert(err.message || 'Failed to submit order.');
    }
  };

  // Approve Order directly (DEALER_OWNER or BRAND_ADMIN)
  const handleApprove = async (orderId) => {
    if (!confirm('Approve this credit-blocked order and reserve warehouse stock?')) return;
    try {
      const res = await approveOrder(user, orderId);
      alert(res.message || 'Order approved.');
      loadOrders();
      if (selectedOrder && selectedOrder.id === orderId) {
        handleViewDetail(orderId);
      }
    } catch (err) {
      alert(err.message || 'Failed to approve order.');
    }
  };

  // Open Cancel Modal
  const handleOpenCancelModal = (order) => {
    setCancellingOrder(order);
    setCancelReason('');
  };

  // Confirm Cancel
  const handleConfirmCancel = async (e) => {
    e.preventDefault();
    if (!cancelReason.trim()) return alert('Please enter a cancellation reason.');

    setCancelSubmitting(true);
    try {
      const res = await cancelOrder(user, cancellingOrder.id, cancelReason);
      alert(res.message || 'Order cancelled.');
      setCancellingOrder(null);
      loadOrders();
      if (selectedOrder && selectedOrder.id === cancellingOrder.id) {
        handleViewDetail(cancellingOrder.id);
      }
    } catch (err) {
      alert(err.message || 'Failed to cancel order.');
    } finally {
      setCancelSubmitting(false);
    }
  };

  // Render Status Badge
  const renderStatusBadge = (status) => {
    const s = String(status || '').toLowerCase();
    let label = status;
    switch (status) {
      case 'DRAFT':
        label = 'Draft';
        break;
      case 'SUBMITTED':
        label = 'Submitted';
        break;
      case 'PENDING_APPROVAL':
        label = 'Pending Approval (Credit Breach)';
        break;
      case 'APPROVED':
        label = 'Approved (Stock Reserved)';
        break;
      case 'PARTIALLY_BILLED':
        label = 'Partially Billed';
        break;
      case 'FULLY_BILLED':
        label = 'Fully Billed';
        break;
      case 'CLOSED':
        label = 'Closed';
        break;
      case 'CANCELLED':
        label = 'Cancelled';
        break;
      default:
        label = status;
    }
    return <span className={`status-pill status-${s}`}>{label}</span>;
  };

  // Filtered SKUs for Create autocomplete
  const filteredSkus = skusList.filter(
    (s) =>
      !skuSearchQuery ||
      s.code.toLowerCase().includes(skuSearchQuery.toLowerCase()) ||
      s.name.toLowerCase().includes(skuSearchQuery.toLowerCase()) ||
      (s.category && s.category.toLowerCase().includes(skuSearchQuery.toLowerCase()))
  );

  return (
    <div className="orders-page-container">
      {/* HEADER & ACTION BAR */}
      <div className="table-meta-bar" style={{ marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2>Secondary Orders & Stock Reservation</h2>
          <small style={{ color: '#64748b' }}>
            Dealer secondary order management with server-side price resolution, credit limits, and append-only inventory reservation.
          </small>
        </div>

        <button className="btn btn-primary" onClick={handleOpenCreateModal}>
          + Create New Order
        </button>
      </div>

      {/* Brand Dealership Selector */}
      {isBrand && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', background: '#FDFBF7', padding: '10px 16px', borderRadius: '8px', border: '1px solid #E7D7B5', marginBottom: '16px' }}>
          <span style={{ fontSize: '13px', fontWeight: 600, color: '#785A18' }}>🏢 Active Dealership Scope:</span>
          <select
            value={selectedDealerId}
            onChange={(e) => setSelectedDealerId(e.target.value)}
            style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #E7D7B5', background: '#fff', fontSize: '13px', fontWeight: 500 }}
          >
            <option value="">All Dealerships</option>
            {dealers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
          <span style={{ fontSize: '12px', color: '#64748b', marginLeft: 'auto' }}>
            Brand HQ inspecting dealership secondary orders, reservations &amp; approvals.
          </span>
        </div>
      )}

      {/* FILTER TABS & SEARCH */}
      <div className="brand-tabs-bar" style={{ marginBottom: '16px' }}>
        {[
          { key: '', label: 'All Orders' },
          { key: 'DRAFT', label: 'Drafts' },
          { key: 'PENDING_APPROVAL', label: 'Pending Approval' },
          { key: 'APPROVED', label: 'Approved (Reserved)' },
          { key: 'CANCELLED', label: 'Cancelled' }
        ].map((tab) => (
          <button
            key={tab.key}
            className={`tab-btn ${statusFilter === tab.key ? 'active' : ''}`}
            onClick={() => {
              setStatusFilter(tab.key);
              setPage(1);
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', flexWrap: 'wrap' }}>
        <input
          type="text"
          className="search-input"
          placeholder="Search by order number or retailer name..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
          style={{ flex: 1, minWidth: '240px', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
        />

        {search && (
          <button
            className="btn btn-outline btn-sm"
            onClick={() => {
              setSearch('');
              setPage(1);
            }}
          >
            Clear Search
          </button>
        )}
      </div>

      {/* ORDERS DATA TABLE */}
      {error && (
        <div className="error" style={{ marginBottom: '16px' }}>
          {error}
        </div>
      )}

      {loading ? (
        <div className="loading-card" style={{ padding: '40px', textAlign: 'center', background: '#fff', borderRadius: '12px' }}>
          <p>Loading secondary orders…</p>
        </div>
      ) : orders.length === 0 ? (
        <div className="empty-card" style={{ padding: '50px 20px', textAlign: 'center', background: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
          <div style={{ fontSize: '36px', marginBottom: '10px' }}>📦</div>
          <h3>No Orders Found</h3>
          <p style={{ color: '#64748b' }}>
            {statusFilter
              ? `There are no secondary orders currently in "${statusFilter}" status.`
              : 'Create your first secondary order for an approved retailer.'}
          </p>
          <button className="btn btn-primary btn-sm" onClick={handleOpenCreateModal} style={{ marginTop: '12px' }}>
            Create Order Now
          </button>
        </div>
      ) : (
        <div className="table-card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Date</th>
                  <th>Retailer</th>
                  <th>Warehouse</th>
                  <th>Lines</th>
                  <th>Order Total</th>
                  <th>Credit Check</th>
                  <th>Status</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id}>
                    <td>
                      <strong style={{ color: '#1e293b' }}>{o.orderNo}</strong>
                      <span className="badge-pill" style={{ marginLeft: '6px', fontSize: '10px' }}>
                        {o.channel}
                      </span>
                    </td>
                    <td>{new Date(o.createdAt).toLocaleDateString('en-IN')}</td>
                    <td>
                      <div>
                        <strong>{o.retailer?.legalName}</strong>
                        {o.retailer?.tradeName && (
                          <small style={{ display: 'block', color: '#64748b' }}>
                            {o.retailer.tradeName}
                          </small>
                        )}
                      </div>
                    </td>
                    <td>{o.warehouse?.name || 'Default Warehouse'}</td>
                    <td>{o.itemCount || o.lines?.length || 0} items</td>
                    <td>
                      <strong>{inrFormat.format(o.totalAmount)}</strong>
                    </td>
                    <td>
                      {o.creditLimitExceeded ? (
                        <span className="badge-warning" style={{ fontSize: '11px', display: 'inline-flex', alignItems: 'center', gap: '3px' }}>
                          ⚠️ Exceeded Limit
                        </span>
                      ) : (
                        <span style={{ fontSize: '11px', color: '#16a34a', fontWeight: 600 }}>
                          ✓ Within Limit
                        </span>
                      )}
                    </td>
                    <td>{renderStatusBadge(o.status)}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div className="table-action-group" style={{ justifyContent: 'flex-end', gap: '6px' }}>
                        <button
                          className="table-action-btn"
                          onClick={() => handleViewDetail(o.id)}
                          title="View order lines & reservation"
                        >
                          Details
                        </button>

                        {o.status === 'DRAFT' && (
                          <button
                            className="table-action-btn primary"
                            onClick={() => handleSubmitFromList(o.id)}
                            title="Submit for credit check & reservation"
                          >
                            Submit
                          </button>
                        )}

                        {o.status === 'PENDING_APPROVAL' && isOwner && (
                          <button
                            className="table-action-btn primary"
                            onClick={() => handleApprove(o.id)}
                            title="Approve credit limit breach"
                            style={{ background: '#16a34a', color: '#fff' }}
                          >
                            Approve
                          </button>
                        )}

                        {['DRAFT', 'SUBMITTED', 'PENDING_APPROVAL', 'APPROVED'].includes(o.status) && (
                          <button
                            className="table-action-btn"
                            onClick={() => handleOpenCancelModal(o)}
                            title="Cancel order and release reservation"
                            style={{ color: '#dc2626' }}
                          >
                            Cancel
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CREATE / EDIT ORDER MODAL */}
      {showCreateModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '900px' }}>
            <div className="modal-header">
              <div>
                <h2>{editingOrderId ? 'Edit Draft Order' : 'Create Secondary Order'}</h2>
                <small>Select an approved retailer, add SKUs, and preview server-side pricing & live inventory.</small>
              </div>
              <button className="close-btn" onClick={() => setShowCreateModal(false)}>
                ✕
              </button>
            </div>

            <div className="modal-body" style={{ maxHeight: '72vh', overflowY: 'auto' }}>
              {formError && (
                <div className="error" style={{ marginBottom: '14px' }}>
                  {formError}
                </div>
              )}

              {/* Step 1 & 2: Retailer & Warehouse Selection */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '14px', marginBottom: '18px' }}>
                <label>
                  Retailer (Approved Only) *
                  <select
                    value={formRetailerId}
                    onChange={(e) => setFormRetailerId(e.target.value)}
                    required
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  >
                    <option value="">Select an Approved Retailer</option>
                    {retailersList.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.legalName} ({r.tradeName || r.retailerClass}) - Credit Limit: {inrFormat.format(r.creditLimit)}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  Fulfillment Warehouse *
                  <select
                    value={formWarehouseId}
                    onChange={(e) => setFormWarehouseId(e.target.value)}
                    required
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  >
                    {warehousesList.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.code}) {w.isDefault ? '- Default' : ''}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              {/* Step 3: SKU Search & Line Addition */}
              <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0', marginBottom: '18px' }}>
                <h4 style={{ margin: '0 0 10px', fontSize: '13px', textTransform: 'uppercase', color: '#475569' }}>
                  Add Line Item
                </h4>

                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr auto', gap: '10px', alignItems: 'flex-end' }}>
                  <div>
                    <label style={{ fontSize: '12px' }}>Search Billable SKU</label>
                    <input
                      type="text"
                      placeholder="Type SKU code, name or category..."
                      value={skuSearchQuery}
                      onChange={(e) => setSkuSearchQuery(e.target.value)}
                      style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                    />
                    {skuSearchQuery && filteredSkus.length > 0 && !selectedSkuToAdd && (
                      <div
                        style={{
                          background: '#fff',
                          border: '1px solid #cbd5e1',
                          borderRadius: '6px',
                          maxHeight: '160px',
                          overflowY: 'auto',
                          marginTop: '4px',
                          boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)'
                        }}
                      >
                        {filteredSkus.slice(0, 10).map((s) => (
                          <div
                            key={s.id}
                            onClick={() => {
                              setSelectedSkuToAdd(s);
                              setSkuSearchQuery(`${s.code} - ${s.name}`);
                            }}
                            style={{
                              padding: '8px 12px',
                              cursor: 'pointer',
                              borderBottom: '1px solid #f1f5f9',
                              fontSize: '12px'
                            }}
                          >
                            <strong>{s.code}</strong> - {s.name} (MRP: ₹{s.mrp})
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <label style={{ fontSize: '12px' }}>Quantity</label>
                    <input
                      type="number"
                      min="1"
                      value={addQty}
                      onChange={(e) => setAddQty(Math.max(1, parseInt(e.target.value, 10) || 1))}
                      style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                    />
                  </div>

                  <button
                    type="button"
                    className="btn btn-primary"
                    disabled={!selectedSkuToAdd}
                    onClick={handleAddSkuLine}
                    style={{ height: '38px' }}
                  >
                    + Add Line
                  </button>
                </div>
              </div>

              {/* Step 4: Line Items Table */}
              <div style={{ marginBottom: '18px' }}>
                <h4 style={{ margin: '0 0 10px', fontSize: '13px', textTransform: 'uppercase', color: '#475569' }}>
                  Order Lines ({formLines.length})
                </h4>

                {formLines.length === 0 ? (
                  <div style={{ padding: '20px', textAlign: 'center', background: '#f8fafc', borderRadius: '8px', color: '#64748b', fontSize: '13px' }}>
                    No items added yet. Search and add SKUs above.
                  </div>
                ) : (
                  <div className="table-responsive">
                    <table className="data-table" style={{ fontSize: '12px' }}>
                      <thead>
                        <tr>
                          <th>SKU</th>
                          <th>MRP</th>
                          <th>Unit Price (Resolved)</th>
                          <th>Rule Level</th>
                          <th>Avail. Stock</th>
                          <th style={{ width: '100px' }}>Ordered Qty</th>
                          <th>Line Value</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {formLines.map((line) => (
                          <tr key={line.skuId}>
                            <td>
                              <strong>{line.sku?.code || line.skuCode}</strong>
                              <small style={{ display: 'block', color: '#64748b' }}>
                                {line.sku?.name || line.skuName}
                              </small>
                            </td>
                            <td>₹{line.mrp}</td>
                            <td>
                              <strong style={{ color: '#16a34a' }}>
                                ₹{line.unitPrice}
                              </strong>
                            </td>
                            <td>
                              <span className="badge-pill" style={{ fontSize: '10px' }}>
                                {line.pricingLevel || 'Calculating...'}
                              </span>
                            </td>
                            <td>
                              <span style={{ fontWeight: 600, color: line.availableStock > 0 ? '#16a34a' : '#dc2626' }}>
                                {line.availableStock ?? '—'} units
                              </span>
                            </td>
                            <td>
                              <input
                                type="number"
                                min="1"
                                value={line.orderedQty}
                                onChange={(e) => handleUpdateQty(line.skuId, e.target.value)}
                                style={{ width: '70px', padding: '4px', borderRadius: '4px', border: '1px solid #cbd5e1' }}
                              />
                            </td>
                            <td>
                              <strong>{inrFormat.format(line.lineValue || line.unitPrice * line.orderedQty)}</strong>
                            </td>
                            <td>
                              <button
                                type="button"
                                onClick={() => handleRemoveLine(line.skuId)}
                                style={{ background: 'transparent', border: 'none', color: '#dc2626', cursor: 'pointer', fontWeight: 700 }}
                              >
                                ✕
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Step 5: Live Summary & Credit Exposure Meter */}
              {formSummary && (
                <div className="credit-exposure-meter">
                  <div className="exposure-grid">
                    <div className="exposure-cell">
                      <small>Order Subtotal</small>
                      <strong>{inrFormat.format(formSummary.totalAmount)}</strong>
                    </div>
                    <div className="exposure-cell">
                      <small>Retailer Credit Limit</small>
                      <strong>{inrFormat.format(formSummary.creditLimit)}</strong>
                    </div>
                    <div className="exposure-cell">
                      <small>Current Outstanding</small>
                      <strong>{inrFormat.format(formSummary.currentOutstanding)}</strong>
                    </div>
                    <div className="exposure-cell">
                      <small>Total Exposure</small>
                      <strong style={{ color: formSummary.creditLimitExceeded ? '#dc2626' : '#16a34a' }}>
                        {inrFormat.format(formSummary.currentOutstanding + formSummary.totalAmount)}
                      </strong>
                    </div>
                  </div>

                  {formSummary.creditLimitExceeded ? (
                    <div className="credit-alert-box exceeded">
                      <span style={{ fontSize: '18px' }}>⚠️</span>
                      <div>
                        <strong>Credit Limit Exceeded:</strong> Total exposure exceeds the credit limit by{' '}
                        {inrFormat.format((formSummary.currentOutstanding + formSummary.totalAmount) - formSummary.creditLimit)}.
                        If submitted, order will be routed to <strong>Pending Approval</strong> for Dealer Owner authorization.
                      </div>
                    </div>
                  ) : (
                    <div className="credit-alert-box pass">
                      <span style={{ fontSize: '18px' }}>✅</span>
                      <div>
                        <strong>Credit Check Passed:</strong> Order is within the credit limit.
                        When submitted, order will be <strong>Auto-Approved</strong> and warehouse stock reserved immediately.
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Order Notes */}
              <div style={{ marginTop: '16px' }}>
                <label>
                  Order Notes & Instructions
                  <textarea
                    rows="2"
                    placeholder="Optional notes or dispatch instructions..."
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </label>
              </div>
            </div>

            <div className="modal-footer" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => setShowCreateModal(false)}
                disabled={formSubmitting}
              >
                Cancel
              </button>

              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => handleSaveOrder(false)}
                  disabled={formSubmitting || formLines.length === 0}
                >
                  {formSubmitting ? 'Saving…' : 'Save as Draft'}
                </button>

                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => handleSaveOrder(true)}
                  disabled={formSubmitting || formLines.length === 0}
                >
                  {formSubmitting ? 'Submitting…' : 'Submit Order'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ORDER DETAIL DRAWER / MODAL */}
      {selectedOrder && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '920px' }}>
            <div className="modal-header">
              <div>
                <h2>Order Details: {selectedOrder.orderNo}</h2>
                <small>Financial Year: {selectedOrder.financialYear} | Channel: {selectedOrder.channel}</small>
              </div>
              <button className="close-btn" onClick={() => setSelectedOrder(null)}>
                ✕
              </button>
            </div>

            <div className="modal-body" style={{ maxHeight: '74vh', overflowY: 'auto' }}>
              {/* Order Workflow Timeline */}
              <div className="order-workflow-timeline">
                <div className="timeline-step-item completed">
                  <div className="timeline-dot">1</div>
                  <span>Draft</span>
                </div>
                <div className={`timeline-connector ${selectedOrder.status !== 'DRAFT' ? 'completed' : ''}`} />

                <div className={`timeline-step-item ${selectedOrder.status !== 'DRAFT' ? 'completed' : 'active'}`}>
                  <div className="timeline-dot">2</div>
                  <span>Submitted</span>
                </div>
                <div className={`timeline-connector ${['APPROVED', 'PARTIALLY_BILLED', 'FULLY_BILLED', 'CLOSED'].includes(selectedOrder.status) ? 'completed' : ''}`} />

                {selectedOrder.status === 'CANCELLED' ? (
                  <div className="timeline-step-item cancelled">
                    <div className="timeline-dot">✕</div>
                    <span>Cancelled</span>
                  </div>
                ) : selectedOrder.status === 'PENDING_APPROVAL' ? (
                  <div className="timeline-step-item active">
                    <div className="timeline-dot">!</div>
                    <span>Pending Approval</span>
                  </div>
                ) : (
                  <div className={`timeline-step-item ${['APPROVED', 'PARTIALLY_BILLED', 'FULLY_BILLED', 'CLOSED'].includes(selectedOrder.status) ? 'completed' : ''}`}>
                    <div className="timeline-dot">3</div>
                    <span>Approved & Reserved</span>
                  </div>
                )}
                <div className={`timeline-connector ${['PARTIALLY_BILLED', 'FULLY_BILLED', 'CLOSED'].includes(selectedOrder.status) ? 'completed' : ''}`} />

                <div className={`timeline-step-item ${['PARTIALLY_BILLED', 'FULLY_BILLED', 'CLOSED'].includes(selectedOrder.status) ? 'completed' : ''}`}>
                  <div className="timeline-dot">4</div>
                  <span>Billed / Closed</span>
                </div>
              </div>

              {/* Status & Shortfall Alert Banner */}
              {selectedOrder.status === 'APPROVED' && (
                <div style={{ marginBottom: '16px' }}>
                  {selectedOrder.lines.some((l) => l.shortfallQty > 0) ? (
                    <div className="credit-alert-box exceeded" style={{ margin: 0 }}>
                      <span style={{ fontSize: '18px' }}>⚠️</span>
                      <div>
                        <strong>Partial Inventory Reservation (Back-Order Shortfall):</strong>
                        {' '}Some lines could not be fully fulfilled from warehouse stock on hand. Available stock has been reserved, and remaining quantities are logged as shortfall back-orders.
                      </div>
                    </div>
                  ) : (
                    <div className="credit-alert-box pass" style={{ margin: 0 }}>
                      <span style={{ fontSize: '18px' }}>✅</span>
                      <div>
                        <strong>Full Inventory Reservation Confirmed:</strong>
                        {' '}All ordered items are successfully reserved in warehouse stock on hand via append-only ledger entries.
                      </div>
                    </div>
                  )}
                </div>
              )}

              {selectedOrder.status === 'PENDING_APPROVAL' && (
                <div className="credit-alert-box exceeded" style={{ marginBottom: '16px', marginTop: 0 }}>
                  <span style={{ fontSize: '18px' }}>⏳</span>
                  <div>
                    <strong>Credit Limit Exceeded:</strong> Total exposure exceeds the retailer credit limit.
                    Awaiting authorization by Dealer Owner or Brand Admin before stock reservation can occur.
                  </div>
                </div>
              )}

              {/* Meta Grid */}
              <div className="order-detail-meta-grid">
                <div className="order-meta-card">
                  <h4>Retailer</h4>
                  <p><strong>{selectedOrder.retailer?.legalName}</strong></p>
                  <p style={{ fontSize: '12px', color: '#64748b' }}>Trade: {selectedOrder.retailer?.tradeName || 'N/A'}</p>
                  <p style={{ fontSize: '12px', color: '#64748b' }}>Class: {selectedOrder.retailer?.retailerClass} | GSTIN: {selectedOrder.retailer?.gstin || 'Unregistered'}</p>
                </div>

                <div className="order-meta-card">
                  <h4>Credit Snapshot</h4>
                  <p>Limit: <strong>{inrFormat.format(selectedOrder.creditLimit || selectedOrder.retailer?.creditLimit || 0)}</strong></p>
                  <p>Outstanding: <strong>{inrFormat.format(selectedOrder.currentOutstanding || 0)}</strong></p>
                  <p>Order Total: <strong style={{ color: '#16a34a' }}>{inrFormat.format(selectedOrder.totalAmount)}</strong></p>
                </div>

                <div className="order-meta-card">
                  <h4>Warehouse & Expiry</h4>
                  <p>Warehouse: <strong>{selectedOrder.warehouse?.name || 'Default Warehouse'}</strong></p>
                  <p style={{ fontSize: '12px', color: '#64748b' }}>Expires: {selectedOrder.expiresAt ? new Date(selectedOrder.expiresAt).toLocaleDateString('en-IN') : 'N/A'}</p>
                  <p style={{ fontSize: '12px', color: '#64748b' }}>Created: {new Date(selectedOrder.createdAt).toLocaleDateString('en-IN')}</p>
                </div>
              </div>

              {/* Order Lines with Reservation & Shortfall Breakdown */}
              <div style={{ marginBottom: '18px' }}>
                <h4 style={{ margin: '0 0 10px', fontSize: '13px', textTransform: 'uppercase', color: '#475569' }}>
                  Line Items & Inventory Reservation Breakdown
                </h4>

                <div className="table-responsive">
                  <table className="data-table" style={{ fontSize: '12px' }}>
                    <thead>
                      <tr>
                        <th>SKU Code & Name</th>
                        <th>MRP</th>
                        <th>Unit Price</th>
                        <th>Price Level</th>
                        <th>Ordered</th>
                        <th>Reserved</th>
                        <th>Shortfall</th>
                        <th>Line Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedOrder.lines.map((l) => (
                        <tr key={l.id}>
                          <td>
                            <strong>{l.sku?.code}</strong>
                            <small style={{ display: 'block', color: '#64748b' }}>{l.sku?.name}</small>
                          </td>
                          <td>₹{l.sku?.mrp}</td>
                          <td>₹{l.unitPrice}</td>
                          <td>
                            <span className="badge-pill" style={{ fontSize: '10px' }}>
                              {l.pricingLevel || 'NATIONAL'}
                            </span>
                          </td>
                          <td>
                            <strong>{l.orderedQty}</strong>
                          </td>
                          <td>
                            <span className="reserved-badge">
                              ✓ {l.reservedQty}
                            </span>
                          </td>
                          <td>
                            {l.shortfallQty > 0 ? (
                              <span className="shortfall-badge">
                                ⚠️ {l.shortfallQty}
                              </span>
                            ) : (
                              <span style={{ color: '#94a3b8' }}>0</span>
                            )}
                          </td>
                          <td>
                            <strong>{inrFormat.format(l.lineValue)}</strong>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Audit & Notes */}
              {selectedOrder.notes && (
                <div style={{ background: '#f8fafc', padding: '12px 14px', borderRadius: '8px', marginBottom: '14px', fontSize: '12px' }}>
                  <strong>Order Notes:</strong> {selectedOrder.notes}
                </div>
              )}

              {selectedOrder.cancelledReason && (
                <div style={{ background: '#ffe4e6', padding: '12px 14px', borderRadius: '8px', marginBottom: '14px', fontSize: '12px', color: '#be123c' }}>
                  <strong>Cancellation Reason:</strong> {selectedOrder.cancelledReason} (Cancelled by: {selectedOrder.cancelledByEmail})
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button className="btn btn-outline" onClick={() => setSelectedOrder(null)}>
                Close
              </button>

              <div style={{ display: 'flex', gap: '8px' }}>
                {selectedOrder.status === 'DRAFT' && (
                  <button
                    className="btn btn-primary"
                    onClick={() => handleSubmitFromList(selectedOrder.id)}
                  >
                    Submit Order
                  </button>
                )}

                {selectedOrder.status === 'PENDING_APPROVAL' && isOwner && (
                  <button
                    className="btn btn-primary"
                    onClick={() => handleApprove(selectedOrder.id)}
                    style={{ background: '#16a34a' }}
                  >
                    Approve Order
                  </button>
                )}

                {['DRAFT', 'SUBMITTED', 'PENDING_APPROVAL', 'APPROVED'].includes(selectedOrder.status) && (
                  <button
                    className="btn btn-outline"
                    onClick={() => handleOpenCancelModal(selectedOrder)}
                    style={{ color: '#dc2626', borderColor: '#fca5a5' }}
                  >
                    Cancel Order
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL REASON PROMPT MODAL */}
      {cancellingOrder && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <div>
                <h2>Cancel Order {cancellingOrder.orderNo}</h2>
                <small>Cancelling will release all reserved inventory back to available stock.</small>
              </div>
              <button className="close-btn" onClick={() => setCancellingOrder(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmCancel}>
              <div className="modal-body">
                <label>
                  Reason for Cancellation *
                  <textarea
                    rows="3"
                    required
                    placeholder="Enter reason for cancelling this order..."
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </label>
              </div>

              <div className="modal-footer" style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => setCancellingOrder(null)}
                  disabled={cancelSubmitting}
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ background: '#dc2626' }}
                  disabled={cancelSubmitting}
                >
                  {cancelSubmitting ? 'Cancelling…' : 'Confirm Cancellation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

