import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchHsnList,
  createHsn,
  updateHsn,
  deleteHsn
} from '../services/api/masters.js';
import { isBrandRole } from '@dms/shared';

export function HsnPage({ user }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [modalMode, setModalMode] = useState(null); // 'create' | 'edit' | null
  const [selectedHsn, setSelectedHsn] = useState(null);
  const [formData, setFormData] = useState({
    code: '',
    description: '',
    gstRate: 18,
    effectiveFrom: new Date().toISOString().slice(0, 10)
  });
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState(null);

  const canEdit = isBrandRole(user.role);

  const loadHsn = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchHsnList(user, search);
      setItems(data.items || []);
    } catch (err) {
      setError(err.message || 'Failed to fetch HSN list.');
    } finally {
      setLoading(false);
    }
  }, [user, search]);

  useEffect(() => {
    loadHsn();
  }, [loadHsn]);

  const handleOpenCreate = () => {
    setSelectedHsn(null);
    setFormData({
      code: '',
      description: '',
      gstRate: 18,
      effectiveFrom: new Date().toISOString().slice(0, 10)
    });
    setActionError(null);
    setModalMode('create');
  };

  const handleOpenEdit = (hsn) => {
    setSelectedHsn(hsn);
    setFormData({
      code: hsn.code,
      description: hsn.description,
      gstRate: hsn.gstRate,
      effectiveFrom: hsn.effectiveFrom ? hsn.effectiveFrom.slice(0, 10) : ''
    });
    setActionError(null);
    setModalMode('edit');
  };

  const handleDelete = async (hsn) => {
    if (!confirm(`Are you sure you want to delete HSN code ${hsn.code}?`)) return;
    try {
      await deleteHsn(user, hsn.id);
      loadHsn();
    } catch (err) {
      alert(err.message || 'Failed to delete HSN record.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!/^\d{6}(\d{2})?$/.test(formData.code.trim())) {
      return setActionError('HSN code must be exactly 6 or 8 digits.');
    }

    setSubmitting(true);
    setActionError(null);

    try {
      if (modalMode === 'create') {
        await createHsn(user, formData);
      } else {
        await updateHsn(user, selectedHsn.id, formData);
      }
      setModalMode(null);
      loadHsn();
    } catch (err) {
      setActionError(err.message || 'Failed to save HSN.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="master-page hsn-page">
      <div className="page-header-row">
        <div>
          <h2>HSN Masters</h2>
          <p className="page-desc">
            Harmonized System of Nomenclature tax codes (6 or 8 digits) and GST tax rates.
          </p>
        </div>

        <div className="header-actions">
          {canEdit && (
            <button className="btn btn-primary" onClick={handleOpenCreate}>
              + Add HSN Code
            </button>
          )}
          <button className="btn btn-secondary" onClick={loadHsn}>
            ↻ Refresh
          </button>
        </div>
      </div>

      <div className="search-filter-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search by HSN code or description…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <button className="btn btn-outline btn-sm" onClick={() => setSearch('')}>
            Clear Search
          </button>
        )}
      </div>

      {loading ? (
        <div className="loading-card">
          <div className="spinner" />
          <p>Loading HSN codes…</p>
        </div>
      ) : error ? (
        <div className="error-alert">
          <p>{error}</p>
          <button className="btn btn-secondary btn-sm" onClick={loadHsn}>
            Try Again
          </button>
        </div>
      ) : items.length === 0 ? (
        <div className="empty-card">
          <div className="empty-icon">🏷️</div>
          <h3>No HSN Codes Found</h3>
          <p>Add your first HSN code or clear search filters.</p>
          {canEdit && (
            <button className="btn btn-primary" onClick={handleOpenCreate}>
              + Add HSN Code
            </button>
          )}
        </div>
      ) : (
        <div className="table-card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>HSN Code</th>
                  <th>Description</th>
                  <th className="num-col">GST Rate</th>
                  <th>Effective From</th>
                  {canEdit && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <span className="sku-badge">{item.code}</span>
                    </td>
                    <td>
                      <strong>{item.description}</strong>
                    </td>
                    <td className="num-col">
                      <span className="gst-badge">{item.gstRate}%</span>
                    </td>
                    <td>{new Date(item.effectiveFrom).toLocaleDateString()}</td>
                    {canEdit && (
                      <td>
                        <div className="table-action-group">
                          <button
                            className="btn btn-secondary btn-xs"
                            onClick={() => handleOpenEdit(item)}
                          >
                            Edit
                          </button>
                          <button
                            className="btn btn-danger-outline btn-xs"
                            onClick={() => handleDelete(item)}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {modalMode && (
        <div className="modal-backdrop" onClick={() => setModalMode(null)}>
          <div className="modal-card modal-sm" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{modalMode === 'create' ? 'Add New HSN Code' : `Edit HSN ${selectedHsn?.code}`}</h3>
              <button className="close-btn" onClick={() => setModalMode(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="modal-body">
              <label className="form-field">
                <span>HSN Code (6 or 8 digits):</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. 87082900 or 870829"
                  pattern="\d{6}(\d{2})?"
                  title="Must be 6 or 8 digits"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  disabled={modalMode === 'edit'}
                  autoFocus
                />
              </label>

              <label className="form-field">
                <span>Description:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Parts and accessories of motor vehicles"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>GST Rate (%):</span>
                <select
                  value={formData.gstRate}
                  onChange={(e) => setFormData({ ...formData, gstRate: parseFloat(e.target.value) })}
                >
                  <option value={0}>0% (Exempt)</option>
                  <option value={5}>5%</option>
                  <option value={12}>12%</option>
                  <option value={18}>18%</option>
                  <option value={28}>28% (Standard Auto)</option>
                </select>
              </label>

              <label className="form-field">
                <span>Effective From:</span>
                <input
                  type="date"
                  required
                  value={formData.effectiveFrom}
                  onChange={(e) => setFormData({ ...formData, effectiveFrom: e.target.value })}
                />
              </label>

              {actionError && <div className="error-alert">{actionError}</div>}

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setModalMode(null)}
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving…' : modalMode === 'create' ? 'Create HSN' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

