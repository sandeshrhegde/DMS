import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchSapInventory,
  fetchSapConfig,
  updateSapConfig,
  inwardSapItem
} from '../../services/api/inventory.js';

export function NewInventoryTab({ user, onInwardSuccess }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [data, setData] = useState({
    items: [],
    stats: {},
    source: 'PRODUCTION_SIMULATION',
    isLiveSap: false,
    endpointUrl: '',
    liveFetchError: null
  });

  // Filter states
  const [divisionFilter, setDivisionFilter] = useState('ALL');
  const [brandFilter, setBrandFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals state
  const [selectedItemForInspect, setSelectedItemForInspect] = useState(null);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [configForm, setConfigForm] = useState({
    endpointUrl: '',
    apiKey: '',
    timeoutMs: 10000
  });
  const [configStatus, setConfigStatus] = useState(null);
  const [configSaving, setConfigSaving] = useState(false);
  const [inwardingId, setInwardingId] = useState(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState(null);

  // Load SAP Inventory Data
  const loadInventory = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchSapInventory(user, {
        division: divisionFilter,
        brand: brandFilter,
        search: searchTerm
      });
      setData(res);
    } catch (err) {
      setError(err.message || 'Failed to load SAP S/4HANA inventory feed.');
    } finally {
      setLoading(false);
    }
  }, [user, divisionFilter, brandFilter, searchTerm]);

  // Load SAP Configuration Status
  const loadConfig = useCallback(async () => {
    try {
      const cfg = await fetchSapConfig(user);
      setConfigStatus(cfg);
      setConfigForm({
        endpointUrl: cfg.endpointUrl || '',
        apiKey: '',
        timeoutMs: cfg.timeoutMs || 10000
      });
    } catch {
      // Ignore background config lookup failure
    }
  }, [user]);

  useEffect(() => {
    loadInventory();
  }, [loadInventory]);

  useEffect(() => {
    loadConfig();
  }, [loadConfig]);

  // Handle Save Endpoint Config
  const handleSaveConfig = async (e) => {
    e.preventDefault();
    setConfigSaving(true);
    try {
      const res = await updateSapConfig(user, configForm);
      alert(res.message || 'SAP S/4HANA configuration updated successfully!');
      setShowConfigModal(false);
      loadConfig();
      loadInventory();
    } catch (err) {
      alert('Failed to save SAP configuration: ' + err.message);
    } finally {
      setConfigSaving(false);
    }
  };

  // Handle Inward to DMS ASN
  const handleInwardItem = async (item) => {
    if (!confirm(`Do you want to inward SAP Invoice #${item.billNo} (${item.article}) into DMS In-Transit ASN?`)) {
      return;
    }
    setInwardingId(item.id);
    setActionSuccessMsg(null);
    try {
      const res = await inwardSapItem(user, { item });
      setActionSuccessMsg(`✅ Success! Invoice ${item.billNo} (${item.article}) is now In-Transit ASN in DMS (ASN ID: ${res.asnId.slice(0, 8)}...).`);
      if (onInwardSuccess) onInwardSuccess();
    } catch (err) {
      alert('Failed to inward SAP item: ' + err.message);
    } finally {
      setInwardingId(null);
    }
  };

  const isBrand = user?.role === 'BRAND_ADMIN';
  const filteredItems = data.items || [];
  const stats = data.stats || {};

  return (
    <div className="new-inventory-tab" style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      
      {/* 1. Integration Status Banner */}
      <div
        className="card"
        style={{
          background: 'linear-gradient(135deg, #1A1A1A 0%, #2A2A2A 100%)',
          color: '#FFFFFF',
          borderLeft: data.isLiveSap ? '5px solid #10B981' : '5px solid #C5A059',
          padding: '16px 20px',
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '15px'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <div
            style={{
              width: '42px',
              height: '42px',
              borderRadius: '50%',
              background: data.isLiveSap ? 'rgba(16, 185, 129, 0.2)' : 'rgba(197, 160, 89, 0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '22px'
            }}
          >
            {data.isLiveSap ? '🟢' : '⚡'}
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <h4 style={{ margin: 0, color: '#FFFFFF', fontSize: '1.1rem', fontWeight: 600 }}>
                SAP S/4HANA Primary Inventory Feed
              </h4>
              <span
                style={{
                  fontSize: '0.75rem',
                  fontWeight: 'bold',
                  padding: '3px 8px',
                  borderRadius: '12px',
                  background: data.isLiveSap ? '#10B981' : '#C5A059',
                  color: '#FFFFFF'
                }}
              >
                {data.isLiveSap ? 'LIVE SAP S/4HANA CONNECTED' : 'PRODUCTION SIMULATION (READY FOR ENDPOINT)'}
              </span>
            </div>
            <p style={{ margin: '4px 0 0', fontSize: '0.85rem', color: '#CCCCCC' }}>
              {data.isLiveSap ? (
                <span>Streaming live billing &amp; PGI feeds from: <code style={{ color: '#FCD34D' }}>{data.endpointUrl}</code></span>
              ) : (
                <span>
                  Using production-grade Siyaram's Fabric &amp; Garment feeds. Simply click <strong>"Configure SAP Endpoint"</strong> to connect your live SAP S/4HANA URL anytime.
                </span>
              )}
            </p>
            {data.liveFetchError && (
              <p style={{ margin: '4px 0 0', fontSize: '0.8rem', color: '#F87171' }}>
                ⚠️ Warning: {data.liveFetchError}
              </p>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={loadInventory}
            disabled={loading}
            title="Refresh latest feed from SAP"
          >
            🔄 {loading ? 'Fetching...' : 'Refresh Feed'}
          </button>
          <button
            type="button"
            className="btn btn-outline btn-sm"
            style={{ borderColor: '#C5A059', color: '#C5A059' }}
            onClick={() => setShowConfigModal(true)}
          >
            ⚙️ SAP Endpoint Settings
          </button>
        </div>
      </div>

      {actionSuccessMsg && (
        <div className="alert alert-success" style={{ padding: '12px 16px', borderRadius: '6px' }}>
          {actionSuccessMsg}
        </div>
      )}

      {/* 2. Key Metrics Summary Cards */}
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
        <div className="stat-card">
          <div className="stat-label">Total SAP Feed Items</div>
          <div className="stat-value" style={{ color: '#1E293B' }}>{stats.totalItemsCount || 0}</div>
          <div className="stat-desc">Fabric Lumps &amp; Garment Pieces</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">🧵 Fabric Division Total</div>
          <div className="stat-value" style={{ color: '#C5A059' }}>{stats.fabricMetersTotal || 0} MTR</div>
          <div className="stat-desc">{stats.fabricPiecesCount || 0} Cut Pieces / Lumps (Cadini &amp; Siyaram)</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">👔 Garment Division Total</div>
          <div className="stat-value" style={{ color: '#2563EB' }}>{stats.garmentPiecesCount || 0} PCS</div>
          <div className="stat-desc">Apparel Units (Oxemberg Trousers &amp; Shirts)</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Invoiced Value (₹)</div>
          <div className="stat-value" style={{ color: '#E21E25' }}>
            ₹{(stats.totalInvoicedValue || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
          </div>
          <div className="stat-desc">Primary SAP Billing Dispatches</div>
        </div>
      </div>

      {/* 3. Filter Controls & Division Tabs */}
      <div className="card" style={{ padding: '16px' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px', alignItems: 'center', justifyContent: 'space-between' }}>
          
          {/* Division Pill Filter */}
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              type="button"
              className={`btn btn-sm ${divisionFilter === 'ALL' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setDivisionFilter('ALL')}
            >
              All Items ({stats.totalItemsCount || 0})
            </button>
            <button
              type="button"
              className={`btn btn-sm ${divisionFilter === 'FABRIC' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setDivisionFilter('FABRIC')}
              style={divisionFilter === 'FABRIC' ? { background: '#C5A059', borderColor: '#C5A059' } : {}}
            >
              🧵 Fabric Division ({stats.fabricPiecesCount || 0})
            </button>
            <button
              type="button"
              className={`btn btn-sm ${divisionFilter === 'GARMENT' ? 'btn-primary' : 'btn-outline'}`}
              onClick={() => setDivisionFilter('GARMENT')}
              style={divisionFilter === 'GARMENT' ? { background: '#2563EB', borderColor: '#2563EB' } : {}}
            >
              👔 Garment Division ({stats.garmentPiecesCount || 0})
            </button>
          </div>

          {/* Search & Brand Filter */}
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <select
              value={brandFilter}
              onChange={(e) => setBrandFilter(e.target.value)}
              style={{ padding: '6px 12px', borderRadius: '4px', border: '1px solid #D1D5DB' }}
            >
              <option value="">All Brands</option>
              <option value="CADINI">CADINI</option>
              <option value="SIYARAM">SIYARAM</option>
              <option value="J.HAMPSTEAD">J.HAMPSTEAD</option>
              <option value="Oxemberg">Oxemberg</option>
            </select>

            <input
              type="text"
              placeholder="Search Article, Barcode, Bill No..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ minWidth: '260px', padding: '6px 12px', borderRadius: '4px', border: '1px solid #D1D5DB' }}
            />
          </div>
        </div>
      </div>

      {/* 4. Interactive Data Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
            ⏳ Fetching SAP S/4HANA Inventory Feed...
          </div>
        ) : error ? (
          <div style={{ padding: '30px', textAlign: 'center', color: '#E21E25' }}>
            ❌ {error}
          </div>
        ) : filteredItems.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: '#666' }}>
            No SAP dispatch records found matching your filters.
          </div>
        ) : (
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Bill / Invoice #</th>
                  <th>Customer (Sold / Bill To)</th>
                  <th>Brand &amp; Division</th>
                  <th>Article Description</th>
                  <th>Barcode / Itemcode</th>
                  <th>Shade / Size</th>
                  <th>Qty / Length</th>
                  <th>Bill Rate (₹)</th>
                  <th>MRP (₹)</th>
                  <th>Total Amount (₹)</th>
                  <th>Transporter / LR</th>
                  <th style={{ textAlign: 'center' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredItems.map((item) => {
                  const isFabric = item.type === 'FABRIC';
                  return (
                    <tr key={item.id}>
                      <td>
                        <span
                          className="status-pill"
                          style={{
                            background: isFabric ? '#FEF3C7' : '#DBEAFE',
                            color: isFabric ? '#92400E' : '#1E40AF',
                            fontWeight: 'bold',
                            fontSize: '0.75rem'
                          }}
                        >
                          {isFabric ? '🧵 FABRIC' : '👔 GARMENT'}
                        </span>
                      </td>

                      <td>
                        <strong>{item.billNo}</strong>
                        <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                          {item.billDate}
                        </div>
                      </td>

                      <td>
                        <div style={{ fontWeight: 500 }}>{item.partyName}</div>
                        <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                          Code: {item.partyCode}
                        </div>
                      </td>

                      <td>
                        <strong>{item.brand}</strong>
                        <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                          {item.division}
                        </div>
                      </td>

                      <td>
                        <strong>{item.article}</strong>
                        {isFabric && item.fibre && (
                          <div style={{ fontSize: '0.75rem', color: '#059669' }}>
                            {item.fibre}
                          </div>
                        )}
                        {!isFabric && item.fit && (
                          <div style={{ fontSize: '0.75rem', color: '#2563EB' }}>
                            {item.fit} | {item.fibre}
                          </div>
                        )}
                      </td>

                      <td>
                        <span style={{ fontFamily: 'monospace', fontWeight: 600, fontSize: '0.85rem' }}>
                          {item.barcode}
                        </span>
                        {item.batch && (
                          <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                            Lot: {item.batch}
                          </div>
                        )}
                      </td>

                      <td>
                        <div>Shade: <strong>{item.shade || 'N/A'}</strong></div>
                        <div style={{ fontSize: '0.8rem', color: '#4B5563' }}>
                          Size: <strong>{item.sizeOrLength || 'N/A'}</strong>
                        </div>
                      </td>

                      <td>
                        <strong style={{ fontSize: '1rem', color: isFabric ? '#C5A059' : '#1E293B' }}>
                          {item.qty} {item.uom}
                        </strong>
                      </td>

                      <td>₹{item.rate?.toFixed(2)}</td>

                      <td>₹{item.mrp?.toFixed(2)}</td>

                      <td>
                        <strong>₹{item.totalAmount?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
                        {item.taxAmount > 0 && (
                          <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                            GST: ₹{item.taxAmount?.toFixed(2)} ({item.taxRate}%)
                          </div>
                        )}
                      </td>

                      <td>
                        <div style={{ fontSize: '0.8rem' }}>{item.transporter || 'Direct Dispatch'}</div>
                        {item.lrNo && (
                          <div style={{ fontSize: '0.75rem', color: '#6B7280' }}>
                            LR: {item.lrNo}
                          </div>
                        )}
                      </td>

                      <td style={{ textAlign: 'center' }}>
                        <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                          <button
                            type="button"
                            className="btn btn-outline btn-xs"
                            onClick={() => setSelectedItemForInspect(item)}
                            title="Inspect all 50+ SAP S/4HANA fields"
                          >
                            🔍 Inspect SAP
                          </button>
                          <button
                            type="button"
                            className="btn btn-primary btn-xs"
                            onClick={() => handleInwardItem(item)}
                            disabled={inwardingId === item.id}
                            title="Inward this invoice into DMS In-Transit ASN"
                          >
                            {inwardingId === item.id ? 'Inwarding...' : '📥 Inward ASN'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 5. Modal: Inspect Raw SAP S/4HANA Fields (Fiori Inspector) */}
      {selectedItemForInspect && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '900px', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header" style={{ flexShrink: 0 }}>
              <div>
                <h3 style={{ margin: 0 }}>
                  🔍 SAP S/4HANA Line Inspector: {selectedItemForInspect.article}
                </h3>
                <span style={{ fontSize: '0.85rem', color: '#6B7280' }}>
                  Bill No: <strong>{selectedItemForInspect.billNo}</strong> | Division: <strong>{selectedItemForInspect.type}</strong>
                </span>
              </div>
              <button className="close-btn" onClick={() => setSelectedItemForInspect(null)}>✕</button>
            </div>

            <div className="modal-body" style={{ overflowY: 'auto', flexGrow: 1, padding: '20px' }}>
              
              {/* Inspection Sections */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '15px', marginBottom: '20px' }}>
                <div style={{ background: '#F9FAFB', padding: '12px', borderRadius: '6px', border: '1px solid #E5E7EB' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#C5A059' }}>📦 Document &amp; Dispatch</h5>
                  <div style={{ fontSize: '0.85rem' }}><strong>Bill No:</strong> {selectedItemForInspect.billNo}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Bill Date:</strong> {selectedItemForInspect.billDate}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Challan / PGI:</strong> {selectedItemForInspect.challanNo}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Sold-To Customer:</strong> {selectedItemForInspect.partyName} ({selectedItemForInspect.partyCode})</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Plant / Place:</strong> {selectedItemForInspect.plant}</div>
                </div>

                <div style={{ background: '#F9FAFB', padding: '12px', borderRadius: '6px', border: '1px solid #E5E7EB' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#2563EB' }}>🏷️ Material &amp; Specification</h5>
                  <div style={{ fontSize: '0.85rem' }}><strong>Brand:</strong> {selectedItemForInspect.brand}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Article:</strong> {selectedItemForInspect.article}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Barcode (EAN/Itemcode):</strong> {selectedItemForInspect.barcode}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Shade:</strong> {selectedItemForInspect.shade}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Size / Length:</strong> {selectedItemForInspect.sizeOrLength}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Batch / Lot:</strong> {selectedItemForInspect.batch}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Fibre:</strong> {selectedItemForInspect.fibre}</div>
                </div>

                <div style={{ background: '#F9FAFB', padding: '12px', borderRadius: '6px', border: '1px solid #E5E7EB' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#E21E25' }}>💰 Commercials &amp; GST</h5>
                  <div style={{ fontSize: '0.85rem' }}><strong>Quantity:</strong> {selectedItemForInspect.qty} {selectedItemForInspect.uom}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Bill Rate / Ex-Mill:</strong> ₹{selectedItemForInspect.rate}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Wholesale Rate:</strong> ₹{selectedItemForInspect.wholesaleRate}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>MRP:</strong> ₹{selectedItemForInspect.mrp}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>HSN Code:</strong> {selectedItemForInspect.hsnCode}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>GST Rate:</strong> {selectedItemForInspect.taxRate}%</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Tax Amount:</strong> ₹{selectedItemForInspect.taxAmount}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>Line Total:</strong> ₹{selectedItemForInspect.totalAmount}</div>
                </div>

                <div style={{ background: '#F9FAFB', padding: '12px', borderRadius: '6px', border: '1px solid #E5E7EB' }}>
                  <h5 style={{ margin: '0 0 8px', color: '#10B981' }}>🚚 Logistics &amp; Transport</h5>
                  <div style={{ fontSize: '0.85rem' }}><strong>Transporter:</strong> {selectedItemForInspect.transporter}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>LR Number:</strong> {selectedItemForInspect.lrNo}</div>
                  <div style={{ fontSize: '0.85rem' }}><strong>LR Date:</strong> {selectedItemForInspect.lrDate}</div>
                </div>
              </div>

              {/* Raw SAP S/4HANA JSON payload */}
              <div style={{ marginTop: '15px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
                  <strong>Complete Raw SAP JSON Payload (50+ Fields):</strong>
                  <button
                    type="button"
                    className="btn btn-outline btn-xs"
                    onClick={() => {
                      navigator.clipboard.writeText(JSON.stringify(selectedItemForInspect.rawSapData, null, 2));
                      alert('Copied raw SAP JSON to clipboard!');
                    }}
                  >
                    📋 Copy JSON
                  </button>
                </div>
                <pre
                  style={{
                    background: '#1F2937',
                    color: '#F9FAFB',
                    padding: '12px',
                    borderRadius: '6px',
                    fontSize: '0.78rem',
                    overflowX: 'auto',
                    maxHeight: '220px'
                  }}
                >
                  {JSON.stringify(selectedItemForInspect.rawSapData, null, 2)}
                </pre>
              </div>
            </div>

            <div className="modal-footer" style={{ flexShrink: 0, justifyContent: 'space-between' }}>
              <button type="button" className="btn btn-secondary" onClick={() => setSelectedItemForInspect(null)}>
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  const itm = selectedItemForInspect;
                  setSelectedItemForInspect(null);
                  handleInwardItem(itm);
                }}
              >
                📥 Inward to DMS In-Transit ASN
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Modal: SAP S/4HANA Endpoint Settings */}
      {showConfigModal && (
        <div className="modal-backdrop">
          <div className="modal-card" style={{ maxWidth: '650px' }}>
            <div className="modal-header">
              <h3>⚙️ Configure SAP S/4HANA Endpoint URL</h3>
              <button className="close-btn" onClick={() => setShowConfigModal(false)}>✕</button>
            </div>
            <form onSubmit={handleSaveConfig}>
              <div className="modal-body form-grid">
                <div className="grid-span-full">
                  <p style={{ margin: '0 0 12px', fontSize: '0.88rem', color: '#4B5563' }}>
                    Enter the live SAP S/4HANA OData / REST service URL provided by your SAP team.
                    When empty, DMS automatically runs in <strong>Production-Fidelity Simulation Mode</strong> using real Siyaram's Fabric and Garment schemas.
                  </p>
                </div>

                <div className="form-field grid-span-full">
                  <label>SAP S/4HANA Service Endpoint URL</label>
                  <input
                    type="url"
                    placeholder="https://sap-api.siyaram.com/sap/opu/odata/sap/API_BILLING_DOCUMENT_SRV/A_BillingDocument"
                    value={configForm.endpointUrl}
                    onChange={(e) => setConfigForm({ ...configForm, endpointUrl: e.target.value })}
                  />
                  <small style={{ color: '#6B7280' }}>
                    Leave blank to use the built-in production simulation feeds.
                  </small>
                </div>

                <div className="form-field grid-span-full">
                  <label>SAP API Key / Bearer Token (Optional)</label>
                  <input
                    type="password"
                    placeholder="e.g. Bearer eyJhbGciOi..."
                    value={configForm.apiKey}
                    onChange={(e) => setConfigForm({ ...configForm, apiKey: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Request Timeout (Milliseconds)</label>
                  <input
                    type="number"
                    min="1000"
                    step="1000"
                    value={configForm.timeoutMs}
                    onChange={(e) => setConfigForm({ ...configForm, timeoutMs: Number(e.target.value) })}
                  />
                </div>

                {configStatus && (
                  <div className="grid-span-full" style={{ background: '#F3F4F6', padding: '10px 14px', borderRadius: '4px' }}>
                    <div style={{ fontSize: '0.85rem' }}>
                      Status: <strong>{configStatus.isConfigured ? '🟢 Custom SAP Endpoint Configured' : '🟡 Using Production Simulation'}</strong>
                    </div>
                    {configStatus.lastUpdated && (
                      <div style={{ fontSize: '0.78rem', color: '#6B7280' }}>
                        Last Configured: {new Date(configStatus.lastUpdated).toLocaleString()}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowConfigModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={configSaving}>
                  {configSaving ? 'Saving & Probing...' : 'Save & Connect SAP URL'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

