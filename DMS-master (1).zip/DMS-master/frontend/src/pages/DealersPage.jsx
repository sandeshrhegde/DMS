import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchDealers,
  createDealer,
  updateDealer,
  deleteDealer,
  importDealersCsv,
  fetchSampleDealersCsv,
  fetchGeoNodes
} from '../services/api/masters.js';
import { CsvImportModal } from '../components/CsvImportModal.jsx';

export function DealersPage({ user }) {
  const [dealers, setDealers] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [totalPages, setTotalPages] = useState(1);
  const [geoNodes, setGeoNodes] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  // Modals
  const [showImportModal, setShowImportModal] = useState(false);
  const [modalMode, setModalMode] = useState(null); // 'create' | 'edit' | null
  const [activeDealer, setActiveDealer] = useState(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    gstin: '',
    stateCode: '27',
    contactName: '',
    contactEmail: '',
    contactPhone: '',
    address: '',
    pincode: '',
    creditDays: 30,
    maxHeaderDiscountPct: 5.0,
    eInvoiceEnabled: false,
    geoNodeId: '',
    isActive: true
  });
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState(null);

  const loadDealers = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [dealerRes, geoRes] = await Promise.all([
        fetchDealers(user, { page, limit, search }),
        fetchGeoNodes(user)
      ]);
      setDealers(dealerRes.dealers || []);
      setTotal(dealerRes.total || 0);
      setTotalPages(dealerRes.totalPages || 1);
      if (geoRes?.nodes) setGeoNodes(geoRes.nodes);
    } catch (err) {
      setError(err.message || 'Failed to load dealers.');
    } finally {
      setLoading(false);
    }
  }, [user, page, limit, search]);

  useEffect(() => {
    loadDealers();
  }, [loadDealers]);

  const handleOpenCreate = () => {
    setActiveDealer(null);
    setFormData({
      code: '',
      name: '',
      gstin: '',
      stateCode: '27',
      contactName: '',
      contactEmail: '',
      contactPhone: '',
      address: '',
      pincode: '',
      creditDays: 30,
      maxHeaderDiscountPct: 5.0,
      eInvoiceEnabled: false,
      geoNodeId: geoNodes[0]?.id || '',
      isActive: true
    });
    setActionError(null);
    setModalMode('create');
  };

  const handleOpenEdit = (dealer) => {
    setActiveDealer(dealer);
    setFormData({
      code: dealer.code,
      name: dealer.name,
      gstin: dealer.gstin || '',
      stateCode: dealer.stateCode || '',
      contactName: dealer.contactName || '',
      contactEmail: dealer.contactEmail || '',
      contactPhone: dealer.contactPhone || '',
      address: dealer.address || '',
      pincode: dealer.pincode || '',
      creditDays: dealer.creditDays ?? 30,
      maxHeaderDiscountPct: dealer.maxHeaderDiscountPct ?? 0,
      eInvoiceEnabled: dealer.eInvoiceEnabled ?? false,
      geoNodeId: dealer.geoNodeId || '',
      isActive: dealer.isActive
    });
    setActionError(null);
    setModalMode('edit');
  };

  const handleDelete = async (dealer) => {
    if (!confirm(`Are you sure you want to deactivate/delete dealer '${dealer.name}'?`)) return;
    try {
      await deleteDealer(user, dealer.id);
      loadDealers();
    } catch (err) {
      alert(err.message || 'Failed to delete dealer.');
    }
  };

  const handleSubmitModal = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setActionError(null);

    try {
      if (modalMode === 'create') {
        await createDealer(user, formData);
      } else {
        await updateDealer(user, activeDealer.id, formData);
      }
      setModalMode(null);
      loadDealers();
    } catch (err) {
      setActionError(err.message || 'Failed to save dealer.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="master-page dealers-page">
      <div className="page-header-row">
        <div>
          <h2>Authorized Dealerships Master</h2>
          <p className="page-desc">
            Manage dealer network partners, credit limits, e-Invoicing compliance, and territory alignment.
          </p>
        </div>

        <div className="header-actions">
          <button className="btn btn-outline" onClick={() => setShowImportModal(true)}>
            📥 Import CSV
          </button>
          <button className="btn btn-primary" onClick={handleOpenCreate}>
            + Add Dealer
          </button>
          <button className="btn btn-secondary" onClick={loadDealers}>
            ↻ Refresh
          </button>
        </div>
      </div>

      <div className="search-filter-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search dealer by code, name, GSTIN, contact…"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setPage(1);
          }}
        />
        {search && (
          <button
            className="btn btn-outline btn-sm"
            onClick={() => {
              setSearch('');
              setPage(1);
            }}
          >
            Clear Search
          </button>
        )}
      </div>

      {loading ? (
        <div className="loading-card">
          <div className="spinner" />
          <p>Loading dealer directory…</p>
        </div>
      ) : error ? (
        <div className="error-alert">
          <p>{error}</p>
          <button className="btn btn-secondary btn-sm" onClick={loadDealers}>
            Try Again
          </button>
        </div>
      ) : dealers.length === 0 ? (
        <div className="empty-card">
          <div className="empty-icon">🏢</div>
          <h3>No Dealers Found</h3>
          <p>Add a new dealer partner or import dealers via CSV.</p>
          <button className="btn btn-primary" onClick={handleOpenCreate}>
            + Add Dealer
          </button>
        </div>
      ) : (
        <div className="table-card">
          <div className="table-meta-bar">
            <span>
              Showing {dealers.length} of <strong>{total}</strong> dealer{total === 1 ? '' : 's'}
            </span>
            <span className="pagination-quick">
              Page {page} of {totalPages}
            </span>
          </div>

          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Dealer Code</th>
                  <th>Dealer Name</th>
                  <th>Territory / Geo Node</th>
                  <th>GSTIN / State</th>
                  <th>Key Contact</th>
                  <th>Credit Terms</th>
                  <th>e-Invoice</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {dealers.map((dealer) => (
                  <tr key={dealer.id}>
                    <td>
                      <span className="sku-badge">{dealer.code}</span>
                    </td>
                    <td>
                      <strong>{dealer.name}</strong>
                      {dealer.address && <small className="address-hint">{dealer.address}</small>}
                    </td>
                    <td>
                      {dealer.geoNode ? (
                        <div>
                          <span className="geo-tag-pill">{dealer.geoNode.type}</span>{' '}
                          <strong>{dealer.geoNode.name}</strong>
                          <br />
                          <small className="geo-path-small">{dealer.geoNode.path}</small>
                        </div>
                      ) : (
                        <span className="text-muted">Unassigned</span>
                      )}
                    </td>
                    <td>
                      {dealer.gstin ? <code>{dealer.gstin}</code> : <span className="text-muted">—</span>}
                      <br />
                      <small>State: {dealer.stateCode}</small>
                    </td>
                    <td>
                      {dealer.contactName || '—'}
                      {dealer.contactPhone && (
                        <small className="contact-small">{dealer.contactPhone}</small>
                      )}
                      {dealer.contactEmail && (
                        <small className="contact-small">{dealer.contactEmail}</small>
                      )}
                    </td>
                    <td>
                      <span>{dealer.creditDays} days credit</span>
                      <br />
                      <small>Max disc: {dealer.maxHeaderDiscountPct}%</small>
                    </td>
                    <td>
                      <span
                        className={`status-pill ${
                          dealer.eInvoiceEnabled ? 'status-billable' : 'status-low'
                        }`}
                      >
                        {dealer.eInvoiceEnabled ? 'Enabled' : 'Disabled'}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`status-dot ${
                          dealer.isActive ? 'dot-active' : 'dot-inactive'
                        }`}
                        title={dealer.isActive ? 'Active' : 'Inactive'}
                      />
                    </td>
                    <td>
                      <div className="table-action-group">
                        <button
                          className="btn btn-secondary btn-xs"
                          onClick={() => handleOpenEdit(dealer)}
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-danger-outline btn-xs"
                          onClick={() => handleDelete(dealer)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && (
            <div className="pagination-bar">
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
              >
                Previous
              </button>
              <span className="pagination-indicator">
                Page {page} of {totalPages}
              </span>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {/* CSV Import Modal */}
      {showImportModal && (
        <CsvImportModal
          title="Import Dealers from CSV"
          sampleDownloadUrl="http://localhost:4000/api/dealers/sample-csv"
          onFetchSample={() => fetchSampleDealersCsv(user)}
          onImport={(payload) => importDealersCsv(user, payload)}
          onClose={() => setShowImportModal(false)}
          onSuccess={() => {
            loadDealers();
          }}
        />
      )}

      {/* Create / Edit Dealer Modal */}
      {modalMode && (
        <div className="modal-backdrop" onClick={() => setModalMode(null)}>
          <div className="modal-card modal-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>
                {modalMode === 'create' ? 'Create New Dealer' : `Edit Dealer ${activeDealer?.code}`}
              </h3>
              <button className="close-btn" onClick={() => setModalMode(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="modal-body form-grid">
              <label className="form-field">
                <span>Dealer Code *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. DLR-MUM-001"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  disabled={modalMode === 'edit'}
                />
              </label>

              <label className="form-field">
                <span>Dealership Business Name *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. City Auto Wheels Mumbai"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>GSTIN:</span>
                <input
                  type="text"
                  placeholder="e.g. 27AABCU9603R1ZM"
                  value={formData.gstin}
                  onChange={(e) => setFormData({ ...formData, gstin: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>GST State Code *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. 27"
                  value={formData.stateCode}
                  onChange={(e) => setFormData({ ...formData, stateCode: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Geography Node Territory:</span>
                <select
                  value={formData.geoNodeId}
                  onChange={(e) => setFormData({ ...formData, geoNodeId: e.target.value })}
                >
                  <option value="">-- Select Geography Node --</option>
                  {geoNodes.map((n) => (
                    <option key={n.id} value={n.id}>
                      [{n.type}] {n.name} ({n.path})
                    </option>
                  ))}
                </select>
              </label>

              <label className="form-field">
                <span>Contact Person Name:</span>
                <input
                  type="text"
                  placeholder="e.g. Anil Sharma"
                  value={formData.contactName}
                  onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Contact Phone:</span>
                <input
                  type="text"
                  placeholder="e.g. +91 98201 11223"
                  value={formData.contactPhone}
                  onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Contact Email:</span>
                <input
                  type="email"
                  placeholder="e.g. anil@cityauto.local"
                  value={formData.contactEmail}
                  onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                />
              </label>

              <label className="form-field grid-span-full">
                <span>Business Address:</span>
                <input
                  type="text"
                  placeholder="e.g. Plot 12, Link Road, Andheri West, Mumbai"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>PIN Code:</span>
                <input
                  type="text"
                  placeholder="e.g. 400053"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Credit Days:</span>
                <input
                  type="number"
                  min="0"
                  value={formData.creditDays}
                  onChange={(e) =>
                    setFormData({ ...formData, creditDays: parseInt(e.target.value, 10) || 0 })
                  }
                />
              </label>

              <label className="form-field">
                <span>Max Header Discount %:</span>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={formData.maxHeaderDiscountPct}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      maxHeaderDiscountPct: parseFloat(e.target.value) || 0
                    })
                  }
                />
              </label>

              <label className="form-checkbox-label">
                <input
                  type="checkbox"
                  checked={formData.eInvoiceEnabled}
                  onChange={(e) =>
                    setFormData({ ...formData, eInvoiceEnabled: e.target.checked })
                  }
                />
                <span>Enable e-Invoicing Integration</span>
              </label>

              <label className="form-field">
                <span>Status:</span>
                <select
                  value={formData.isActive ? 'true' : 'false'}
                  onChange={(e) =>
                    setFormData({ ...formData, isActive: e.target.value === 'true' })
                  }
                >
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </label>

              {actionError && <div className="error-alert grid-span-full">{actionError}</div>}

              <div className="modal-footer grid-span-full">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setModalMode(null)}
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving…' : modalMode === 'create' ? 'Create Dealer' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

