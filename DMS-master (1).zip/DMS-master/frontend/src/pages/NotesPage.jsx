import React, { useState, useEffect, useMemo } from 'react';
import {
  fetchNotes,
  fetchNoteById,
  fetchReturnableInvoice,
  createSalesReturn,
  createFinancialNote,
  fetchPendingApprovals,
  approveNote,
  rejectNote,
  allocateCreditNote,
  fetchPendingQuarantine,
  inspectQuarantine,
  fetchNotePrintData
} from '../services/api/notes.js';
import { fetchRetailers } from '../services/api/retailers.js';
import { fetchInvoices } from '../services/api/billing.js';
import { fetchWarehouses } from '../services/api/inventory.js';
import { fetchDealers } from '../services/api/masters.js';
import {
  NOTE_TYPES,
  NOTE_REASON_CODES,
  NOTE_STATUSES,
  DASHBOARD_ROLES,
  isBrandRole
} from '@dms/shared';

export function NotesPage({ user }) {
  const isBrand = isBrandRole(user.role);
  const isDealerOwner = user.role === DASHBOARD_ROLES.DEALER_OWNER || isBrand;

  // Tabs: 'list' | 'sales-return' | 'financial' | 'approvals' | 'quarantine'
  const [activeTab, setActiveTab] = useState('list');

  // Multi-dealer context for Brand Admin
  const [dealers, setDealers] = useState([]);
  const [selectedDealerId, setSelectedDealerId] = useState(user.dealerId || '');

  // Master Data
  const [retailers, setRetailers] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [loadingMasters, setLoadingMasters] = useState(false);

  // Notes List State
  const [notes, setNotes] = useState([]);
  const [loadingNotes, setLoadingNotes] = useState(false);
  const [listTypeFilter, setListTypeFilter] = useState('ALL'); // 'ALL' | 'CREDIT' | 'DEBIT'
  const [listStatusFilter, setListStatusFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRetailerFilter, setSelectedRetailerFilter] = useState('');

  // Approvals State
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [loadingApprovals, setLoadingApprovals] = useState(false);
  const [approvingId, setApprovingId] = useState(null);
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectingNote, setRejectingNote] = useState(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [submittingReject, setSubmittingReject] = useState(false);

  // Quarantine State
  const [quarantineLines, setQuarantineLines] = useState([]);
  const [loadingQuarantine, setLoadingQuarantine] = useState(false);
  const [inspectModalOpen, setInspectModalOpen] = useState(false);
  const [inspectingLine, setInspectingLine] = useState(null);
  const [inspectGoodQty, setInspectGoodQty] = useState(0);
  const [inspectDamagedQty, setInspectDamagedQty] = useState(0);
  const [inspectWarehouseId, setInspectWarehouseId] = useState('');
  const [inspectNotes, setInspectNotes] = useState('');
  const [submittingInspect, setSubmittingInspect] = useState(false);
  const [inspectError, setInspectError] = useState('');

  // Print Modal State
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [printData, setPrintData] = useState(null);
  const [loadingPrint, setLoadingPrint] = useState(false);

  // Allocation Modal State
  const [allocationModalOpen, setAllocationModalOpen] = useState(false);
  const [allocatingNote, setAllocatingNote] = useState(null);
  const [submittingAllocation, setSubmittingAllocation] = useState(false);
  const [allocationSuccess, setAllocationSuccess] = useState('');
  const [allocationError, setAllocationError] = useState('');

  // Sales Return Form State
  const [srRetailerId, setSrRetailerId] = useState('');
  const [availableInvoices, setAvailableInvoices] = useState([]);
  const [loadingInvoices, setLoadingInvoices] = useState(false);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [invoiceDetails, setInvoiceDetails] = useState(null);
  const [loadingInvoiceDetails, setLoadingInvoiceDetails] = useState(false);
  const [srReasonCode, setSrReasonCode] = useState(NOTE_REASON_CODES.RETURN_DAMAGED);
  const [srNotes, setSrNotes] = useState('');
  const [returnQtys, setReturnQtys] = useState({}); // { [invoiceLineId]: qty }
  const [submittingReturn, setSubmittingReturn] = useState(false);
  const [returnError, setReturnError] = useState('');
  const [returnSuccess, setReturnSuccess] = useState('');

  // Financial Note Form State
  const [finRetailerId, setFinRetailerId] = useState('');
  const [finType, setFinType] = useState(NOTE_TYPES.CREDIT_FINANCIAL);
  const [finReasonCode, setFinReasonCode] = useState(NOTE_REASON_CODES.SCHEME_BENEFIT);
  const [finAmount, setFinAmount] = useState('');
  const [finIsTaxable, setFinIsTaxable] = useState(false);
  const [finGstRate, setFinGstRate] = useState(18);
  const [finNotes, setFinNotes] = useState('');
  const [submittingFin, setSubmittingFin] = useState(false);
  const [finError, setFinError] = useState('');
  const [finSuccess, setFinSuccess] = useState('');

  // Global message banner
  const [messageBanner, setMessageBanner] = useState({ text: '', type: '' });

  const effectiveUser = useMemo(() => {
    return selectedDealerId ? { ...user, dealerId: selectedDealerId } : user;
  }, [user, selectedDealerId]);

  // Load Dealers if Brand Admin
  useEffect(() => {
    if (isBrand) {
      fetchDealers(user)
        .then((res) => {
          const list = res.dealers || res || [];
          setDealers(list);
          if (list.length > 0 && !selectedDealerId) {
            setSelectedDealerId(list[0].id);
          }
        })
        .catch((err) => console.error('Failed to load dealers:', err));
    }
  }, [isBrand, user]);

  // Load Masters (Retailers, Warehouses)
  useEffect(() => {
    setLoadingMasters(true);
    Promise.all([
      fetchRetailers(effectiveUser, { dealerId: selectedDealerId }),
      fetchWarehouses(effectiveUser, { dealerId: selectedDealerId }).catch(() => [])
    ])
      .then(([retRes, whRes]) => {
        const rList = Array.isArray(retRes) ? retRes : retRes.retailers || [];
        setRetailers(rList.filter((r) => r.status === 'APPROVED'));
        const wList = Array.isArray(whRes) ? whRes : whRes.warehouses || [];
        setWarehouses(wList);
      })
      .catch((err) => console.error('Error fetching masters:', err))
      .finally(() => setLoadingMasters(false));
  }, [effectiveUser, selectedDealerId]);

  // Load Notes List
  const loadNotesList = () => {
    setLoadingNotes(true);
    let typeParam = undefined;
    if (listTypeFilter === 'CREDIT') {
      typeParam = undefined; // handled via frontend filter or query
    } else if (listTypeFilter === 'DEBIT') {
      typeParam = NOTE_TYPES.DEBIT;
    }

    fetchNotes(effectiveUser, {
      dealerId: selectedDealerId,
      status: listStatusFilter || undefined,
      retailerId: selectedRetailerFilter || undefined,
      type: typeParam,
      search: searchQuery || undefined,
      limit: 50
    })
      .then((res) => {
        let list = res.notes || res || [];
        if (listTypeFilter === 'CREDIT') {
          list = list.filter((n) => n.type !== NOTE_TYPES.DEBIT);
        }
        setNotes(list);
      })
      .catch((err) => setMessageBanner({ text: err.message, type: 'error' }))
      .finally(() => setLoadingNotes(false));
  };

  useEffect(() => {
    if (activeTab === 'list') {
      loadNotesList();
    }
  }, [activeTab, listTypeFilter, listStatusFilter, selectedRetailerFilter, searchQuery, selectedDealerId]);

  // Load Approvals
  const loadPendingApprovals = () => {
    setLoadingApprovals(true);
    fetchPendingApprovals(effectiveUser)
      .then((res) => setPendingApprovals(res.notes || []))
      .catch((err) => console.error('Failed to load approvals:', err))
      .finally(() => setLoadingApprovals(false));
  };

  useEffect(() => {
    if (activeTab === 'approvals') {
      loadPendingApprovals();
    }
  }, [activeTab, selectedDealerId]);

  // Load Quarantine
  const loadQuarantine = () => {
    setLoadingQuarantine(true);
    fetchPendingQuarantine(effectiveUser)
      .then((res) => setQuarantineLines(res.lines || []))
      .catch((err) => console.error('Failed to load quarantine lines:', err))
      .finally(() => setLoadingQuarantine(false));
  };

  useEffect(() => {
    if (activeTab === 'quarantine') {
      loadQuarantine();
    }
  }, [activeTab, selectedDealerId]);

  // Invoices for Sales Return
  useEffect(() => {
    if (srRetailerId) {
      setLoadingInvoices(true);
      fetchInvoices(effectiveUser, {
        retailerId: srRetailerId,
        status: 'ISSUED',
        dealerId: selectedDealerId
      })
        .then((res) => {
          const list = res.invoices || res || [];
          setAvailableInvoices(list);
        })
        .catch((err) => console.error('Error fetching invoices:', err))
        .finally(() => setLoadingInvoices(false));
    } else {
      setAvailableInvoices([]);
      setSelectedInvoiceId('');
      setInvoiceDetails(null);
    }
  }, [srRetailerId, selectedDealerId]);

  // Selected Invoice Details
  useEffect(() => {
    if (selectedInvoiceId) {
      setLoadingInvoiceDetails(true);
      fetchReturnableInvoice(effectiveUser, selectedInvoiceId)
        .then((details) => {
          setInvoiceDetails(details);
          const initQtys = {};
          details.lines.forEach((l) => {
            initQtys[l.id] = 0;
          });
          setReturnQtys(initQtys);
        })
        .catch((err) => setReturnError(err.message))
        .finally(() => setLoadingInvoiceDetails(false));
    } else {
      setInvoiceDetails(null);
      setReturnQtys({});
    }
  }, [selectedInvoiceId]);

  // Computed Sales Return Preview
  const returnPreview = useMemo(() => {
    if (!invoiceDetails || !invoiceDetails.lines) return null;

    let totalGross = 0;
    let totalDiscount = 0;
    let totalTaxable = 0;
    let totalCgst = 0;
    let totalSgst = 0;
    let totalIgst = 0;
    let totalReturnItems = 0;

    const isIntraState = invoiceDetails.invoice.dealer?.stateCode === invoiceDetails.invoice.retailer?.stateCode;

    const linesPreview = invoiceDetails.lines.map((line) => {
      const returnQty = parseInt(returnQtys[line.id] || 0, 10);
      if (returnQty <= 0) return null;

      totalReturnItems += returnQty;
      const originalQty = line.qty || 1;
      const ratio = returnQty / originalQty;

      const lineGross = Math.round(returnQty * line.unitPrice * 100) / 100;
      const lineDiscount = Math.round((line.discountShare * ratio) * 100) / 100;
      const lineTaxable = Math.round((lineGross - lineDiscount) * 100) / 100;

      let lineCgst = 0;
      let lineSgst = 0;
      let lineIgst = 0;

      if (isIntraState) {
        lineCgst = Math.round((line.cgstAmount * ratio) * 100) / 100;
        lineSgst = Math.round((line.sgstAmount * ratio) * 100) / 100;
      } else {
        lineIgst = Math.round((line.igstAmount * ratio) * 100) / 100;
      }

      const lineTax = Math.round((lineCgst + lineSgst + lineIgst) * 100) / 100;
      const lineTotal = Math.round((lineTaxable + lineTax) * 100) / 100;

      totalGross += lineGross;
      totalDiscount += lineDiscount;
      totalTaxable += lineTaxable;
      totalCgst += lineCgst;
      totalSgst += lineSgst;
      totalIgst += lineIgst;

      return {
        ...line,
        returnQty,
        lineGross,
        lineDiscount,
        lineTaxable,
        lineCgst,
        lineSgst,
        lineIgst,
        lineTax,
        lineTotal
      };
    }).filter(Boolean);

    const taxTotal = Math.round((totalCgst + totalSgst + totalIgst) * 100) / 100;
    const rawNet = totalTaxable + taxTotal;
    const netTotal = Math.round(rawNet);
    const rounding = Math.round((netTotal - rawNet) * 100) / 100;

    return {
      lines: linesPreview,
      totalItems: totalReturnItems,
      grossAmount: Math.round(totalGross * 100) / 100,
      discountAmount: Math.round(totalDiscount * 100) / 100,
      taxableAmount: Math.round(totalTaxable * 100) / 100,
      cgstAmount: Math.round(totalCgst * 100) / 100,
      sgstAmount: Math.round(totalSgst * 100) / 100,
      igstAmount: Math.round(totalIgst * 100) / 100,
      taxAmount: taxTotal,
      rounding,
      netTotal,
      threshold: invoiceDetails.invoice.dealer?.noteApprovalThreshold || 50000,
      exceedsThreshold: netTotal > (invoiceDetails.invoice.dealer?.noteApprovalThreshold || 50000)
    };
  }, [invoiceDetails, returnQtys]);

  // Computed Financial Note Preview
  const financialPreview = useMemo(() => {
    const amount = Number(finAmount || 0);
    if (amount <= 0) return null;

    const retailer = retailers.find((r) => r.id === finRetailerId);
    const isIntraState = true; // or match dealer
    if (!finIsTaxable) {
      return {
        isTaxable: false,
        taxableAmount: 0,
        cgst: 0,
        sgst: 0,
        igst: 0,
        taxAmount: 0,
        netTotal: amount,
        exceedsThreshold: amount > 50000
      };
    }

    const rate = Number(finGstRate || 18);
    let cgst = 0;
    let sgst = 0;
    let igst = 0;

    if (isIntraState) {
      cgst = Math.round((amount * (rate / 2) / 100) * 100) / 100;
      sgst = Math.round((amount * (rate / 2) / 100) * 100) / 100;
    } else {
      igst = Math.round((amount * rate / 100) * 100) / 100;
    }

    const taxAmount = Math.round((cgst + sgst + igst) * 100) / 100;
    const netTotal = Math.round(amount + taxAmount);

    return {
      isTaxable: true,
      taxableAmount: amount,
      cgst,
      sgst,
      igst,
      taxAmount,
      netTotal,
      exceedsThreshold: netTotal > 50000
    };
  }, [finAmount, finRetailerId, finIsTaxable, finGstRate, retailers]);

  // Submit Sales Return
  const handleCreateSalesReturn = async (e) => {
    e.preventDefault();
    setReturnError('');
    setReturnSuccess('');

    if (!srRetailerId) {
      setReturnError('Please select a retailer.');
      return;
    }
    if (!selectedInvoiceId) {
      setReturnError('Please select an invoice.');
      return;
    }
    if (!returnPreview || returnPreview.lines.length === 0) {
      setReturnError('Please enter return quantity > 0 for at least one item.');
      return;
    }

    setSubmittingReturn(true);
    try {
      const payloadLines = returnPreview.lines.map((l) => ({
        invoiceLineId: l.id,
        qty: l.returnQty,
        batch: l.batch || 'DEFAULT'
      }));

      const res = await createSalesReturn(effectiveUser, {
        retailerId: srRetailerId,
        invoiceId: selectedInvoiceId,
        reasonCode: srReasonCode,
        lines: payloadLines,
        notes: srNotes
      });

      setReturnSuccess(res.message || 'Sales return created successfully.');
      setReturnQtys({});
      setSrNotes('');
      // Reload details to update max returnable counts
      fetchReturnableInvoice(effectiveUser, selectedInvoiceId).then(setInvoiceDetails);
    } catch (err) {
      setReturnError(err.message);
    } finally {
      setSubmittingReturn(false);
    }
  };

  // Submit Financial Note
  const handleCreateFinancialNote = async (e) => {
    e.preventDefault();
    setFinError('');
    setFinSuccess('');

    if (!finRetailerId) {
      setFinError('Please select a retailer.');
      return;
    }
    if (!finAmount || Number(finAmount) <= 0) {
      setFinError('Please enter a valid amount.');
      return;
    }

    setSubmittingFin(true);
    try {
      const res = await createFinancialNote(effectiveUser, {
        retailerId: finRetailerId,
        type: finType,
        reasonCode: finReasonCode,
        amount: Number(finAmount),
        isTaxable: finIsTaxable,
        gstRate: Number(finGstRate),
        notes: finNotes
      });

      setFinSuccess(res.message || 'Note created successfully.');
      setFinAmount('');
      setFinNotes('');
    } catch (err) {
      setFinError(err.message);
    } finally {
      setSubmittingFin(false);
    }
  };

  // Approve Note Action
  const handleApprove = async (noteId) => {
    setApprovingId(noteId);
    try {
      const res = await approveNote(effectiveUser, noteId);
      setMessageBanner({ text: res.message, type: 'success' });
      loadPendingApprovals();
    } catch (err) {
      setMessageBanner({ text: err.message, type: 'error' });
    } finally {
      setApprovingId(null);
    }
  };

  // Reject Note Action
  const handleRejectSubmit = async () => {
    if (!rejectingNote) return;
    setSubmittingReject(true);
    try {
      const res = await rejectNote(effectiveUser, rejectingNote.id, rejectionReason);
      setMessageBanner({ text: res.message, type: 'success' });
      setRejectModalOpen(false);
      setRejectingNote(null);
      setRejectionReason('');
      loadPendingApprovals();
    } catch (err) {
      setMessageBanner({ text: err.message, type: 'error' });
    } finally {
      setSubmittingReject(false);
    }
  };

  // Open Print Modal
  const handleOpenPrint = async (noteId) => {
    setLoadingPrint(true);
    setPrintModalOpen(true);
    try {
      const data = await fetchNotePrintData(effectiveUser, noteId);
      setPrintData(data);
    } catch (err) {
      setMessageBanner({ text: `Failed to load print view: ${err.message}`, type: 'error' });
      setPrintModalOpen(false);
    } finally {
      setLoadingPrint(false);
    }
  };

  // Open Inspect Modal
  const handleOpenInspect = (line) => {
    setInspectingLine(line);
    setInspectGoodQty(line.pendingQty);
    setInspectDamagedQty(0);
    setInspectWarehouseId(warehouses[0]?.id || '');
    setInspectNotes('');
    setInspectError('');
    setInspectModalOpen(true);
  };

  // Submit Quarantine Inspection
  const handleInspectSubmit = async (e) => {
    e.preventDefault();
    setInspectError('');
    if (!inspectingLine) return;

    const good = parseInt(inspectGoodQty || 0, 10);
    const damaged = parseInt(inspectDamagedQty || 0, 10);

    if (good + damaged !== inspectingLine.pendingQty) {
      setInspectError(`Sum of Good (${good}) and Damaged (${damaged}) must equal pending quantity (${inspectingLine.pendingQty}).`);
      return;
    }

    setSubmittingInspect(true);
    try {
      const res = await inspectQuarantine(effectiveUser, {
        noteId: inspectingLine.note.id,
        noteLineId: inspectingLine.id,
        warehouseId: inspectWarehouseId,
        goodQty: good,
        damagedQty: damaged,
        notes: inspectNotes
      });

      setMessageBanner({ text: res.message, type: 'success' });
      setInspectModalOpen(false);
      setInspectingLine(null);
      loadQuarantine();
    } catch (err) {
      setInspectError(err.message);
    } finally {
      setSubmittingInspect(false);
    }
  };

  // Allocate Credit Note
  const handleOpenAllocate = (note) => {
    setAllocatingNote(note);
    setAllocationSuccess('');
    setAllocationError('');
    setAllocationModalOpen(true);
  };

  const handleAllocateSubmit = async () => {
    if (!allocatingNote) return;
    setSubmittingAllocation(true);
    setAllocationError('');
    try {
      const res = await allocateCreditNote(effectiveUser, allocatingNote.id, {
        autoAllocateFifo: true
      });
      setAllocationSuccess(res.message);
      loadNotesList();
    } catch (err) {
      setAllocationError(err.message);
    } finally {
      setSubmittingAllocation(false);
    }
  };

  const formatCurrency = (amt) => {
    const num = Number(amt) || 0;
    return `₹${num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <div className="notes-page-container" style={{ padding: '4px 0' }}>
      {/* Brand multi-dealer picker */}
      {isBrand && (
        <div className="card" style={{ marginBottom: '16px', background: '#f8fafc', padding: '12px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '13px', fontWeight: 600, color: '#334155' }}>
              Select Dealership Workspace:
            </span>
            <select
              value={selectedDealerId}
              onChange={(e) => setSelectedDealerId(e.target.value)}
              style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
            >
              {dealers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.code}) - {d.stateCode}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* Global alert banner */}
      {messageBanner.text && (
        <div
          style={{
            marginBottom: '16px',
            padding: '12px 16px',
            borderRadius: '8px',
            background: messageBanner.type === 'error' ? '#fef2f2' : '#f0fdf4',
            border: `1px solid ${messageBanner.type === 'error' ? '#fecaca' : '#bbf7d0'}`,
            color: messageBanner.type === 'error' ? '#991b1b' : '#166534',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}
        >
          <span>{messageBanner.text}</span>
          <button
            onClick={() => setMessageBanner({ text: '', type: '' })}
            style={{ background: 'transparent', border: 'none', cursor: 'pointer', fontSize: '16px' }}
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Tabs Navigation */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', borderBottom: '2px solid #e2e8f0', paddingBottom: '4px', flexWrap: 'wrap' }}>
        <button
          className={`btn-tab ${activeTab === 'list' ? 'active' : ''}`}
          onClick={() => setActiveTab('list')}
          style={{
            padding: '8px 16px',
            fontWeight: 600,
            fontSize: '14px',
            borderRadius: '6px 6px 0 0',
            border: 'none',
            cursor: 'pointer',
            background: activeTab === 'list' ? '#E21E25' : 'transparent',
            color: activeTab === 'list' ? '#fff' : '#64748b'
          }}
        >
          📋 Notes Register
        </button>

        <button
          className={`btn-tab ${activeTab === 'sales-return' ? 'active' : ''}`}
          onClick={() => setActiveTab('sales-return')}
          style={{
            padding: '8px 16px',
            fontWeight: 600,
            fontSize: '14px',
            borderRadius: '6px 6px 0 0',
            border: 'none',
            cursor: 'pointer',
            background: activeTab === 'sales-return' ? '#E21E25' : 'transparent',
            color: activeTab === 'sales-return' ? '#fff' : '#64748b'
          }}
        >
          🔄 Create Sales Return
        </button>

        <button
          className={`btn-tab ${activeTab === 'financial' ? 'active' : ''}`}
          onClick={() => setActiveTab('financial')}
          style={{
            padding: '8px 16px',
            fontWeight: 600,
            fontSize: '14px',
            borderRadius: '6px 6px 0 0',
            border: 'none',
            cursor: 'pointer',
            background: activeTab === 'financial' ? '#E21E25' : 'transparent',
            color: activeTab === 'financial' ? '#fff' : '#64748b'
          }}
        >
          💰 Financial Note (Credit / Debit)
        </button>

        <button
          className={`btn-tab ${activeTab === 'approvals' ? 'active' : ''}`}
          onClick={() => setActiveTab('approvals')}
          style={{
            padding: '8px 16px',
            fontWeight: 600,
            fontSize: '14px',
            borderRadius: '6px 6px 0 0',
            border: 'none',
            cursor: 'pointer',
            background: activeTab === 'approvals' ? '#E21E25' : 'transparent',
            color: activeTab === 'approvals' ? '#fff' : '#64748b',
            position: 'relative'
          }}
        >
          🛡️ Approvals Inbox
          {pendingApprovals.length > 0 && (
            <span style={{
              marginLeft: '6px',
              background: '#ef4444',
              color: '#fff',
              fontSize: '11px',
              padding: '2px 6px',
              borderRadius: '999px'
            }}>
              {pendingApprovals.length}
            </span>
          )}
        </button>

        <button
          className={`btn-tab ${activeTab === 'quarantine' ? 'active' : ''}`}
          onClick={() => setActiveTab('quarantine')}
          style={{
            padding: '8px 16px',
            fontWeight: 600,
            fontSize: '14px',
            borderRadius: '6px 6px 0 0',
            border: 'none',
            cursor: 'pointer',
            background: activeTab === 'quarantine' ? '#E21E25' : 'transparent',
            color: activeTab === 'quarantine' ? '#fff' : '#64748b'
          }}
        >
          🔬 Quarantine Inspection
          {quarantineLines.length > 0 && (
            <span style={{
              marginLeft: '6px',
              background: '#f59e0b',
              color: '#fff',
              fontSize: '11px',
              padding: '2px 6px',
              borderRadius: '999px'
            }}>
              {quarantineLines.length}
            </span>
          )}
        </button>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: NOTES REGISTER LIST */}
      {/* ============================================================== */}
      {activeTab === 'list' && (
        <div>
          {/* Filters Bar */}
          <div className="card" style={{ marginBottom: '16px', padding: '16px' }}>
            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', alignItems: 'center' }}>
              {/* Type Switcher */}
              <div style={{ display: 'inline-flex', borderRadius: '6px', border: '1px solid #cbd5e1', overflow: 'hidden' }}>
                {['ALL', 'CREDIT', 'DEBIT'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setListTypeFilter(t)}
                    style={{
                      padding: '6px 12px',
                      fontSize: '13px',
                      fontWeight: 500,
                      border: 'none',
                      background: listTypeFilter === t ? '#E21E25' : '#fff',
                      color: listTypeFilter === t ? '#fff' : '#475569',
                      cursor: 'pointer'
                    }}
                  >
                    {t === 'ALL' ? 'All Notes' : t === 'CREDIT' ? 'Credit Notes (CN)' : 'Debit Notes (DN)'}
                  </button>
                ))}
              </div>

              {/* Status Filter */}
              <select
                value={listStatusFilter}
                onChange={(e) => setListStatusFilter(e.target.value)}
                style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
              >
                <option value="">All Statuses</option>
                <option value={NOTE_STATUSES.APPROVED}>APPROVED</option>
                <option value={NOTE_STATUSES.PENDING_APPROVAL}>PENDING_APPROVAL</option>
                <option value={NOTE_STATUSES.CANCELLED}>CANCELLED</option>
                <option value={NOTE_STATUSES.DRAFT}>DRAFT</option>
              </select>

              {/* Retailer Filter */}
              <select
                value={selectedRetailerFilter}
                onChange={(e) => setSelectedRetailerFilter(e.target.value)}
                style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px', maxWidth: '200px' }}
              >
                <option value="">All Retailers</option>
                {retailers.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.tradeName || r.legalName}
                  </option>
                ))}
              </select>

              {/* Search */}
              <input
                type="text"
                placeholder="Search note no, retailer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  padding: '6px 12px',
                  borderRadius: '6px',
                  border: '1px solid #cbd5e1',
                  fontSize: '13px',
                  flex: '1',
                  minWidth: '180px'
                }}
              />

              <button
                type="button"
                onClick={loadNotesList}
                style={{
                  padding: '6px 14px',
                  borderRadius: '6px',
                  background: '#f1f5f9',
                  border: '1px solid #cbd5e1',
                  fontSize: '13px',
                  cursor: 'pointer'
                }}
              >
                🔄 Refresh
              </button>
            </div>
          </div>

          {/* Notes Table */}
          <div className="card" style={{ padding: '0', overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
              <thead>
                <tr style={{ background: '#f8fafc', borderBottom: '2px solid #e2e8f0', color: '#475569' }}>
                  <th style={{ padding: '12px 14px' }}>Note #</th>
                  <th style={{ padding: '12px 14px' }}>Date</th>
                  <th style={{ padding: '12px 14px' }}>Retailer</th>
                  <th style={{ padding: '12px 14px' }}>Type</th>
                  <th style={{ padding: '12px 14px' }}>Reason</th>
                  <th style={{ padding: '12px 14px' }}>Ref Invoice</th>
                  <th style={{ padding: '12px 14px', textAlign: 'right' }}>Total Amount</th>
                  <th style={{ padding: '12px 14px', textAlign: 'right' }}>Unallocated</th>
                  <th style={{ padding: '12px 14px', textAlign: 'center' }}>Status</th>
                  <th style={{ padding: '12px 14px', textAlign: 'center' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {loadingNotes ? (
                  <tr>
                    <td colSpan="10" style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
                      Loading notes register...
                    </td>
                  </tr>
                ) : notes.length === 0 ? (
                  <tr>
                    <td colSpan="10" style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
                      No credit or debit notes found matching the selected filters.
                    </td>
                  </tr>
                ) : (
                  notes.map((note) => {
                    const isCredit = note.type !== NOTE_TYPES.DEBIT;
                    return (
                      <tr key={note.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '12px 14px', fontWeight: 600, color: '#1e293b' }}>
                          {note.noteNo}
                        </td>
                        <td style={{ padding: '12px 14px', color: '#64748b' }}>
                          {new Date(note.date || note.createdAt).toLocaleDateString('en-IN')}
                        </td>
                        <td style={{ padding: '12px 14px' }}>
                          <div style={{ fontWeight: 500 }}>{note.retailer?.tradeName || note.retailer?.legalName}</div>
                          <small style={{ color: '#94a3b8' }}>GSTIN: {note.retailer?.gstin || 'Unregistered'}</small>
                        </td>
                        <td style={{ padding: '12px 14px' }}>
                          <span style={{
                            fontSize: '11px',
                            fontWeight: 600,
                            padding: '3px 8px',
                            borderRadius: '4px',
                            background: note.type === NOTE_TYPES.CREDIT_SALES_RETURN ? '#e0f2fe' : note.type === NOTE_TYPES.CREDIT_FINANCIAL ? '#ecfdf5' : '#fee2e2',
                            color: note.type === NOTE_TYPES.CREDIT_SALES_RETURN ? '#0369a1' : note.type === NOTE_TYPES.CREDIT_FINANCIAL ? '#047857' : '#b91c1c'
                          }}>
                            {note.type === NOTE_TYPES.CREDIT_SALES_RETURN ? 'CN: SALES RETURN' : note.type === NOTE_TYPES.CREDIT_FINANCIAL ? 'CN: FINANCIAL' : 'DEBIT NOTE'}
                          </span>
                        </td>
                        <td style={{ padding: '12px 14px', color: '#475569' }}>
                          {note.reasonCode?.replace(/_/g, ' ')}
                        </td>
                        <td style={{ padding: '12px 14px', color: '#64748b' }}>
                          {note.refInvoice ? (
                            <span style={{ fontWeight: 500, color: '#E21E25' }}>
                              {note.refInvoice.invoiceNo}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td style={{ padding: '12px 14px', textAlign: 'right', fontWeight: 600, color: '#0f172a' }}>
                          {formatCurrency(note.totalAmount)}
                        </td>
                        <td style={{ padding: '12px 14px', textAlign: 'right' }}>
                          {isCredit && note.status === NOTE_STATUSES.APPROVED ? (
                            <span style={{ color: note.balanceAmount > 0 ? '#ea580c' : '#16a34a', fontWeight: 500 }}>
                              {formatCurrency(note.balanceAmount)}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                        <td style={{ padding: '12px 14px', textAlign: 'center' }}>
                          <span style={{
                            fontSize: '11px',
                            fontWeight: 600,
                            padding: '3px 8px',
                            borderRadius: '4px',
                            background: note.status === NOTE_STATUSES.APPROVED ? '#dcfce7' : note.status === NOTE_STATUSES.PENDING_APPROVAL ? '#fef3c7' : '#f1f5f9',
                            color: note.status === NOTE_STATUSES.APPROVED ? '#15803d' : note.status === NOTE_STATUSES.PENDING_APPROVAL ? '#b45309' : '#64748b'
                          }}>
                            {note.status}
                          </span>
                        </td>
                        <td style={{ padding: '12px 14px', textAlign: 'center' }}>
                          <div style={{ display: 'flex', gap: '6px', justifyContent: 'center' }}>
                            <button
                              type="button"
                              onClick={() => handleOpenPrint(note.id)}
                              title="Print Note"
                              style={{
                                padding: '4px 8px',
                                fontSize: '11px',
                                borderRadius: '4px',
                                border: '1px solid #cbd5e1',
                                background: '#fff',
                                cursor: 'pointer'
                              }}
                            >
                              🖨️ Print
                            </button>

                            {isCredit && note.status === NOTE_STATUSES.APPROVED && note.balanceAmount > 0.01 && (
                              <button
                                type="button"
                                onClick={() => handleOpenAllocate(note)}
                                title="Allocate to open invoices"
                                style={{
                                  padding: '4px 8px',
                                  fontSize: '11px',
                                  borderRadius: '4px',
                                  border: '1px solid #E7D7B5',
                                  background: '#FDFBF7',
                                  color: '#785A18',
                                  cursor: 'pointer',
                                  fontWeight: 500
                                }}
                              >
                                Settle
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: CREATE SALES RETURN WIZARD */}
      {/* ============================================================== */}
      {activeTab === 'sales-return' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1.2fr)', gap: '20px' }}>
          {/* Left: Input Selection & Lines Grid */}
          <div className="card" style={{ padding: '20px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '16px', color: '#1e293b' }}>
              Sales Return Item Details
            </h2>

            {returnError && (
              <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {returnError}
              </div>
            )}
            {returnSuccess && (
              <div style={{ padding: '10px 14px', background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {returnSuccess}
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Select Retailer *
                </label>
                <select
                  value={srRetailerId}
                  onChange={(e) => setSrRetailerId(e.target.value)}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                >
                  <option value="">-- Choose Approved Retailer --</option>
                  {retailers.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.tradeName || r.legalName} ({r.stateCode})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Select Original Invoice *
                </label>
                <select
                  value={selectedInvoiceId}
                  onChange={(e) => setSelectedInvoiceId(e.target.value)}
                  disabled={!srRetailerId || loadingInvoices}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                >
                  <option value="">
                    {loadingInvoices ? 'Loading invoices...' : availableInvoices.length === 0 ? 'No ISSUED invoices found' : '-- Choose ISSUED Invoice --'}
                  </option>
                  {availableInvoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.invoiceNo} (Date: {new Date(inv.invoiceDate || inv.createdAt).toLocaleDateString('en-IN')}) - {formatCurrency(inv.netTotal)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Lines Grid */}
            {loadingInvoiceDetails ? (
              <div style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
                Loading original invoice items and return limits...
              </div>
            ) : invoiceDetails ? (
              <div>
                <h3 style={{ fontSize: '14px', fontWeight: 600, color: '#334155', marginBottom: '8px' }}>
                  Billed Line Items (Specify Return Quantity)
                </h3>
                <div style={{ overflowX: 'auto', border: '1px solid #e2e8f0', borderRadius: '6px', marginBottom: '16px' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                    <thead>
                      <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0', color: '#475569' }}>
                        <th style={{ padding: '8px 10px', textAlign: 'left' }}>SKU</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Billed Qty</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Prev. Returned</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Max Returnable</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Unit Price</th>
                        <th style={{ padding: '8px 10px', textAlign: 'center' }}>Return Qty</th>
                      </tr>
                    </thead>
                    <tbody>
                      {invoiceDetails.lines.map((line) => {
                        const currentVal = returnQtys[line.id] ?? 0;
                        const isExceeded = currentVal > line.maxReturnableQty;
                        return (
                          <tr key={line.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '8px 10px' }}>
                              <div style={{ fontWeight: 600, color: '#1e293b' }}>{line.sku?.name || line.skuId}</div>
                              <small style={{ color: '#64748b' }}>Code: {line.sku?.code} | GST: {line.gstRate}%</small>
                            </td>
                            <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: 500 }}>
                              {line.qty}
                            </td>
                            <td style={{ padding: '8px 10px', textAlign: 'right', color: '#64748b' }}>
                              {line.cumulativeReturnedQty || 0}
                            </td>
                            <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: 600, color: line.maxReturnableQty > 0 ? '#16a34a' : '#dc2626' }}>
                              {line.maxReturnableQty}
                            </td>
                            <td style={{ padding: '8px 10px', textAlign: 'right', color: '#475569' }}>
                              {formatCurrency(line.unitPrice)}
                            </td>
                            <td style={{ padding: '8px 10px', textAlign: 'center' }}>
                              <input
                                type="number"
                                min="0"
                                max={line.maxReturnableQty}
                                value={currentVal}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value, 10);
                                  setReturnQtys((prev) => ({
                                    ...prev,
                                    [line.id]: isNaN(val) ? 0 : Math.max(0, val)
                                  }));
                                }}
                                style={{
                                  width: '70px',
                                  padding: '4px 8px',
                                  borderRadius: '4px',
                                  border: `1px solid ${isExceeded ? '#dc2626' : '#cbd5e1'}`,
                                  background: isExceeded ? '#fef2f2' : '#fff',
                                  textAlign: 'center',
                                  fontWeight: 600
                                }}
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Reason & Remarks */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                      Return Reason Code *
                    </label>
                    <select
                      value={srReasonCode}
                      onChange={(e) => setSrReasonCode(e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                    >
                      <option value={NOTE_REASON_CODES.RETURN_DAMAGED}>RETURN_DAMAGED (Damaged Goods)</option>
                      <option value={NOTE_REASON_CODES.RETURN_WRONG_ITEM}>RETURN_WRONG_ITEM (Incorrect Delivery)</option>
                      <option value={NOTE_REASON_CODES.OTHER}>OTHER (Other Reason)</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                      Remarks / Notes
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Broken packaging reported upon receipt"
                      value={srNotes}
                      onChange={(e) => setSrNotes(e.target.value)}
                      style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div style={{ padding: '40px 20px', textAlign: 'center', color: '#94a3b8', background: '#f8fafc', borderRadius: '8px' }}>
                Select a retailer and referenced invoice to load billed items.
              </div>
            )}
          </div>

          {/* Right: Exact Tax Reversal Preview & Submission */}
          <div className="card" style={{ padding: '20px', alignSelf: 'start' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '16px', color: '#1e293b' }}>
              Tax Reversal Breakdown
            </h2>

            {returnPreview && returnPreview.lines.length > 0 ? (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                  <span>Returned Items Count:</span>
                  <strong style={{ color: '#1e293b' }}>{returnPreview.totalItems} units</strong>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                  <span>Gross Reversal Value:</span>
                  <span>{formatCurrency(returnPreview.grossAmount)}</span>
                </div>

                {returnPreview.discountAmount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#16a34a' }}>
                    <span>Pro-rata Discount Reversal:</span>
                    <span>-{formatCurrency(returnPreview.discountAmount)}</span>
                  </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                  <span>Taxable Value:</span>
                  <strong style={{ color: '#1e293b' }}>{formatCurrency(returnPreview.taxableAmount)}</strong>
                </div>

                <div style={{ borderTop: '1px dashed #cbd5e1', margin: '8px 0' }} />

                {returnPreview.cgstAmount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#64748b' }}>
                    <span>CGST Reversal:</span>
                    <span>{formatCurrency(returnPreview.cgstAmount)}</span>
                  </div>
                )}

                {returnPreview.sgstAmount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#64748b' }}>
                    <span>SGST Reversal:</span>
                    <span>{formatCurrency(returnPreview.sgstAmount)}</span>
                  </div>
                )}

                {returnPreview.igstAmount > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#64748b' }}>
                    <span>IGST Reversal (Inter-state):</span>
                    <span>{formatCurrency(returnPreview.igstAmount)}</span>
                  </div>
                )}

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                  <span>Total Tax Reversal:</span>
                  <strong style={{ color: '#1e293b' }}>{formatCurrency(returnPreview.taxAmount)}</strong>
                </div>

                {returnPreview.rounding !== 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#94a3b8' }}>
                    <span>Rounding Adjustment:</span>
                    <span>{returnPreview.rounding > 0 ? `+${returnPreview.rounding}` : returnPreview.rounding}</span>
                  </div>
                )}

                <div style={{ borderTop: '2px solid #e2e8f0', margin: '12px 0' }} />

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '16px', fontWeight: 700, color: '#0f172a' }}>
                  <span>Total Credit Note Amount:</span>
                  <span style={{ color: '#E21E25' }}>{formatCurrency(returnPreview.netTotal)}</span>
                </div>

                {/* Threshold Badge & Info */}
                {returnPreview.exceedsThreshold ? (
                  <div style={{ marginTop: '16px', padding: '12px', background: '#fffbeb', border: '1px solid #fcd34d', borderRadius: '6px', fontSize: '12px', color: '#b45309' }}>
                    ⚠️ <b>Threshold Exceeded:</b> Credit amount {formatCurrency(returnPreview.netTotal)} exceeds dealer limit ({formatCurrency(returnPreview.threshold)}).
                    <br />
                    This return will be queued for <b>DEALER OWNER</b> approval before posting to stock and ledger.
                  </div>
                ) : (
                  <div style={{ marginTop: '16px', padding: '12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '6px', fontSize: '12px', color: '#166534' }}>
                    ✅ <b>Auto-Approve Eligible:</b> Within dealer threshold ({formatCurrency(returnPreview.threshold)}).
                    <br />
                    Stock will move to <b>QUARANTINE</b> and ledger will be credited immediately.
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleCreateSalesReturn}
                  disabled={submittingReturn}
                  style={{
                    width: '100%',
                    marginTop: '16px',
                    padding: '12px',
                    background: '#E21E25',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '6px',
                    fontSize: '14px',
                    fontWeight: 600,
                    cursor: submittingReturn ? 'not-allowed' : 'pointer',
                    opacity: submittingReturn ? 0.7 : 1
                  }}
                >
                  {submittingReturn ? 'Creating Return...' : 'Confirm & Create Credit Note'}
                </button>
              </div>
            ) : (
              <div style={{ padding: '30px 10px', textAlign: 'center', color: '#94a3b8', fontSize: '13px' }}>
                Enter return quantities on the left to see live tax breakdown.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 3: CREATE FINANCIAL CREDIT/DEBIT NOTE */}
      {/* ============================================================== */}
      {activeTab === 'financial' && (
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.8fr) minmax(0, 1.2fr)', gap: '20px' }}>
          <div className="card" style={{ padding: '20px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '16px', color: '#1e293b' }}>
              Issue Financial Adjustment Note
            </h2>

            {finError && (
              <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {finError}
              </div>
            )}
            {finSuccess && (
              <div style={{ padding: '10px 14px', background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {finSuccess}
              </div>
            )}

            <form onSubmit={handleCreateFinancialNote}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Target Retailer *
                </label>
                <select
                  value={finRetailerId}
                  onChange={(e) => setFinRetailerId(e.target.value)}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                >
                  <option value="">-- Choose Approved Retailer --</option>
                  {retailers.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.tradeName || r.legalName} ({r.stateCode})
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                    Note Type *
                  </label>
                  <select
                    value={finType}
                    onChange={(e) => setFinType(e.target.value)}
                    style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                  >
                    <option value={NOTE_TYPES.CREDIT_FINANCIAL}>CREDIT NOTE (Credits Retailer Balance)</option>
                    <option value={NOTE_TYPES.DEBIT}>DEBIT NOTE (Debits Retailer Balance)</option>
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                    Reason Code *
                  </label>
                  <select
                    value={finReasonCode}
                    onChange={(e) => setFinReasonCode(e.target.value)}
                    style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                  >
                    <option value={NOTE_REASON_CODES.SCHEME_BENEFIT}>SCHEME_BENEFIT (Trade discount / scheme rebate)</option>
                    <option value={NOTE_REASON_CODES.RATE_DIFFERENCE}>RATE_DIFFERENCE (Price correction)</option>
                    <option value={NOTE_REASON_CODES.CHEQUE_BOUNCE_CHARGE}>CHEQUE_BOUNCE_CHARGE (Penalty fee)</option>
                    <option value={NOTE_REASON_CODES.OTHER}>OTHER (General financial adjustment)</option>
                  </select>
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Adjustment Amount (₹) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  placeholder="e.g. 5000"
                  value={finAmount}
                  onChange={(e) => setFinAmount(e.target.value)}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px', fontWeight: 600 }}
                />
              </div>

              {/* Taxable Toggle */}
              <div style={{ marginBottom: '16px', padding: '12px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '13px', color: '#334155' }}>
                  <input
                    type="checkbox"
                    checked={finIsTaxable}
                    onChange={(e) => setFinIsTaxable(e.target.checked)}
                  />
                  Apply GST Tax Treatment (Taxable Adjustment)
                </label>

                {finIsTaxable && (
                  <div style={{ marginTop: '10px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <span style={{ fontSize: '12px', color: '#64748b' }}>GST Rate:</span>
                    <select
                      value={finGstRate}
                      onChange={(e) => setFinGstRate(Number(e.target.value))}
                      style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                    >
                      <option value="5">5%</option>
                      <option value="12">12%</option>
                      <option value="18">18% (Standard)</option>
                      <option value="28">28%</option>
                    </select>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Remarks / Internal Notes
                </label>
                <textarea
                  rows="2"
                  placeholder="Optional details regarding scheme or calculation basis"
                  value={finNotes}
                  onChange={(e) => setFinNotes(e.target.value)}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                />
              </div>

              <button
                type="submit"
                disabled={submittingFin}
                style={{
                  padding: '10px 20px',
                  background: '#E21E25',
                  color: '#fff',
                  border: 'none',
                  borderRadius: '6px',
                  fontSize: '14px',
                  fontWeight: 600,
                  cursor: submittingFin ? 'not-allowed' : 'pointer'
                }}
              >
                {submittingFin ? 'Creating Note...' : `Issue ${finType === NOTE_TYPES.DEBIT ? 'Debit Note' : 'Financial Credit Note'}`}
              </button>
            </form>
          </div>

          {/* Right: Live Preview */}
          <div className="card" style={{ padding: '20px', alignSelf: 'start' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '16px', color: '#1e293b' }}>
              Note Summary Preview
            </h2>

            {financialPreview ? (
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                  <span>Adjustment Base:</span>
                  <strong style={{ color: '#1e293b' }}>{formatCurrency(financialPreview.taxableAmount || finAmount)}</strong>
                </div>

                {financialPreview.isTaxable ? (
                  <>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#64748b' }}>
                      <span>CGST ({finGstRate / 2}%):</span>
                      <span>{formatCurrency(financialPreview.cgst)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: '12px', color: '#64748b' }}>
                      <span>SGST ({finGstRate / 2}%):</span>
                      <span>{formatCurrency(financialPreview.sgst)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '13px', color: '#64748b' }}>
                      <span>Total GST:</span>
                      <strong style={{ color: '#1e293b' }}>{formatCurrency(financialPreview.taxAmount)}</strong>
                    </div>
                  </>
                ) : (
                  <div style={{ padding: '6px 0', fontSize: '12px', color: '#64748b', fontStyle: 'italic' }}>
                    Non-taxable adjustment (No GST applied)
                  </div>
                )}

                <div style={{ borderTop: '2px solid #e2e8f0', margin: '12px 0' }} />

                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '16px', fontWeight: 700, color: '#0f172a' }}>
                  <span>Total Amount:</span>
                  <span style={{ color: '#E21E25' }}>
                    {formatCurrency(financialPreview.netTotal)}
                  </span>
                </div>

                {financialPreview.exceedsThreshold ? (
                  <div style={{ marginTop: '16px', padding: '12px', background: '#fffbeb', border: '1px solid #fcd34d', borderRadius: '6px', fontSize: '12px', color: '#b45309' }}>
                    ⚠️ Exceeds approval threshold (₹50,000) - will require DEALER OWNER approval.
                  </div>
                ) : (
                  <div style={{ marginTop: '16px', padding: '12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: '6px', fontSize: '12px', color: '#166534' }}>
                    ✅ Under threshold (₹50,000) - will auto-approve immediately upon creation.
                  </div>
                )}
              </div>
            ) : (
              <div style={{ padding: '30px 10px', textAlign: 'center', color: '#94a3b8', fontSize: '13px' }}>
                Enter an amount to see calculation breakdown.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 4: APPROVALS INBOX */}
      {/* ============================================================== */}
      {activeTab === 'approvals' && (
        <div className="card" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 600, color: '#1e293b' }}>
              Pending Notes Requiring Approver Action
            </h2>
            <button
              type="button"
              onClick={loadPendingApprovals}
              style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '12px', cursor: 'pointer' }}
            >
              🔄 Refresh Inbox
            </button>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '2px solid #e2e8f0', color: '#475569' }}>
                <th style={{ padding: '10px 12px' }}>Note #</th>
                <th style={{ padding: '10px 12px' }}>Date</th>
                <th style={{ padding: '10px 12px' }}>Retailer</th>
                <th style={{ padding: '10px 12px' }}>Type</th>
                <th style={{ padding: '10px 12px' }}>Reason</th>
                <th style={{ padding: '10px 12px', textAlign: 'right' }}>Total Amount</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>Threshold Flag</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>Decision Actions</th>
              </tr>
            </thead>
            <tbody>
              {loadingApprovals ? (
                <tr>
                  <td colSpan="8" style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
                    Loading pending approval queue...
                  </td>
                </tr>
              ) : pendingApprovals.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ padding: '40px', textAlign: 'center', color: '#16a34a' }}>
                    ✨ All clear! There are no notes pending approval right now.
                  </td>
                </tr>
              ) : (
                pendingApprovals.map((note) => (
                  <tr key={note.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '12px', fontWeight: 600 }}>{note.noteNo}</td>
                    <td style={{ padding: '12px', color: '#64748b' }}>
                      {new Date(note.date || note.createdAt).toLocaleDateString('en-IN')}
                    </td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 500 }}>{note.retailer?.tradeName || note.retailer?.legalName}</div>
                      <small style={{ color: '#94a3b8' }}>Created by: {note.createdByEmail || 'Operator'}</small>
                    </td>
                    <td style={{ padding: '12px' }}>
                      <span style={{
                        fontSize: '11px',
                        fontWeight: 600,
                        padding: '3px 8px',
                        borderRadius: '4px',
                        background: note.type === NOTE_TYPES.CREDIT_SALES_RETURN ? '#e0f2fe' : '#ecfdf5',
                        color: note.type === NOTE_TYPES.CREDIT_SALES_RETURN ? '#0369a1' : '#047857'
                      }}>
                        {note.type}
                      </span>
                    </td>
                    <td style={{ padding: '12px', color: '#475569' }}>{note.reasonCode?.replace(/_/g, ' ')}</td>
                    <td style={{ padding: '12px', textAlign: 'right', fontWeight: 700, color: '#1e293b' }}>
                      {formatCurrency(note.totalAmount)}
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <span style={{
                        fontSize: '11px',
                        fontWeight: 600,
                        padding: '3px 8px',
                        borderRadius: '999px',
                        background: '#fef3c7',
                        color: '#b45309',
                        border: '1px solid #fde68a'
                      }}>
                        &gt; ₹50,000 Threshold
                      </span>
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      {isDealerOwner ? (
                        <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                          <button
                            type="button"
                            onClick={() => handleApprove(note.id)}
                            disabled={approvingId === note.id}
                            style={{
                              padding: '5px 12px',
                              background: '#16a34a',
                              color: '#fff',
                              border: 'none',
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: 600,
                              cursor: 'pointer'
                            }}
                          >
                            {approvingId === note.id ? 'Approving...' : 'Approve'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setRejectingNote(note);
                              setRejectionReason('');
                              setRejectModalOpen(true);
                            }}
                            style={{
                              padding: '5px 12px',
                              background: '#ef4444',
                              color: '#fff',
                              border: 'none',
                              borderRadius: '4px',
                              fontSize: '12px',
                              fontWeight: 600,
                              cursor: 'pointer'
                            }}
                          >
                            Reject
                          </button>
                        </div>
                      ) : (
                        <span style={{ fontSize: '11px', color: '#64748b' }}>
                          Dealer Owner Only
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 5: QUARANTINE RESOLUTION */}
      {/* ============================================================== */}
      {activeTab === 'quarantine' && (
        <div className="card" style={{ padding: '20px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              <h2 style={{ fontSize: '16px', fontWeight: 600, color: '#1e293b' }}>
                Quarantined Stock Inspection Queue
              </h2>
              <p style={{ fontSize: '13px', color: '#64748b', margin: '4px 0 0 0' }}>
                Stock returned by retailers is held in QUARANTINE. Run inspection to move items into AVAILABLE or DAMAGED.
              </p>
            </div>
            <button
              type="button"
              onClick={loadQuarantine}
              style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '12px', cursor: 'pointer' }}
            >
              🔄 Refresh Queue
            </button>
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '13px' }}>
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '2px solid #e2e8f0', color: '#475569' }}>
                <th style={{ padding: '10px 12px' }}>Return Note #</th>
                <th style={{ padding: '10px 12px' }}>Retailer</th>
                <th style={{ padding: '10px 12px' }}>SKU Code & Name</th>
                <th style={{ padding: '10px 12px' }}>Batch</th>
                <th style={{ padding: '10px 12px', textAlign: 'right' }}>Total Returned</th>
                <th style={{ padding: '10px 12px', textAlign: 'right' }}>Inspected (Good / Damaged)</th>
                <th style={{ padding: '10px 12px', textAlign: 'right' }}>Pending Inspection</th>
                <th style={{ padding: '10px 12px', textAlign: 'center' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {loadingQuarantine ? (
                <tr>
                  <td colSpan="8" style={{ padding: '30px', textAlign: 'center', color: '#64748b' }}>
                    Loading quarantine inventory...
                  </td>
                </tr>
              ) : quarantineLines.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ padding: '40px', textAlign: 'center', color: '#16a34a' }}>
                    ✨ No pending stock in quarantine! All returned items have been inspected.
                  </td>
                </tr>
              ) : (
                quarantineLines.map((line) => (
                  <tr key={line.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '12px', fontWeight: 600 }}>{line.note?.noteNo}</td>
                    <td style={{ padding: '12px' }}>{line.note?.retailer?.tradeName || line.note?.retailer?.legalName}</td>
                    <td style={{ padding: '12px' }}>
                      <div style={{ fontWeight: 600, color: '#1e293b' }}>{line.sku?.name}</div>
                      <small style={{ color: '#64748b' }}>Code: {line.sku?.code}</small>
                    </td>
                    <td style={{ padding: '12px', color: '#475569' }}>{line.batch || 'DEFAULT'}</td>
                    <td style={{ padding: '12px', textAlign: 'right', fontWeight: 500 }}>{line.quarantinedQty}</td>
                    <td style={{ padding: '12px', textAlign: 'right', color: '#64748b' }}>
                      <span style={{ color: '#16a34a' }}>{line.inspectedGoodQty}</span> / <span style={{ color: '#dc2626' }}>{line.inspectedDamagedQty}</span>
                    </td>
                    <td style={{ padding: '12px', textAlign: 'right', fontWeight: 700, color: '#f59e0b' }}>
                      {line.pendingQty} units
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>
                      <button
                        type="button"
                        onClick={() => handleOpenInspect(line)}
                        style={{
                          padding: '5px 12px',
                          background: '#E21E25',
                          color: '#fff',
                          border: 'none',
                          borderRadius: '4px',
                          fontSize: '12px',
                          fontWeight: 600,
                          cursor: 'pointer'
                        }}
                      >
                        Inspect & Release
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: QUARANTINE INSPECTION RESOLUTION */}
      {/* ============================================================== */}
      {inspectModalOpen && inspectingLine && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="card" style={{ width: '480px', padding: '24px', background: '#fff', borderRadius: '8px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '8px', color: '#1e293b' }}>
              🔬 Quarantine Stock Inspection
            </h2>
            <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
              Item: <b>{inspectingLine.sku?.name}</b> ({inspectingLine.pendingQty} units pending)
            </p>

            {inspectError && (
              <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {inspectError}
              </div>
            )}

            <form onSubmit={handleInspectSubmit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#16a34a', marginBottom: '4px' }}>
                    Good Quantity (→ AVAILABLE)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max={inspectingLine.pendingQty}
                    value={inspectGoodQty}
                    onChange={(e) => {
                      const g = Math.max(0, parseInt(e.target.value || 0, 10));
                      setInspectGoodQty(g);
                      setInspectDamagedQty(Math.max(0, inspectingLine.pendingQty - g));
                    }}
                    required
                    style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px', fontWeight: 600 }}
                  />
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#dc2626', marginBottom: '4px' }}>
                    Damaged Quantity (→ DAMAGED)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max={inspectingLine.pendingQty}
                    value={inspectDamagedQty}
                    onChange={(e) => {
                      const d = Math.max(0, parseInt(e.target.value || 0, 10));
                      setInspectDamagedQty(d);
                      setInspectGoodQty(Math.max(0, inspectingLine.pendingQty - d));
                    }}
                    required
                    style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '14px', fontWeight: 600 }}
                  />
                </div>
              </div>

              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Target Warehouse
                </label>
                <select
                  value={inspectWarehouseId}
                  onChange={(e) => setInspectWarehouseId(e.target.value)}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                >
                  {warehouses.map((wh) => (
                    <option key={wh.id} value={wh.id}>{wh.name} ({wh.code})</option>
                  ))}
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 600, color: '#475569', marginBottom: '4px' }}>
                  Inspection QC Remarks
                </label>
                <input
                  type="text"
                  placeholder="e.g. Scratched outer surface; acceptable internals"
                  value={inspectNotes}
                  onChange={(e) => setInspectNotes(e.target.value)}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px' }}
                />
              </div>

              <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  onClick={() => setInspectModalOpen(false)}
                  style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '13px', cursor: 'pointer' }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingInspect}
                  style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#E21E25', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}
                >
                  {submittingInspect ? 'Posting Resolution...' : 'Confirm Resolution'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: REJECT NOTE */}
      {/* ============================================================== */}
      {rejectModalOpen && rejectingNote && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="card" style={{ width: '420px', padding: '24px', background: '#fff', borderRadius: '8px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '8px', color: '#b91c1c' }}>
              Reject Note {rejectingNote.noteNo}
            </h2>
            <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
              Please state the reason for rejecting this note.
            </p>

            <textarea
              rows="3"
              placeholder="e.g. Return request not approved due to missing invoice documentation"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px', marginBottom: '16px' }}
            />

            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => setRejectModalOpen(false)}
                style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '13px', cursor: 'pointer' }}
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={submittingReject}
                onClick={handleRejectSubmit}
                style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#dc2626', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}
              >
                {submittingReject ? 'Rejecting...' : 'Confirm Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: ALLOCATE CREDIT NOTE */}
      {/* ============================================================== */}
      {allocationModalOpen && allocatingNote && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999
        }}>
          <div className="card" style={{ width: '480px', padding: '24px', background: '#fff', borderRadius: '8px' }}>
            <h2 style={{ fontSize: '16px', fontWeight: 700, marginBottom: '8px', color: '#1e293b' }}>
              Settle Credit Note {allocatingNote.noteNo}
            </h2>
            <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '16px' }}>
              Available Unallocated Credit: <b style={{ color: '#16a34a' }}>{formatCurrency(allocatingNote.balanceAmount)}</b>
            </p>

            {allocationError && (
              <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {allocationError}
              </div>
            )}
            {allocationSuccess && (
              <div style={{ padding: '10px 14px', background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', borderRadius: '6px', marginBottom: '16px', fontSize: '13px' }}>
                {allocationSuccess}
              </div>
            )}

            <p style={{ fontSize: '13px', color: '#475569', lineHeight: 1.5, marginBottom: '20px' }}>
              Clicking <b>Auto-Allocate (FIFO)</b> will systematically apply this credit note to open unpaid invoices for this retailer in order of invoice date.
            </p>

            <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
              <button
                type="button"
                onClick={() => setAllocationModalOpen(false)}
                style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '13px', cursor: 'pointer' }}
              >
                Close
              </button>
              <button
                type="button"
                disabled={submittingAllocation}
                onClick={handleAllocateSubmit}
                style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#E21E25', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}
              >
                {submittingAllocation ? 'Allocating...' : 'Auto-Allocate (FIFO)'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: PRINTABLE NOTE VIEW */}
      {/* ============================================================== */}
      {printModalOpen && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0,0,0,0.6)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 9999,
          padding: '20px'
        }}>
          <div className="card" style={{
            width: '800px',
            maxHeight: '90vh',
            overflowY: 'auto',
            background: '#fff',
            borderRadius: '8px',
            padding: '32px'
          }}>
            {loadingPrint || !printData ? (
              <div style={{ padding: '40px', textAlign: 'center', color: '#64748b' }}>
                Loading printable document...
              </div>
            ) : (
              <div>
                {/* Print Header */}
                <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '2px solid #0f172a', paddingBottom: '16px', marginBottom: '20px' }}>
                  <div>
                    <h1 style={{ fontSize: '20px', fontWeight: 800, margin: '0 0 4px 0', color: '#0f172a' }}>
                      {printData.dealer.name}
                    </h1>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      Dealership Code: <b>{printData.dealer.code}</b> | State Code: <b>{printData.dealer.stateCode}</b>
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      GSTIN: <b>{printData.dealer.gstin || '27AAACD1234F1Z5'}</b>
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: '#1e3a8a' }}>
                      {printData.title}
                    </div>
                    <div style={{ fontSize: '13px', fontWeight: 600, color: '#334155' }}>
                      Note No: {printData.noteNo}
                    </div>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>
                      Date: {new Date(printData.date).toLocaleDateString('en-IN')} | FY: {printData.financialYear}
                    </div>
                  </div>
                </div>

                {/* Recipient Details & Original Reference */}
                <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '20px', marginBottom: '20px', background: '#f8fafc', padding: '12px 16px', borderRadius: '6px' }}>
                  <div>
                    <div style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>
                      Retailer / Buyer Details
                    </div>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: '#1e293b', marginTop: '2px' }}>
                      {printData.retailer.tradeName || printData.retailer.legalName}
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      Legal Name: {printData.retailer.legalName}
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      GSTIN: {printData.retailer.gstin || 'Unregistered'} | State: {printData.retailer.stateCode}
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      Address: {printData.retailer.billingAddress || 'N/A'}
                    </div>
                  </div>

                  <div>
                    <div style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>
                      Reference Information
                    </div>
                    {printData.refInvoice ? (
                      <>
                        <div style={{ fontSize: '12px', color: '#475569', marginTop: '2px' }}>
                          Original Invoice No: <b>{printData.refInvoice.invoiceNo}</b>
                        </div>
                        <div style={{ fontSize: '12px', color: '#475569' }}>
                          Invoice Date: {new Date(printData.refInvoice.invoiceDate).toLocaleDateString('en-IN')}
                        </div>
                      </>
                    ) : (
                      <div style={{ fontSize: '12px', color: '#475569', marginTop: '2px' }}>
                        Type: Financial Adjustment ({printData.type})
                      </div>
                    )}
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      Reason for Issue: <b>{printData.reasonCode?.replace(/_/g, ' ')}</b>
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569' }}>
                      Status: <b style={{ color: '#16a34a' }}>{printData.status}</b>
                    </div>
                  </div>
                </div>

                {/* Items Table if Sales Return */}
                {printData.lines && printData.lines.length > 0 && (
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px', marginBottom: '20px' }}>
                    <thead>
                      <tr style={{ background: '#f1f5f9', borderBottom: '2px solid #cbd5e1', color: '#334155' }}>
                        <th style={{ padding: '8px 10px', textAlign: 'left' }}>Item Description</th>
                        <th style={{ padding: '8px 10px', textAlign: 'left' }}>HSN</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Qty</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Rate</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Taxable</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>GST %</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Tax</th>
                        <th style={{ padding: '8px 10px', textAlign: 'right' }}>Total (₹)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {printData.lines.map((l, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid #e2e8f0' }}>
                          <td style={{ padding: '8px 10px' }}>
                            <b>{l.skuName}</b>
                            <div style={{ fontSize: '10px', color: '#64748b' }}>{l.skuCode} | Batch: {l.batch}</div>
                          </td>
                          <td style={{ padding: '8px 10px' }}>{l.hsnCode || '—'}</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right' }}>{l.qty}</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right' }}>{formatCurrency(l.unitPrice)}</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right' }}>{formatCurrency(l.taxableValue)}</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right' }}>{l.gstRate}%</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right' }}>{formatCurrency(l.lineTax)}</td>
                          <td style={{ padding: '8px 10px', textAlign: 'right', fontWeight: 600 }}>{formatCurrency(l.lineTotal)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {/* Totals Summary Box */}
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '24px' }}>
                  <div style={{ width: '320px', background: '#f8fafc', padding: '16px', borderRadius: '6px', border: '1px solid #e2e8f0', fontSize: '13px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#64748b' }}>
                      <span>Gross Amount:</span>
                      <span>{formatCurrency(printData.totals.grossAmount)}</span>
                    </div>

                    {printData.totals.discountAmount > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#16a34a' }}>
                        <span>Discount Reversal:</span>
                        <span>-{formatCurrency(printData.totals.discountAmount)}</span>
                      </div>
                    )}

                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', color: '#64748b' }}>
                      <span>Taxable Value:</span>
                      <strong>{formatCurrency(printData.totals.taxableAmount)}</strong>
                    </div>

                    {printData.totals.cgstAmount > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: '12px', color: '#64748b' }}>
                        <span>CGST:</span>
                        <span>{formatCurrency(printData.totals.cgstAmount)}</span>
                      </div>
                    )}

                    {printData.totals.sgstAmount > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: '12px', color: '#64748b' }}>
                        <span>SGST:</span>
                        <span>{formatCurrency(printData.totals.sgstAmount)}</span>
                      </div>
                    )}

                    {printData.totals.igstAmount > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0', fontSize: '12px', color: '#64748b' }}>
                        <span>IGST:</span>
                        <span>{formatCurrency(printData.totals.igstAmount)}</span>
                      </div>
                    )}

                    <div style={{ borderTop: '1px solid #cbd5e1', margin: '8px 0' }} />

                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>
                      <span>Total Note Value:</span>
                      <span style={{ color: '#E21E25' }}>{formatCurrency(printData.totals.totalAmount)}</span>
                    </div>
                  </div>
                </div>

                {/* Signatory Footer */}
                <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #e2e8f0', paddingTop: '20px', fontSize: '12px', color: '#64748b' }}>
                  <div>
                    {printData.approval?.approvedByEmail && (
                      <div>
                        Approved by: <b>{printData.approval.approvedByEmail}</b>
                        <br />
                        Date: {new Date(printData.approval.approvedAt).toLocaleString('en-IN')}
                      </div>
                    )}
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ height: '40px' }} />
                    <div style={{ borderTop: '1px solid #94a3b8', width: '180px', paddingTop: '4px', fontWeight: 600, color: '#334155' }}>
                      For {printData.dealer.name}
                      <br />
                      Authorized Signatory
                    </div>
                  </div>
                </div>

                {/* Buttons */}
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '24px' }}>
                  <button
                    type="button"
                    onClick={() => setPrintModalOpen(false)}
                    style={{ padding: '8px 16px', borderRadius: '6px', border: '1px solid #cbd5e1', background: '#fff', fontSize: '13px', cursor: 'pointer' }}
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={() => window.print()}
                    style={{ padding: '8px 16px', borderRadius: '6px', border: 'none', background: '#E21E25', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}
                  >
                    🖨️ Print Document
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

