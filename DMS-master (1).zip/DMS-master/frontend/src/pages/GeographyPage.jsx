import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchGeoTree,
  createGeoNode,
  updateGeoNode,
  deleteGeoNode
} from '../services/api/masters.js';
import { isBrandRole } from '@dms/shared';

const GEO_LEVEL_ORDER = ['ZONE', 'STATE', 'REGION', 'CITY', 'CLUSTER'];

function getNextChildType(parentType) {
  const idx = GEO_LEVEL_ORDER.indexOf(parentType);
  if (idx === -1 || idx >= GEO_LEVEL_ORDER.length - 1) return null;
  return GEO_LEVEL_ORDER[idx + 1];
}

const TYPE_COLORS = {
  ZONE: { bg: '#FEF2F2', color: '#991B1B', border: '#FECACA' },
  STATE: { bg: '#f3e8ff', color: '#6b21a8', border: '#e9d5ff' },
  REGION: { bg: '#e0f2fe', color: '#0369a1', border: '#bae6fd' },
  CITY: { bg: '#dcfce7', color: '#15803d', border: '#bbf7d0' },
  CLUSTER: { bg: '#ffedd5', color: '#c2410c', border: '#fed7aa' }
};

function TreeNode({
  node,
  canEdit,
  searchTerm,
  onAddChild,
  onEdit,
  onDelete
}) {
  const [expanded, setExpanded] = useState(true);
  const nextType = getNextChildType(node.type);
  const hasChildren = node.children && node.children.length > 0;
  const colors = TYPE_COLORS[node.type] || TYPE_COLORS.ZONE;

  const matchesSearch =
    !searchTerm ||
    node.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    node.type.toLowerCase().includes(searchTerm.toLowerCase());

  return (
    <div className={`geo-tree-node-wrapper ${matchesSearch ? 'matches-search' : ''}`}>
      <div className="geo-tree-row">
        <div className="geo-node-main">
          {hasChildren ? (
            <button
              className="expand-toggle-btn"
              onClick={() => setExpanded(!expanded)}
              aria-label={expanded ? 'Collapse' : 'Expand'}
            >
              {expanded ? '▼' : '►'}
            </button>
          ) : (
            <span className="leaf-bullet">•</span>
          )}

          <span
            className="geo-type-pill"
            style={{
              backgroundColor: colors.bg,
              color: colors.color,
              borderColor: colors.border
            }}
          >
            {node.type}
          </span>

          <strong className="geo-node-name">{node.name}</strong>

          <span className="geo-path-hint">{node.path}</span>

          {node._count?.dealers > 0 && (
            <span className="geo-dealers-count">
              {node._count.dealers} dealer{node._count.dealers === 1 ? '' : 's'}
            </span>
          )}
        </div>

        {canEdit && (
          <div className="geo-node-actions">
            {nextType && (
              <button
                className="btn btn-outline btn-xs"
                onClick={() => onAddChild(node, nextType)}
                title={`Add ${nextType} under ${node.name}`}
              >
                + Add {nextType}
              </button>
            )}
            <button
              className="btn btn-secondary btn-xs"
              onClick={() => onEdit(node)}
              title="Edit name"
            >
              Edit
            </button>
            <button
              className="btn btn-danger-outline btn-xs"
              onClick={() => onDelete(node)}
              title="Delete node"
            >
              Delete
            </button>
          </div>
        )}
      </div>

      {hasChildren && expanded && (
        <div className="geo-tree-children">
          {node.children.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              canEdit={canEdit}
              searchTerm={searchTerm}
              onAddChild={onAddChild}
              onEdit={onEdit}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function GeographyPage({ user }) {
  const [tree, setTree] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [modalMode, setModalMode] = useState(null); // 'create' | 'edit' | null
  const [activeNode, setActiveNode] = useState(null);
  const [formData, setFormData] = useState({ name: '', type: 'ZONE', parentId: null });
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState(null);

  const canEdit = isBrandRole(user.role);

  const loadTree = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchGeoTree(user);
      setTree(data.tree || []);
    } catch (err) {
      setError(err.message || 'Failed to load geography tree.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadTree();
  }, [loadTree]);

  const handleOpenAddRoot = () => {
    setActiveNode(null);
    setFormData({ name: '', type: 'ZONE', parentId: null });
    setActionError(null);
    setModalMode('create');
  };

  const handleOpenAddChild = (parent, nextType) => {
    setActiveNode(parent);
    setFormData({ name: '', type: nextType, parentId: parent.id });
    setActionError(null);
    setModalMode('create');
  };

  const handleOpenEdit = (node) => {
    setActiveNode(node);
    setFormData({ name: node.name, type: node.type, parentId: node.parentId });
    setActionError(null);
    setModalMode('edit');
  };

  const handleDelete = async (node) => {
    if (node._count?.dealers > 0) {
      return alert(`Cannot delete '${node.name}': it has ${node._count.dealers} associated dealer(s).`);
    }

    if (
      !confirm(
        `Are you sure you want to delete '${node.name}' (${node.type})? Any descendant nodes will also be removed.`
      )
    ) {
      return;
    }

    try {
      await deleteGeoNode(user, node.id);
      loadTree();
    } catch (err) {
      alert(err.message || 'Failed to delete geography node.');
    }
  };

  const handleSubmitModal = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      return setActionError('Name is required.');
    }

    setSubmitting(true);
    setActionError(null);

    try {
      if (modalMode === 'create') {
        await createGeoNode(user, formData);
      } else if (modalMode === 'edit') {
        await updateGeoNode(user, activeNode.id, { name: formData.name });
      }
      setModalMode(null);
      loadTree();
    } catch (err) {
      setActionError(err.message || 'Operation failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="master-page geography-page">
      <div className="page-header-row">
        <div>
          <h2>Geography Hierarchy</h2>
          <p className="page-desc">
            Organize distribution network zones: <code>ZONE → STATE → REGION → CITY → CLUSTER</code>
          </p>
        </div>

        <div className="header-actions">
          {canEdit && (
            <button className="btn btn-primary" onClick={handleOpenAddRoot}>
              + Add Root Zone
            </button>
          )}
          <button className="btn btn-secondary" onClick={loadTree}>
            ↻ Refresh
          </button>
        </div>
      </div>

      <div className="hierarchy-legend-bar">
        <span className="legend-title">Hierarchy Levels:</span>
        {GEO_LEVEL_ORDER.map((level, i) => (
          <span key={level} className="legend-step">
            <span
              className="geo-type-pill"
              style={{
                backgroundColor: TYPE_COLORS[level].bg,
                color: TYPE_COLORS[level].color,
                borderColor: TYPE_COLORS[level].border
              }}
            >
              {level}
            </span>
            {i < GEO_LEVEL_ORDER.length - 1 && <span className="arrow">→</span>}
          </span>
        ))}
      </div>

      <div className="search-filter-bar">
        <input
          type="text"
          className="search-input"
          placeholder="Search by location name or level…"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {searchTerm && (
          <button className="btn btn-outline btn-sm" onClick={() => setSearchTerm('')}>
            Clear Search
          </button>
        )}
      </div>

      {loading ? (
        <div className="loading-card">
          <div className="spinner" />
          <p>Loading geography hierarchy tree…</p>
        </div>
      ) : error ? (
        <div className="error-alert">
          <p>{error}</p>
          <button className="btn btn-secondary btn-sm" onClick={loadTree}>
            Try Again
          </button>
        </div>
      ) : tree.length === 0 ? (
        <div className="empty-card">
          <div className="empty-icon">🗺️</div>
          <h3>No Geography Nodes Configured</h3>
          <p>Start by adding your first root Zone.</p>
          {canEdit && (
            <button className="btn btn-primary" onClick={handleOpenAddRoot}>
              + Create First Zone
            </button>
          )}
        </div>
      ) : (
        <div className="tree-container-card">
          {tree.map((rootNode) => (
            <TreeNode
              key={rootNode.id}
              node={rootNode}
              canEdit={canEdit}
              searchTerm={searchTerm}
              onAddChild={handleOpenAddChild}
              onEdit={handleOpenEdit}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {modalMode && (
        <div className="modal-backdrop" onClick={() => setModalMode(null)}>
          <div className="modal-card modal-sm" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>
                {modalMode === 'create'
                  ? `Add ${formData.type} ${activeNode ? `under ${activeNode.name}` : ''}`
                  : `Edit ${activeNode?.name}`}
              </h3>
              <button className="close-btn" onClick={() => setModalMode(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="modal-body">
              {activeNode && modalMode === 'create' && (
                <div className="info-box">
                  <strong>Parent:</strong> {activeNode.name} ({activeNode.type})
                  <br />
                  <strong>Child Level:</strong> {formData.type} (Strict hierarchy enforced)
                </div>
              )}

              <label className="form-field">
                <span>Location Name:</span>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={`e.g. ${
                    formData.type === 'ZONE'
                      ? 'North Zone'
                      : formData.type === 'STATE'
                      ? 'Maharashtra'
                      : formData.type === 'REGION'
                      ? 'Pune Region'
                      : formData.type === 'CITY'
                      ? 'Pune City'
                      : 'Hinjewadi Auto Cluster'
                  }`}
                  autoFocus
                />
              </label>

              {actionError && <div className="error-alert">{actionError}</div>}

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setModalMode(null)}
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving…' : modalMode === 'create' ? 'Create Node' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

