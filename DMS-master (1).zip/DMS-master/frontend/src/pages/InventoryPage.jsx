import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  fetchWarehouses,
  createWarehouse,
  fetchAsns,
  fetchInTransitAsns,
  fetchAsnById,
  createPrimaryDispatchAsn,
  confirmGrn,
  fetchClaims,
  approveClaim,
  rejectClaim,
  fetchStockOnHand,
  fetchStockLedger,
  updateMinStockThreshold,
  fetchTransfers,
  createTransfer,
  fetchPurchaseReturns,
  createPurchaseReturn,
  fetchStockAudits,
  createStockAudit,
  approveStockAudit,
  rejectStockAudit,
  fetchInventoryAnalytics
} from '../services/api/inventory.js';
import { fetchSkus, fetchDealers } from '../services/api/masters.js';
import { isBrandRole, DASHBOARD_ROLES } from '@dms/shared';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

export function InventoryPage({ user }) {
  const isBrand = isBrandRole(user.role);
  const isDealerOwner = user.role === DASHBOARD_ROLES.DEALER_OWNER || isBrand;

  // Active Tab
  const [activeTab, setActiveTab] = useState(isBrand ? 'asns' : 'grn');

  // Master lookups
  const [dealers, setDealers] = useState([]);
  const [skus, setSkus] = useState([]);
  const [warehouses, setWarehouses] = useState([]);

  // Data states
  const [asns, setAsns] = useState([]);
  const [inTransitAsns, setInTransitAsns] = useState([]);
  const [claims, setClaims] = useState([]);
  const [stockOnHand, setStockOnHand] = useState([]);
  const [stockLedger, setStockLedger] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [purchaseReturns, setPurchaseReturns] = useState([]);
  const [audits, setAudits] = useState([]);
  const [analytics, setAnalytics] = useState(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters
  const [selectedDealerId, setSelectedDealerId] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState('');
  const [selectedSkuId, setSelectedSkuId] = useState('');
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const [ledgerSearchSku, setLedgerSearchSku] = useState('');
  const [stockSubView, setStockSubView] = useState('inventory'); // 'inventory' | 'reorders'

  // Modals
  const [showDispatchModal, setShowDispatchModal] = useState(false);
  const [showGrnModal, setShowGrnModal] = useState(false);
  const [selectedAsnForGrn, setSelectedAsnForGrn] = useState(null);
  const [grnWarehouseId, setGrnWarehouseId] = useState('');
  const [grnLineData, setGrnLineData] = useState({});
  const [grnSubmitting, setGrnSubmitting] = useState(false);
  const [barcodeScanInput, setBarcodeScanInput] = useState('');
  const [barcodeScanFeedback, setBarcodeScanFeedback] = useState(null);
  const barcodeInputRef = useRef(null);

  useEffect(() => {
    if (showGrnModal) {
      const timer = setTimeout(() => {
        barcodeInputRef.current?.focus();
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [showGrnModal]);

  const [showTransferModal, setShowTransferModal] = useState(false);
  const [newTransfer, setNewTransfer] = useState({
    sourceWarehouseId: '',
    targetWarehouseId: '',
    notes: '',
    lines: [{ skuId: '', batch: '', qty: 10 }]
  });

  const [showPurchaseReturnModal, setShowPurchaseReturnModal] = useState(false);
  const [newPurchaseReturn, setNewPurchaseReturn] = useState({
    warehouseId: '',
    reason: 'DAMAGED_IN_TRANSIT',
    fromStockState: 'DAMAGED',
    notes: '',
    lines: [{ skuId: '', batch: '', qty: 5, fromStockState: 'DAMAGED' }]
  });

  const [showAuditModal, setShowAuditModal] = useState(false);
  const [newAudit, setNewAudit] = useState({
    warehouseId: '',
    notes: '',
    lines: [{ skuId: '', batch: '', countedQty: 0, reasonCode: 'COUNTING_VARIANCE' }]
  });
  const [auditScanInput, setAuditScanInput] = useState('');

  const [showClaimModal, setShowClaimModal] = useState(false);
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [claimActionType, setClaimActionType] = useState('APPROVE');
  const [claimNotes, setClaimNotes] = useState('');

  const [showMinStockModal, setShowMinStockModal] = useState(false);
  const [editingMinStockSku, setEditingMinStockSku] = useState(null);
  const [newMinStockVal, setNewMinStockVal] = useState('10');

  // New Dispatch Form State (Brand)
  const [newDispatch, setNewDispatch] = useState({
    invoiceNo: '',
    invoiceDate: new Date().toISOString().slice(0, 10),
    dealerId: '',
    notes: '',
    lines: [{ skuId: '', invoicedQty: 50, batch: '', landingPrice: '' }]
  });

  // Load Initial Data
  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [skusRes, whRes] = await Promise.all([
        fetchSkus(user, { limit: 150 }).catch(() => ({ skus: [], items: [] })),
        fetchWarehouses(user).catch(() => ({ warehouses: [] }))
      ]);

      const skusList = skusRes.skus || skusRes.items || [];
      const whList = whRes.warehouses || [];
      setSkus(skusList);
      setWarehouses(whList);

      if (isBrand) {
        const [dealersRes, asnsRes, claimsRes, stockRes, trfRes, prRes, audRes] = await Promise.all([
          fetchDealers(user).catch(() => ({ dealers: [] })),
          fetchAsns(user, { dealerId: selectedDealerId }),
          fetchClaims(user, { dealerId: selectedDealerId }),
          fetchStockOnHand(user, { dealerId: selectedDealerId, lowStockOnly }),
          fetchTransfers(user, { dealerId: selectedDealerId }).catch(() => ({ transfers: [] })),
          fetchPurchaseReturns(user, { dealerId: selectedDealerId }).catch(() => ({ purchaseReturns: [] })),
          fetchStockAudits(user, { dealerId: selectedDealerId }).catch(() => ({ audits: [] }))
        ]);
        setDealers(dealersRes.dealers || []);
        setAsns(asnsRes.asns || []);
        setClaims(claimsRes.claims || []);
        setStockOnHand(stockRes.stockOnHand || []);
        setTransfers(trfRes.transfers || []);
        setPurchaseReturns(prRes.purchaseReturns || []);
        setAudits(audRes.audits || []);
      } else {
        const [inTransitRes, asnsRes, claimsRes, stockRes, ledgerRes, trfRes, prRes, audRes, analyticsRes] = await Promise.all([
          fetchInTransitAsns(user),
          fetchAsns(user),
          fetchClaims(user),
          fetchStockOnHand(user, { lowStockOnly, warehouseId: selectedWarehouseId }),
          fetchStockLedger(user, { skuId: ledgerSearchSku }),
          fetchTransfers(user).catch(() => ({ transfers: [] })),
          fetchPurchaseReturns(user).catch(() => ({ purchaseReturns: [] })),
          fetchStockAudits(user).catch(() => ({ audits: [] })),
          fetchInventoryAnalytics(user, { warehouseId: selectedWarehouseId }).catch(() => null)
        ]);
        setInTransitAsns(inTransitRes.inTransitAsns || []);
        setAsns(asnsRes.asns || []);
        setClaims(claimsRes.claims || []);
        setStockOnHand(stockRes.stockOnHand || []);
        setStockLedger(ledgerRes.entries || []);
        setTransfers(trfRes.transfers || []);
        setPurchaseReturns(prRes.purchaseReturns || []);
        setAudits(audRes.audits || []);
        setAnalytics(analyticsRes);
      }
    } catch (err) {
      setError(err.message || 'Failed to load inventory data.');
    } finally {
      setLoading(false);
    }
  }, [user, isBrand, selectedDealerId, selectedWarehouseId, lowStockOnly, ledgerSearchSku]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Primary Dispatch Line handlers (Brand)
  const handleAddDispatchLine = () => {
    setNewDispatch({
      ...newDispatch,
      lines: [...newDispatch.lines, { skuId: '', invoicedQty: 50, batch: '', landingPrice: '' }]
    });
  };

  const handleRemoveDispatchLine = (index) => {
    const updated = newDispatch.lines.filter((_, i) => i !== index);
    setNewDispatch({ ...newDispatch, lines: updated });
  };

  const handleUpdateDispatchLine = (index, field, value) => {
    const updated = [...newDispatch.lines];
    updated[index] = { ...updated[index], [field]: value };
    if (field === 'skuId') {
      const s = skus.find((item) => item.id === value);
      if (s) {
        if (!updated[index].landingPrice) updated[index].landingPrice = s.landingPrice || (s.mrp * 0.6);
        if (!updated[index].batch) updated[index].batch = `B-${new Date().getFullYear()}-${s.code?.slice(0, 4) || 'GEN'}`;
      }
    }
    setNewDispatch({ ...newDispatch, lines: updated });
  };

  const handleCreateDispatch = async (e) => {
    e.preventDefault();
    if (!newDispatch.dealerId) {
      alert('Please select a destination dealership.');
      return;
    }
    if (newDispatch.lines.some((l) => !l.skuId || !l.invoicedQty)) {
      alert('Please select SKU and quantity for all lines.');
      return;
    }

    try {
      await createPrimaryDispatchAsn(user, newDispatch);
      alert('Primary Dispatch ASN created successfully in status IN_TRANSIT.');
      setShowDispatchModal(false);
      setNewDispatch({
        invoiceNo: '',
        invoiceDate: new Date().toISOString().slice(0, 10),
        dealerId: '',
        notes: '',
        lines: [{ skuId: '', invoicedQty: 50, batch: '', landingPrice: '' }]
      });
      loadData();
    } catch (err) {
      alert('Failed to create dispatch: ' + err.message);
    }
  };

  // Open GRN Receiving Modal (Dealer)
  const handleOpenGrnModal = async (asn) => {
    try {
      const fullAsn = await fetchAsnById(user, asn.id);
      setSelectedAsnForGrn(fullAsn);

      // Default warehouse
      const defWh = warehouses.find((w) => w.isDefault) || warehouses[0];
      setGrnWarehouseId(defWh ? defWh.id : '');

      // Initialize line inputs with 0 scanned good quantity to facilitate barcode scan
      const initialLines = {};
      (fullAsn.lines || []).forEach((line) => {
        initialLines[line.id] = {
          receivedGoodQty: line.invoicedQty,
          shortQty: 0,
          excessQty: 0,
          damagedQty: 0,
          varianceReason: '',
          photoUrl: ''
        };
      });
      setGrnLineData(initialLines);
      setBarcodeScanInput('');
      setBarcodeScanFeedback(null);
      setShowGrnModal(true);
    } catch (err) {
      alert('Failed to load ASN details: ' + err.message);
    }
  };

  const handleUpdateGrnLine = (lineId, field, value) => {
    setGrnLineData((prev) => {
      const current = prev[lineId] || {};
      const updated = { ...current, [field]: value };

      // Helper calculations
      const invQty = selectedAsnForGrn?.lines?.find((l) => l.id === lineId)?.invoicedQty || 0;
      const good = parseInt(field === 'receivedGoodQty' ? value : current.receivedGoodQty || 0, 10) || 0;
      const damaged = parseInt(field === 'damagedQty' ? value : current.damagedQty || 0, 10) || 0;

      if (field === 'receivedGoodQty' || field === 'damagedQty') {
        const totalReceived = good + damaged;
        if (totalReceived < invQty) {
          updated.shortQty = invQty - totalReceived;
          updated.excessQty = 0;
        } else if (good > invQty) {
          updated.excessQty = good - invQty;
          updated.shortQty = 0;
        } else {
          updated.shortQty = 0;
          updated.excessQty = 0;
        }
      }

      return {
        ...prev,
        [lineId]: updated
      };
    });
  };

  // Barcode Scanner handler for GRN
  const handleBarcodeScan = (e, overrideCode = null) => {
    if (e?.preventDefault) e.preventDefault();
    if (e?.stopPropagation) e.stopPropagation();

    const raw = (overrideCode !== null && overrideCode !== undefined ? overrideCode : barcodeScanInput);
    const rawCode = String(raw || '').trim().toUpperCase().replace(/[\r\n\t]/g, '');
    if (!rawCode || !selectedAsnForGrn) return;

    // Search lines by SKU barcode, code, batch, or article
    const matchingLine = (selectedAsnForGrn.lines || []).find((l) => {
      const skuCode = (l.sku?.code || '').toUpperCase();
      const skuBarcode = (l.sku?.barcode || '').toUpperCase();
      const lineBatch = (l.batch || '').toUpperCase();
      const skuName = (l.sku?.name || '').toUpperCase();

      return (
        (skuBarcode && skuBarcode === rawCode) ||
        skuCode === rawCode ||
        lineBatch === rawCode ||
        (skuBarcode && (skuBarcode.includes(rawCode) || rawCode.includes(skuBarcode))) ||
        skuCode.includes(rawCode) ||
        rawCode.includes(skuCode) ||
        skuName.includes(rawCode)
      );
    });

    if (matchingLine) {
      const lineId = matchingLine.id;
      const currentGood = parseInt(grnLineData[lineId]?.receivedGoodQty || 0, 10);
      const newGood = currentGood + 1;

      handleUpdateGrnLine(lineId, 'receivedGoodQty', newGood);
      setBarcodeScanFeedback({
        type: 'success',
        message: `✅ Scanned ${matchingLine.sku?.code} (${matchingLine.sku?.name}): +1 pcs accepted (Total: ${newGood} / Invoiced: ${matchingLine.invoicedQty})`
      });
      setBarcodeScanInput('');
      setTimeout(() => barcodeInputRef.current?.focus(), 50);

      // Play affirmation beep
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.value = 880;
        gain.gain.value = 0.1;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      } catch (_) {}
    } else {
      const availableList = (selectedAsnForGrn.lines || [])
        .map((l) => `${l.sku?.code}${l.sku?.barcode ? ` (${l.sku.barcode})` : ''}`)
        .join(', ');
      setBarcodeScanFeedback({
        type: 'error',
        message: `⚠️ Code "${rawCode}" not found in this shipment. Available items: ${availableList}`
      });
      setTimeout(() => barcodeInputRef.current?.focus(), 50);

      // Play warning buzz
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.frequency.value = 220;
        gain.gain.value = 0.1;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      } catch (_) {}
    }
  };

  // Bulk Accept Sealed Cartons
  const handleBulkAcceptSealedCartons = () => {
    if (!selectedAsnForGrn) return;
    const allAccepted = {};
    (selectedAsnForGrn.lines || []).forEach((line) => {
      allAccepted[line.id] = {
        receivedGoodQty: line.invoicedQty,
        shortQty: 0,
        excessQty: 0,
        damagedQty: 0,
        varianceReason: '',
        photoUrl: ''
      };
    });
    setGrnLineData(allAccepted);
    setBarcodeScanFeedback({
      type: 'success',
      message: '📦 All sealed cartons bulk accepted: Scanned quantity matches 100% of invoiced quantity.'
    });
    setTimeout(() => barcodeInputRef.current?.focus(), 50);
  };

  // Reset Scanned Counts to 0
  const handleResetScannedCounts = () => {
    if (!selectedAsnForGrn) return;
    const resetLines = {};
    (selectedAsnForGrn.lines || []).forEach((line) => {
      resetLines[line.id] = {
        receivedGoodQty: 0,
        shortQty: line.invoicedQty,
        excessQty: 0,
        damagedQty: 0,
        varianceReason: '',
        photoUrl: ''
      };
    });
    setGrnLineData(resetLines);
    setBarcodeScanFeedback({
      type: 'info',
      message: '🔄 Counts reset to 0. You can now physically scan each item or carton.'
    });
    setTimeout(() => barcodeInputRef.current?.focus(), 50);
  };

  // Submit and Confirm GRN
  const handleConfirmGrn = async (e) => {
    e.preventDefault();
    if (!grnWarehouseId) {
      alert('Please select a destination warehouse.');
      return;
    }

    setGrnSubmitting(true);
    try {
      const linesPayload = Object.keys(grnLineData).map((lineId) => ({
        asnLineId: lineId,
        receivedGoodQty: parseInt(grnLineData[lineId].receivedGoodQty || 0, 10),
        shortQty: parseInt(grnLineData[lineId].shortQty || 0, 10),
        excessQty: parseInt(grnLineData[lineId].excessQty || 0, 10),
        damagedQty: parseInt(grnLineData[lineId].damagedQty || 0, 10),
        varianceReason: grnLineData[lineId].varianceReason,
        photoUrl: grnLineData[lineId].photoUrl
      }));

      const res = await confirmGrn(user, selectedAsnForGrn.id, {
        warehouseId: grnWarehouseId,
        lines: linesPayload
      });

      alert(res.message || 'GRN Confirmed successfully! ERP receipt acknowledged.');
      setShowGrnModal(false);
      setSelectedAsnForGrn(null);
      loadData();
    } catch (err) {
      alert('Failed to confirm GRN: ' + err.message);
    } finally {
      setGrnSubmitting(false);
    }
  };

  // Inter-warehouse Transfer Submit
  const handleCreateTransfer = async (e) => {
    e.preventDefault();
    if (newTransfer.sourceWarehouseId === newTransfer.targetWarehouseId) {
      alert('Source and destination warehouse cannot be the same.');
      return;
    }
    if (newTransfer.lines.some((l) => !l.skuId || !l.qty)) {
      alert('Please select SKU and quantity for all transfer lines.');
      return;
    }

    try {
      const res = await createTransfer(user, newTransfer);
      alert(res.message || 'Transfer completed successfully.');
      setShowTransferModal(false);
      setNewTransfer({
        sourceWarehouseId: '',
        targetWarehouseId: '',
        notes: '',
        lines: [{ skuId: '', batch: '', qty: 10 }]
      });
      loadData();
    } catch (err) {
      alert('Transfer failed: ' + err.message);
    }
  };

  // Purchase Return Submit
  const handleCreatePurchaseReturn = async (e) => {
    e.preventDefault();
    if (!newPurchaseReturn.warehouseId) {
      alert('Please choose a warehouse.');
      return;
    }
    if (newPurchaseReturn.lines.some((l) => !l.skuId || !l.qty)) {
      alert('Please specify SKU and quantity for all return items.');
      return;
    }

    try {
      const res = await createPurchaseReturn(user, newPurchaseReturn);
      alert(res.message || 'Purchase return submitted and ERP return order generated.');
      setShowPurchaseReturnModal(false);
      setNewPurchaseReturn({
        warehouseId: '',
        reason: 'DAMAGED_IN_TRANSIT',
        fromStockState: 'DAMAGED',
        notes: '',
        lines: [{ skuId: '', batch: '', qty: 5, fromStockState: 'DAMAGED' }]
      });
      loadData();
    } catch (err) {
      alert('Purchase return failed: ' + err.message);
    }
  };

  // Physical Audit Submit
  const handleCreateAudit = async (e) => {
    e.preventDefault();
    if (!newAudit.warehouseId) {
      alert('Please select a warehouse.');
      return;
    }
    if (newAudit.lines.some((l) => !l.skuId)) {
      alert('Please specify SKUs for all audit lines.');
      return;
    }

    try {
      const res = await createStockAudit(user, newAudit);
      alert(res.message || 'Stock count audit submitted. Awaiting Dealer Owner approval.');
      setShowAuditModal(false);
      setNewAudit({
        warehouseId: '',
        notes: '',
        lines: [{ skuId: '', batch: '', countedQty: 0, reasonCode: 'COUNTING_VARIANCE' }]
      });
      loadData();
    } catch (err) {
      alert('Audit submission failed: ' + err.message);
    }
  };

  // Approve Audit
  const handleApproveAudit = async (auditId) => {
    if (!window.confirm('Are you sure you want to approve this stock audit and post variance adjustments to the immutable ledger?')) return;
    try {
      const res = await approveStockAudit(user, auditId);
      alert(res.message || 'Audit approved and adjustments posted.');
      loadData();
    } catch (err) {
      alert('Approval failed: ' + err.message);
    }
  };

  // Reject Audit
  const handleRejectAudit = async (auditId) => {
    const reason = window.prompt('Enter rejection reason:');
    if (!reason) return;
    try {
      const res = await rejectStockAudit(user, auditId, reason);
      alert(res.message || 'Audit rejected.');
      loadData();
    } catch (err) {
      alert('Rejection failed: ' + err.message);
    }
  };

  // Claims Actions (Brand Admin)
  const handleOpenClaimModal = (claim, action) => {
    setSelectedClaim(claim);
    setClaimActionType(action);
    setClaimNotes('');
    setShowClaimModal(true);
  };

  const handleResolveClaim = async () => {
    try {
      if (claimActionType === 'APPROVE') {
        await approveClaim(user, selectedClaim.id, claimNotes);
        alert('Transit claim approved.');
      } else {
        await rejectClaim(user, selectedClaim.id, claimNotes);
        alert('Transit claim rejected.');
      }
      setShowClaimModal(false);
      setSelectedClaim(null);
      loadData();
    } catch (err) {
      alert('Failed to update claim: ' + err.message);
    }
  };

  // Min Stock Threshold update
  const handleSaveMinStock = async () => {
    try {
      await updateMinStockThreshold(user, {
        skuId: editingMinStockSku.id,
        minStock: parseInt(newMinStockVal, 10) || 10
      });
      setShowMinStockModal(false);
      setEditingMinStockSku(null);
      loadData();
    } catch (err) {
      alert('Failed to update minimum stock: ' + err.message);
    }
  };

  return (
    <div className="master-page inventory-page">
      {/* Top Tabs Bar */}
      <div className="brand-tabs-bar" style={{ flexWrap: 'wrap' }}>
        {isBrand ? (
          <>
            <button
              className={`tab-btn ${activeTab === 'asns' ? 'active' : ''}`}
              onClick={() => setActiveTab('asns')}
            >
              🚛 Primary Dispatches (ASNs)
              <span className="tab-badge-alert" style={{ background: '#C5A059' }}>
                {asns.length}
              </span>
            </button>
            <button
              className={`tab-btn ${activeTab === 'claims' ? 'active' : ''}`}
              onClick={() => setActiveTab('claims')}
            >
              ⚠️ Transit Claims
              {claims.filter((c) => c.status === 'OPEN').length > 0 && (
                <span className="tab-badge-alert">
                  {claims.filter((c) => c.status === 'OPEN').length}
                </span>
              )}
            </button>
            <button
              className={`tab-btn ${activeTab === 'stock' ? 'active' : ''}`}
              onClick={() => setActiveTab('stock')}
            >
              📦 Dealer Stock on Hand
            </button>
            <button
              className={`tab-btn ${activeTab === 'transfers' ? 'active' : ''}`}
              onClick={() => setActiveTab('transfers')}
            >
              🔄 Inter-Warehouse Transfers ({transfers.length})
            </button>
            <button
              className={`tab-btn ${activeTab === 'purchaseReturns' ? 'active' : ''}`}
              onClick={() => setActiveTab('purchaseReturns')}
            >
              📦 Purchase Returns ({purchaseReturns.length})
            </button>
            <button
              className={`tab-btn ${activeTab === 'audits' ? 'active' : ''}`}
              onClick={() => setActiveTab('audits')}
            >
              📋 Physical Stock Audits ({audits.length})
            </button>
          </>
        ) : (
          <>
            <button
              className={`tab-btn ${activeTab === 'grn' ? 'active' : ''}`}
              onClick={() => setActiveTab('grn')}
            >
              📥 In-Transit &amp; GRN Receipt
              {inTransitAsns.length > 0 && (
                <span className="tab-badge-alert">
                  {inTransitAsns.length} New
                </span>
              )}
            </button>
            <button
              className={`tab-btn ${activeTab === 'stock' ? 'active' : ''}`}
              onClick={() => setActiveTab('stock')}
            >
              📦 Stock on Hand &amp; Ageing
            </button>
            <button
              className={`tab-btn ${activeTab === 'transfers' ? 'active' : ''}`}
              onClick={() => setActiveTab('transfers')}
            >
              🔄 Warehouse Transfers ({transfers.length})
            </button>
            <button
              className={`tab-btn ${activeTab === 'purchaseReturns' ? 'active' : ''}`}
              onClick={() => setActiveTab('purchaseReturns')}
            >
              📦 Returns to Brand ({purchaseReturns.length})
            </button>
            <button
              className={`tab-btn ${activeTab === 'audits' ? 'active' : ''}`}
              onClick={() => setActiveTab('audits')}
            >
              📋 Stock Audits &amp; Counts
              {audits.filter((a) => a.status === 'PENDING_APPROVAL').length > 0 && (
                <span className="tab-badge-alert" style={{ background: '#E21E25' }}>
                  {audits.filter((a) => a.status === 'PENDING_APPROVAL').length} Pending
                </span>
              )}
            </button>
            <button
              className={`tab-btn ${activeTab === 'ledger' ? 'active' : ''}`}
              onClick={() => setActiveTab('ledger')}
            >
              📜 Append-Only Stock Ledger
            </button>
            <button
              className={`tab-btn ${activeTab === 'claims' ? 'active' : ''}`}
              onClick={() => setActiveTab('claims')}
            >
              ⚠️ Transit Claims ({claims.length})
            </button>
          </>
        )}

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '10px' }}>
          {isBrand && (
            <button
              className="btn btn-primary btn-sm"
              onClick={() => setShowDispatchModal(true)}
            >
              + Create Simulated Dispatch
            </button>
          )}
          {!isBrand && activeTab === 'transfers' && warehouses.length >= 2 && (
            <button
              className="btn btn-primary btn-sm"
              onClick={() => {
                const defSource = warehouses[0]?.id || '';
                const defTarget = warehouses[1]?.id || '';
                setNewTransfer({
                  sourceWarehouseId: defSource,
                  targetWarehouseId: defTarget,
                  notes: '',
                  lines: [{ skuId: skus[0]?.id || '', batch: 'DEFAULT', qty: 10 }]
                });
                setShowTransferModal(true);
              }}
            >
              + New Warehouse Transfer
            </button>
          )}
          {!isBrand && activeTab === 'purchaseReturns' && (
            <button
              className="btn btn-primary btn-sm"
              onClick={() => {
                setNewPurchaseReturn({
                  warehouseId: warehouses[0]?.id || '',
                  reason: 'DAMAGED_IN_TRANSIT',
                  fromStockState: 'DAMAGED',
                  notes: '',
                  lines: [{ skuId: skus[0]?.id || '', batch: 'DEFAULT', qty: 5, fromStockState: 'DAMAGED' }]
                });
                setShowPurchaseReturnModal(true);
              }}
            >
              + Return Stock to Brand
            </button>
          )}
          {!isBrand && activeTab === 'audits' && (
            <button
              className="btn btn-primary btn-sm"
              onClick={() => {
                setNewAudit({
                  warehouseId: warehouses[0]?.id || '',
                  notes: '',
                  lines: [{ skuId: skus[0]?.id || '', batch: 'DEFAULT', countedQty: 0, reasonCode: 'COUNTING_VARIANCE' }]
                });
                setShowAuditModal(true);
              }}
            >
              + Conduct Physical Stock Count
            </button>
          )}
        </div>
      </div>

      {error && <div className="error-alert">{error}</div>}

      {/* ==========================================================
          TAB: BRAND PRIMARY DISPATCHES (ASNs)
         ========================================================== */}
      {isBrand && activeTab === 'asns' && (
        <div>
          <div className="search-filter-bar" style={{ marginBottom: '16px' }}>
            <select
              value={selectedDealerId}
              onChange={(e) => setSelectedDealerId(e.target.value)}
              style={{ padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              <option value="">All Dealerships</option>
              {dealers.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.code})
                </option>
              ))}
            </select>
          </div>

          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Invoice / ASN #</th>
                    <th>Invoice Date</th>
                    <th>Destination Dealer</th>
                    <th>Status</th>
                    <th>GRN Reference</th>
                    <th>ERP Ack</th>
                    <th>Lines</th>
                    <th>Claims</th>
                  </tr>
                </thead>
                <tbody>
                  {asns.length === 0 ? (
                    <tr>
                      <td colSpan="8" style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No dispatches found. Click "+ Create Simulated Dispatch" to create one.</span>
                      </td>
                    </tr>
                  ) : (
                    asns.map((asn) => (
                      <tr key={asn.id}>
                        <td>
                          <strong>{asn.invoiceNo}</strong>
                        </td>
                        <td>{new Date(asn.invoiceDate).toLocaleDateString()}</td>
                        <td>
                          <b>{asn.dealer?.name}</b>
                          <span className="article-tag">{asn.dealer?.code} - {asn.dealer?.stateCode}</span>
                        </td>
                        <td>
                          <span
                            className={`status-pill ${
                              asn.status === 'RECEIVED'
                                ? 'status-billable'
                                : asn.status === 'RECEIVED_WITH_VARIANCE'
                                ? 'status-low'
                                : 'status-warning'
                            }`}
                          >
                            {asn.status.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td>
                          {asn.grnNumber ? (
                            <span className="barcode-badge">{asn.grnNumber}</span>
                          ) : (
                            <span className="text-muted">—</span>
                          )}
                        </td>
                        <td>
                          {asn.erpAcknowledgedAt ? (
                            <span style={{ color: '#059669', fontSize: '11px', fontWeight: 600 }}>
                              ✓ {new Date(asn.erpAcknowledgedAt).toLocaleDateString()}
                            </span>
                          ) : (
                            <span className="text-muted">Pending Receipt</span>
                          )}
                        </td>
                        <td>{asn._count?.lines || 0} items</td>
                        <td>
                          {asn._count?.claims > 0 ? (
                            <span className="status-pill status-critical">{asn._count.claims} Claims</span>
                          ) : (
                            <span style={{ color: '#059669', fontSize: '12px' }}>0</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: DEALER IN-TRANSIT & GRN RECEIPT
         ========================================================== */}
      {!isBrand && activeTab === 'grn' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Section 1: In-Transit Awaiting GRN */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
              <h3 style={{ margin: 0, fontSize: '16px', color: '#0f172a' }}>
                🚚 In-Transit Shipments Dispatched by Brand (Awaiting Physical Receipt)
              </h3>
              <span className="article-tag" style={{ background: '#FEF2F2', color: '#E21E25', fontWeight: 700 }}>
                {inTransitAsns.length} Shipments In Transit
              </span>
            </div>

            <div className="table-card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>ERP Invoice No</th>
                      <th>Dispatch Date</th>
                      <th>Status</th>
                      <th>SKU Lines &amp; Batch</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inTransitAsns.length === 0 ? (
                      <tr>
                        <td colSpan="5" style={{ textAlign: 'center', padding: '30px' }}>
                          <span className="text-muted">No in-transit shipments currently pending receipt. Brand dispatches will appear here instantly.</span>
                        </td>
                      </tr>
                    ) : (
                      inTransitAsns.map((asn) => (
                        <tr key={asn.id}>
                          <td>
                            <strong>{asn.invoiceNo}</strong>
                          </td>
                          <td>{new Date(asn.invoiceDate).toLocaleDateString()}</td>
                          <td>
                            <span className="status-pill status-warning">IN TRANSIT</span>
                          </td>
                          <td>
                            {(asn.lines || []).map((l) => (
                              <span key={l.id} className="article-tag" style={{ display: 'inline-block', margin: '2px' }}>
                                • {l.sku?.code} ({l.invoicedQty} pcs, Batch: {l.batch})
                              </span>
                            ))}
                          </td>
                          <td>
                            <button
                              className="btn btn-primary btn-sm"
                              onClick={() => handleOpenGrnModal(asn)}
                            >
                              📥 Receive / Barcode Scan
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Section 2: Historical Received Shipments */}
          <div>
            <h3 style={{ margin: '0 0 10px', fontSize: '16px', color: '#0f172a' }}>
              📋 Received Shipments History
            </h3>
            <div className="table-card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Invoice No</th>
                      <th>GRN Number</th>
                      <th>GRN Date</th>
                      <th>Status</th>
                      <th>Warehouse</th>
                      <th>ERP Status</th>
                      <th>Variance Claims</th>
                    </tr>
                  </thead>
                  <tbody>
                    {asns.filter((a) => a.status !== 'IN_TRANSIT').length === 0 ? (
                      <tr>
                        <td colSpan="7" style={{ textAlign: 'center', padding: '24px' }}>
                          <span className="text-muted">No historical GRNs yet.</span>
                        </td>
                      </tr>
                    ) : (
                      asns.filter((a) => a.status !== 'IN_TRANSIT').map((asn) => (
                        <tr key={asn.id}>
                          <td><strong>{asn.invoiceNo}</strong></td>
                          <td><span className="barcode-badge">{asn.grnNumber}</span></td>
                          <td>{asn.grnDate ? new Date(asn.grnDate).toLocaleDateString() : '—'}</td>
                          <td>
                            <span
                              className={`status-pill ${
                                asn.status === 'RECEIVED' ? 'status-billable' : 'status-low'
                              }`}
                            >
                              {asn.status.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td>{asn.receivedWarehouse?.name || 'Main Warehouse'}</td>
                          <td>
                            {asn.erpAcknowledgedAt ? (
                              <span style={{ color: '#059669', fontSize: '11px', fontWeight: 600 }}>
                                ✓ Acknowledged
                              </span>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </td>
                          <td>
                            {asn._count?.claims > 0 ? (
                              <span className="status-pill status-critical" style={{ fontSize: '10px' }}>
                                {asn._count.claims} Claims Raised
                              </span>
                            ) : (
                              <span style={{ color: '#059669', fontSize: '11px', fontWeight: 600 }}>Zero Variance</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: STOCK ON HAND & AGEING
         ========================================================== */}
      {activeTab === 'stock' && (
        <div>
          {/* Top Ageing Summary Metric Cards */}
          {analytics?.ageingBuckets && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', marginBottom: '20px' }}>
              <div style={{ background: '#FFFFFF', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0', borderLeft: '4px solid #059669' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>0–30 Days (Fast Moving)</span>
                <h3 style={{ margin: '6px 0 0', fontSize: '22px', color: '#0f172a' }}>{analytics.ageingBuckets['0_30']?.qty || 0} pcs</h3>
                <small style={{ color: '#059669', fontWeight: 600 }}>{analytics.ageingBuckets['0_30']?.count || 0} lots</small>
              </div>

              <div style={{ background: '#FFFFFF', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0', borderLeft: '4px solid #C5A059' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>31–60 Days (Normal)</span>
                <h3 style={{ margin: '6px 0 0', fontSize: '22px', color: '#0f172a' }}>{analytics.ageingBuckets['31_60']?.qty || 0} pcs</h3>
                <small style={{ color: '#C5A059', fontWeight: 600 }}>{analytics.ageingBuckets['31_60']?.count || 0} lots</small>
              </div>

              <div style={{ background: '#FFFFFF', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0', borderLeft: '4px solid #d97706' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>61–90 Days (Slow Moving)</span>
                <h3 style={{ margin: '6px 0 0', fontSize: '22px', color: '#0f172a' }}>{analytics.ageingBuckets['61_90']?.qty || 0} pcs</h3>
                <small style={{ color: '#d97706', fontWeight: 600 }}>{analytics.slowMovingCount || 0} slow lots</small>
              </div>

              <div style={{ background: '#FFFFFF', padding: '16px', borderRadius: '12px', border: '1px solid #e2e8f0', borderLeft: '4px solid #E21E25' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>90+ Days (Non-Moving Alert)</span>
                <h3 style={{ margin: '6px 0 0', fontSize: '22px', color: '#E21E25' }}>{analytics.ageingBuckets['90_plus']?.qty || 0} pcs</h3>
                <small style={{ color: '#E21E25', fontWeight: 600 }}>{analytics.nonMovingCount || 0} dead stock lots</small>
              </div>
            </div>
          )}

          {/* Subview Filter Tabs: Stock on Hand vs Primary Reorder Suggestions */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                className={`tab-btn ${stockSubView === 'inventory' ? 'active' : ''}`}
                style={{ padding: '6px 14px', fontSize: '12px' }}
                onClick={() => setStockSubView('inventory')}
              >
                📦 Full Stock Inventory (SKU × Size × Colour × Batch × Location)
              </button>
              <button
                className={`tab-btn ${stockSubView === 'reorders' ? 'active' : ''}`}
                style={{ padding: '6px 14px', fontSize: '12px' }}
                onClick={() => setStockSubView('reorders')}
              >
                💡 Primary Reorder Suggestions
                {analytics?.reorderSuggestions?.length > 0 && (
                  <span className="tab-badge-alert" style={{ background: '#E21E25' }}>
                    {analytics.reorderSuggestions.length} Shortfalls
                  </span>
                )}
              </button>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 600, color: '#334155' }}>
                <input
                  type="checkbox"
                  checked={lowStockOnly}
                  onChange={(e) => setLowStockOnly(e.target.checked)}
                />
                ⚠️ Low Stock Alert Only
              </label>

              <select
                value={selectedWarehouseId}
                onChange={(e) => setSelectedWarehouseId(e.target.value)}
                style={{ padding: '6px 10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                <option value="">All Warehouses</option>
                {warehouses.map((w) => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            </div>
          </div>

          {/* SubView 1: Full Inventory */}
          {stockSubView === 'inventory' && (
            <div className="table-card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>SKU Code &amp; Name</th>
                      <th>Attributes (Size × Colour)</th>
                      <th>Warehouse</th>
                      <th>Batch</th>
                      <th>Stock State</th>
                      <th>Quantity</th>
                      <th>Ageing (Inward)</th>
                      <th>Status</th>
                      {!isBrand && <th>Action</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {stockOnHand.length === 0 ? (
                      <tr>
                        <td colSpan="9" style={{ textAlign: 'center', padding: '30px' }}>
                          <span className="text-muted">No stock on hand found matching filters.</span>
                        </td>
                      </tr>
                    ) : (
                      stockOnHand.map((item) => (
                        <tr key={item.id} style={{ background: item.isLowStock ? '#fffbeb' : 'transparent' }}>
                          <td>
                            <strong>{item.sku?.code}</strong>
                            <span className="article-tag">{item.sku?.name}</span>
                          </td>
                          <td>
                            <span className="barcode-badge">
                              {item.sku?.size || 'Free Size'} | {item.sku?.colour || 'Standard'}
                            </span>
                          </td>
                          <td>{item.warehouse?.name}</td>
                          <td><span className="barcode-badge">{item.batch}</span></td>
                          <td>
                            <span
                              className={`status-pill ${
                                item.stockState === 'AVAILABLE'
                                  ? 'status-billable'
                                  : item.stockState === 'DAMAGED'
                                  ? 'status-critical'
                                  : item.stockState === 'QUARANTINE'
                                  ? 'status-warning'
                                  : 'status-low'
                              }`}
                            >
                              {item.stockState}
                            </span>
                          </td>
                          <td>
                            <span style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                              {item.qty} {item.sku?.uom}
                            </span>
                          </td>
                          <td>
                            {item.inwardDate ? (
                              <div>
                                <small style={{ color: '#64748b' }}>{new Date(item.inwardDate).toLocaleDateString()}</small>
                                {(() => {
                                  const age = Math.max(0, Math.floor((Date.now() - new Date(item.inwardDate).getTime()) / (1000 * 60 * 60 * 24)));
                                  if (age > 90) return <span className="status-pill status-critical" style={{ fontSize: '9px', display: 'block' }}>90+ d (Non-Moving)</span>;
                                  if (age > 60) return <span className="status-pill status-low" style={{ fontSize: '9px', display: 'block' }}>61-90 d (Slow)</span>;
                                  return <span className="status-pill status-billable" style={{ fontSize: '9px', display: 'block' }}>{age} d</span>;
                                })()}
                              </div>
                            ) : (
                              <span className="text-muted">—</span>
                            )}
                          </td>
                          <td>
                            {item.isLowStock ? (
                              <span className="status-pill status-critical" style={{ fontSize: '10px' }}>
                                ⚠️ LOW (Min: {item.minStock})
                              </span>
                            ) : (
                              <span className="status-pill status-billable" style={{ fontSize: '10px' }}>
                                HEALTHY
                              </span>
                            )}
                          </td>
                          {!isBrand && (
                            <td>
                              <button
                                className="btn btn-outline btn-xs"
                                onClick={() => {
                                  setEditingMinStockSku(item.sku);
                                  setNewMinStockVal(String(item.minStock || 10));
                                  setShowMinStockModal(true);
                                }}
                              >
                                Edit Min
                              </button>
                            </td>
                          )}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SubView 2: Reorder Recommendations */}
          {stockSubView === 'reorders' && (
            <div>
              <div style={{ padding: '12px 16px', background: '#FDFBF7', border: '1px solid #E7D7B5', borderRadius: '8px', marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <strong style={{ color: '#785A18' }}>Suggested Primary Order to Siyaram's Brand/SAP:</strong>
                  <span style={{ fontSize: '13px', color: '#785A18', marginLeft: '8px' }}>
                    Based on dealer min-stock buffers, safe stock formulas, and current available inventory.
                  </span>
                </div>
                <div style={{ fontSize: '15px', fontWeight: 800, color: '#E21E25' }}>
                  Est. Order Value: {inrFormat.format(analytics?.totalEstimatedOrderValue || 0)}
                </div>
              </div>

              <div className="table-card">
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>SKU Code &amp; Article</th>
                        <th>Category &amp; Size</th>
                        <th>Current Available</th>
                        <th>Min Stock Threshold</th>
                        <th>Shortfall</th>
                        <th>Suggested Primary Order Qty</th>
                        <th>Landing Price</th>
                        <th>Estimated Order Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {!analytics?.reorderSuggestions || analytics.reorderSuggestions.length === 0 ? (
                        <tr>
                          <td colSpan="8" style={{ textAlign: 'center', padding: '30px' }}>
                            <span style={{ color: '#059669', fontWeight: 600 }}>
                              ✅ All inventory lines are adequately stocked above minimum buffer thresholds.
                            </span>
                          </td>
                        </tr>
                      ) : (
                        analytics.reorderSuggestions.map((rec) => (
                          <tr key={rec.skuId}>
                            <td>
                              <strong>{rec.skuCode}</strong>
                              <span className="article-tag">{rec.skuName}</span>
                            </td>
                            <td>
                              <span className="barcode-badge">{rec.category} | {rec.size || 'STD'} | {rec.colour || 'STD'}</span>
                            </td>
                            <td>
                              <span style={{ fontWeight: 700, color: rec.currentAvailable === 0 ? '#E21E25' : '#b45309' }}>
                                {rec.currentAvailable} pcs
                              </span>
                            </td>
                            <td>{rec.minStock} pcs</td>
                            <td>
                              <span className="status-pill status-critical" style={{ fontSize: '11px' }}>
                                -{rec.shortfall} pcs
                              </span>
                            </td>
                            <td>
                              <span style={{ fontSize: '15px', fontWeight: 800, color: '#059669' }}>
                                {rec.suggestedQty} pcs
                              </span>
                            </td>
                            <td>{inrFormat.format(rec.landingPrice)}</td>
                            <td>
                              <strong>{inrFormat.format(rec.estimatedValue)}</strong>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==========================================================
          TAB: MULTI-WAREHOUSE TRANSFERS
         ========================================================== */}
      {activeTab === 'transfers' && (
        <div>
          <div style={{ marginBottom: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#0f172a' }}>
              🔄 Inter-Warehouse Stock Transfers (Double-Entry Ledger Verified)
            </h3>
            {warehouses.length < 2 && !isBrand && (
              <span className="article-tag" style={{ background: '#fffbeb', color: '#b45309' }}>
                ℹ️ Transfer requires at least 2 active warehouses under your dealership.
              </span>
            )}
          </div>

          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Transfer #</th>
                    <th>Date</th>
                    <th>Source Warehouse</th>
                    <th>Target Warehouse</th>
                    <th>Items Transferred</th>
                    <th>Status</th>
                    <th>Transferred By</th>
                  </tr>
                </thead>
                <tbody>
                  {transfers.length === 0 ? (
                    <tr>
                      <td colSpan="7" style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No warehouse transfers recorded yet.</span>
                      </td>
                    </tr>
                  ) : (
                    transfers.map((trf) => (
                      <tr key={trf.id}>
                        <td><strong>{trf.transferNo}</strong></td>
                        <td>{new Date(trf.createdAt).toLocaleString()}</td>
                        <td>
                          <span className="barcode-badge">{trf.sourceWarehouse?.name}</span>
                        </td>
                        <td>
                          <span className="barcode-badge" style={{ background: '#ecfdf5', color: '#059669' }}>
                            {trf.targetWarehouse?.name}
                          </span>
                        </td>
                        <td>
                          {(trf.lines || []).map((l) => (
                            <span key={l.id} className="article-tag" style={{ display: 'inline-block', margin: '2px' }}>
                              {l.sku?.code} ({l.qty} pcs, Batch: {l.batch})
                            </span>
                          ))}
                        </td>
                        <td>
                          <span className="status-pill status-billable">{trf.status}</span>
                        </td>
                        <td><small style={{ color: '#64748b' }}>{trf.transferredByEmail || 'Staff'}</small></td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: PURCHASE RETURNS TO BRAND
         ========================================================== */}
      {activeTab === 'purchaseReturns' && (
        <div>
          <div style={{ marginBottom: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#0f172a' }}>
              📦 Purchase Returns to Siyaram's Brand (DMS Request → ERP Return Order)
            </h3>
          </div>

          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Return No</th>
                    <th>ERP Return Order #</th>
                    <th>Submission Date</th>
                    <th>Warehouse</th>
                    <th>Reason</th>
                    <th>Returned Items</th>
                    <th>Status</th>
                    <th>Submitted By</th>
                  </tr>
                </thead>
                <tbody>
                  {purchaseReturns.length === 0 ? (
                    <tr>
                      <td colSpan="8" style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No purchase returns recorded yet.</span>
                      </td>
                    </tr>
                  ) : (
                    purchaseReturns.map((pr) => (
                      <tr key={pr.id}>
                        <td><strong>{pr.returnNo}</strong></td>
                        <td>
                          <span className="barcode-badge" style={{ background: '#eff6ff', color: '#1d4ed8', fontWeight: 700 }}>
                            {pr.erpReturnOrderNo || 'PENDING_ERP'}
                          </span>
                        </td>
                        <td>{new Date(pr.submittedAt || pr.createdAt).toLocaleDateString()}</td>
                        <td>{pr.warehouse?.name}</td>
                        <td>
                          <span className="status-pill status-warning" style={{ fontSize: '11px' }}>
                            {pr.reason.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td>
                          {(pr.lines || []).map((l) => (
                            <span key={l.id} className="article-tag" style={{ display: 'inline-block', margin: '2px' }}>
                              {l.sku?.code} ({l.qty} pcs from {l.fromStockState})
                            </span>
                          ))}
                        </td>
                        <td>
                          <span className="status-pill status-billable">{pr.status}</span>
                        </td>
                        <td><small style={{ color: '#64748b' }}>{pr.createdByEmail || 'Staff'}</small></td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: PHYSICAL STOCK AUDITS & COUNTS
         ========================================================== */}
      {activeTab === 'audits' && (
        <div>
          <div style={{ marginBottom: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ margin: 0, fontSize: '16px', color: '#0f172a' }}>
              📋 Periodic Physical Stock Audits by Barcode Scanning
            </h3>
          </div>

          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Audit #</th>
                    <th>Date</th>
                    <th>Warehouse</th>
                    <th>Variance Details (Book vs Physical Count)</th>
                    <th>Status</th>
                    <th>Auditor</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {audits.length === 0 ? (
                    <tr>
                      <td colSpan="7" style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No physical counts performed yet. Click "+ Conduct Physical Stock Count" to start.</span>
                      </td>
                    </tr>
                  ) : (
                    audits.map((aud) => (
                      <tr key={aud.id}>
                        <td><strong>{aud.auditNo}</strong></td>
                        <td>{new Date(aud.createdAt).toLocaleString()}</td>
                        <td>{aud.warehouse?.name}</td>
                        <td>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                            {(aud.lines || []).map((l) => (
                              <div key={l.id} style={{ fontSize: '12px' }}>
                                <b>{l.sku?.code}</b>: Book <b>{l.bookQty}</b> → Counted <b>{l.countedQty}</b>
                                {' '}
                                <span
                                  className={`status-pill ${
                                    l.varianceQty === 0
                                      ? 'status-billable'
                                      : l.varianceQty < 0
                                      ? 'status-critical'
                                      : 'status-low'
                                  }`}
                                  style={{ fontSize: '10px', marginLeft: '6px' }}
                                >
                                  {l.varianceQty > 0 ? `+${l.varianceQty}` : l.varianceQty} pcs ({l.reasonCode || 'OK'})
                                </span>
                              </div>
                            ))}
                          </div>
                        </td>
                        <td>
                          <span
                            className={`status-pill ${
                              aud.status === 'APPROVED'
                                ? 'status-billable'
                                : aud.status === 'REJECTED'
                                ? 'status-critical'
                                : 'status-warning'
                            }`}
                          >
                            {aud.status.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td><small style={{ color: '#64748b' }}>{aud.conductedByEmail || 'Auditor'}</small></td>
                        <td>
                          {aud.status === 'PENDING_APPROVAL' && isDealerOwner ? (
                            <div style={{ display: 'flex', gap: '6px' }}>
                              <button
                                className="btn btn-primary btn-xs"
                                onClick={() => handleApproveAudit(aud.id)}
                              >
                                ✅ Approve Adjustment
                              </button>
                              <button
                                className="btn btn-danger-outline btn-xs"
                                onClick={() => handleRejectAudit(aud.id)}
                              >
                                ❌ Reject
                              </button>
                            </div>
                          ) : aud.status === 'APPROVED' ? (
                            <span style={{ color: '#059669', fontSize: '11px', fontWeight: 600 }}>Adjusted in Ledger</span>
                          ) : (
                            <span className="text-muted">—</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: APPEND-ONLY STOCK LEDGER (Dealer)
         ========================================================== */}
      {!isBrand && activeTab === 'ledger' && (
        <div>
          <div className="search-filter-bar" style={{ marginBottom: '16px' }}>
            <span style={{ fontSize: '12px', color: '#059669', fontWeight: 700, background: '#ecfdf5', padding: '6px 12px', borderRadius: '6px' }}>
              🔒 Append-Only Immutable Ledger (PostgreSQL Trigger Protected)
            </span>

            <select
              value={ledgerSearchSku}
              onChange={(e) => setLedgerSearchSku(e.target.value)}
              style={{ marginLeft: 'auto', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              <option value="">All SKUs</option>
              {skus.map((s) => (
                <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
              ))}
            </select>
          </div>

          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Timestamp</th>
                    <th>SKU Code</th>
                    <th>Warehouse</th>
                    <th>Batch</th>
                    <th>Stock State</th>
                    <th>Qty Change</th>
                    <th>Source Type</th>
                    <th>Source Reference</th>
                    <th>Recorded By</th>
                  </tr>
                </thead>
                <tbody>
                  {stockLedger.length === 0 ? (
                    <tr>
                      <td colSpan="9" style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No stock ledger transactions yet. Confirm a GRN or Transfer to create records.</span>
                      </td>
                    </tr>
                  ) : (
                    stockLedger.map((tx) => (
                      <tr key={tx.id}>
                        <td>
                          <small style={{ color: '#64748b' }}>
                            {new Date(tx.createdAt).toLocaleString()}
                          </small>
                        </td>
                        <td>
                          <strong>{tx.sku?.code}</strong>
                          <span className="article-tag">{tx.sku?.name}</span>
                        </td>
                        <td>{tx.warehouse?.name}</td>
                        <td><span className="barcode-badge">{tx.batch}</span></td>
                        <td>
                          <span
                            className={`status-pill ${
                              tx.stockState === 'AVAILABLE'
                                ? 'status-billable'
                                : tx.stockState === 'DAMAGED'
                                ? 'status-critical'
                                : 'status-warning'
                            }`}
                          >
                            {tx.stockState}
                          </span>
                        </td>
                        <td>
                          <span
                            style={{
                              fontSize: '14px',
                              fontWeight: 800,
                              color: tx.qtyChange >= 0 ? '#059669' : '#dc2626'
                            }}
                          >
                            {tx.qtyChange >= 0 ? `+${tx.qtyChange}` : tx.qtyChange}
                          </span>
                        </td>
                        <td>
                          <span className="barcode-badge">{tx.sourceType}</span>
                        </td>
                        <td>
                          <b>{tx.sourceId}</b>
                        </td>
                        <td>
                          <small style={{ color: '#64748b' }}>{tx.createdByEmail || 'System'}</small>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          TAB: TRANSIT CLAIMS (Brand & Dealer)
         ========================================================== */}
      {activeTab === 'claims' && (
        <div>
          <div className="table-card">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Claim #</th>
                    <th>Type</th>
                    <th>Invoice / ASN #</th>
                    {isBrand && <th>Dealership</th>}
                    <th>SKU &amp; Quantity</th>
                    <th>Reason / Evidence</th>
                    <th>Status</th>
                    {isBrand && <th>Actions</th>}
                  </tr>
                </thead>
                <tbody>
                  {claims.length === 0 ? (
                    <tr>
                      <td colSpan={isBrand ? 8 : 7} style={{ textAlign: 'center', padding: '30px' }}>
                        <span className="text-muted">No transit claims registered. All shipments received with zero variance!</span>
                      </td>
                    </tr>
                  ) : (
                    claims.map((claim) => (
                      <tr key={claim.id}>
                        <td>
                          <strong>CLM-{claim.id.slice(0, 8).toUpperCase()}</strong>
                        </td>
                        <td>
                          <span
                            className={`status-pill ${
                              claim.claimType === 'DAMAGED'
                                ? 'status-critical'
                                : claim.claimType === 'SHORT'
                                ? 'status-warning'
                                : 'status-low'
                            }`}
                          >
                            {claim.claimType}
                          </span>
                        </td>
                        <td>
                          <strong>{claim.asn?.invoiceNo}</strong>
                        </td>
                        {isBrand && (
                          <td>
                            <b>{claim.dealer?.name}</b>
                            <span className="article-tag">{claim.dealer?.code}</span>
                          </td>
                        )}
                        <td>
                          <strong>{claim.sku?.code}</strong>
                          <span style={{ fontSize: '13px', fontWeight: 700, marginLeft: '6px' }}>
                            ({claim.qty} pcs)
                          </span>
                        </td>
                        <td>
                          <div>
                            <span>{claim.reason || 'No description provided'}</span>
                            {claim.photoUrl && (
                              <div style={{ marginTop: '4px' }}>
                                <a
                                  href={claim.photoUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  style={{ fontSize: '11px', color: '#E21E25', textDecoration: 'underline' }}
                                >
                                  📷 View Damage Photo
                                </a>
                              </div>
                            )}
                          </div>
                        </td>
                        <td>
                          <span
                            className={`status-pill ${
                              claim.status === 'APPROVED'
                                ? 'status-billable'
                                : claim.status === 'REJECTED'
                                ? 'status-critical'
                                : 'status-warning'
                            }`}
                          >
                            {claim.status}
                          </span>
                        </td>
                        {isBrand && (
                          <td>
                            {claim.status === 'OPEN' ? (
                              <div style={{ display: 'flex', gap: '6px' }}>
                                <button
                                  className="btn btn-primary btn-xs"
                                  onClick={() => handleOpenClaimModal(claim, 'APPROVE')}
                                >
                                  Approve
                                </button>
                                <button
                                  className="btn btn-danger-outline btn-xs"
                                  onClick={() => handleOpenClaimModal(claim, 'REJECT')}
                                >
                                  Reject
                                </button>
                              </div>
                            ) : (
                              <small style={{ color: '#64748b' }}>
                                Reviewed: {claim.resolutionNotes || claim.status}
                              </small>
                            )}
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================================
          MODALS
         ========================================================== */}

      {/* Modal 1: Create Simulated Dispatch (Brand Admin) */}
      {showDispatchModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <h3>Create Primary Dispatch ASN (Simulated SAP)</h3>
              <button className="close-btn" onClick={() => setShowDispatchModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreateDispatch}>
              <div className="modal-body form-grid">
                <div className="form-field">
                  <label>Primary Invoice Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. SAP-INV-2026-9812"
                    value={newDispatch.invoiceNo}
                    onChange={(e) => setNewDispatch({ ...newDispatch, invoiceNo: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Invoice Date *</label>
                  <input
                    type="date"
                    required
                    value={newDispatch.invoiceDate}
                    onChange={(e) => setNewDispatch({ ...newDispatch, invoiceDate: e.target.value })}
                  />
                </div>

                <div className="form-field grid-span-full">
                  <label>Destination Dealership *</label>
                  <select
                    required
                    value={newDispatch.dealerId}
                    onChange={(e) => setNewDispatch({ ...newDispatch, dealerId: e.target.value })}
                  >
                    <option value="">-- Select Dealer --</option>
                    {dealers.map((d) => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code}) - {d.stateCode}</option>
                    ))}
                  </select>
                </div>

                <div className="form-field grid-span-full">
                  <label>Shipping / Dispatch Notes</label>
                  <input
                    type="text"
                    placeholder="e.g. Dispatched via Express Logistics Truck MH-04-1234"
                    value={newDispatch.notes}
                    onChange={(e) => setNewDispatch({ ...newDispatch, notes: e.target.value })}
                  />
                </div>

                {/* Lines Section */}
                <div className="grid-span-full" style={{ marginTop: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong>Invoice Line Items ({newDispatch.lines.length})</strong>
                    <button type="button" className="btn btn-outline btn-xs" onClick={handleAddDispatchLine}>
                      + Add Line
                    </button>
                  </div>

                  {newDispatch.lines.map((line, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '2fr 1fr 1.5fr 1fr 40px',
                        gap: '8px',
                        marginBottom: '8px',
                        alignItems: 'center'
                      }}
                    >
                      <select
                        required
                        value={line.skuId}
                        onChange={(e) => handleUpdateDispatchLine(idx, 'skuId', e.target.value)}
                      >
                        <option value="">-- Select SKU --</option>
                        {skus.map((s) => (
                          <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
                        ))}
                      </select>

                      <input
                        type="number"
                        min="1"
                        required
                        placeholder="Invoiced Qty"
                        value={line.invoicedQty}
                        onChange={(e) => handleUpdateDispatchLine(idx, 'invoicedQty', e.target.value)}
                      />

                      <input
                        type="text"
                        placeholder="Batch Number"
                        value={line.batch}
                        onChange={(e) => handleUpdateDispatchLine(idx, 'batch', e.target.value)}
                      />

                      <input
                        type="number"
                        step="0.01"
                        placeholder="Landing Price"
                        value={line.landingPrice}
                        onChange={(e) => handleUpdateDispatchLine(idx, 'landingPrice', e.target.value)}
                      />

                      {newDispatch.lines.length > 1 && (
                        <button
                          type="button"
                          className="close-btn"
                          onClick={() => handleRemoveDispatchLine(idx)}
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowDispatchModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Dispatch Shipment (IN_TRANSIT)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: GRN Receiving Line Grid with Barcode Scanner (Dealer) */}
      {showGrnModal && selectedAsnForGrn && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '1120px', maxHeight: '92vh', height: '90vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div className="modal-header" style={{ flexShrink: 0 }}>
              <div>
                <h3 style={{ margin: 0 }}>Goods Receipt Note (GRN) Barcode Scanning</h3>
                <small style={{ color: '#64748b' }}>
                  ERP Invoice: <b>{selectedAsnForGrn.invoiceNo}</b> | Dispatch Date: {new Date(selectedAsnForGrn.invoiceDate).toLocaleDateString()}
                </small>
              </div>
              <button className="close-btn" onClick={() => setShowGrnModal(false)}>✕</button>
            </div>

            <form onSubmit={handleConfirmGrn} style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <div className="modal-body" style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: '16px 24px' }}>
                {/* Barcode Scanner & Quick Action Bar */}
                <div style={{ background: '#F8FAFC', padding: '14px', borderRadius: '10px', border: '1px solid #E2E8F0', marginBottom: '16px' }}>
                  <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
                    <div style={{ flex: 1, minWidth: '280px' }}>
                      <input
                        ref={barcodeInputRef}
                        type="text"
                        autoFocus
                        placeholder="🔍 Scan SKU Barcode or Enter Code (Press Enter)"
                        value={barcodeScanInput}
                        onChange={(e) => setBarcodeScanInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            e.stopPropagation();
                            handleBarcodeScan(e);
                          }
                        }}
                        style={{ width: '100%', padding: '9px 12px', fontSize: '13px', border: '2px solid #C5A059', borderRadius: '6px', fontWeight: 600 }}
                      />
                    </div>
                    <button type="button" className="btn btn-primary btn-sm" onClick={(e) => handleBarcodeScan(e)}>
                      ⚡ Scan / Enter
                    </button>
                    <button type="button" className="btn btn-outline btn-sm" onClick={handleBulkAcceptSealedCartons} title="Accept entire shipment as matching invoiced quantities">
                      📦 Bulk Accept Sealed Cartons
                    </button>
                    <button type="button" className="btn btn-danger-outline btn-sm" onClick={handleResetScannedCounts} title="Reset scanned counts to 0 for blind scan">
                      🔄 Reset All to 0
                    </button>
                  </div>

                  {/* Quick Barcode Click-to-Test helper pills */}
                  <div style={{ marginTop: '10px', display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                    <span style={{ fontSize: '11px', color: '#64748b', fontWeight: 600 }}>Click to Scan Item in Shipment:</span>
                    {(selectedAsnForGrn.lines || []).map((l) => (
                      <button
                        key={l.id}
                        type="button"
                        className="article-tag"
                        style={{ cursor: 'pointer', background: '#FFFFFF', border: '1px solid #CBD5E1', padding: '3px 8px', borderRadius: '4px', fontSize: '11px' }}
                        onClick={() => handleBarcodeScan(null, l.sku?.barcode || l.sku?.code)}
                        title={`Click to simulate scanning ${l.sku?.code}`}
                      >
                        ⚡ {l.sku?.code} {l.sku?.barcode ? `(${l.sku.barcode})` : ''} (+1)
                      </button>
                    ))}
                  </div>

                  {barcodeScanFeedback && (
                    <div
                      style={{
                        marginTop: '10px',
                        padding: '8px 12px',
                        borderRadius: '6px',
                        fontSize: '12px',
                        fontWeight: 600,
                        background: barcodeScanFeedback.type === 'success' ? '#ECFDF5' : barcodeScanFeedback.type === 'error' ? '#FEF2F2' : '#EFF6FF',
                        color: barcodeScanFeedback.type === 'success' ? '#059669' : barcodeScanFeedback.type === 'error' ? '#DC2626' : '#2563EB',
                        border: `1px solid ${barcodeScanFeedback.type === 'success' ? '#A7F3D0' : barcodeScanFeedback.type === 'error' ? '#FECACA' : '#BFDBFE'}`
                      }}
                    >
                      {barcodeScanFeedback.message}
                    </div>
                  )}
                </div>

                {/* Select Destination Warehouse */}
                <div className="form-field" style={{ marginBottom: '16px' }}>
                  <label>Destination Warehouse *</label>
                  <select
                    required
                    value={grnWarehouseId}
                    onChange={(e) => setGrnWarehouseId(e.target.value)}
                  >
                    <option value="">-- Choose Destination Warehouse --</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code}) {w.isDefault ? '[DEFAULT]' : ''}</option>
                    ))}
                  </select>
                </div>

                {/* Line Items Receiving Grid */}
                <div className="table-responsive" style={{ maxHeight: '360px', overflowY: 'auto' }}>
                  <table className="data-table" style={{ fontSize: '12px' }}>
                    <thead>
                      <tr>
                        <th>SKU &amp; Barcode</th>
                        <th>Inv Qty</th>
                        <th>Good Qty (Accepted)</th>
                        <th>Short Qty</th>
                        <th>Excess Qty</th>
                        <th>Damaged Qty</th>
                        <th>Variance Reason &amp; Photo</th>
                        <th>Quick Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(selectedAsnForGrn.lines || []).map((line) => {
                        const lData = grnLineData[line.id] || {};
                        const hasVar = (parseInt(lData.shortQty, 10) > 0) || (parseInt(lData.excessQty, 10) > 0) || (parseInt(lData.damagedQty, 10) > 0);

                        return (
                          <tr key={line.id} style={{ background: hasVar ? '#fffbeb' : 'transparent' }}>
                            <td>
                              <strong>{line.sku?.code}</strong>
                              <span className="article-tag">{line.sku?.name}</span>
                              <div style={{ display: 'flex', gap: '4px', marginTop: '2px', flexWrap: 'wrap' }}>
                                <span className="barcode-badge">Batch: {line.batch}</span>
                                {line.sku?.barcode && (
                                  <span className="barcode-badge" style={{ background: '#ecfdf5', color: '#059669', fontWeight: 700 }}>
                                    ||| {line.sku.barcode}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td><b style={{ fontSize: '14px' }}>{line.invoicedQty}</b></td>
                            <td>
                              <input
                                type="number"
                                min="0"
                                style={{ width: '70px', padding: '4px', fontWeight: 700 }}
                                value={lData.receivedGoodQty}
                                onChange={(e) => handleUpdateGrnLine(line.id, 'receivedGoodQty', e.target.value)}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                min="0"
                                style={{ width: '60px', padding: '4px', borderColor: lData.shortQty > 0 ? '#dc2626' : '#cbd5e1' }}
                                value={lData.shortQty}
                                onChange={(e) => handleUpdateGrnLine(line.id, 'shortQty', e.target.value)}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                min="0"
                                style={{ width: '60px', padding: '4px', borderColor: lData.excessQty > 0 ? '#b45309' : '#cbd5e1' }}
                                value={lData.excessQty}
                                onChange={(e) => handleUpdateGrnLine(line.id, 'excessQty', e.target.value)}
                              />
                            </td>
                            <td>
                              <input
                                type="number"
                                min="0"
                                style={{ width: '60px', padding: '4px', borderColor: lData.damagedQty > 0 ? '#dc2626' : '#cbd5e1' }}
                                value={lData.damagedQty}
                                onChange={(e) => handleUpdateGrnLine(line.id, 'damagedQty', e.target.value)}
                              />
                            </td>
                            <td>
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                <input
                                  type="text"
                                  placeholder="Reason if variance..."
                                  value={lData.varianceReason}
                                  onChange={(e) => handleUpdateGrnLine(line.id, 'varianceReason', e.target.value)}
                                  style={{ padding: '4px 6px', fontSize: '11px' }}
                                />
                                <input
                                  type="text"
                                  placeholder="Photo URL / evidence..."
                                  value={lData.photoUrl}
                                  onChange={(e) => handleUpdateGrnLine(line.id, 'photoUrl', e.target.value)}
                                  style={{ padding: '4px 6px', fontSize: '11px' }}
                                />
                              </div>
                            </td>
                            <td>
                              <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                                <button
                                  type="button"
                                  className="btn btn-outline btn-xs"
                                  onClick={() => handleBarcodeScan(null, line.sku?.barcode || line.sku?.code)}
                                  title="Simulate scanning 1 piece of this item"
                                >
                                  📷 +1 Scan
                                </button>
                                <button
                                  type="button"
                                  className="btn btn-secondary btn-xs"
                                  onClick={() => handleUpdateGrnLine(line.id, 'receivedGoodQty', line.invoicedQty)}
                                  title="Set accepted quantity to invoiced quantity"
                                  style={{ fontSize: '10px' }}
                                >
                                  ✓ Match All
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Atomic Posting Rules Notice */}
                <div style={{ marginTop: '14px', padding: '12px', background: '#FDFBF7', borderRadius: '8px', border: '1px solid #E7D7B5', fontSize: '11px', color: '#785A18' }}>
                  <strong>Posting Rules on Confirm:</strong> Good Qty will post to AVAILABLE; Damaged Qty will post to DAMAGED. Short and Excess quantities are NOT posted to stock and automatically raise Transit Claims for Brand review. ERP receipt acknowledgement is recorded atomically.
                </div>
              </div>

              {/* Fixed sticky bottom footer in frame */}
              <div className="modal-footer" style={{ flexShrink: 0, position: 'sticky', bottom: 0, zIndex: 10, background: '#F8FAFC', borderTop: '1px solid #E2E8F0', padding: '14px 24px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowGrnModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={grnSubmitting}>
                  {grnSubmitting ? 'Confirming GRN...' : '✅ Confirm GRN & Post Inventory'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Inter-Warehouse Transfer */}
      {showTransferModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <h3>Initiate Inter-Warehouse Transfer</h3>
              <button className="close-btn" onClick={() => setShowTransferModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreateTransfer}>
              <div className="modal-body form-grid">
                <div className="form-field">
                  <label>Source Warehouse (Origin) *</label>
                  <select
                    required
                    value={newTransfer.sourceWarehouseId}
                    onChange={(e) => setNewTransfer({ ...newTransfer, sourceWarehouseId: e.target.value })}
                  >
                    <option value="">-- Choose Origin Warehouse --</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code})</option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Target Warehouse (Destination) *</label>
                  <select
                    required
                    value={newTransfer.targetWarehouseId}
                    onChange={(e) => setNewTransfer({ ...newTransfer, targetWarehouseId: e.target.value })}
                  >
                    <option value="">-- Choose Target Warehouse --</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code})</option>
                    ))}
                  </select>
                </div>

                <div className="form-field grid-span-full">
                  <label>Transfer Notes / Reason</label>
                  <input
                    type="text"
                    placeholder="e.g. Stock balancing to Showroom for festival display"
                    value={newTransfer.notes}
                    onChange={(e) => setNewTransfer({ ...newTransfer, notes: e.target.value })}
                  />
                </div>

                {/* Transfer Lines */}
                <div className="grid-span-full" style={{ marginTop: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong>Transfer Line Items ({newTransfer.lines.length})</strong>
                    <button
                      type="button"
                      className="btn btn-outline btn-xs"
                      onClick={() => setNewTransfer({ ...newTransfer, lines: [...newTransfer.lines, { skuId: skus[0]?.id || '', batch: 'DEFAULT', qty: 10 }] })}
                    >
                      + Add SKU
                    </button>
                  </div>

                  {newTransfer.lines.map((line, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '2fr 1fr 1fr 40px',
                        gap: '8px',
                        marginBottom: '8px',
                        alignItems: 'center'
                      }}
                    >
                      <select
                        required
                        value={line.skuId}
                        onChange={(e) => {
                          const updated = [...newTransfer.lines];
                          updated[idx].skuId = e.target.value;
                          setNewTransfer({ ...newTransfer, lines: updated });
                        }}
                      >
                        <option value="">-- Select SKU --</option>
                        {skus.map((s) => (
                          <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
                        ))}
                      </select>

                      <input
                        type="text"
                        placeholder="Batch"
                        value={line.batch}
                        onChange={(e) => {
                          const updated = [...newTransfer.lines];
                          updated[idx].batch = e.target.value;
                          setNewTransfer({ ...newTransfer, lines: updated });
                        }}
                      />

                      <input
                        type="number"
                        min="1"
                        required
                        placeholder="Qty"
                        value={line.qty}
                        onChange={(e) => {
                          const updated = [...newTransfer.lines];
                          updated[idx].qty = parseInt(e.target.value, 10);
                          setNewTransfer({ ...newTransfer, lines: updated });
                        }}
                      />

                      {newTransfer.lines.length > 1 && (
                        <button
                          type="button"
                          className="close-btn"
                          onClick={() => {
                            const updated = newTransfer.lines.filter((_, i) => i !== idx);
                            setNewTransfer({ ...newTransfer, lines: updated });
                          }}
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowTransferModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Execute Double-Entry Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 4: Purchase Return to Brand */}
      {showPurchaseReturnModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <h3>Initiate Purchase Return to Brand</h3>
              <button className="close-btn" onClick={() => setShowPurchaseReturnModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreatePurchaseReturn}>
              <div className="modal-body form-grid">
                <div className="form-field">
                  <label>Origin Warehouse *</label>
                  <select
                    required
                    value={newPurchaseReturn.warehouseId}
                    onChange={(e) => setNewPurchaseReturn({ ...newPurchaseReturn, warehouseId: e.target.value })}
                  >
                    <option value="">-- Choose Warehouse --</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code})</option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Return Reason *</label>
                  <select
                    required
                    value={newPurchaseReturn.reason}
                    onChange={(e) => setNewPurchaseReturn({ ...newPurchaseReturn, reason: e.target.value })}
                  >
                    <option value="DAMAGED_IN_TRANSIT">DAMAGED IN TRANSIT</option>
                    <option value="FACTORY_DEFECT">FACTORY DEFECT / WEAVING FLAW</option>
                    <option value="SLOW_MOVING">SLOW MOVING SEASONAL ROTATION</option>
                    <option value="CUSTOMER_RETURNED_DEFECTIVE">CUSTOMER DEFECTIVE RETURN</option>
                    <option value="EXCESS_STOCK">EXCESS STOCK RETURN</option>
                  </select>
                </div>

                <div className="form-field grid-span-full">
                  <label>Return Notes / Dispatch Lorry Receipt #</label>
                  <input
                    type="text"
                    placeholder="e.g. Return authorized via Brand Sales Manager memo #BM-2026-88"
                    value={newPurchaseReturn.notes}
                    onChange={(e) => setNewPurchaseReturn({ ...newPurchaseReturn, notes: e.target.value })}
                  />
                </div>

                {/* Return Lines */}
                <div className="grid-span-full" style={{ marginTop: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong>Items to Return ({newPurchaseReturn.lines.length})</strong>
                    <button
                      type="button"
                      className="btn btn-outline btn-xs"
                      onClick={() => setNewPurchaseReturn({
                        ...newPurchaseReturn,
                        lines: [...newPurchaseReturn.lines, { skuId: skus[0]?.id || '', batch: 'DEFAULT', qty: 5, fromStockState: 'DAMAGED' }]
                      })}
                    >
                      + Add Item
                    </button>
                  </div>

                  {newPurchaseReturn.lines.map((line, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '2fr 1fr 1fr 1fr 40px',
                        gap: '8px',
                        marginBottom: '8px',
                        alignItems: 'center'
                      }}
                    >
                      <select
                        required
                        value={line.skuId}
                        onChange={(e) => {
                          const updated = [...newPurchaseReturn.lines];
                          updated[idx].skuId = e.target.value;
                          setNewPurchaseReturn({ ...newPurchaseReturn, lines: updated });
                        }}
                      >
                        <option value="">-- Select SKU --</option>
                        {skus.map((s) => (
                          <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
                        ))}
                      </select>

                      <input
                        type="text"
                        placeholder="Batch"
                        value={line.batch}
                        onChange={(e) => {
                          const updated = [...newPurchaseReturn.lines];
                          updated[idx].batch = e.target.value;
                          setNewPurchaseReturn({ ...newPurchaseReturn, lines: updated });
                        }}
                      />

                      <select
                        value={line.fromStockState}
                        onChange={(e) => {
                          const updated = [...newPurchaseReturn.lines];
                          updated[idx].fromStockState = e.target.value;
                          setNewPurchaseReturn({ ...newPurchaseReturn, lines: updated });
                        }}
                      >
                        <option value="DAMAGED">DAMAGED State</option>
                        <option value="AVAILABLE">AVAILABLE State</option>
                      </select>

                      <input
                        type="number"
                        min="1"
                        required
                        placeholder="Qty"
                        value={line.qty}
                        onChange={(e) => {
                          const updated = [...newPurchaseReturn.lines];
                          updated[idx].qty = parseInt(e.target.value, 10);
                          setNewPurchaseReturn({ ...newPurchaseReturn, lines: updated });
                        }}
                      />

                      {newPurchaseReturn.lines.length > 1 && (
                        <button
                          type="button"
                          className="close-btn"
                          onClick={() => {
                            const updated = newPurchaseReturn.lines.filter((_, i) => i !== idx);
                            setNewPurchaseReturn({ ...newPurchaseReturn, lines: updated });
                          }}
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowPurchaseReturnModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Submit Return &amp; Generate ERP Return Order
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 5: Conduct Physical Stock Count */}
      {showAuditModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <h3>Conduct Physical Stock Count Audit</h3>
              <button className="close-btn" onClick={() => setShowAuditModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreateAudit}>
              <div className="modal-body form-grid">
                <div className="form-field">
                  <label>Audit Warehouse *</label>
                  <select
                    required
                    value={newAudit.warehouseId}
                    onChange={(e) => setNewAudit({ ...newAudit, warehouseId: e.target.value })}
                  >
                    <option value="">-- Choose Warehouse --</option>
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>{w.name} ({w.code})</option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Audit Notes</label>
                  <input
                    type="text"
                    placeholder="e.g. Annual physical inventory audit Q3"
                    value={newAudit.notes}
                    onChange={(e) => setNewAudit({ ...newAudit, notes: e.target.value })}
                  />
                </div>

                {/* Audit Lines */}
                <div className="grid-span-full" style={{ marginTop: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                    <strong>Counted Items ({newAudit.lines.length})</strong>
                    <button
                      type="button"
                      className="btn btn-outline btn-xs"
                      onClick={() => setNewAudit({
                        ...newAudit,
                        lines: [...newAudit.lines, { skuId: skus[0]?.id || '', batch: 'DEFAULT', countedQty: 0, reasonCode: 'COUNTING_VARIANCE' }]
                      })}
                    >
                      + Add Item
                    </button>
                  </div>

                  {newAudit.lines.map((line, idx) => (
                    <div
                      key={idx}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '2fr 1fr 1fr 1.5fr 40px',
                        gap: '8px',
                        marginBottom: '8px',
                        alignItems: 'center'
                      }}
                    >
                      <select
                        required
                        value={line.skuId}
                        onChange={(e) => {
                          const updated = [...newAudit.lines];
                          updated[idx].skuId = e.target.value;
                          setNewAudit({ ...newAudit, lines: updated });
                        }}
                      >
                        <option value="">-- Select SKU --</option>
                        {skus.map((s) => (
                          <option key={s.id} value={s.id}>{s.code} - {s.name}</option>
                        ))}
                      </select>

                      <input
                        type="text"
                        placeholder="Batch"
                        value={line.batch}
                        onChange={(e) => {
                          const updated = [...newAudit.lines];
                          updated[idx].batch = e.target.value;
                          setNewAudit({ ...newAudit, lines: updated });
                        }}
                      />

                      <input
                        type="number"
                        min="0"
                        required
                        placeholder="Counted Qty"
                        value={line.countedQty}
                        onChange={(e) => {
                          const updated = [...newAudit.lines];
                          updated[idx].countedQty = parseInt(e.target.value, 10);
                          setNewAudit({ ...newAudit, lines: updated });
                        }}
                      />

                      <select
                        value={line.reasonCode}
                        onChange={(e) => {
                          const updated = [...newAudit.lines];
                          updated[idx].reasonCode = e.target.value;
                          setNewAudit({ ...newAudit, lines: updated });
                        }}
                      >
                        <option value="COUNTING_VARIANCE">COUNTING VARIANCE</option>
                        <option value="THEFT_OR_PILFERAGE">THEFT / PILFERAGE</option>
                        <option value="DAMAGED_WRITE_OFF">DAMAGED WRITE OFF</option>
                        <option value="DATA_ENTRY_CORRECTION">DATA ENTRY CORRECTION</option>
                      </select>

                      {newAudit.lines.length > 1 && (
                        <button
                          type="button"
                          className="close-btn"
                          onClick={() => {
                            const updated = newAudit.lines.filter((_, i) => i !== idx);
                            setNewAudit({ ...newAudit, lines: updated });
                          }}
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={() => setShowAuditModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Submit Count for Owner Approval
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 6: Claims Review (Brand Admin) */}
      {showClaimModal && selectedClaim && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <h3>{claimActionType === 'APPROVE' ? 'Approve Transit Claim' : 'Reject Transit Claim'}</h3>
              <button className="close-btn" onClick={() => setShowClaimModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: '13px', color: '#475569' }}>
                Claim Type: <b>{selectedClaim.claimType}</b> | Qty: <b>{selectedClaim.qty}</b> | SKU: <b>{selectedClaim.sku?.code}</b>
              </p>
              <div className="form-field">
                <label>Resolution Notes / Carrier Verification</label>
                <textarea
                  rows="3"
                  placeholder="e.g. Credit note issued for shortage"
                  value={claimNotes}
                  onChange={(e) => setClaimNotes(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowClaimModal(false)}>
                Cancel
              </button>
              <button
                className={`btn ${claimActionType === 'APPROVE' ? 'btn-primary' : 'btn-danger-outline'}`}
                onClick={handleResolveClaim}
              >
                Confirm {claimActionType === 'APPROVE' ? 'Approval' : 'Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 7: Edit Min Stock Threshold */}
      {showMinStockModal && editingMinStockSku && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <h3>Configure Low-Stock Alert</h3>
              <button className="close-btn" onClick={() => setShowMinStockModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: '13px', color: '#475569', marginBottom: '10px' }}>
                Set the minimum stock alert threshold for SKU <b>{editingMinStockSku.code}</b> ({editingMinStockSku.name}).
              </p>
              <div className="form-field">
                <label>Minimum Stock Threshold</label>
                <input
                  type="number"
                  min="0"
                  value={newMinStockVal}
                  onChange={(e) => setNewMinStockVal(e.target.value)}
                />
                <span className="field-hint">When available stock falls below or equal to this number, a low-stock alert triggers.</span>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowMinStockModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSaveMinStock}>
                Save Threshold
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
