import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchPriceLists,
  fetchPriceListById,
  createPriceList,
  updatePriceList,
  submitPriceList,
  approvePriceList,
  rejectPriceList,
  deactivatePriceList,
  addPriceRule,
  deletePriceRule,
  importPriceRulesCsv,
  fetchPricingSettings,
  updatePricingSettings,
  resolvePricePreview
} from '../services/api/pricing.js';
import { fetchSkus, fetchGeoNodes } from '../services/api/masters.js';
import { fetchRetailers } from '../services/api/retailers.js';
import {
  PRICE_PRECEDENCE_ORDER,
  PRICE_METHOD,
  PRICE_TARGET_TYPE,
  isBrandRole
} from '@dms/shared';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 2
});

export function PricingPage({ user }) {
  const isBrand = isBrandRole(user.role);

  // Tabs: 'lists' | 'resolver'
  const [activeTab, setActiveTab] = useState('lists');

  // Pricing lists state
  const [priceLists, setPriceLists] = useState([]);
  const [selectedList, setSelectedList] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');

  // Global settings
  const [minMarginPct, setMinMarginPct] = useState(10);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [newMarginInput, setNewMarginInput] = useState('10');

  // Master lookups for forms
  const [skus, setSkus] = useState([]);
  const [retailers, setRetailers] = useState([]);
  const [geoNodes, setGeoNodes] = useState([]);

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showAddRuleModal, setShowAddRuleModal] = useState(false);
  const [showCsvModal, setShowCsvModal] = useState(false);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  // Create list form
  const [newListData, setNewListData] = useState({
    name: '',
    version: 1,
    validFrom: new Date().toISOString().slice(0, 10),
    validTo: new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString().slice(0, 10)
  });

  // Add rule form
  const [newRuleData, setNewRuleData] = useState({
    skuId: '',
    targetType: 'NATIONAL',
    targetId: '',
    method: 'FIXED',
    value: '',
    validFrom: '',
    validTo: ''
  });
  const [ruleGuardrailWarning, setRuleGuardrailWarning] = useState(null);

  // CSV import state
  const [csvText, setCsvText] = useState('');
  const [csvMode, setCsvMode] = useState('skip_bad_rows');
  const [csvImporting, setCsvImporting] = useState(false);
  const [csvReport, setCsvReport] = useState(null);

  // Price Resolver Tool state
  const [resolverParams, setResolverParams] = useState({
    retailerId: '',
    skuId: '',
    date: new Date().toISOString().slice(0, 10),
    landingPrice: ''
  });
  const [resolving, setResolving] = useState(false);
  const [resolvedResult, setResolvedResult] = useState(null);
  const [resolverError, setResolverError] = useState(null);

  // Load Initial Data
  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [listsRes, settingsRes, skusRes, retailersRes, geoRes] = await Promise.all([
        fetchPriceLists(user, { status: statusFilter, search }),
        fetchPricingSettings(user).catch(() => ({ minMarginPct: 10 })),
        fetchSkus(user, { limit: 100 }).catch(() => ({ skus: [] })),
        fetchRetailers(user, { limit: 100 }).catch(() => ({ retailers: [] })),
        fetchGeoNodes(user).catch(() => ({ nodes: [] }))
      ]);

      setPriceLists(listsRes.priceLists || []);
      if (settingsRes.minMarginPct !== undefined) {
        setMinMarginPct(settingsRes.minMarginPct);
        setNewMarginInput(String(settingsRes.minMarginPct));
      }
      setSkus(skusRes.skus || []);
      setRetailers(retailersRes.retailers || []);
      setGeoNodes(geoRes.nodes || []);

      // If a list was selected, refresh its details
      if (selectedList) {
        const refreshed = await fetchPriceListById(user, selectedList.id);
        setSelectedList(refreshed);
      }
    } catch (err) {
      setError(err.message || 'Failed to load pricing data.');
    } finally {
      setLoading(false);
    }
  }, [user, statusFilter, search, selectedList?.id]);

  useEffect(() => {
    loadData();
  }, [statusFilter, search]);

  // Select a price list to view rules
  const handleSelectList = async (list) => {
    try {
      setLoading(true);
      const full = await fetchPriceListById(user, list.id);
      setSelectedList(full);
    } catch (err) {
      alert('Failed to load price list: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  // Create Price List
  const handleCreateList = async (e) => {
    e.preventDefault();
    try {
      const created = await createPriceList(user, newListData);
      setShowCreateModal(false);
      setNewListData({
        name: '',
        version: 1,
        validFrom: new Date().toISOString().slice(0, 10),
        validTo: new Date(Date.now() + 365 * 24 * 3600 * 1000).toISOString().slice(0, 10)
      });
      await loadData();
      setSelectedList(created);
    } catch (err) {
      alert('Failed to create price list: ' + err.message);
    }
  };

  // Submit for Approval
  const handleSubmitForApproval = async (listId) => {
    if (!window.confirm('Submit this price list for Brand Admin approval?')) return;
    try {
      await submitPriceList(user, listId);
      await loadData();
    } catch (err) {
      alert('Submission failed: ' + err.message);
    }
  };

  // Approve Price List (Maker-Checker enforced)
  const handleApprove = async (listId) => {
    try {
      await approvePriceList(user, listId);
      alert('Price list approved and activated!');
      await loadData();
    } catch (err) {
      alert(err.message || 'Approval failed.');
    }
  };

  // Reject Price List
  const handleReject = async () => {
    if (!rejectReason.trim()) {
      alert('Please provide a rejection reason.');
      return;
    }
    try {
      await rejectPriceList(user, selectedList.id, rejectReason);
      setShowRejectModal(false);
      setRejectReason('');
      await loadData();
    } catch (err) {
      alert('Rejection failed: ' + err.message);
    }
  };

  // Deactivate Price List
  const handleDeactivate = async (listId) => {
    if (!window.confirm('Deactivate this approved price list?')) return;
    try {
      await deactivatePriceList(user, listId);
      await loadData();
    } catch (err) {
      alert('Deactivation failed: ' + err.message);
    }
  };

  // Live guardrail check in Add Rule form
  useEffect(() => {
    if (!newRuleData.skuId || !newRuleData.value) {
      setRuleGuardrailWarning(null);
      return;
    }

    const sku = skus.find((s) => s.id === newRuleData.skuId);
    if (!sku) return;

    const val = parseFloat(newRuleData.value);
    if (isNaN(val) || val <= 0) {
      setRuleGuardrailWarning('Value must be a positive number');
      return;
    }

    const mrp = sku.mrp || 0;
    const landing = sku.landingPrice || (mrp * 0.6);
    let calcPrice = val;

    if (newRuleData.method === 'PERCENT_OFF_MRP') {
      calcPrice = mrp * (1 - val / 100);
    } else if (newRuleData.method === 'MARKUP_ON_LANDING') {
      calcPrice = landing * (1 + val / 100);
    }

    calcPrice = Math.round(calcPrice * 100) / 100;

    const minAllowed = Math.round(landing * (1 + minMarginPct / 100) * 100) / 100;

    if (mrp && calcPrice > mrp) {
      setRuleGuardrailWarning(`BREACH: Price (₹${calcPrice}) exceeds MRP (₹${mrp}). Must be <= MRP.`);
    } else if (landing && calcPrice < minAllowed) {
      setRuleGuardrailWarning(`BREACH: Price (₹${calcPrice}) is below min allowed ₹${minAllowed} (Landing ₹${landing} + ${minMarginPct}% min margin).`);
    } else {
      setRuleGuardrailWarning(null);
    }
  }, [newRuleData, skus, minMarginPct]);

  // Add Single Rule
  const handleAddRule = async (e) => {
    e.preventDefault();
    if (ruleGuardrailWarning && ruleGuardrailWarning.startsWith('BREACH:')) {
      alert('Cannot save rule: ' + ruleGuardrailWarning);
      return;
    }

    try {
      await addPriceRule(user, selectedList.id, {
        ...newRuleData,
        value: parseFloat(newRuleData.value),
        validFrom: newRuleData.validFrom || null,
        validTo: newRuleData.validTo || null
      });
      setShowAddRuleModal(false);
      setNewRuleData({
        skuId: '',
        targetType: 'NATIONAL',
        targetId: '',
        method: 'FIXED',
        value: '',
        validFrom: '',
        validTo: ''
      });
      // Refresh current list
      const refreshed = await fetchPriceListById(user, selectedList.id);
      setSelectedList(refreshed);
      await loadData();
    } catch (err) {
      alert('Failed to add rule: ' + err.message);
    }
  };

  // Delete Rule
  const handleDeleteRule = async (ruleId) => {
    if (!window.confirm('Delete this price rule?')) return;
    try {
      await deletePriceRule(user, selectedList.id, ruleId);
      const refreshed = await fetchPriceListById(user, selectedList.id);
      setSelectedList(refreshed);
      await loadData();
    } catch (err) {
      alert('Failed to delete rule: ' + err.message);
    }
  };

  // CSV Bulk Import for Rules
  const handleCsvImport = async () => {
    if (!csvText.trim()) {
      alert('Please paste or upload CSV text.');
      return;
    }

    const lines = csvText.trim().split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length < 2) {
      alert('CSV must contain a header line and at least one data row.');
      return;
    }

    const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
    const rows = lines.slice(1).map((line) => {
      const parts = line.split(',').map((p) => p.trim().replace(/^"|"$/g, ''));
      const obj = {};
      headers.forEach((h, i) => {
        obj[h] = parts[i] || '';
      });
      return obj;
    });

    setCsvImporting(true);
    setCsvReport(null);
    try {
      const res = await importPriceRulesCsv(user, selectedList.id, { rows, mode: csvMode });
      setCsvReport(res);
      const refreshed = await fetchPriceListById(user, selectedList.id);
      setSelectedList(refreshed);
      await loadData();
    } catch (err) {
      alert('CSV import failed: ' + err.message);
    } finally {
      setCsvImporting(false);
    }
  };

  // Update Global minMarginPct
  const handleSaveMargin = async () => {
    const val = parseFloat(newMarginInput);
    if (isNaN(val) || val < 0 || val > 100) {
      alert('Please enter a valid percentage between 0 and 100.');
      return;
    }
    try {
      const res = await updatePricingSettings(user, { minMarginPct: val });
      setMinMarginPct(res.minMarginPct);
      setShowSettingsModal(false);
      alert(`Global minimum margin updated to ${res.minMarginPct}%.`);
    } catch (err) {
      alert('Failed to update margin setting: ' + err.message);
    }
  };

  // Run Price Resolver Tool
  const handleResolvePrice = async (e) => {
    e.preventDefault();
    if (!resolverParams.retailerId || !resolverParams.skuId) {
      alert('Please select both a Retailer and a SKU.');
      return;
    }

    setResolving(true);
    setResolverError(null);
    setResolvedResult(null);
    try {
      const payload = {
        retailerId: resolverParams.retailerId,
        skuId: resolverParams.skuId,
        date: resolverParams.date || new Date().toISOString()
      };
      if (resolverParams.landingPrice) {
        payload.landingPrice = parseFloat(resolverParams.landingPrice);
      }
      const res = await resolvePricePreview(user, payload);
      setResolvedResult(res);
    } catch (err) {
      setResolverError(err.message || 'Price resolution failed.');
    } finally {
      setResolving(false);
    }
  };

  // Download Sample CSV
  const downloadSampleCsv = () => {
    const sampleSku = skus[0]?.code || 'BRK-PAD-001';
    const csvContent =
      `skuCode,targetType,targetId,method,value,validFrom,validTo\n` +
      `${sampleSku},NATIONAL,,FIXED,1550,2026-01-01,2026-12-31\n` +
      `${sampleSku},RETAILER_CLASS,A,PERCENT_OFF_MRP,12,,\n` +
      `${sampleSku},CLUSTER,${geoNodes[0]?.id || ''},MARKUP_ON_LANDING,25,,\n`;

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'sample_price_rules.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="master-page pricing-page">
      {/* Top Header Tabs */}
      <div className="brand-tabs-bar">
        <button
          className={`tab-btn ${activeTab === 'lists' ? 'active' : ''}`}
          onClick={() => setActiveTab('lists')}
        >
          🏷️ Price Lists &amp; Rules
          <span className="tab-badge-alert" style={{ background: '#C5A059' }}>
            {priceLists.length}
          </span>
        </button>
        <button
          className={`tab-btn ${activeTab === 'resolver' ? 'active' : ''}`}
          onClick={() => setActiveTab('resolver')}
        >
          🔍 Price Check Tool
        </button>

        {isBrand && (
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '12px', color: '#475569', fontWeight: 600 }}>
              🛡️ Guardrail Min Margin: <b>{minMarginPct}%</b>
            </span>
            <button
              className="btn btn-outline btn-xs"
              onClick={() => setShowSettingsModal(true)}
            >
              Configure
            </button>
          </div>
        )}
      </div>

      {error && <div className="error-alert">{error}</div>}

      {/* ==========================================================
          TAB 1: PRICE LISTS & RULES VIEW
         ========================================================== */}
      {activeTab === 'lists' && (
        <div>
          {!selectedList ? (
            <div>
              {/* Controls bar */}
              <div className="search-filter-bar" style={{ marginBottom: '16px' }}>
                <input
                  type="text"
                  placeholder="Search price lists by name..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="search-input"
                />

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  style={{
                    padding: '8px 12px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    fontSize: '13px'
                  }}
                >
                  <option value="">All Statuses</option>
                  <option value="DRAFT">Draft</option>
                  <option value="PENDING_APPROVAL">Pending Approval</option>
                  <option value="APPROVED">Approved (Active)</option>
                  <option value="INACTIVE">Inactive</option>
                </select>

                {isBrand && (
                  <button
                    className="btn btn-primary"
                    style={{ marginLeft: 'auto' }}
                    onClick={() => setShowCreateModal(true)}
                  >
                    + New Price List
                  </button>
                )}
              </div>

              {/* Price Lists Table */}
              <div className="table-card">
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Price List</th>
                        <th>Version</th>
                        <th>Status</th>
                        <th>Validity Window</th>
                        <th>Maker (Created By)</th>
                        <th>Checker (Approved By)</th>
                        <th>Rules</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {priceLists.length === 0 ? (
                        <tr>
                          <td colSpan="8" style={{ textAlign: 'center', padding: '30px' }}>
                            {loading ? (
                              <div className="spinner" />
                            ) : (
                              <span className="text-muted">No price lists found. Create a draft to get started.</span>
                            )}
                          </td>
                        </tr>
                      ) : (
                        priceLists.map((pl) => (
                          <tr key={pl.id}>
                            <td>
                              <strong>{pl.name}</strong>
                              {pl.rejectionReason && (
                                <span className="rejection-reason-hint">
                                  Rejected: {pl.rejectionReason}
                                </span>
                              )}
                            </td>
                            <td>
                              <span className="barcode-badge">v{pl.version}</span>
                            </td>
                            <td>
                              <span
                                className={`status-pill ${
                                  pl.status === 'APPROVED'
                                    ? 'status-billable'
                                    : pl.status === 'PENDING_APPROVAL'
                                    ? 'status-low'
                                    : pl.status === 'DRAFT'
                                    ? 'status-warning'
                                    : 'status-critical'
                                }`}
                              >
                                {pl.status.replace('_', ' ')}
                              </span>
                            </td>
                            <td>
                              <small style={{ color: '#475569' }}>
                                {new Date(pl.validFrom).toLocaleDateString()} —{' '}
                                {pl.validTo ? new Date(pl.validTo).toLocaleDateString() : 'Indefinite'}
                              </small>
                            </td>
                            <td>
                              <span style={{ fontSize: '12px', color: '#1e293b', fontWeight: 600 }}>
                                {pl.createdByEmail || 'Brand Admin'}
                              </span>
                            </td>
                            <td>
                              <span style={{ fontSize: '12px', color: pl.approvedByEmail ? '#059669' : '#94a3b8' }}>
                                {pl.approvedByEmail || 'Pending Checker'}
                              </span>
                            </td>
                            <td>
                              <b>{pl._count?.rules || 0}</b> rules
                            </td>
                            <td>
                              <div className="btn-group">
                                <button
                                  className="btn btn-primary btn-xs"
                                  onClick={() => handleSelectList(pl)}
                                >
                                  Manage Rules
                                </button>
                                {isBrand && pl.status === 'DRAFT' && pl._count?.rules > 0 && (
                                  <button
                                    className="btn btn-outline btn-xs"
                                    onClick={() => handleSubmitForApproval(pl.id)}
                                  >
                                    Submit
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            /* Selected Price List Rules Details View */
            <div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '16px',
                  background: '#ffffff',
                  padding: '16px 20px',
                  borderRadius: '12px',
                  border: '1px solid #e2e8f0'
                }}
              >
                <div>
                  <button
                    className="btn btn-secondary btn-xs"
                    onClick={() => setSelectedList(null)}
                    style={{ marginBottom: '6px' }}
                  >
                    ← Back to Price Lists
                  </button>
                  <h2 style={{ margin: '0 0 4px', fontSize: '18px', color: '#0f172a' }}>
                    {selectedList.name}{' '}
                    <span className="barcode-badge">v{selectedList.version}</span>
                  </h2>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>
                    Status:{' '}
                    <span
                      className={`status-pill ${
                        selectedList.status === 'APPROVED'
                          ? 'status-billable'
                          : selectedList.status === 'PENDING_APPROVAL'
                          ? 'status-low'
                          : selectedList.status === 'DRAFT'
                          ? 'status-warning'
                          : 'status-critical'
                      }`}
                    >
                      {selectedList.status}
                    </span>{' '}
                    | Valid: {new Date(selectedList.validFrom).toLocaleDateString()} to{' '}
                    {selectedList.validTo ? new Date(selectedList.validTo).toLocaleDateString() : 'Indefinite'}{' '}
                    | Maker: <b>{selectedList.createdByEmail || 'brand@dms.local'}</b>
                  </div>
                </div>

                <div className="btn-group">
                  {/* Maker-Checker Workflow Action Buttons */}
                  {isBrand && selectedList.status === 'DRAFT' && (
                    <>
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => setShowAddRuleModal(true)}
                      >
                        + Add Rule
                      </button>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() => {
                          setCsvText('');
                          setCsvReport(null);
                          setShowCsvModal(true);
                        }}
                      >
                        📥 Bulk CSV Import
                      </button>
                      <button
                        className="btn btn-outline btn-sm"
                        disabled={!selectedList.rules || selectedList.rules.length === 0}
                        onClick={() => handleSubmitForApproval(selectedList.id)}
                      >
                        🚀 Submit for Approval
                      </button>
                    </>
                  )}

                  {isBrand && selectedList.status === 'PENDING_APPROVAL' && (
                    <>
                      {/* Maker-checker check: if creator email matches current user email */}
                      {selectedList.createdByEmail &&
                      user.email &&
                      selectedList.createdByEmail.toLowerCase() === user.email.toLowerCase() ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span
                            style={{
                              fontSize: '11px',
                              background: '#fffbeb',
                              border: '1px solid #fde68a',
                              color: '#b45309',
                              padding: '6px 10px',
                              borderRadius: '6px',
                              fontWeight: 600
                            }}
                          >
                            ⚠️ Maker–Checker: Another admin must approve (e.g. brand2@dms.local)
                          </span>
                          <button
                            className="btn btn-primary btn-sm"
                            disabled
                            title="You created this price list and cannot approve it under Maker-Checker rules."
                          >
                            Approve
                          </button>
                        </div>
                      ) : (
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => handleApprove(selectedList.id)}
                        >
                          ✅ Approve (Checker)
                        </button>
                      )}

                      <button
                        className="btn btn-danger-outline btn-sm"
                        onClick={() => {
                          setRejectReason('');
                          setShowRejectModal(true);
                        }}
                      >
                        ❌ Reject
                      </button>
                    </>
                  )}

                  {isBrand && selectedList.status === 'APPROVED' && (
                    <button
                      className="btn btn-danger-outline btn-sm"
                      onClick={() => handleDeactivate(selectedList.id)}
                    >
                      Deactivate
                    </button>
                  )}
                </div>
              </div>

              {/* Rules Table */}
              <div className="table-card">
                <div className="table-meta-bar">
                  <span>
                    Pricing Rules (<b>{selectedList.rules?.length || 0}</b> configured)
                  </span>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>
                    Resolver tests precedence in order: Retailer → Class/Channel → Cluster → City → Region → State → Zone → National
                  </span>
                </div>
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>SKU Code &amp; Name</th>
                        <th>SKU MRP</th>
                        <th>Landing Price</th>
                        <th>Precedence Level</th>
                        <th>Target ID / Value</th>
                        <th>Pricing Method</th>
                        <th>Rule Value</th>
                        <th>Calculated Price</th>
                        <th>Validity Window</th>
                        {selectedList.status === 'DRAFT' && <th>Action</th>}
                      </tr>
                    </thead>
                    <tbody>
                      {!selectedList.rules || selectedList.rules.length === 0 ? (
                        <tr>
                          <td colSpan="10" style={{ textAlign: 'center', padding: '30px' }}>
                            <span className="text-muted">
                              No rules in this price list. Add rules manually or import via CSV.
                            </span>
                          </td>
                        </tr>
                      ) : (
                        selectedList.rules.map((rule) => {
                          const mrp = rule.sku?.mrp || 0;
                          const landing = rule.sku?.landingPrice || (mrp * 0.6);
                          let price = rule.value;
                          if (rule.method === 'PERCENT_OFF_MRP') {
                            price = mrp * (1 - rule.value / 100);
                          } else if (rule.method === 'MARKUP_ON_LANDING') {
                            price = landing * (1 + rule.value / 100);
                          }
                          price = Math.round(price * 100) / 100;

                          return (
                            <tr key={rule.id}>
                              <td>
                                <strong>{rule.sku?.code}</strong>
                                <span className="article-tag">{rule.sku?.name}</span>
                              </td>
                              <td>{inrFormat.format(mrp)}</td>
                              <td>{inrFormat.format(landing)}</td>
                              <td>
                                <span
                                  className="hsn-pill"
                                  style={{
                                    background:
                                      rule.targetType === 'RETAILER'
                                        ? '#fee2e2'
                                        : rule.targetType === 'RETAILER_CLASS'
                                        ? '#fef3c7'
                                        : rule.targetType === 'NATIONAL'
                                        ? '#e0e7ff'
                                        : '#ecfdf5',
                                    color:
                                      rule.targetType === 'RETAILER'
                                        ? '#b91c1c'
                                        : rule.targetType === 'RETAILER_CLASS'
                                        ? '#b45309'
                                        : rule.targetType === 'NATIONAL'
                                        ? '#3730a3'
                                        : '#065f46'
                                  }}
                                >
                                  {rule.targetType}
                                </span>
                              </td>
                              <td>
                                <span className="barcode-badge">
                                  {rule.targetId || 'ALL (National)'}
                                </span>
                              </td>
                              <td>
                                <span style={{ fontSize: '11px', fontWeight: 600 }}>
                                  {rule.method.replace(/_/g, ' ')}
                                </span>
                              </td>
                              <td>
                                <strong>
                                  {rule.method === 'FIXED'
                                    ? inrFormat.format(rule.value)
                                    : `${rule.value}%`}
                                </strong>
                              </td>
                              <td>
                                <span
                                  style={{
                                    fontSize: '13px',
                                    fontWeight: 700,
                                    color: '#059669'
                                  }}
                                >
                                  {inrFormat.format(price)}
                                </span>
                              </td>
                              <td>
                                <small style={{ color: '#64748b' }}>
                                  {rule.validFrom ? new Date(rule.validFrom).toLocaleDateString() : 'Start'} —{' '}
                                  {rule.validTo ? new Date(rule.validTo).toLocaleDateString() : 'End'}
                                </small>
                              </td>
                              {selectedList.status === 'DRAFT' && (
                                <td>
                                  <button
                                    className="btn btn-danger-outline btn-xs"
                                    onClick={() => handleDeleteRule(rule.id)}
                                  >
                                    Delete
                                  </button>
                                </td>
                              )}
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==========================================================
          TAB 2: PRICE CHECK RESOLVER TOOL
         ========================================================== */}
      {activeTab === 'resolver' && (
        <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', gap: '24px' }}>
          {/* Resolver Input Form */}
          <div className="table-card" style={{ padding: '24px' }}>
            <h3 style={{ margin: '0 0 6px', fontSize: '16px', color: '#0f172a' }}>
              🔍 Price Resolution Simulator
            </h3>
            <p style={{ margin: '0 0 18px', fontSize: '12px', color: '#64748b' }}>
              Pick a retailer, SKU and transaction date to simulate how the pure price resolver resolves the winning secondary price.
            </p>

            <form onSubmit={handleResolvePrice} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="form-field">
                <label>Target Retailer *</label>
                <select
                  value={resolverParams.retailerId}
                  onChange={(e) => setResolverParams({ ...resolverParams, retailerId: e.target.value })}
                  required
                >
                  <option value="">-- Select Retailer --</option>
                  {retailers.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.legalName} ({r.retailerClass} - {r.channelType}) - {r.stateCode}
                    </option>
                  ))}
                </select>
                <span className="field-hint">Contains Class, Channel, State Code and Cluster hierarchy</span>
              </div>

              <div className="form-field">
                <label>SKU to Price *</label>
                <select
                  value={resolverParams.skuId}
                  onChange={(e) => setResolverParams({ ...resolverParams, skuId: e.target.value })}
                  required
                >
                  <option value="">-- Select SKU --</option>
                  {skus.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} - {s.name} (MRP: {inrFormat.format(s.mrp || 0)})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label>Pricing Date</label>
                <input
                  type="date"
                  value={resolverParams.date}
                  onChange={(e) => setResolverParams({ ...resolverParams, date: e.target.value })}
                  required
                />
                <span className="field-hint">Tests rule and price list date validity</span>
              </div>

              <div className="form-field">
                <label>Landing Price (INR, Optional Override)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="Defaults to SKU Landing Price"
                  value={resolverParams.landingPrice}
                  onChange={(e) => setResolverParams({ ...resolverParams, landingPrice: e.target.value })}
                />
                <span className="field-hint">Used for MARKUP_ON_LANDING and guardrail margin checks</span>
              </div>

              <button
                type="submit"
                className="btn btn-primary"
                disabled={resolving}
                style={{ marginTop: '8px' }}
              >
                {resolving ? 'Resolving...' : '⚡ Resolve Secondary Price'}
              </button>
            </form>
          </div>

          {/* Resolver Results View */}
          <div>
            {resolverError && (
              <div className="error-alert" style={{ marginBottom: '16px' }}>
                {resolverError}
              </div>
            )}

            {!resolvedResult && !resolverError && (
              <div className="empty-card" style={{ padding: '60px 20px' }}>
                <span style={{ fontSize: '40px', display: 'block', marginBottom: '12px' }}>🎯</span>
                <h3 style={{ margin: '0 0 6px', color: '#0f172a' }}>Ready to simulate price resolution</h3>
                <p style={{ margin: 0, fontSize: '13px', color: '#64748b' }}>
                  Select a Retailer and SKU on the left to preview the winning price rule and guardrail status.
                </p>
              </div>
            )}

            {resolvedResult && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                {resolvedResult.status === 'NO_PRICE' ? (
                  <div className="empty-card" style={{ background: '#fef2f2', borderColor: '#fecaca' }}>
                    <span style={{ fontSize: '36px', display: 'block', marginBottom: '8px' }}>⚠️</span>
                    <h3 style={{ margin: '0 0 4px', color: '#991b1b' }}>NO_PRICE: No Rule Matched</h3>
                    <p style={{ margin: 0, fontSize: '13px', color: '#b91c1c' }}>
                      {resolvedResult.message}
                    </p>
                  </div>
                ) : (
                  <div
                    className="table-card"
                    style={{
                      padding: '24px',
                      background: '#ffffff',
                      border: '2px solid #10b981'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                      <div>
                        <span className="eyebrow" style={{ color: '#059669' }}>
                          WINNING RESOLVED SECONDARY PRICE
                        </span>
                        <div style={{ fontSize: '36px', fontWeight: 800, color: '#0f172a', margin: '4px 0 8px' }}>
                          {inrFormat.format(resolvedResult.price)}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <span
                            className="status-pill status-billable"
                            style={{ fontSize: '12px', padding: '4px 10px' }}
                          >
                            Winning Level: {resolvedResult.level}
                          </span>
                          <span style={{ fontSize: '12px', color: '#475569' }}>
                            Rule ID: <code style={{ background: '#f1f5f9', padding: '2px 5px' }}>{resolvedResult.ruleId?.slice(0, 8)}...</code>
                          </span>
                        </div>
                      </div>

                      <div style={{ textAlign: 'right' }}>
                        <span className="sample-label">SKU MRP</span>
                        <div style={{ fontSize: '18px', fontWeight: 700, color: '#475569' }}>
                          {inrFormat.format(resolvedResult.sku.mrp || 0)}
                        </div>
                        <small style={{ color: '#059669', fontWeight: 600 }}>
                          Margin:{' '}
                          {inrFormat.format(
                            resolvedResult.price - (resolvedResult.sku.landingPrice || 0)
                          )}
                        </small>
                      </div>
                    </div>

                    {/* Precedence explanation banner */}
                    <div
                      style={{
                        margin: '18px 0',
                        padding: '12px 16px',
                        background: '#FDFBF7',
                        borderRadius: '8px',
                        border: '1px solid #E7D7B5',
                        fontSize: '12px',
                        color: '#785A18'
                      }}
                    >
                      <strong>Precedence Logic:</strong> Rule for target level <b>{resolvedResult.level}</b> took precedence because it is the most specific valid approved rule available for this retailer and SKU on {new Date(resolvedResult.date).toLocaleDateString()}.
                    </div>

                    {/* Hierarchy ladder */}
                    <div style={{ marginBottom: '16px' }}>
                      <span className="mode-label" style={{ marginBottom: '6px' }}>
                        DMS Precedence Hierarchy Ladder
                      </span>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {PRICE_PRECEDENCE_ORDER.map((lvl, idx) => {
                          const isWinner = lvl === resolvedResult.level;
                          return (
                            <div
                              key={lvl}
                              style={{
                                padding: '6px 10px',
                                borderRadius: '6px',
                                fontSize: '11px',
                                fontWeight: 700,
                                background: isWinner ? '#10b981' : '#f1f5f9',
                                color: isWinner ? '#ffffff' : '#64748b',
                                border: isWinner ? '1px solid #059669' : '1px solid #e2e8f0',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '4px'
                              }}
                            >
                              <span>{idx + 1}. {lvl}</span>
                              {isWinner && <span>★ WON</span>}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Guardrails check card */}
                    <div
                      style={{
                        padding: '14px',
                        background: '#f8fafc',
                        borderRadius: '8px',
                        border: '1px solid #e2e8f0',
                        fontSize: '12px'
                      }}
                    >
                      <strong style={{ display: 'block', marginBottom: '6px', color: '#0f172a' }}>
                        🛡️ Guardrail Compliance Summary
                      </strong>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
                        <div>
                          <span className="prop-label">Condition 1: Price &lt;= MRP</span>
                          <span style={{ fontWeight: 600, color: '#059669', display: 'block' }}>
                            ✅ PASSED ({inrFormat.format(resolvedResult.price)} &le; {inrFormat.format(resolvedResult.sku.mrp || 0)})
                          </span>
                        </div>
                        <div>
                          <span className="prop-label">Condition 2: Min Margin ({minMarginPct}%)</span>
                          <span style={{ fontWeight: 600, color: '#059669', display: 'block' }}>
                            ✅ PASSED (Landing: {inrFormat.format(resolvedResult.sku.landingPrice || 0)})
                          </span>
                        </div>
                        <div>
                          <span className="prop-label">Calculation Method</span>
                          <span style={{ fontWeight: 600, color: '#334155', display: 'block' }}>
                            {resolvedResult.method}: {resolvedResult.value}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================================
          MODALS
         ========================================================== */}

      {/* Modal 1: Create Price List */}
      {showCreateModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-md">
            <div className="modal-header">
              <h3>Create Draft Price List</h3>
              <button className="close-btn" onClick={() => setShowCreateModal(false)}>✕</button>
            </div>
            <form onSubmit={handleCreateList}>
              <div className="modal-body form-grid">
                <div className="form-field grid-span-full">
                  <label>Price List Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Maharashtra Q3 Dealer Secondary Price List"
                    value={newListData.name}
                    onChange={(e) => setNewListData({ ...newListData, name: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Version</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={newListData.version}
                    onChange={(e) => setNewListData({ ...newListData, version: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Status</label>
                  <input type="text" disabled value="DRAFT (Initial State)" />
                </div>

                <div className="form-field">
                  <label>Valid From *</label>
                  <input
                    type="date"
                    required
                    value={newListData.validFrom}
                    onChange={(e) => setNewListData({ ...newListData, validFrom: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Valid To (Optional)</label>
                  <input
                    type="date"
                    value={newListData.validTo}
                    onChange={(e) => setNewListData({ ...newListData, validTo: e.target.value })}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowCreateModal(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Create Draft
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Add Price Rule */}
      {showAddRuleModal && selectedList && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <div>
                <h3>Add Rule to {selectedList.name}</h3>
                <small>Guardrail verified at save time</small>
              </div>
              <button className="close-btn" onClick={() => setShowAddRuleModal(false)}>✕</button>
            </div>

            <form onSubmit={handleAddRule}>
              <div className="modal-body form-grid">
                <div className="form-field grid-span-full">
                  <label>Select SKU *</label>
                  <select
                    required
                    value={newRuleData.skuId}
                    onChange={(e) => setNewRuleData({ ...newRuleData, skuId: e.target.value })}
                  >
                    <option value="">-- Choose SKU --</option>
                    {skus.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} - {s.name} (MRP: {inrFormat.format(s.mrp || 0)}, Landing: {inrFormat.format(s.landingPrice || 0)})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Target Precedence Level *</label>
                  <select
                    required
                    value={newRuleData.targetType}
                    onChange={(e) => setNewRuleData({ ...newRuleData, targetType: e.target.value, targetId: '' })}
                  >
                    {PRICE_PRECEDENCE_ORDER.map((lvl) => (
                      <option key={lvl} value={lvl}>{lvl}</option>
                    ))}
                  </select>
                </div>

                <div className="form-field">
                  <label>Target Identifier</label>
                  {newRuleData.targetType === 'NATIONAL' ? (
                    <input type="text" disabled value="Applies Nationally across all dealers/retailers" />
                  ) : newRuleData.targetType === 'RETAILER' ? (
                    <select
                      required
                      value={newRuleData.targetId}
                      onChange={(e) => setNewRuleData({ ...newRuleData, targetId: e.target.value })}
                    >
                      <option value="">-- Select Retailer --</option>
                      {retailers.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.legalName} ({r.stateCode})
                        </option>
                      ))}
                    </select>
                  ) : newRuleData.targetType === 'RETAILER_CLASS' ? (
                    <select
                      required
                      value={newRuleData.targetId}
                      onChange={(e) => setNewRuleData({ ...newRuleData, targetId: e.target.value })}
                    >
                      <option value="">-- Select Class / Channel --</option>
                      <option value="A">Class A</option>
                      <option value="B">Class B</option>
                      <option value="C">Class C</option>
                      <option value="MBO">Channel: MBO</option>
                      <option value="EBO">Channel: EBO</option>
                      <option value="ETHNIC">Channel: ETHNIC</option>
                    </select>
                  ) : (
                    <select
                      required
                      value={newRuleData.targetId}
                      onChange={(e) => setNewRuleData({ ...newRuleData, targetId: e.target.value })}
                    >
                      <option value="">-- Select Geo Node ({newRuleData.targetType}) --</option>
                      {geoNodes
                        .filter((g) => g.type === newRuleData.targetType)
                        .map((g) => (
                          <option key={g.id} value={g.id}>
                            {g.name} ({g.path})
                          </option>
                        ))}
                    </select>
                  )}
                </div>

                <div className="form-field">
                  <label>Pricing Method *</label>
                  <select
                    required
                    value={newRuleData.method}
                    onChange={(e) => setNewRuleData({ ...newRuleData, method: e.target.value })}
                  >
                    <option value="FIXED">FIXED (Exact Amount in INR)</option>
                    <option value="PERCENT_OFF_MRP">PERCENT_OFF_MRP (% Discount from MRP)</option>
                    <option value="MARKUP_ON_LANDING">MARKUP_ON_LANDING (% Markup over Landing)</option>
                  </select>
                </div>

                <div className="form-field">
                  <label>
                    Rule Value * ({newRuleData.method === 'FIXED' ? 'INR' : '%'})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder={newRuleData.method === 'FIXED' ? 'e.g. 1550' : 'e.g. 15'}
                    value={newRuleData.value}
                    onChange={(e) => setNewRuleData({ ...newRuleData, value: e.target.value })}
                  />
                </div>

                {/* Guardrail Live Warning Banner */}
                {ruleGuardrailWarning && (
                  <div
                    className="error-alert grid-span-full"
                    style={{
                      background: ruleGuardrailWarning.startsWith('BREACH:') ? '#fef2f2' : '#fffbeb',
                      borderColor: ruleGuardrailWarning.startsWith('BREACH:') ? '#fca5a5' : '#fde68a',
                      color: ruleGuardrailWarning.startsWith('BREACH:') ? '#b91c1c' : '#b45309'
                    }}
                  >
                    {ruleGuardrailWarning}
                  </div>
                )}

                <div className="form-field">
                  <label>Rule Valid From (Optional)</label>
                  <input
                    type="date"
                    value={newRuleData.validFrom}
                    onChange={(e) => setNewRuleData({ ...newRuleData, validFrom: e.target.value })}
                  />
                </div>

                <div className="form-field">
                  <label>Rule Valid To (Optional)</label>
                  <input
                    type="date"
                    value={newRuleData.validTo}
                    onChange={(e) => setNewRuleData({ ...newRuleData, validTo: e.target.value })}
                  />
                </div>
              </div>

              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowAddRuleModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={Boolean(ruleGuardrailWarning && ruleGuardrailWarning.startsWith('BREACH:'))}
                >
                  Save Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Bulk CSV Import for Rules */}
      {showCsvModal && selectedList && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg">
            <div className="modal-header">
              <div>
                <h3>Bulk Import Pricing Rules via CSV</h3>
                <small>Importing into {selectedList.name}</small>
              </div>
              <button className="close-btn" onClick={() => setShowCsvModal(false)}>✕</button>
            </div>

            <div className="modal-body">
              <div className="sample-actions-bar">
                <span className="sample-label">Download template format:</span>
                <button
                  type="button"
                  className="btn btn-outline btn-xs"
                  onClick={downloadSampleCsv}
                >
                  📥 Download Sample CSV
                </button>
              </div>

              <div className="mode-selector">
                <span className="mode-label">Import Mode:</span>
                <div className="radio-options">
                  <label
                    className={`radio-card ${csvMode === 'skip_bad_rows' ? 'active' : ''}`}
                    onClick={() => setCsvMode('skip_bad_rows')}
                  >
                    <input
                      type="radio"
                      name="csvMode"
                      checked={csvMode === 'skip_bad_rows'}
                      onChange={() => setCsvMode('skip_bad_rows')}
                    />
                    <div>
                      <strong>Skip Bad Rows (Recommended)</strong>
                      <p>Creates valid rules and returns rejected rows with detailed reasons.</p>
                    </div>
                  </label>

                  <label
                    className={`radio-card ${csvMode === 'all_or_nothing' ? 'active' : ''}`}
                    onClick={() => setCsvMode('all_or_nothing')}
                  >
                    <input
                      type="radio"
                      name="csvMode"
                      checked={csvMode === 'all_or_nothing'}
                      onChange={() => setCsvMode('all_or_nothing')}
                    />
                    <div>
                      <strong>All-or-Nothing</strong>
                      <p>Rolls back the entire import if any row fails validation or guardrails.</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="form-field" style={{ marginBottom: '16px' }}>
                <label>Paste CSV Data or Drag &amp; Drop:</label>
                <textarea
                  rows="7"
                  style={{
                    width: '100%',
                    padding: '10px',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1',
                    fontFamily: 'monospace',
                    fontSize: '12px'
                  }}
                  placeholder="skuCode,targetType,targetId,method,value,validFrom,validTo&#10;BRK-PAD-001,NATIONAL,,FIXED,1550,2026-01-01,2026-12-31"
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                />
              </div>

              {/* CSV Report Summary */}
              {csvReport && (
                <div style={{ marginTop: '16px' }}>
                  <div
                    className={`report-summary-banner ${
                      csvReport.rejectedCount === 0 ? 'success' : 'has-errors'
                    }`}
                  >
                    <div>
                      <h3>{csvReport.message}</h3>
                      <p>
                        Created: <b>{csvReport.createdCount}</b> | Rejected:{' '}
                        <b>{csvReport.rejectedCount}</b>
                      </p>
                    </div>
                  </div>

                  {csvReport.rejectedRows && csvReport.rejectedRows.length > 0 && (
                    <div style={{ marginTop: '12px' }}>
                      <h4 style={{ color: '#991b1b', margin: '0 0 6px' }}>Rejected Rows</h4>
                      <div className="table-responsive" style={{ maxHeight: '180px' }}>
                        <table className="rejected-table">
                          <thead>
                            <tr>
                              <th>Row #</th>
                              <th>SKU</th>
                              <th>Reason</th>
                            </tr>
                          </thead>
                          <tbody>
                            {csvReport.rejectedRows.map((r, i) => (
                              <tr key={i}>
                                <td>{r.row}</td>
                                <td>{r.data?.skuCode || 'N/A'}</td>
                                <td style={{ color: '#dc2626' }}>{r.reason}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setShowCsvModal(false)}
              >
                Close
              </button>
              <button
                type="button"
                className="btn btn-primary"
                disabled={csvImporting || !csvText.trim()}
                onClick={handleCsvImport}
              >
                {csvImporting ? 'Processing...' : 'Run Import'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 4: Rejection Reason Modal */}
      {showRejectModal && selectedList && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <h3>Reject Price List</h3>
              <button className="close-btn" onClick={() => setShowRejectModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: '13px', color: '#475569' }}>
                Please provide a rejection reason. The price list will return to <b>DRAFT</b> status for correction.
              </p>
              <textarea
                rows="4"
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  fontSize: '13px'
                }}
                placeholder="e.g. Tier A prices are too low compared to competitors."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
              />
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowRejectModal(false)}>
                Cancel
              </button>
              <button className="btn btn-danger-outline" onClick={handleReject}>
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 5: Global Settings (minMarginPct) */}
      {showSettingsModal && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <h3>Configure Pricing Guardrails</h3>
              <button className="close-btn" onClick={() => setShowSettingsModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-field">
                <label>Global Minimum Margin Percentage (%)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="100"
                  value={newMarginInput}
                  onChange={(e) => setNewMarginInput(e.target.value)}
                />
                <span className="field-hint">
                  All price rules will be rejected if the calculated selling price is below Landing Price + this minimum margin percentage.
                </span>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowSettingsModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSaveMargin}>
                Save Setting
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

