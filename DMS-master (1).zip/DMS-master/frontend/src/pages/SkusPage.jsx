import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchSkus,
  createSku,
  updateSku,
  deleteSku,
  importSkusCsv,
  fetchSampleSkusCsv
} from '../services/api/masters.js';
import { isBrandRole } from '@dms/shared';
import { CsvImportModal } from '../components/CsvImportModal.jsx';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

export function SkusPage({ user }) {
  const [skus, setSkus] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [totalPages, setTotalPages] = useState(1);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('');
  const [billableFilter, setBillableFilter] = useState('');
  const [activeFilter, setActiveFilter] = useState('');

  // Modals
  const [showImportModal, setShowImportModal] = useState(false);
  const [modalMode, setModalMode] = useState(null); // 'create' | 'edit' | null
  const [activeSku, setActiveSku] = useState(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    brand: 'AutoPro Genuine',
    category: 'General',
    article: '',
    size: 'Standard',
    colour: '',
    uom: 'PCS',
    mrp: '',
    hsnCode: '',
    barcode: '',
    isActive: true
  });
  const [submitting, setSubmitting] = useState(false);
  const [actionError, setActionError] = useState(null);

  const canEdit = isBrandRole(user.role);

  const loadSkus = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        page,
        limit,
        search,
        category: selectedCategory,
        brand: selectedBrand,
        isBillable: billableFilter,
        isActive: activeFilter
      };
      const data = await fetchSkus(user, params);
      setSkus(data.items || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
      if (data.categories) setCategories(data.categories);
      if (data.brands) setBrands(data.brands);
    } catch (err) {
      setError(err.message || 'Failed to load SKUs.');
    } finally {
      setLoading(false);
    }
  }, [user, page, limit, search, selectedCategory, selectedBrand, billableFilter, activeFilter]);

  useEffect(() => {
    loadSkus();
  }, [loadSkus]);

  const handleOpenCreate = () => {
    setActiveSku(null);
    setFormData({
      code: '',
      name: '',
      brand: brands[0] || 'AutoPro Genuine',
      category: categories[0] || 'General',
      article: '',
      size: 'Standard',
      colour: '',
      uom: 'PCS',
      mrp: '',
      hsnCode: '',
      barcode: `890${Date.now().toString().slice(-9)}`,
      isActive: true
    });
    setActionError(null);
    setModalMode('create');
  };

  const handleOpenEdit = (sku) => {
    setActiveSku(sku);
    setFormData({
      code: sku.code,
      name: sku.name,
      brand: sku.brand || '',
      category: sku.category || '',
      article: sku.article || '',
      size: sku.size || '',
      colour: sku.colour || '',
      uom: sku.uom || 'PCS',
      mrp: sku.mrp != null ? sku.mrp : '',
      hsnCode: sku.hsnCode || '',
      barcode: sku.barcode || '',
      isActive: sku.isActive
    });
    setActionError(null);
    setModalMode('edit');
  };

  const handleDelete = async (sku) => {
    if (!confirm(`Are you sure you want to delete SKU '${sku.code}'?`)) return;
    try {
      await deleteSku(user, sku.id);
      loadSkus();
    } catch (err) {
      alert(err.message || 'Failed to delete SKU.');
    }
  };

  const handleSubmitModal = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setActionError(null);

    try {
      if (modalMode === 'create') {
        await createSku(user, formData);
      } else {
        await updateSku(user, activeSku.id, formData);
      }
      setModalMode(null);
      loadSkus();
    } catch (err) {
      setActionError(err.message || 'Failed to save SKU.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="master-page skus-page">
      <div className="page-header-row">
        <div>
          <h2>SKU Master Catalog</h2>
          <p className="page-desc">
            Product master with barcode tracking, HSN tax tagging, and billability status.
          </p>
        </div>

        <div className="header-actions">
          {canEdit && (
            <>
              <button
                className="btn btn-outline"
                onClick={() => setShowImportModal(true)}
              >
                📥 Import CSV
              </button>
              <button className="btn btn-primary" onClick={handleOpenCreate}>
                + Add SKU
              </button>
            </>
          )}
          <button className="btn btn-secondary" onClick={loadSkus}>
            ↻ Refresh
          </button>
        </div>
      </div>

      {!canEdit && (
        <div className="dealer-readonly-notice">
          ℹ️ Dealership View: You have read-only access to browse and search the brand SKU catalog.
        </div>
      )}

      {/* Filters Bar */}
      <div className="filters-container-card">
        <div className="filter-item search-field">
          <input
            type="text"
            className="search-input"
            placeholder="Search code, name, barcode, article…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>

        <div className="filter-item">
          <select
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div className="filter-item">
          <select
            value={selectedBrand}
            onChange={(e) => {
              setSelectedBrand(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Brands</option>
            {brands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
        </div>

        <div className="filter-item">
          <select
            value={billableFilter}
            onChange={(e) => {
              setBillableFilter(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Billability</option>
            <option value="true">Billable Only (Ready)</option>
            <option value="false">Non-Billable (Missing MRP/HSN)</option>
          </select>
        </div>

        <div className="filter-item">
          <select
            value={activeFilter}
            onChange={(e) => {
              setActiveFilter(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Status</option>
            <option value="true">Active Only</option>
            <option value="false">Inactive Only</option>
          </select>
        </div>

        {(search || selectedCategory || selectedBrand || billableFilter || activeFilter) && (
          <button
            className="btn btn-outline btn-sm"
            onClick={() => {
              setSearch('');
              setSelectedCategory('');
              setSelectedBrand('');
              setBillableFilter('');
              setActiveFilter('');
              setPage(1);
            }}
          >
            Clear Filters
          </button>
        )}
      </div>

      {loading ? (
        <div className="loading-card">
          <div className="spinner" />
          <p>Loading SKU catalog…</p>
        </div>
      ) : error ? (
        <div className="error-alert">
          <p>{error}</p>
          <button className="btn btn-secondary btn-sm" onClick={loadSkus}>
            Try Again
          </button>
        </div>
      ) : skus.length === 0 ? (
        <div className="empty-card">
          <div className="empty-icon">📦</div>
          <h3>No SKUs Found</h3>
          <p>Try clearing filters or importing SKUs via CSV.</p>
          {canEdit && (
            <button
              className="btn btn-primary"
              onClick={() => setShowImportModal(true)}
            >
              📥 Import 100+ Sample SKUs
            </button>
          )}
        </div>
      ) : (
        <div className="table-card">
          <div className="table-meta-bar">
            <span>
              Showing {skus.length} of <strong>{total}</strong> SKU{total === 1 ? '' : 's'}
            </span>
            <span className="pagination-quick">
              Page {page} of {totalPages}
            </span>
          </div>

          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>SKU Code</th>
                  <th>Product Name</th>
                  <th>Category / Brand</th>
                  <th>Barcode</th>
                  <th className="num-col">MRP</th>
                  <th>HSN Code</th>
                  <th>Billable Status</th>
                  <th>Active</th>
                  {canEdit && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {skus.map((sku) => {
                  const billable = sku.isBillable;
                  const nonBillableReason = !sku.isActive
                    ? 'SKU is marked inactive'
                    : !sku.hsnCode
                    ? 'Missing HSN tax code'
                    : sku.mrp == null || sku.mrp <= 0
                    ? 'Missing or zero MRP'
                    : '';

                  return (
                    <tr key={sku.id}>
                      <td>
                        <span className="sku-badge">{sku.code}</span>
                      </td>
                      <td>
                        <strong>{sku.name}</strong>
                        {sku.article && <small className="article-tag">{sku.article}</small>}
                      </td>
                      <td>
                        <span className="cat-brand-text">
                          {sku.category} <span className="dim">•</span> {sku.brand}
                        </span>
                      </td>
                      <td>
                        <span className="barcode-badge">{sku.barcode}</span>
                      </td>
                      <td className="num-col">
                        {sku.mrp != null ? (
                          <strong>{inrFormat.format(sku.mrp)}</strong>
                        ) : (
                          <span className="text-muted">Unset</span>
                        )}
                      </td>
                      <td>
                        {sku.hsnCode ? (
                          <span className="hsn-pill">{sku.hsnCode}</span>
                        ) : (
                          <span className="missing-pill">Missing</span>
                        )}
                      </td>
                      <td>
                        <span
                          className={`status-pill ${
                            billable ? 'status-billable' : 'status-blocked'
                          }`}
                          title={nonBillableReason}
                        >
                          {billable ? '✓ Billable' : '⛔ Blocked'}
                        </span>
                      </td>
                      <td>
                        <span
                          className={`status-dot ${
                            sku.isActive ? 'dot-active' : 'dot-inactive'
                          }`}
                          title={sku.isActive ? 'Active' : 'Inactive'}
                        />
                      </td>
                      {canEdit && (
                        <td>
                          <div className="table-action-group">
                            <button
                              className="btn btn-secondary btn-xs"
                              onClick={() => handleOpenEdit(sku)}
                            >
                              Edit
                            </button>
                            <button
                              className="btn btn-danger-outline btn-xs"
                              onClick={() => handleDelete(sku)}
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {totalPages > 1 && (
            <div className="pagination-bar">
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
              >
                Previous
              </button>
              <span className="pagination-indicator">
                Page {page} of {totalPages}
              </span>
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {/* CSV Import Modal */}
      {showImportModal && (
        <CsvImportModal
          title="Import SKUs from CSV"
          sampleDownloadUrl="http://localhost:4000/api/skus/sample-csv"
          onFetchSample={() => fetchSampleSkusCsv(user)}
          onImport={(payload) => importSkusCsv(user, payload)}
          onClose={() => setShowImportModal(false)}
          onSuccess={() => {
            loadSkus();
          }}
        />
      )}

      {/* Create / Edit SKU Modal */}
      {modalMode && (
        <div className="modal-backdrop" onClick={() => setModalMode(null)}>
          <div className="modal-card modal-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>{modalMode === 'create' ? 'Create New SKU' : `Edit SKU ${activeSku?.code}`}</h3>
              <button className="close-btn" onClick={() => setModalMode(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitModal} className="modal-body form-grid">
              <label className="form-field">
                <span>SKU Code *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. BRK-PAD-001"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  disabled={modalMode === 'edit'}
                />
              </label>

              <label className="form-field">
                <span>Product Name *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Front Brake Pads Ceramic"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Brand:</span>
                <input
                  type="text"
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Category:</span>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Article / Part No:</span>
                <input
                  type="text"
                  value={formData.article}
                  onChange={(e) => setFormData({ ...formData, article: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Barcode (Unique) *:</span>
                <input
                  type="text"
                  required
                  placeholder="e.g. 8901234500018"
                  value={formData.barcode}
                  onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>MRP (₹):</span>
                <input
                  type="number"
                  step="0.01"
                  placeholder="e.g. 1850.00"
                  value={formData.mrp}
                  onChange={(e) => setFormData({ ...formData, mrp: e.target.value })}
                />
                <small className="field-hint">Required for SKU to be billable</small>
              </label>

              <label className="form-field">
                <span>HSN Tax Code:</span>
                <input
                  type="text"
                  placeholder="e.g. 87083000"
                  value={formData.hsnCode}
                  onChange={(e) => setFormData({ ...formData, hsnCode: e.target.value })}
                />
                <small className="field-hint">Required for SKU to be billable</small>
              </label>

              <label className="form-field">
                <span>Unit of Measure (UOM):</span>
                <input
                  type="text"
                  value={formData.uom}
                  onChange={(e) => setFormData({ ...formData, uom: e.target.value })}
                />
              </label>

              <label className="form-field">
                <span>Active Status:</span>
                <select
                  value={formData.isActive ? 'true' : 'false'}
                  onChange={(e) =>
                    setFormData({ ...formData, isActive: e.target.value === 'true' })
                  }
                >
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </label>

              {actionError && <div className="error-alert grid-span-full">{actionError}</div>}

              <div className="modal-footer grid-span-full">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setModalMode(null)}
                  disabled={submitting}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'Saving…' : modalMode === 'create' ? 'Create SKU' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

