import React, { useState, useEffect, useCallback } from 'react';
import {
  fetchPendingOrders,
  previewInvoice,
  createInvoice,
  fetchInvoices,
  fetchInvoiceById,
  cancelInvoice
} from '../services/api/billing.js';
import { fetchRetailers } from '../services/api/retailers.js';
import { fetchDealers } from '../services/api/masters.js';
import { isBrandRole } from '@dms/shared';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

const inrDecFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

// Simple number to words helper for invoice total
function numberToWordsINR(amount) {
  const num = Math.round(Number(amount) || 0);
  if (num === 0) return 'Zero Rupees Only';
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function inWords(n) {
    if (n < 20) return a[n];
    if (n < 100) return b[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + a[n % 10] : '');
    if (n < 1000) return a[Math.floor(n / 100)] + ' Hundred' + (n % 100 !== 0 ? ' and ' + inWords(n % 100) : '');
    if (n < 100000) return inWords(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 !== 0 ? ' ' + inWords(n % 1000) : '');
    if (n < 10000000) return inWords(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 !== 0 ? ' ' + inWords(n % 100000) : '');
    return inWords(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 !== 0 ? ' ' + inWords(n % 10000000) : '');
  }

  return `${inWords(num)} Rupees Only`;
}

export function BillingPage({ user }) {
  const isBrand = isBrandRole(user.role);

  // Active top tab: 'directory' | 'bill-order'
  const [activeTab, setActiveTab] = useState('directory');

  // Dealers Master (for Brand Admin scope)
  const [dealers, setDealers] = useState([]);
  const [selectedDealerId, setSelectedDealerId] = useState('');

  // Load Dealers if Brand Admin
  useEffect(() => {
    if (isBrand) {
      fetchDealers(user)
        .then((res) => {
          const list = res.dealers || res || [];
          setDealers(list);
          if (list.length > 0 && !selectedDealerId) {
            const demo = list.find((d) => d.code === 'DEMO-001') || list[0];
            setSelectedDealerId(demo.id);
          }
        })
        .catch((err) => console.error('Failed to load dealers for billing:', err));
    }
  }, [isBrand, user]);

  // Invoices Directory states
  const [invoices, setInvoices] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loadingInvoices, setLoadingInvoices] = useState(true);
  const [invoicesError, setInvoicesError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  // Bill An Order Wizard states
  const [retailersWithOrders, setRetailersWithOrders] = useState([]);
  const [selectedRetailerId, setSelectedRetailerId] = useState('');
  const [pendingOrders, setPendingOrders] = useState([]);
  const [selectedOrderIds, setSelectedOrderIds] = useState([]);
  const [billedQuantities, setBilledQuantities] = useState({}); // { [orderLineId]: qty }
  const [headerDiscountMode, setHeaderDiscountMode] = useState('PERCENT'); // 'PERCENT' | 'AMOUNT'
  const [headerDiscountVal, setHeaderDiscountVal] = useState(0);
  const [headerDiscountReason, setHeaderDiscountReason] = useState('');
  const [calculationResult, setCalculationResult] = useState(null);
  const [calcLoading, setCalcLoading] = useState(false);
  const [calcError, setCalcError] = useState(null);
  const [creatingInvoice, setCreatingInvoice] = useState(false);

  // Invoice Detail / Print Modal state
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Same-Day Cancel Modal state
  const [cancellingInvoice, setCancellingInvoice] = useState(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelSubmitting, setCancelSubmitting] = useState(false);

  // 1. Load Invoices Directory
  const loadInvoices = useCallback(async () => {
    setLoadingInvoices(true);
    setInvoicesError(null);
    try {
      const params = {
        status: statusFilter,
        search,
        page,
        limit: 25
      };
      if (isBrand && selectedDealerId) {
        params.dealerId = selectedDealerId;
      }
      const res = await fetchInvoices(user, params);
      setInvoices(res.invoices || []);
      setTotalCount(res.totalCount || 0);
    } catch (err) {
      setInvoicesError(err.message || 'Failed to load invoices.');
    } finally {
      setLoadingInvoices(false);
    }
  }, [user, isBrand, selectedDealerId, statusFilter, search, page]);

  useEffect(() => {
    if (activeTab === 'directory') {
      loadInvoices();
    }
  }, [activeTab, loadInvoices]);

  // 2. Load Retailers with Pending Orders
  const loadPendingRetailers = useCallback(async () => {
    try {
      const params = {};
      if (isBrand && selectedDealerId) {
        params.dealerId = selectedDealerId;
      }
      const res = await fetchPendingOrders(user, params);
      const orders = res.orders || [];
      const retMap = new Map();
      orders.forEach((o) => {
        if (o.retailer) {
          retMap.set(o.retailer.id, o.retailer);
        }
      });
      const uniqueRetailers = Array.from(retMap.values());
      setRetailersWithOrders(uniqueRetailers);

      if (uniqueRetailers.length > 0 && !selectedRetailerId) {
        setSelectedRetailerId(uniqueRetailers[0].id);
      }
    } catch (err) {
      console.error('Failed to load pending billable retailers:', err);
    }
  }, [user, isBrand, selectedDealerId, selectedRetailerId]);

  useEffect(() => {
    if (activeTab === 'bill-order') {
      loadPendingRetailers();
    }
  }, [activeTab, loadPendingRetailers]);

  // 3. Load Pending Orders when retailer changes
  useEffect(() => {
    if (!selectedRetailerId) {
      setPendingOrders([]);
      setSelectedOrderIds([]);
      setBilledQuantities({});
      setCalculationResult(null);
      return;
    }

    const params = { retailerId: selectedRetailerId };
    if (isBrand && selectedDealerId) {
      params.dealerId = selectedDealerId;
    }

    fetchPendingOrders(user, params)
      .then((res) => {
        const ords = res.orders || [];
        setPendingOrders(ords);
        // Pre-select all orders by default
        const allIds = ords.map((o) => o.id);
        setSelectedOrderIds(allIds);

        // Pre-fill quantities from reservedQty
        const initialQty = {};
        ords.forEach((o) => {
          o.lines.forEach((l) => {
            if (l.reservedQty > 0) {
              initialQty[l.id] = l.reservedQty;
            }
          });
        });
        setBilledQuantities(initialQty);
      })
      .catch((err) => {
        console.error('Failed to fetch pending orders for retailer:', err);
      });
  }, [selectedRetailerId, user, isBrand, selectedDealerId]);

  // 4. Run Live Tax & Discount Calculation Preview
  const runLiveCalculation = useCallback(async () => {
    if (!selectedRetailerId || selectedOrderIds.length === 0) {
      setCalculationResult(null);
      return;
    }

    // Build billedItems list
    const items = Object.entries(billedQuantities)
      .map(([orderLineId, qty]) => ({ orderLineId, qty: parseInt(qty, 10) }))
      .filter((i) => i.qty > 0);

    if (items.length === 0) {
      setCalculationResult(null);
      return;
    }

    setCalcLoading(true);
    setCalcError(null);

    try {
      const payload = {
        retailerId: selectedRetailerId,
        orderIds: selectedOrderIds,
        billedItems: items,
        headerDiscountPct: headerDiscountMode === 'PERCENT' ? Number(headerDiscountVal) : 0,
        headerDiscountAmount: headerDiscountMode === 'AMOUNT' ? Number(headerDiscountVal) : 0,
        headerDiscountReason: headerDiscountReason,
        ...(isBrand && selectedDealerId ? { dealerId: selectedDealerId } : {})
      };

      const res = await previewInvoice(user, payload);
      setCalculationResult(res);
    } catch (err) {
      setCalcError(err.message || 'Tax calculation failed.');
      setCalculationResult(null);
    } finally {
      setCalcLoading(false);
    }
  }, [selectedRetailerId, selectedOrderIds, billedQuantities, headerDiscountMode, headerDiscountVal, headerDiscountReason, user, isBrand, selectedDealerId]);

  useEffect(() => {
    if (activeTab === 'bill-order' && selectedRetailerId && selectedOrderIds.length > 0) {
      const timer = setTimeout(() => {
        runLiveCalculation();
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [runLiveCalculation, activeTab, selectedRetailerId, selectedOrderIds, billedQuantities, headerDiscountMode, headerDiscountVal, headerDiscountReason]);

  // Toggle order checkbox
  const handleToggleOrder = (orderId) => {
    setSelectedOrderIds((prev) => {
      const isSelected = prev.includes(orderId);
      const next = isSelected ? prev.filter((id) => id !== orderId) : [...prev, orderId];

      // Update billed quantities for lines of unselected order
      const targetOrder = pendingOrders.find((o) => o.id === orderId);
      if (targetOrder) {
        setBilledQuantities((prevQty) => {
          const copy = { ...prevQty };
          targetOrder.lines.forEach((l) => {
            if (isSelected) {
              delete copy[l.id];
            } else {
              copy[l.id] = l.reservedQty;
            }
          });
          return copy;
        });
      }
      return next;
    });
  };

  // Adjust line billed quantity
  const handleQtyChange = (orderLineId, maxReserved, val) => {
    const parsed = parseInt(val, 10);
    if (isNaN(parsed) || parsed < 0) return;
    const clamped = Math.min(parsed, maxReserved);
    setBilledQuantities((prev) => ({
      ...prev,
      [orderLineId]: clamped
    }));
  };

  // Confirm and Generate Invoice
  const handleCreateInvoice = async () => {
    if (!selectedRetailerId) return alert('Please select a retailer.');
    if (selectedOrderIds.length === 0) return alert('Please select at least one pending order.');
    if (!calculationResult || calculationResult.lines.length === 0) {
      return alert('No billable quantities specified.');
    }

    if (!confirm(`Generate and issue secondary tax invoice for net total ₹${calculationResult.netTotal.toLocaleString()}? Prices will be locked and inventory consumed.`)) {
      return;
    }

    setCreatingInvoice(true);
    setCalcError(null);

    try {
      const items = Object.entries(billedQuantities)
        .map(([orderLineId, qty]) => ({ orderLineId, qty: parseInt(qty, 10) }))
        .filter((i) => i.qty > 0);

      const payload = {
        retailerId: selectedRetailerId,
        orderIds: selectedOrderIds,
        billedItems: items,
        headerDiscountPct: headerDiscountMode === 'PERCENT' ? Number(headerDiscountVal) : 0,
        headerDiscountAmount: headerDiscountMode === 'AMOUNT' ? Number(headerDiscountVal) : 0,
        headerDiscountReason: headerDiscountReason,
        invoiceDate: new Date().toISOString(),
        ...(isBrand && selectedDealerId ? { dealerId: selectedDealerId } : {})
      };

      const invoice = await createInvoice(user, payload);
      alert(`Invoice ${invoice.invoiceNo} successfully generated and posted!`);

      // Open print view of the new invoice
      setSelectedInvoice(invoice);
      setActiveTab('directory');
      loadInvoices();
    } catch (err) {
      setCalcError(err.message || 'Failed to issue tax invoice.');
    } finally {
      setCreatingInvoice(false);
    }
  };

  // View Invoice Detail Modal
  const handleViewInvoice = async (invoiceId) => {
    setDetailLoading(true);
    try {
      const inv = await fetchInvoiceById(user, invoiceId);
      setSelectedInvoice(inv);
    } catch (err) {
      alert(err.message || 'Failed to load invoice details.');
    } finally {
      setDetailLoading(false);
    }
  };

  // Open Cancel Modal
  const handleOpenCancelModal = (inv) => {
    setCancellingInvoice(inv);
    setCancelReason('');
  };

  // Confirm Same-Day Cancellation
  const handleConfirmCancel = async (e) => {
    e.preventDefault();
    if (!cancelReason.trim()) return alert('Please enter cancellation reason.');

    setCancelSubmitting(true);
    try {
      const res = await cancelInvoice(user, cancellingInvoice.id, cancelReason);
      alert(res.message || 'Invoice cancelled.');
      setCancellingInvoice(null);
      if (selectedInvoice && selectedInvoice.id === cancellingInvoice.id) {
        setSelectedInvoice(res.invoice);
      }
      loadInvoices();
    } catch (err) {
      alert(err.message || 'Cancellation failed.');
    } finally {
      setCancelSubmitting(false);
    }
  };

  // Print Invoice
  const handlePrint = () => {
    window.print();
  };

  // Helper to check if invoice can be cancelled (same day and ISSUED)
  const canCancelInvoice = (inv) => {
    if (!inv || inv.status !== 'ISSUED') return false;
    const invDateStr = new Date(inv.invoiceDate).toISOString().slice(0, 10);
    const todayStr = new Date().toISOString().slice(0, 10);
    return invDateStr === todayStr;
  };

  return (
    <div className="billing-page-container">
      {/* HEADER & TOP TABS */}
      <div className="table-meta-bar" style={{ marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2>Secondary Invoicing & GST Billing</h2>
          <small style={{ color: '#64748b' }}>
            Generate tax invoices from approved orders with locked prices, dealer-capped header discounts, and atomic stock consumption.
          </small>
        </div>

        <div className="brand-tabs-bar" style={{ margin: 0 }}>
          <button
            className={`tab-btn ${activeTab === 'directory' ? 'active' : ''}`}
            onClick={() => setActiveTab('directory')}
          >
            📋 Invoices Directory
          </button>
          <button
            className={`tab-btn ${activeTab === 'bill-order' ? 'active' : ''}`}
            onClick={() => setActiveTab('bill-order')}
          >
            ⚡ Bill an Order
          </button>
        </div>
      </div>

      {/* Brand Dealership Selector */}
      {isBrand && (
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', background: '#FDFBF7', padding: '10px 16px', borderRadius: '8px', border: '1px solid #E7D7B5', marginBottom: '16px' }}>
          <span style={{ fontSize: '13px', fontWeight: 600, color: '#785A18' }}>🏢 Active Dealership Scope:</span>
          <select
            value={selectedDealerId}
            onChange={(e) => setSelectedDealerId(e.target.value)}
            style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #E7D7B5', background: '#fff', fontSize: '13px', fontWeight: 500 }}
          >
            <option value="">All Dealerships</option>
            {dealers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
          <span style={{ fontSize: '12px', color: '#64748b', marginLeft: 'auto' }}>
            Brand HQ inspecting dealership invoices, billable orders &amp; tax calculations.
          </span>
        </div>
      )}

      {/* TAB 1: INVOICES DIRECTORY */}
      {activeTab === 'directory' && (
        <div>
          {/* Filters & Search */}
          <div style={{ display: 'flex', gap: '12px', marginBottom: '18px', flexWrap: 'wrap' }}>
            <div className="brand-tabs-bar" style={{ margin: 0 }}>
              {[
                { key: '', label: 'All Invoices' },
                { key: 'ISSUED', label: 'Issued' },
                { key: 'CANCELLED', label: 'Cancelled' }
              ].map((tab) => (
                <button
                  key={tab.key}
                  className={`tab-btn ${statusFilter === tab.key ? 'active' : ''}`}
                  onClick={() => {
                    setStatusFilter(tab.key);
                    setPage(1);
                  }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <input
              type="text"
              placeholder="Search by invoice number or retailer..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              style={{ flex: 1, minWidth: '220px', padding: '8px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            />

            {search && (
              <button
                className="btn btn-outline btn-sm"
                onClick={() => {
                  setSearch('');
                  setPage(1);
                }}
              >
                Clear Search
              </button>
            )}
          </div>

          {invoicesError && (
            <div className="error" style={{ marginBottom: '16px' }}>
              {invoicesError}
            </div>
          )}

          {loadingInvoices ? (
            <div className="loading-card" style={{ padding: '40px', textAlign: 'center', background: '#fff', borderRadius: '12px' }}>
              <p>Loading invoices…</p>
            </div>
          ) : invoices.length === 0 ? (
            <div className="empty-card" style={{ padding: '50px 20px', textAlign: 'center', background: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '36px', marginBottom: '10px' }}>🧾</div>
              <h3>No Invoices Found</h3>
              <p style={{ color: '#64748b' }}>
                {statusFilter
                  ? `There are no invoices currently in "${statusFilter}" status.`
                  : 'No tax invoices have been generated yet. Use the "Bill an Order" tab to create your first invoice.'}
              </p>
              <button
                className="btn btn-primary btn-sm"
                onClick={() => setActiveTab('bill-order')}
                style={{ marginTop: '12px' }}
              >
                Bill Pending Orders
              </button>
            </div>
          ) : (
            <div className="table-card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Invoice #</th>
                      <th>Date</th>
                      <th>Retailer</th>
                      <th>Taxable Total</th>
                      <th>CGST + SGST / IGST</th>
                      <th>Rounding</th>
                      <th>Net Total</th>
                      <th>Status</th>
                      <th style={{ textAlign: 'right' }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoices.map((inv) => (
                      <tr key={inv.id}>
                        <td>
                          <strong style={{ color: '#0f172a' }}>{inv.invoiceNo}</strong>
                          <span className="badge-pill" style={{ marginLeft: '6px', fontSize: '10px' }}>
                            {inv.financialYear}
                          </span>
                        </td>
                        <td>{new Date(inv.invoiceDate).toLocaleDateString('en-IN')}</td>
                        <td>
                          <strong>{inv.retailer?.legalName}</strong>
                          <small style={{ display: 'block', color: '#64748b' }}>
                            GSTIN: {inv.retailer?.gstin || 'Unregistered'}
                          </small>
                        </td>
                        <td>{inrFormat.format(inv.taxableTotal)}</td>
                        <td>
                          <span style={{ fontSize: '12px', color: '#475569' }}>
                            {inv.igstTotal > 0
                              ? `IGST: ${inrFormat.format(inv.igstTotal)}`
                              : `C: ${inrFormat.format(inv.cgstTotal)} | S: ${inrFormat.format(inv.sgstTotal)}`}
                          </span>
                        </td>
                        <td>
                          <span style={{ fontSize: '11px', color: inv.rounding !== 0 ? '#b45309' : '#94a3b8' }}>
                            {inv.rounding > 0 ? `+₹${inv.rounding}` : inv.rounding < 0 ? `-₹${Math.abs(inv.rounding)}` : '₹0.00'}
                          </span>
                        </td>
                        <td>
                          <strong style={{ color: '#16a34a', fontSize: '14px' }}>
                            {inrFormat.format(inv.netTotal)}
                          </strong>
                        </td>
                        <td>
                          <span className={`status-pill status-${inv.status.toLowerCase()}`}>
                            {inv.status}
                          </span>
                        </td>
                        <td style={{ textAlign: 'right' }}>
                          <div className="table-action-group" style={{ justifyContent: 'flex-end', gap: '6px' }}>
                            <button
                              className="table-action-btn primary"
                              onClick={() => handleViewInvoice(inv.id)}
                              title="View and print A4 invoice"
                            >
                              View / Print
                            </button>

                            {canCancelInvoice(inv) && (
                              <button
                                className="table-action-btn"
                                onClick={() => handleOpenCancelModal(inv)}
                                title="Same-day cancellation"
                                style={{ color: '#dc2626' }}
                              >
                                Cancel
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BILL AN ORDER WIZARD */}
      {activeTab === 'bill-order' && (
        <div style={{ background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '24px' }}>
          {calcError && (
            <div className="error" style={{ marginBottom: '18px' }}>
              {calcError}
            </div>
          )}

          {/* STEP 1: CHOOSE RETAILER */}
          <div style={{ marginBottom: '22px' }}>
            <label style={{ fontSize: '13px', fontWeight: 700, textTransform: 'uppercase', color: '#475569', display: 'block', marginBottom: '6px' }}>
              Step 1: Select Approved Retailer
            </label>

            {retailersWithOrders.length === 0 ? (
              <div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0', color: '#64748b' }}>
                No retailers currently have approved orders with reserved inventory waiting to be billed.
              </div>
            ) : (
              <select
                value={selectedRetailerId}
                onChange={(e) => setSelectedRetailerId(e.target.value)}
                style={{ width: '100%', maxWidth: '520px', padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px' }}
              >
                {retailersWithOrders.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.legalName} ({r.tradeName || r.gstin || 'Unregistered'}) — State: {r.stateCode}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* STEP 2: PICK PENDING ORDERS */}
          {pendingOrders.length > 0 && (
            <div style={{ marginBottom: '22px' }}>
              <label style={{ fontSize: '13px', fontWeight: 700, textTransform: 'uppercase', color: '#475569', display: 'block', marginBottom: '8px' }}>
                Step 2: Select Pending Orders ({selectedOrderIds.length} of {pendingOrders.length} selected)
              </label>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '12px' }}>
                {pendingOrders.map((ord) => {
                  const isChecked = selectedOrderIds.includes(ord.id);
                  const totalReserved = ord.lines.reduce((s, l) => s + l.reservedQty, 0);

                  return (
                    <div
                      key={ord.id}
                      onClick={() => handleToggleOrder(ord.id)}
                      style={{
                        padding: '12px 14px',
                        borderRadius: '8px',
                        border: isChecked ? '2px solid #E21E25' : '1px solid #e2e8f0',
                        background: isChecked ? '#FEF2F2' : '#f8fafc',
                        cursor: 'pointer',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <strong style={{ color: '#0f172a' }}>{ord.orderNo}</strong>
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // Handled by div onClick
                          style={{ cursor: 'pointer' }}
                        />
                      </div>
                      <div style={{ fontSize: '12px', color: '#64748b' }}>
                        Date: {new Date(ord.createdAt).toLocaleDateString('en-IN')}
                      </div>
                      <div style={{ fontSize: '12px', color: '#16a34a', fontWeight: 600, marginTop: '2px' }}>
                        Reserved: {totalReserved} units | Total: {inrFormat.format(ord.totalAmount)}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* STEP 3: EDIT BILLED QUANTITIES (PARTIAL BILLING) */}
          {selectedOrderIds.length > 0 && (
            <div style={{ marginBottom: '24px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <label style={{ fontSize: '13px', fontWeight: 700, textTransform: 'uppercase', color: '#475569', margin: 0 }}>
                  Step 3: Verify & Adjust Billed Quantities (Partial Billing)
                </label>
                <small style={{ color: '#64748b' }}>
                  Quantities default to reserved stock. Prices are strictly locked from the approved order.
                </small>
              </div>

              <div className="table-responsive">
                <table className="data-table" style={{ fontSize: '12px' }}>
                  <thead>
                    <tr>
                      <th>Order #</th>
                      <th>SKU & Description</th>
                      <th>HSN</th>
                      <th>GST %</th>
                      <th>Reserved Stock</th>
                      <th style={{ width: '130px' }}>Billed Qty</th>
                      <th>Unit Price</th>
                      <th>Line Gross</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingOrders
                      .filter((o) => selectedOrderIds.includes(o.id))
                      .flatMap((o) => o.lines)
                      .filter((l) => l.reservedQty > 0)
                      .map((line) => {
                        const billedQty = billedQuantities[line.id] !== undefined
                          ? billedQuantities[line.id]
                          : line.reservedQty;
                        const lineGross = Math.round((billedQty * line.unitPrice) * 100) / 100;

                        return (
                          <tr key={line.id}>
                            <td>
                              <strong style={{ color: '#64748b' }}>
                                {pendingOrders.find((o) => o.id === line.orderId)?.orderNo}
                              </strong>
                            </td>
                            <td>
                              <strong>{line.sku?.code}</strong>
                              <small style={{ display: 'block', color: '#64748b' }}>{line.sku?.name}</small>
                            </td>
                            <td>{line.sku?.hsnCode || '87082900'}</td>
                            <td>18%</td>
                            <td>
                              <span className="reserved-badge">
                                {line.reservedQty} units
                              </span>
                            </td>
                            <td>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <input
                                  type="number"
                                  min="0"
                                  max={line.reservedQty}
                                  value={billedQty}
                                  onChange={(e) => handleQtyChange(line.id, line.reservedQty, e.target.value)}
                                  style={{
                                    width: '75px',
                                    padding: '5px 8px',
                                    borderRadius: '6px',
                                    border: '1px solid #cbd5e1',
                                    fontWeight: 600
                                  }}
                                />
                                <small style={{ color: '#94a3b8' }}>/ {line.reservedQty}</small>
                              </div>
                            </td>
                            <td>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                                <span style={{ fontWeight: 600 }}>₹{line.unitPrice}</span>
                                <span className="padlock-tag" title="Price is locked from approved order">🔒</span>
                              </div>
                            </td>
                            <td>
                              <strong>{inrFormat.format(lineGross)}</strong>
                            </td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* STEP 4: HEADER DISCOUNT & LIVE TAX SUMMARY */}
          {selectedOrderIds.length > 0 && (
            <div style={{ background: '#f8fafc', padding: '18px 20px', borderRadius: '10px', border: '1px solid #e2e8f0', marginBottom: '24px' }}>
              <label style={{ fontSize: '13px', fontWeight: 700, textTransform: 'uppercase', color: '#475569', display: 'block', marginBottom: '12px' }}>
                Step 4: Header Discount & Tax Preview
              </label>

              {/* Discount Controls */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px', marginBottom: '16px' }}>
                <div>
                  <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px' }}>
                    Header Discount Type
                  </label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      type="button"
                      className={`btn btn-sm ${headerDiscountMode === 'PERCENT' ? 'btn-primary' : 'btn-outline'}`}
                      onClick={() => {
                        setHeaderDiscountMode('PERCENT');
                        setHeaderDiscountVal(0);
                      }}
                    >
                      Percentage (%)
                    </button>
                    <button
                      type="button"
                      className={`btn btn-sm ${headerDiscountMode === 'AMOUNT' ? 'btn-primary' : 'btn-outline'}`}
                      onClick={() => {
                        setHeaderDiscountMode('AMOUNT');
                        setHeaderDiscountVal(0);
                      }}
                    >
                      Flat Amount (₹)
                    </button>
                  </div>
                </div>

                <div>
                  <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px' }}>
                    Discount Value {headerDiscountMode === 'PERCENT' ? '(%)' : '(₹)'}
                    <small style={{ color: '#64748b', marginLeft: '6px' }}>
                      (Max Allowed: {calculationResult?.dealer?.maxHeaderDiscountPct || 10}%)
                    </small>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step={headerDiscountMode === 'PERCENT' ? '0.5' : '10'}
                    value={headerDiscountVal}
                    onChange={(e) => setHeaderDiscountVal(Math.max(0, parseFloat(e.target.value) || 0))}
                    style={{ width: '100%', padding: '7px 10px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </div>

                {((headerDiscountMode === 'PERCENT' && headerDiscountVal > 3) ||
                  (headerDiscountMode === 'AMOUNT' && calculationResult && (headerDiscountVal / calculationResult.grossAmount) * 100 > 3)) && (
                  <div>
                    <label style={{ fontSize: '12px', display: 'block', marginBottom: '4px', color: '#b45309', fontWeight: 600 }}>
                      Discount Reason * (Mandatory &gt; 3%)
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Festival volume concession..."
                      value={headerDiscountReason}
                      onChange={(e) => setHeaderDiscountReason(e.target.value)}
                      style={{ width: '100%', padding: '7px 10px', borderRadius: '6px', border: '1px solid #fde68a', background: '#fffbeb' }}
                    />
                  </div>
                )}
              </div>

              {/* Live Tax Computation Breakdown */}
              {calcLoading ? (
                <div style={{ textAlign: 'center', padding: '20px', color: '#64748b' }}>
                  Recalculating GST and pro-rated discount…
                </div>
              ) : calculationResult ? (
                <div>
                  <div className={`tax-regime-banner ${calculationResult.isIntraState ? 'intra' : 'inter'}`}>
                    <span>
                      {calculationResult.isIntraState
                        ? `📍 Intra-State GST: CGST (50%) + SGST (50%) [Dealer State: ${calculationResult.dealerStateCode} = Retailer State: ${calculationResult.retailerStateCode}]`
                        : `🌐 Inter-State GST: IGST (100%) [Dealer State: ${calculationResult.dealerStateCode} ≠ Retailer State: ${calculationResult.retailerStateCode}]`}
                    </span>
                    <span>HSN 87082900 / 27101981</span>
                  </div>

                  <div className="credit-exposure-meter" style={{ marginTop: 0 }}>
                    <div className="exposure-grid">
                      <div className="exposure-cell">
                        <small>Gross Value</small>
                        <strong>{inrDecFormat.format(calculationResult.grossAmount)}</strong>
                      </div>
                      <div className="exposure-cell">
                        <small>Header Discount</small>
                        <strong style={{ color: '#b45309' }}>
                          - {inrDecFormat.format(calculationResult.headerDiscountAmount)}
                        </strong>
                      </div>
                      <div className="exposure-cell">
                        <small>Taxable Total</small>
                        <strong>{inrDecFormat.format(calculationResult.taxableTotal)}</strong>
                      </div>
                      <div className="exposure-cell">
                        <small>Total Tax</small>
                        <strong style={{ color: '#E21E25' }}>
                          + {inrDecFormat.format(calculationResult.taxTotal)}
                        </strong>
                      </div>
                      <div className="exposure-cell">
                        <small>Rounding</small>
                        <strong style={{ color: '#64748b' }}>
                          {calculationResult.rounding > 0 ? `+₹${calculationResult.rounding}` : calculationResult.rounding < 0 ? `-₹${Math.abs(calculationResult.rounding)}` : '₹0.00'}
                        </strong>
                      </div>
                      <div className="exposure-cell" style={{ background: '#0f172a', color: '#fff' }}>
                        <small style={{ color: '#94a3b8' }}>Net Invoice Total</small>
                        <strong style={{ color: '#4ade80', fontSize: '18px' }}>
                          {inrFormat.format(calculationResult.netTotal)}
                        </strong>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          )}

          {/* STEP 5: CONFIRM & ISSUE BUTTON */}
          {selectedOrderIds.length > 0 && calculationResult && (
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => {
                  setSelectedRetailerId('');
                  setSelectedOrderIds([]);
                }}
              >
                Reset Wizard
              </button>

              <button
                type="button"
                className="btn btn-primary"
                onClick={handleCreateInvoice}
                disabled={creatingInvoice || !calculationResult}
                style={{ padding: '12px 24px', fontSize: '14px', fontWeight: 700 }}
              >
                {creatingInvoice ? 'Issuing Tax Invoice…' : `Confirm & Issue Invoice (${inrFormat.format(calculationResult.netTotal)})`}
              </button>
            </div>
          )}
        </div>
      )}

      {/* INVOICE DETAIL & A4 PRINT VIEW MODAL */}
      {selectedInvoice && (
        <div className="modal-backdrop">
          <div className="modal-card modal-lg" style={{ maxWidth: '960px' }}>
            <div className="modal-header no-print">
              <div>
                <h2>Tax Invoice: {selectedInvoice.invoiceNo}</h2>
                <small>Issued: {new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-IN')}</small>
              </div>

              <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                <button className="btn btn-primary btn-sm" onClick={handlePrint}>
                  🖨️ Print / Save as PDF
                </button>

                {canCancelInvoice(selectedInvoice) && (
                  <button
                    className="btn btn-outline btn-sm"
                    onClick={() => handleOpenCancelModal(selectedInvoice)}
                    style={{ color: '#dc2626', borderColor: '#fca5a5' }}
                  >
                    Cancel Invoice
                  </button>
                )}

                <button className="close-btn" onClick={() => setSelectedInvoice(null)}>
                  ✕
                </button>
              </div>
            </div>

            <div className="modal-body" style={{ maxHeight: '80vh', overflowY: 'auto', padding: '16px' }}>
              {/* PRINTABLE A4 INVOICE SHEET */}
              <div className="a4-invoice-sheet" id="printable-invoice">
                {/* Header Grid */}
                <div className="invoice-header-grid">
                  <div>
                    <h1 style={{ margin: '0 0 4px', fontSize: '22px', fontWeight: 800, color: '#0f172a' }}>
                      TAX INVOICE
                    </h1>
                    <small style={{ color: '#64748b' }}>
                      (Original for Recipient — Rule 46 of CGST Rules, 2017)
                    </small>
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <h3 style={{ margin: '0 0 2px', fontSize: '16px', color: '#0f172a' }}>
                      {selectedInvoice.invoiceNo}
                    </h3>
                    <p style={{ margin: 0, fontSize: '11px', color: '#64748b' }}>
                      Date: <strong>{new Date(selectedInvoice.invoiceDate).toLocaleDateString('en-IN')}</strong> | FY: {selectedInvoice.financialYear}
                    </p>
                    <div style={{ marginTop: '4px' }}>
                      <span className={`status-pill status-${selectedInvoice.status.toLowerCase()}`}>
                        {selectedInvoice.status}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Parties Grid (Dealer Supplier vs Retailer Recipient) */}
                <div className="invoice-parties-grid">
                  <div className="party-box">
                    <h4>Supplier Details (Dealer)</h4>
                    <p><strong>{selectedInvoice.dealer?.name}</strong> ({selectedInvoice.dealer?.code})</p>
                    <p style={{ color: '#64748b' }}>GSTIN: <strong>{selectedInvoice.dealer?.gstin || '27AABCU9603R1ZM'}</strong></p>
                    <p style={{ color: '#64748b' }}>State: Maharashtra (Code: {selectedInvoice.dealer?.stateCode || '27'})</p>
                    <p style={{ color: '#64748b' }}>Fulfillment Warehouse: {selectedInvoice.warehouse?.name || 'Main Dealership Hub'}</p>
                  </div>

                  <div className="party-box">
                    <h4>Billed To (Retailer)</h4>
                    <p><strong>{selectedInvoice.retailer?.legalName}</strong></p>
                    {selectedInvoice.retailer?.tradeName && (
                      <p style={{ color: '#64748b' }}>Trade: {selectedInvoice.retailer?.tradeName}</p>
                    )}
                    <p style={{ color: '#64748b' }}>GSTIN: <strong>{selectedInvoice.retailer?.gstin || 'Unregistered'}</strong></p>
                    <p style={{ color: '#64748b' }}>State Code: {selectedInvoice.retailer?.stateCode || '27'}</p>
                    <p style={{ color: '#64748b' }}>Billing Address: {selectedInvoice.retailer?.billingAddress || 'Local Address'}</p>
                  </div>
                </div>

                {/* Line Items Table with Complete Tax Breakdown */}
                <table className="a4-table">
                  <thead>
                    <tr>
                      <th style={{ width: '25px' }}>#</th>
                      <th>SKU & Description</th>
                      <th>HSN</th>
                      <th>Qty</th>
                      <th>Unit Price</th>
                      <th>Gross</th>
                      <th>Disc.</th>
                      <th>Taxable</th>
                      {selectedInvoice.igstTotal > 0 ? (
                        <>
                          <th>IGST %</th>
                          <th>IGST Amt</th>
                        </>
                      ) : (
                        <>
                          <th>CGST</th>
                          <th>SGST</th>
                        </>
                      )}
                      <th style={{ textAlign: 'right' }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedInvoice.lines.map((line, idx) => (
                      <tr key={line.id}>
                        <td>{idx + 1}</td>
                        <td>
                          <strong>{line.sku?.code}</strong>
                          <div style={{ fontSize: '10px', color: '#64748b' }}>{line.sku?.name}</div>
                        </td>
                        <td>{line.hsnCode || '87082900'}</td>
                        <td style={{ fontWeight: 700 }}>{line.qty}</td>
                        <td>₹{line.unitPrice}</td>
                        <td>{inrDecFormat.format(line.grossAmount)}</td>
                        <td>{line.discountShare > 0 ? `-₹${line.discountShare}` : '—'}</td>
                        <td style={{ fontWeight: 600 }}>{inrDecFormat.format(line.taxableValue)}</td>
                        {selectedInvoice.igstTotal > 0 ? (
                          <>
                            <td>{line.gstRate}%</td>
                            <td>{inrDecFormat.format(line.igstAmount)}</td>
                          </>
                        ) : (
                          <>
                            <td>{inrDecFormat.format(line.cgstAmount)}</td>
                            <td>{inrDecFormat.format(line.sgstAmount)}</td>
                          </>
                        )}
                        <td style={{ textAlign: 'right', fontWeight: 700 }}>
                          {inrDecFormat.format(line.lineTotal)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Totals & Summary Section */}
                <div className="invoice-totals-section">
                  <div className="invoice-words-box">
                    <p style={{ margin: '0 0 6px', fontSize: '11px', color: '#64748b', textTransform: 'uppercase', fontWeight: 700 }}>
                      Invoice Amount in Words:
                    </p>
                    <p style={{ margin: 0, fontSize: '12px', fontWeight: 700, color: '#0f172a' }}>
                      {numberToWordsINR(selectedInvoice.netTotal)}
                    </p>

                    {selectedInvoice.notes && (
                      <div style={{ marginTop: '12px', paddingTop: '8px', borderTop: '1px solid #e2e8f0', fontSize: '11px' }}>
                        <strong>Notes:</strong> {selectedInvoice.notes}
                      </div>
                    )}

                    {selectedInvoice.cancelledReason && (
                      <div style={{ marginTop: '12px', padding: '8px', background: '#ffe4e6', borderRadius: '4px', color: '#be123c', fontSize: '11px' }}>
                        <strong>Cancelled Reason:</strong> {selectedInvoice.cancelledReason} (Cancelled by: {selectedInvoice.cancelledByEmail})
                      </div>
                    )}
                  </div>

                  <div className="invoice-summary-card">
                    <div className="summary-row">
                      <span>Total Gross Value</span>
                      <strong>{inrDecFormat.format(selectedInvoice.grossAmount)}</strong>
                    </div>

                    {selectedInvoice.headerDiscountAmount > 0 && (
                      <div className="summary-row" style={{ color: '#b45309' }}>
                        <span>Header Discount ({selectedInvoice.headerDiscountPct || 0}%)</span>
                        <strong>- {inrDecFormat.format(selectedInvoice.headerDiscountAmount)}</strong>
                      </div>
                    )}

                    <div className="summary-row">
                      <span>Total Taxable Value</span>
                      <strong>{inrDecFormat.format(selectedInvoice.taxableTotal)}</strong>
                    </div>

                    {selectedInvoice.igstTotal > 0 ? (
                      <div className="summary-row">
                        <span>Integrated GST (IGST)</span>
                        <strong>{inrDecFormat.format(selectedInvoice.igstTotal)}</strong>
                      </div>
                    ) : (
                      <>
                        <div className="summary-row">
                          <span>Central GST (CGST)</span>
                          <strong>{inrDecFormat.format(selectedInvoice.cgstTotal)}</strong>
                        </div>
                        <div className="summary-row">
                          <span>State GST (SGST)</span>
                          <strong>{inrDecFormat.format(selectedInvoice.sgstTotal)}</strong>
                        </div>
                      </>
                    )}

                    <div className="summary-row">
                      <span>Total Tax Amount</span>
                      <strong>{inrDecFormat.format(selectedInvoice.taxTotal)}</strong>
                    </div>

                    {selectedInvoice.rounding !== 0 && (
                      <div className="summary-row" style={{ color: '#64748b' }}>
                        <span>Rounding Adjustment</span>
                        <strong>{selectedInvoice.rounding > 0 ? `+₹${selectedInvoice.rounding}` : `-₹${Math.abs(selectedInvoice.rounding)}`}</strong>
                      </div>
                    )}

                    <div className="summary-row total-row">
                      <span>Net Total (INR)</span>
                      <span>{inrFormat.format(selectedInvoice.netTotal)}</span>
                    </div>
                  </div>
                </div>

                {/* Signatory Box */}
                <div className="invoice-signatory-section">
                  <div style={{ fontSize: '10px', color: '#64748b' }}>
                    <p style={{ margin: 0 }}>Terms & Conditions:</p>
                    <p style={{ margin: 0 }}>1. Goods once sold will not be taken back without return claim authorization.</p>
                    <p style={{ margin: 0 }}>2. Interest @ 18% p.a. will be charged if payment is not received within agreed credit terms.</p>
                  </div>

                  <div className="signature-box">
                    <p style={{ margin: 0, fontWeight: 700, fontSize: '11px' }}>
                      For {selectedInvoice.dealer?.name || 'Dealership Motors'}
                    </p>
                    <div className="signature-line">
                      Authorized Signatory
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="modal-footer no-print" style={{ display: 'flex', justifyContent: 'space-between' }}>
              <button className="btn btn-outline" onClick={() => setSelectedInvoice(null)}>
                Close
              </button>

              <button className="btn btn-primary" onClick={handlePrint}>
                🖨️ Print / Save as PDF
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL INVOICE REASON PROMPT MODAL */}
      {cancellingInvoice && (
        <div className="modal-backdrop">
          <div className="modal-card modal-sm">
            <div className="modal-header">
              <div>
                <h2>Cancel Invoice {cancellingInvoice.invoiceNo}</h2>
                <small>Same-day cancellation will restore reserved stock and reverse retailer ledger entries.</small>
              </div>
              <button className="close-btn" onClick={() => setCancellingInvoice(null)}>
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmCancel}>
              <div className="modal-body">
                <label>
                  Reason for Cancellation *
                  <textarea
                    rows="3"
                    required
                    placeholder="Enter reason for cancelling this tax invoice..."
                    value={cancelReason}
                    onChange={(e) => setCancelReason(e.target.value)}
                    style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #cbd5e1' }}
                  />
                </label>
              </div>

              <div className="modal-footer" style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => setCancellingInvoice(null)}
                  disabled={cancelSubmitting}
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ background: '#dc2626' }}
                  disabled={cancelSubmitting}
                >
                  {cancelSubmitting ? 'Cancelling…' : 'Confirm Cancellation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

