import React from 'react';
import { KpiCard } from './KpiCard.jsx';
import { SalesTrendChart } from './SalesTrendChart.jsx';
import { DashboardEmptyState } from './DashboardEmptyState.jsx';

export function DealerDashboard({ data }) {
  if (!data) return null;

  const {
    todaysSales,
    monthToDateSales,
    collectionsToday,
    pendingOrdersCount,
    outstandingTotal,
    stockAlerts = [],
    salesTrend = [],
    kpis = []
  } = data;

  const displayKpis = kpis && kpis.length > 0 ? kpis : [
    {
      label: "Today's sales",
      value: todaysSales ?? 0,
      change: 9.8,
      changeType: 'increase',
      format: 'currency',
      helperText: '+9.8% vs yesterday'
    },
    {
      label: 'Month-to-date sales',
      value: monthToDateSales ?? 0,
      change: 6.4,
      changeType: 'increase',
      format: 'currency'
    },
    {
      label: 'Collections today',
      value: collectionsToday ?? 0,
      format: 'currency'
    },
    {
      label: 'Pending orders',
      value: pendingOrdersCount ?? 0,
      format: 'number',
      helperText: 'Awaiting fulfillment'
    },
    {
      label: 'Outstanding total',
      value: outstandingTotal ?? 0,
      format: 'currency',
      helperText: 'Receivables balance'
    }
  ];

  return (
    <div className="dealer-dashboard">
      {/* KPI Cards Grid */}
      <section className="kpi-grid">
        {displayKpis.map((kpi, idx) => (
          <KpiCard
            key={kpi.label || idx}
            label={kpi.label}
            value={kpi.value}
            change={kpi.change}
            changeType={kpi.changeType}
            format={kpi.format || 'currency'}
            helperText={kpi.helperText}
          />
        ))}
      </section>

      {/* 30-Day Sales Trend Line Chart */}
      <div className="dashboard-charts-grid single-chart">
        <SalesTrendChart
          data={salesTrend}
          title="Dealer Sales Performance (Last 30 Days)"
          subtitle="Daily sales orders billed by this dealership"
        />
      </div>

      {/* Stock Alerts Table (SKUs Below Minimum, Top 10) */}
      <section className="dashboard-card table-card">
        <div className="card-header">
          <div>
            <h3>Stock Alerts — SKUs Below Minimum</h3>
            <small>Priority inventory replenishment list (Top 10)</small>
          </div>
          <span className="badge-pill badge-warning">
            {stockAlerts.length} Critical Alert{stockAlerts.length === 1 ? '' : 's'}
          </span>
        </div>

        {stockAlerts.length === 0 ? (
          <DashboardEmptyState
            icon="✅"
            title="All stock levels optimal"
            description="No SKUs currently fall below the required minimum inventory thresholds."
          />
        ) : (
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>SKU Code</th>
                  <th>Product / Part Name</th>
                  <th>Category</th>
                  <th className="num-col">In Stock</th>
                  <th className="num-col">Minimum Req.</th>
                  <th className="num-col">Shortage</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {stockAlerts.map((item, idx) => {
                  const shortage = Math.max(0, item.minimum - item.available);
                  const isCritical = item.available === 0 || item.available <= item.minimum * 0.25;

                  return (
                    <tr key={item.sku || idx}>
                      <td>
                        <span className="sku-badge">{item.sku}</span>
                      </td>
                      <td>
                        <strong>{item.name}</strong>
                      </td>
                      <td>
                        <span className="category-text">{item.category || 'General Parts'}</span>
                      </td>
                      <td className="num-col">
                        <span className={isCritical ? 'stock-zero' : 'stock-low'}>
                          {item.available}
                        </span>
                      </td>
                      <td className="num-col">{item.minimum}</td>
                      <td className="num-col">
                        <span className="shortage-badge">-{shortage}</span>
                      </td>
                      <td>
                        <span
                          className={`status-pill ${
                            isCritical ? 'status-critical' : 'status-low'
                          }`}
                        >
                          {isCritical ? 'Critical' : 'Low Stock'}
                        </span>
                      </td>
                      <td>
                        <button className="table-action-btn primary" onClick={() => {}}>
                          Reorder
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

