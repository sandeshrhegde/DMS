import React from 'react';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

const numFormat = new Intl.NumberFormat('en-IN');

export function KpiCard({
  label,
  value,
  change,
  changeType,
  format = 'currency',
  helperText
}) {
  const formattedValue =
    format === 'currency'
      ? inrFormat.format(value ?? 0)
      : numFormat.format(value ?? 0);

  const isPositive = (change != null && change > 0) || changeType === 'increase';
  const isNegative = (change != null && change < 0) || changeType === 'decrease';

  return (
    <article className="kpi-card">
      <div className="kpi-card-header">
        <span className="kpi-label">{label}</span>
        {change != null && (
          <span
            className={`kpi-badge ${
              isPositive ? 'badge-up' : isNegative ? 'badge-down' : 'badge-neutral'
            }`}
          >
            {isPositive ? '↑' : isNegative ? '↓' : '•'}{' '}
            {Math.abs(change)}%
          </span>
        )}
      </div>

      <div className="kpi-value">{formattedValue}</div>

      {helperText && <div className="kpi-helper">{helperText}</div>}
    </article>
  );
}

