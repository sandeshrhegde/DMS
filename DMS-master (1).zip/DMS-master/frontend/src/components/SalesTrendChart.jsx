import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer
} from 'recharts';
import { DashboardEmptyState } from './DashboardEmptyState.jsx';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

function compactCurrency(val) {
  if (val == null) return '₹0';
  if (Math.abs(val) >= 10000000) return `₹${(val / 10000000).toFixed(1)}Cr`;
  if (Math.abs(val) >= 100000) return `₹${(val / 100000).toFixed(1)}L`;
  if (Math.abs(val) >= 1000) return `₹${(val / 1000).toFixed(0)}k`;
  return `₹${val}`;
}

export function SalesTrendChart({
  data = [],
  title = 'Sales Trend (Last 30 Days)',
  subtitle = 'Daily secondary sales performance'
}) {
  if (!data || data.length === 0) {
    return (
      <section className="dashboard-card">
        <div className="card-header">
          <div>
            <h3>{title}</h3>
            {subtitle && <small>{subtitle}</small>}
          </div>
        </div>
        <DashboardEmptyState
          title="No trend data recorded"
          description="Sales data over the past 30 days will populate here once transactions occur."
        />
      </section>
    );
  }

  return (
    <section className="dashboard-card">
      <div className="card-header">
        <div>
          <h3>{title}</h3>
          {subtitle && <small>{subtitle}</small>}
        </div>
      </div>
      <div className="chart-container">
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={data} margin={{ top: 10, right: 15, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
            <XAxis
              dataKey="date"
              tickFormatter={(date) => {
                if (!date) return '';
                const parts = date.split('-');
                return parts.length >= 3 ? `${parts[2]}/${parts[1]}` : date;
              }}
              stroke="#64748b"
              fontSize={12}
              tickLine={false}
            />
            <YAxis
              tickFormatter={compactCurrency}
              stroke="#64748b"
              fontSize={12}
              tickLine={false}
              axisLine={false}
              width={65}
            />
            <Tooltip
              formatter={(value) => [inrFormat.format(value), 'Sales']}
              labelFormatter={(label) => `Date: ${label}`}
              contentStyle={{
                backgroundColor: '#1e293b',
                color: '#f8fafc',
                borderRadius: '8px',
                border: 'none',
                boxShadow: '0 10px 25px -5px rgba(0,0,0,0.2)'
              }}
              itemStyle={{ color: '#E21E25' }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="#E21E25"
              strokeWidth={2.5}
              dot={{ r: 2.5, fill: '#E21E25' }}
              activeDot={{ r: 6, fill: '#C4181F', stroke: '#fff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}

