import React, { useEffect, useState, useCallback } from 'react';
import { isBrandRole } from '@dms/shared';
import { fetchDashboard } from '../services/api/dashboard.js';
import { BrandDashboard } from './BrandDashboard.jsx';
import { DealerDashboard } from './DealerDashboard.jsx';
import { DashboardSkeleton } from './DashboardSkeleton.jsx';
import { DashboardErrorState } from './DashboardErrorState.jsx';

export function Dashboard({ user }) {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  const isBrand = isBrandRole(user?.role);

  const loadData = useCallback(async () => {
    if (!user?.role) return;
    setLoading(true);
    setError(null);

    try {
      const responseData = await fetchDashboard(user);
      setData(responseData);
    } catch (err) {
      console.error('Failed to load dashboard:', err);
      setError(
        err.message || 'Could not load dashboard data from API. Please check server connection.'
      );
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (loading) {
    return (
      <div className="dashboard-container">
        <div className="dashboard-toolbar">
          <div className="toolbar-info">
            <span className="live-indicator pulse" />
            <span>Loading {isBrand ? 'Brand Executive' : 'Dealership Operational'} metrics…</span>
          </div>
        </div>
        <DashboardSkeleton isBrand={isBrand} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-container">
        <DashboardErrorState message={error} onRetry={loadData} />
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-toolbar">
        <div className="toolbar-info">
          <span className="live-indicator active" />
          <span>
            {isBrand ? 'Brand Executive Dashboard' : 'Dealership Operations Dashboard'}
          </span>
          <span className="role-tag">{user.role.replaceAll('_', ' ')}</span>
        </div>
        <button className="refresh-btn" onClick={loadData} title="Refresh metrics">
          ↻ Refresh
        </button>
      </div>

      {isBrand ? <BrandDashboard data={data} /> : <DealerDashboard data={data} />}
    </div>
  );
}
