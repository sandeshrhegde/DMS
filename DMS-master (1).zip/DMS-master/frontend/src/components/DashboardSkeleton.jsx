import React from 'react';

export function DashboardSkeleton({ isBrand = false }) {
  return (
    <div className="dashboard-skeleton" aria-label="Loading dashboard metrics">
      <div className="skeleton-grid-kpis">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="skeleton-card skeleton-pulse">
            <div className="skeleton-line skeleton-line-short" />
            <div className="skeleton-line skeleton-line-large" />
            <div className="skeleton-line skeleton-line-mini" />
          </div>
        ))}
      </div>

      <div className="skeleton-grid-charts">
        <div className="skeleton-card skeleton-chart skeleton-pulse">
          <div className="skeleton-line skeleton-line-medium" />
          <div className="skeleton-chart-body" />
        </div>
        <div className="skeleton-card skeleton-chart skeleton-pulse">
          <div className="skeleton-line skeleton-line-medium" />
          <div className="skeleton-chart-body" />
        </div>
      </div>

      <div className="skeleton-card skeleton-table skeleton-pulse">
        <div className="skeleton-line skeleton-line-medium" />
        <div className="skeleton-table-rows">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="skeleton-line skeleton-line-full" />
          ))}
        </div>
      </div>
    </div>
  );
}

