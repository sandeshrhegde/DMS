import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer
} from 'recharts';
import { KpiCard } from './KpiCard.jsx';
import { SalesTrendChart } from './SalesTrendChart.jsx';
import { DashboardEmptyState } from './DashboardEmptyState.jsx';

const inrFormat = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0
});

function compactCurrency(val) {
  if (val == null) return '₹0';
  if (Math.abs(val) >= 10000000) return `₹${(val / 10000000).toFixed(1)}Cr`;
  if (Math.abs(val) >= 100000) return `₹${(val / 100000).toFixed(1)}L`;
  if (Math.abs(val) >= 1000) return `₹${(val / 1000).toFixed(0)}k`;
  return `₹${val}`;
}

export function BrandDashboard({ data }) {
  if (!data) return null;

  const {
    totalSecondarySales,
    activeDealersCount,
    salesByDealer = [],
    dealersWithLowStock = [],
    pendingRetailerApprovalsCount,
    salesTrend = [],
    kpis = []
  } = data;

  // Use pre-computed kpis array or derive from explicit fields
  const displayKpis = kpis && kpis.length > 0 ? kpis : [
    {
      label: 'Secondary sales today',
      value: totalSecondarySales?.today ?? 0,
      change: totalSecondarySales?.vsLastMonthPercent,
      changeType: 'increase',
      format: 'currency',
      helperText: `+${totalSecondarySales?.vsLastMonthPercent ?? 0}% vs last month`
    },
    {
      label: 'Month-to-date sales',
      value: totalSecondarySales?.monthToDate ?? 0,
      format: 'currency'
    },
    {
      label: 'Active dealers',
      value: activeDealersCount ?? 0,
      format: 'number'
    },
    {
      label: 'Pending approvals',
      value: pendingRetailerApprovalsCount ?? 0,
      format: 'number',
      helperText: 'Awaiting retailer review'
    }
  ];

  return (
    <div className="brand-dashboard">
      {/* KPI Cards Grid */}
      <section className="kpi-grid">
        {displayKpis.map((kpi, idx) => (
          <KpiCard
            key={kpi.label || idx}
            label={kpi.label}
            value={kpi.value}
            change={kpi.change}
            changeType={kpi.changeType}
            format={kpi.format || 'currency'}
            helperText={kpi.helperText}
          />
        ))}
      </section>

      {/* Main Charts Row */}
      <div className="dashboard-charts-grid">
        {/* 30-Day Sales Trend Line Chart */}
        <SalesTrendChart
          data={salesTrend}
          title="Brand Secondary Sales Trend (30 Days)"
          subtitle="Consolidated network secondary sales"
        />

        {/* Top 10 Dealers Bar Chart */}
        <section className="dashboard-card">
          <div className="card-header">
            <div>
              <h3>Top 10 Dealers by Sales</h3>
              <small>Highest secondary sales volume</small>
            </div>
            <span className="badge-pill">{salesByDealer.length} Dealers</span>
          </div>

          {salesByDealer.length === 0 ? (
            <DashboardEmptyState
              title="No dealer sales recorded"
              description="Dealer secondary sales figures will rank here once transactions occur."
            />
          ) : (
            <div className="chart-container">
              <ResponsiveContainer width="100%" height={280}>
                <BarChart
                  data={salesByDealer}
                  margin={{ top: 10, right: 15, left: 10, bottom: 45 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis
                    dataKey="name"
                    stroke="#64748b"
                    fontSize={11}
                    tickLine={false}
                    interval={0}
                    angle={-25}
                    textAnchor="end"
                    tickFormatter={(name) => {
                      if (!name) return '';
                      return name.length > 14 ? `${name.slice(0, 14)}…` : name;
                    }}
                  />
                  <YAxis
                    tickFormatter={compactCurrency}
                    stroke="#64748b"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    width={65}
                  />
                  <Tooltip
                    formatter={(val) => [inrFormat.format(val), 'Secondary Sales']}
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      color: '#f8fafc',
                      borderRadius: '8px',
                      border: 'none',
                      boxShadow: '0 10px 25px -5px rgba(0,0,0,0.2)'
                    }}
                    itemStyle={{ color: '#E21E25' }}
                  />
                  <Bar
                    dataKey="value"
                    fill="#E21E25"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </section>
      </div>

      {/* Dealers with Low Stock Section */}
      <section className="dashboard-card table-card">
        <div className="card-header">
          <div>
            <h3>Dealers With Low Stock</h3>
            <small>Dealers requiring inventory replenishment</small>
          </div>
          <span className="badge-pill badge-warning">
            {dealersWithLowStock.length} Alert{dealersWithLowStock.length === 1 ? '' : 's'}
          </span>
        </div>

        {dealersWithLowStock.length === 0 ? (
          <DashboardEmptyState
            icon="✅"
            title="All dealers adequately stocked"
            description="No dealer currently reports inventory below the safety stock threshold."
          />
        ) : (
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Dealer Name</th>
                  <th>Low Stock SKUs</th>
                  <th>Threshold Target</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {dealersWithLowStock.map((item, idx) => (
                  <tr key={item.dealerId || idx}>
                    <td>
                      <strong>{item.dealer}</strong>
                    </td>
                    <td>
                      <span className="stock-count-alert">{item.skus} SKUs</span>
                    </td>
                    <td>{item.minimumThreshold || 10} units min</td>
                    <td>
                      <span
                        className={`status-pill status-${(item.status || 'low').toLowerCase()}`}
                      >
                        {item.status || 'Low'}
                      </span>
                    </td>
                    <td>
                      <button className="table-action-btn" onClick={() => {}}>
                        Dispatch Stock
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

