import React from 'react';

/**
 * Global & Component-level Error Boundary for DMS.
 * Catches JavaScript errors anywhere in their child component tree,
 * logs the error, and displays a graceful fallback UI instead of crashing the app.
 */
export class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
      copied: false
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    // Log to console for debugging
    console.error('[DMS ErrorBoundary caught error]:', error, errorInfo);
    if (this.props.onError) {
      try {
        this.props.onError(error, errorInfo);
      } catch (e) {
        console.error('Error in onError callback:', e);
      }
    }
  }

  componentDidUpdate(prevProps) {
    // If the resetKey changed (e.g., user navigated to a different page in the sidebar),
    // automatically reset the error state so the new page renders cleanly!
    if (this.props.resetKey !== undefined && this.props.resetKey !== prevProps.resetKey) {
      if (this.state.hasError) {
        this.handleReset();
      }
    }
  }

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
      copied: false
    });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  handleGoToDashboard = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      showDetails: false,
      copied: false
    });
    if (this.props.onNavigateToDashboard) {
      this.props.onNavigateToDashboard();
    } else if (this.props.onReset) {
      this.props.onReset();
    }
  };

  handleCopyDetails = () => {
    const details = [
      `Module: ${this.props.moduleName || 'Unknown'}`,
      `Error: ${this.state.error?.name || 'Error'}: ${this.state.error?.message || 'Unknown error'}`,
      `Time: ${new Date().toISOString()}`,
      `URL: ${window.location.href}`,
      '',
      '--- Error Stack ---',
      this.state.error?.stack || 'No error stack available',
      '',
      '--- Component Stack ---',
      this.state.errorInfo?.componentStack || 'No component stack available'
    ].join('\n');

    navigator.clipboard.writeText(details).then(() => {
      this.setState({ copied: true });
      setTimeout(() => this.setState({ copied: false }), 2500);
    }).catch(() => {});
  };

  render() {
    if (this.state.hasError) {
      if (typeof this.props.fallback === 'function') {
        return this.props.fallback({
          error: this.state.error,
          errorInfo: this.state.errorInfo,
          resetError: this.handleReset
        });
      }

      if (this.props.fallback) {
        return this.props.fallback;
      }

      const moduleName = this.props.moduleName || 'This Page';
      const errorMessage = this.state.error?.message || 'An unexpected runtime error occurred.';

      return (
        <div className="error-boundary-card" role="alert">
          <div className="error-boundary-header">
            <div className="error-boundary-icon-wrapper">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                <line x1="12" y1="9" x2="12" y2="13" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
            </div>
            <div>
              <h2 className="error-boundary-title">{moduleName} Encountered an Error</h2>
              <p className="error-boundary-subtitle">
                An unexpected issue interrupted this module. Other sections and navigation tabs remain fully accessible.
              </p>
            </div>
          </div>

          <div className="error-boundary-message-box">
            <strong>Error:</strong> {errorMessage}
          </div>

          <div className="error-boundary-actions">
            <button
              type="button"
              className="error-btn-primary"
              onClick={this.handleReset}
            >
              🔄 Try Again
            </button>

            {this.props.onNavigateToDashboard && (
              <button
                type="button"
                className="error-btn-secondary"
                onClick={this.handleGoToDashboard}
              >
                📊 Go to Dashboard
              </button>
            )}

            <button
              type="button"
              className="error-btn-outline"
              onClick={() => window.location.reload()}
            >
              Reload Browser
            </button>

            <button
              type="button"
              className="error-btn-link"
              onClick={() => this.setState((prev) => ({ showDetails: !prev.showDetails }))}
            >
              {this.state.showDetails ? 'Hide Diagnostics ▲' : 'View Diagnostics ▼'}
            </button>
          </div>

          {this.state.showDetails && (
            <div className="error-boundary-details">
              <div className="error-boundary-details-header">
                <span>Technical Stack Trace & Diagnostics</span>
                <button
                  type="button"
                  className="error-copy-btn"
                  onClick={this.handleCopyDetails}
                >
                  {this.state.copied ? '✓ Copied to Clipboard' : '📋 Copy Details'}
                </button>
              </div>

              <pre className="error-stack-code">
                <strong>Error:</strong> {this.state.error?.toString()}
                {'\n\n'}
                <strong>Stack:</strong>
                {'\n'}
                {this.state.error?.stack || 'No stack trace'}
                {'\n\n'}
                <strong>Component Stack:</strong>
                {'\n'}
                {this.state.errorInfo?.componentStack || 'No component trace'}
              </pre>
            </div>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * Higher-order component to wrap any view or page with ErrorBoundary
 */
export function withErrorBoundary(Component, errorBoundaryProps = {}) {
  const WrappedComponent = (props) => (
    <ErrorBoundary {...errorBoundaryProps}>
      <Component {...props} />
    </ErrorBoundary>
  );
  WrappedComponent.displayName = `withErrorBoundary(${Component.displayName || Component.name || 'Component'})`;
  return WrappedComponent;
}

