import React from 'react';

export function DashboardEmptyState({
  title = 'No data available',
  description = 'There are no records to display at this moment.',
  icon = '📊'
}) {
  return (
    <div className="dashboard-empty-state">
      <div className="empty-icon">{icon}</div>
      <h4>{title}</h4>
      <p>{description}</p>
    </div>
  );
}

