import React from 'react';

export function DashboardErrorState({ message, onRetry }) {
  return (
    <div className="dashboard-error-state" role="alert">
      <div className="error-icon">⚠️</div>
      <h3>Failed to load dashboard data</h3>
      <p>{message || 'An error occurred while fetching dashboard metrics from the API.'}</p>
      {onRetry && (
        <button className="retry-btn" onClick={onRetry}>
          Try Again
        </button>
      )}
    </div>
  );
}

