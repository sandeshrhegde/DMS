import React, { useState } from 'react';

export function CsvImportModal({
  title = 'Import via CSV',
  sampleDownloadUrl,
  onFetchSample,
  onImport,
  onClose,
  onSuccess
}) {
  const [file, setFile] = useState(null);
  const [csvText, setCsvText] = useState('');
  const [mode, setMode] = useState('skip-bad-rows');
  const [loading, setLoading] = useState(false);
  const [sampleLoading, setSampleLoading] = useState(false);
  const [error, setError] = useState(null);
  const [report, setReport] = useState(null);

  const handleFileChange = (e) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setError(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      setCsvText(event.target?.result || '');
    };
    reader.readAsText(selected);
  };

  const handleLoadSample = async () => {
    if (!onFetchSample) return;
    setSampleLoading(true);
    setError(null);
    try {
      const sample = await onFetchSample();
      setCsvText(sample);
      setFile({ name: 'sample_data.csv' });
    } catch (err) {
      setError('Failed to load sample data: ' + err.message);
    } finally {
      setSampleLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!csvText.trim()) {
      return setError('Please choose a CSV file or load sample data.');
    }

    setLoading(true);
    setError(null);
    setReport(null);

    try {
      const result = await onImport({ csvText, mode });
      setReport(result);
      if (onSuccess && (result.createdCount > 0 || result.updatedCount > 0)) {
        onSuccess(result);
      }
    } catch (err) {
      // In all-or-nothing mode, API returns 422 with rejected report
      if (err.rejected || err.message) {
        setError(err.message || 'Import failed with errors.');
        if (err.rejected) {
          setReport(err);
        }
      } else {
        setError(err.toString());
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h2>{title}</h2>
            <small>Upload and validate batch data with instant error reporting</small>
          </div>
          <button className="close-btn" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        {!report ? (
          <form onSubmit={handleSubmit} className="modal-body">
            <div className="sample-actions-bar">
              <span className="sample-label">Need a template?</span>
              <div className="btn-group">
                {onFetchSample && (
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={handleLoadSample}
                    disabled={sampleLoading || loading}
                  >
                    {sampleLoading ? 'Loading…' : '📄 Preload Sample CSV'}
                  </button>
                )}
                {sampleDownloadUrl && (
                  <a
                    href={sampleDownloadUrl}
                    download
                    className="btn btn-outline btn-sm"
                  >
                    ⬇ Download Template
                  </a>
                )}
              </div>
            </div>

            <div className="file-dropzone">
              <input
                type="file"
                id="csvFileInput"
                accept=".csv"
                onChange={handleFileChange}
                style={{ display: 'none' }}
              />
              <label htmlFor="csvFileInput" className="dropzone-label">
                <div className="upload-icon">📁</div>
                <div>
                  <strong>{file ? file.name : 'Choose a CSV file to upload'}</strong>
                  <p>Click to browse local files (.csv format)</p>
                </div>
              </label>
              {csvText && (
                <div className="file-status-indicator">
                  ✓ Ready to upload ({csvText.split('\n').filter(Boolean).length - 1} rows detected)
                </div>
              )}
            </div>

            <div className="mode-selector">
              <span className="mode-label">Validation & Import Mode:</span>
              <div className="radio-options">
                <label className={`radio-card ${mode === 'skip-bad-rows' ? 'active' : ''}`}>
                  <input
                    type="radio"
                    name="mode"
                    value="skip-bad-rows"
                    checked={mode === 'skip-bad-rows'}
                    onChange={() => setMode('skip-bad-rows')}
                  />
                  <div>
                    <strong>Skip bad rows (Recommended)</strong>
                    <p>Imports all valid rows and displays an error report for rejected rows.</p>
                  </div>
                </label>

                <label className={`radio-card ${mode === 'all-or-nothing' ? 'active' : ''}`}>
                  <input
                    type="radio"
                    name="mode"
                    value="all-or-nothing"
                    checked={mode === 'all-or-nothing'}
                    onChange={() => setMode('all-or-nothing')}
                  />
                  <div>
                    <strong>All-or-nothing (Strict)</strong>
                    <p>Rolls back the entire file if any row has validation errors.</p>
                  </div>
                </label>
              </div>
            </div>

            {error && <div className="error-alert">{error}</div>}

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={onClose}
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={loading || !csvText}
              >
                {loading ? 'Processing & Validating…' : 'Start Import'}
              </button>
            </div>
          </form>
        ) : (
          <div className="modal-body report-body">
            <div className={`report-summary-banner ${report.rejectedCount > 0 ? 'has-errors' : 'success'}`}>
              <div className="banner-icon">
                {report.rejectedCount === 0 ? '✅' : report.success === false ? '⛔' : '⚠️'}
              </div>
              <div>
                <h3>{report.message || 'Import Processing Complete'}</h3>
                <p>
                  {report.mode === 'all-or-nothing' && report.rejectedCount > 0
                    ? 'All database writes were rolled back because validation failed in all-or-nothing mode.'
                    : `Processed ${report.totalRows} row(s) against master validation rules.`}
                </p>
              </div>
            </div>

            <div className="report-metric-chips">
              <div className="chip chip-total">
                <span className="chip-label">Total Rows</span>
                <span className="chip-val">{report.totalRows}</span>
              </div>
              <div className="chip chip-created">
                <span className="chip-label">Created</span>
                <span className="chip-val">{report.createdCount}</span>
              </div>
              <div className="chip chip-updated">
                <span className="chip-label">Updated</span>
                <span className="chip-val">{report.updatedCount}</span>
              </div>
              <div className={`chip chip-rejected ${report.rejectedCount > 0 ? 'alert' : ''}`}>
                <span className="chip-label">Rejected</span>
                <span className="chip-val">{report.rejectedCount}</span>
              </div>
            </div>

            {report.rejected && report.rejected.length > 0 && (
              <div className="rejected-table-wrapper">
                <h4>Validation Error Report ({report.rejected.length} Rejected Rows)</h4>
                <p className="rejected-sub">Fix the errors below in your CSV and re-upload:</p>

                <div className="table-responsive">
                  <table className="rejected-table">
                    <thead>
                      <tr>
                        <th>Row #</th>
                        <th>Identifier / Code</th>
                        <th>Name</th>
                        <th>Rejection Reasons</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report.rejected.map((item, idx) => (
                        <tr key={idx}>
                          <td><strong>{item.rowNumber}</strong></td>
                          <td><code>{item.code || '—'}</code></td>
                          <td>{item.name || '—'}</td>
                          <td>
                            <ul className="reasons-list">
                              {item.reasons.map((r, rIdx) => (
                                <li key={rIdx}>{r}</li>
                              ))}
                            </ul>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => {
                  setReport(null);
                  setError(null);
                }}
              >
                Upload Another File
              </button>
              <button type="button" className="btn btn-primary" onClick={onClose}>
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

