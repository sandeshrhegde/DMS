import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';

// Global error handlers for uncaught promises and runtime exceptions
window.addEventListener('unhandledrejection', (event) => {
  console.error('[Global Unhandled Promise Rejection]:', event.reason);
});

window.addEventListener('error', (event) => {
  console.error('[Global Uncaught Window Error]:', event.error || event.message);
});

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
