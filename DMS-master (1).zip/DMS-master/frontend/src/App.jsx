import React, { useState } from 'react';
import './styles.css';
import { Dashboard } from './components/Dashboard.jsx';
import { GeographyPage } from './pages/GeographyPage.jsx';
import { HsnPage } from './pages/HsnPage.jsx';
import { SkusPage } from './pages/SkusPage.jsx';
import { DealersPage } from './pages/DealersPage.jsx';
import { RetailersPage } from './pages/RetailersPage.jsx';
import { PricingPage } from './pages/PricingPage.jsx';
import { InventoryPage } from './pages/InventoryPage.jsx';
import NewInventoryPage from './pages/NewInventoryPage.jsx';
import { OrdersPage } from './pages/OrdersPage.jsx';
import { BillingPage } from './pages/BillingPage.jsx';
import { CollectionsPage } from './pages/CollectionsPage.jsx';
import { NotesPage } from './pages/NotesPage.jsx';
import { ErrorBoundary } from './components/ErrorBoundary.jsx';
import { DASHBOARD_ROLES } from '@dms/shared';

const accounts = [
  { email: 'brand@dms.local', role: DASHBOARD_ROLES.BRAND_ADMIN, name: 'Brand Administrator (Maker)', org: 'Brand National HQ' },
  { email: 'brand2@dms.local', role: DASHBOARD_ROLES.BRAND_ADMIN, name: 'Brand Approver (Checker)', org: 'Brand National HQ' },
  { email: 'owner@demo.local', role: DASHBOARD_ROLES.DEALER_OWNER, name: 'Demo Motors Owner', org: 'Demo Motors Mumbai', dealerId: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1' },
  { email: 'operator@demo.local', role: DASHBOARD_ROLES.DEALER_OPERATOR, name: 'Demo Motors Operator', org: 'Demo Motors Mumbai', dealerId: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1' },
  { email: 'salesman@demo.local', role: DASHBOARD_ROLES.SALESMAN, name: 'Demo Motors Salesman', org: 'Demo Motors Mumbai', dealerId: 'a3b1e293-128c-4ba4-b3de-f2dce93461b1' }
];

const allowedNav = {
  BRAND_ADMIN: ['Dashboard', 'Primary Dispatch', 'New Inventory', 'Pricing Master', 'Retailers', 'Dealers', 'Geography', 'HSN Master', 'SKU Master', 'Orders', 'Billing', 'Collections', 'Credit & Debit Notes'],
  DEALER_OWNER: ['Dashboard', 'Inventory', 'New Inventory', 'Retailers', 'SKU Catalog', 'Orders', 'Billing', 'Collections', 'Credit & Debit Notes'],
  DEALER_OPERATOR: ['Dashboard', 'Inventory', 'New Inventory', 'Retailers', 'SKU Catalog', 'Orders', 'Billing', 'Collections', 'Credit & Debit Notes'],
  SALESMAN: ['Dashboard', 'Inventory', 'New Inventory', 'Retailers', 'SKU Catalog', 'Orders']
};

function Login({ onLogin }) {
  const [email, setEmail] = useState('brand@dms.local');
  const [password, setPassword] = useState('Demo@123');
  const [error, setError] = useState('');

  const selectedAccount = accounts.find((item) => item.email === email);

  const handleRoleChange = (e) => {
    const selectedEmail = e.target.value;
    const found = accounts.find((item) => item.email === selectedEmail);
    if (found) {
      setEmail(found.email);
      setPassword('Demo@123');
      setError('');
    }
  };

  const submit = (e) => {
    e.preventDefault();
    const found = accounts.find((item) => item.email === email);
    if (!found || password !== 'Demo@123') {
      return setError('Use a demo email and password: Demo@123');
    }
    onLogin({
      email: found.email,
      role: found.role,
      name: found.name,
      org: found.org,
      dealerId: found.dealerId || null
    });
  };

  return (
    <main className="login">
      <section className="card login-card">
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <img
            src="/siyarams-logo.webp"
            alt="Siyaram's"
            style={{ height: '52px', objectFit: 'contain', margin: '0 auto', display: 'block' }}
          />
          <div style={{ fontSize: '11px', fontWeight: 800, letterSpacing: '2px', color: '#E21E25', marginTop: '8px', textTransform: 'uppercase' }}>
            DEALER MANAGEMENT SYSTEM
          </div>
          <div style={{ fontSize: '13px', fontStyle: 'italic', fontFamily: "'Playfair Display', serif", color: '#78716c', marginTop: '2px' }}>
            Come home to Siyaram's
          </div>
        </div>

        <h1 style={{ fontFamily: "'Playfair Display', serif", textAlign: 'center', marginTop: '0' }}>Welcome back</h1>
        <p style={{ textAlign: 'center', marginBottom: '20px' }}>Sign in to your brand or dealership workspace.</p>

        <form onSubmit={submit}>
          <label>
            Select Role
            <select
              value={selectedAccount ? selectedAccount.email : ''}
              onChange={handleRoleChange}
              id="login-role-select"
            >
              {!selectedAccount && <option value="">-- Custom Email / Role --</option>}
              {accounts.map((acc) => (
                <option key={acc.email} value={acc.email}>
                  {acc.role.replace('_', ' ')} — {acc.name}
                </option>
              ))}
            </select>
          </label>

          {selectedAccount && (
            <div style={{ marginTop: '6px', fontSize: '11.5px', color: '#78716c', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ color: '#E21E25', fontWeight: 700 }}>Scope:</span>
              <span>{selectedAccount.org} ({selectedAccount.role})</span>
            </div>
          )}

          <label>
            Email
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="user@example.com"
              required
            />
          </label>

          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </label>

          {error && <div className="error">{error}</div>}

          <button type="submit">Sign in to DMS</button>
        </form>

        <div style={{ marginTop: '20px', borderTop: '1px solid #f1f5f9', paddingTop: '16px' }}>
          <small style={{ fontWeight: 600, color: '#475569', display: 'block', marginBottom: '8px' }}>
            Quick demo sign-in (Password: <b>Demo@123</b>):
          </small>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
            {accounts.map((acc) => (
              <button
                key={acc.email}
                type="button"
                onClick={() => {
                  setEmail(acc.email);
                  setPassword('Demo@123');
                  setError('');
                }}
                style={{
                  border: '1px solid #cbd5e1',
                  background: email === acc.email ? '#fef2f2' : '#ffffff',
                  borderColor: email === acc.email ? '#E21E25' : '#cbd5e1',
                  color: email === acc.email ? '#b91c1c' : '#334155',
                  padding: '4px 8px',
                  borderRadius: '6px',
                  fontSize: '11px',
                  cursor: 'pointer',
                  fontWeight: 500
                }}
              >
                {acc.role.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function Shell({ user, logout }) {
  const [page, setPage] = useState('Dashboard');
  const isBrand = user.role === DASHBOARD_ROLES.BRAND_ADMIN;
  const navItems = allowedNav[user.role] || ['Dashboard'];

  const renderContent = () => {
    switch (page) {
      case 'Dashboard':
        return <Dashboard user={user} />;
      case 'Primary Dispatch':
      case 'Dispatches & Claims':
      case 'Inventory':
        return <InventoryPage user={user} />;
      case 'New Inventory':
        return <NewInventoryPage user={user} />;
      case 'Pricing Master':
      case 'Pricing':
        return <PricingPage user={user} />;
      case 'Retailers':
      case 'Retailer Approvals':
        return <RetailersPage user={user} />;
      case 'Dealers':
        return <DealersPage user={user} />;
      case 'Geography':
        return <GeographyPage user={user} />;
      case 'HSN Master':
        return <HsnPage user={user} />;
      case 'SKU Master':
      case 'SKU Catalog':
      case 'SKUs':
        return <SkusPage user={user} />;
      case 'Orders':
      case 'Secondary Orders':
        return <OrdersPage user={user} />;
      case 'Billing':
      case 'Invoicing':
      case 'Tax Invoices':
        return <BillingPage user={user} />;
      case 'Collections':
      case 'Payments':
      case 'Outstanding':
      case 'Ledger':
        return <CollectionsPage user={user} />;
      case 'Credit & Debit Notes':
      case 'Notes':
      case 'Returns':
      case 'Returns & Notes':
        return <NotesPage user={user} />;
      default:
        return (
          <div className="notice">
            <strong>{page}</strong> module is scheduled for implementation in a future sprint.
          </div>
        );
    }
  };

  return (
    <div className="shell">
      <aside>
        <div className="logo-container">
          <div className="logo-brand">
            <img src="/siyarams-logo.webp" alt="Siyaram's" className="brand-logo-img" />
            <span className="brand-badge-dms">DMS</span>
          </div>
          <div className="brand-tagline">Come home to Siyaram's</div>
        </div>
        <div className="dealer">
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ color: '#E21E25', fontSize: '13px' }}>♦</span>
            <span>{user.org || (isBrand ? 'Siyaram Silk Mills HQ' : 'Demo Motors')}</span>
          </div>
          <small>{user.role.replaceAll('_', ' ')}</small>
        </div>
        <nav>
          {navItems.map((item) => (
            <button
              className={page === item ? 'active' : ''}
              onClick={() => setPage(item)}
              key={item}
            >
              {item}
            </button>
          ))}
        </nav>
      </aside>

      <section className="content">
        <header>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <img src="/siyarams-logo.webp" alt="Siyaram's" className="brand-logo-light" />
            <div style={{ height: '24px', width: '1px', background: '#e7e5e4' }} />
            <div>
              <b style={{ fontFamily: "'Playfair Display', serif", fontSize: '18px', color: '#1c1917' }}>{page}</b>
              <small>{isBrand ? 'Siyaram Silk Mills • Central Brand Console' : 'Authorized Dealership Workspace'}</small>
            </div>
          </div>
          <div className="profile">
            <span>
              {user.name}
              <small>{user.role.replaceAll('_', ' ')}</small>
            </span>
            <button onClick={logout}>Logout</button>
          </div>
        </header>

        <main className="workspace">
          <span className="eyebrow">
            {isBrand ? 'SIYARAM SILK MILLS • BRAND EXECUTIVE CONSOLE' : 'SIYARAM • DEALERSHIP OPERATIONS'}
          </span>
          <h1 style={{ fontFamily: "'Playfair Display', serif" }}>{page}</h1>

          <ErrorBoundary
            key={page}
            resetKey={page}
            moduleName={page}
            onNavigateToDashboard={() => setPage('Dashboard')}
          >
            {renderContent()}
          </ErrorBoundary>
        </main>
      </section>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(sessionStorage.getItem('dms-user') || 'null');
    } catch {
      return null;
    }
  });

  const login = (u) => {
    sessionStorage.setItem('dms-user', JSON.stringify(u));
    setUser(u);
  };

  const logout = () => {
    sessionStorage.removeItem('dms-user');
    setUser(null);
  };

  return (
    <ErrorBoundary moduleName="DMS Portal Shell">
      {user ? <Shell user={user} logout={logout} /> : <Login onLogin={login} />}
    </ErrorBoundary>
  );
}
